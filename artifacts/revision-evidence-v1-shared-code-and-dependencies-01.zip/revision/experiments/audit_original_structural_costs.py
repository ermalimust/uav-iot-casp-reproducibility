"""Read-only audit of new profiles of the submitted structural calibrator.

No simulator, model client, network, configuration, or scenario generator is
imported or executed. Original pure functions are extracted from their ASTs;
the original calibrator is replayed only against saved metric fixtures. This
checks the measured execution prefix and accounting, not physical reliability.
Audit output must stay outside the measurement directory.
"""
from __future__ import annotations

import argparse
import ast
import copy
import csv
import hashlib
import json
import math
import os
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from typing import Any


WORKSPACE = Path(__file__).resolve().parents[2]
LEGACY = WORKSPACE / 'revision/experiments/legacy'
FROZEN = (WORKSPACE / 'ZQL_UAV_submission_260708/02_復現_GitHub公開包'
          / '02_EVIDENCE_AND_EXPERIMENTS/02_EVIDENCE_AND_EXPERIMENTS'
          / 'results_frozen_mixed_structural_100seed_20260617')
VERSION = 'independent-original-structural-cost-audit-1'
SCENARIOS = ('S1_seen_burst_east', 'S2_seen_degrade_west',
             'S3_seen_moved_burst', 'S4_heldout_misleading')
METHODS = ('compact', 'compact_plus_expert', 'compact_plus_cached_model')
CLUSTERS = ('west_cluster', 'east_hotspot', 'north_cluster')
MODES = ('route_dwell', 'protocol_trigger', 'full_casp')
BASE = ('B1_max_backlog_route', 'B2_max_blackout_protocol', 'B3_scripted_east_full')
POLICY_FIELDS = ('controller', 'route', 'protocol_mode', 'local_triggers',
                 'min_protocol_hold_slots')


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8-sig'))


def canonical(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: canonical(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [canonical(item) for item in value]
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError('Non-finite policy value')
        return int(value) if value.is_integer() else value
    return value


def policy_hash(policy: dict) -> str:
    semantic = {key: copy.deepcopy(policy.get(key)) for key in POLICY_FIELDS}
    semantic['controller'] = semantic['controller'] or 'route'
    semantic['min_protocol_hold_slots'] = semantic['min_protocol_hold_slots'] or 0
    semantic['local_triggers'] = semantic['local_triggers'] or []
    if isinstance(semantic['local_triggers'], dict):
        semantic['local_triggers'] = [semantic['local_triggers']]
    payload = json.dumps(canonical(semantic), sort_keys=True,
                         separators=(',', ':'), allow_nan=False)
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()


def rank(metrics: dict) -> tuple:
    if type(metrics.get('passed_contract')) is not bool:
        raise ValueError('Original passed_contract must be boolean')
    values = [metrics.get(key) for key in ('qsr', 'recovery_time', 'max_blackout')]
    if any(isinstance(value, bool) or not isinstance(value, (int, float))
           or not math.isfinite(value) for value in values):
        raise ValueError('Original ranking metrics must be finite numbers')
    qsr, recovery, blackout = values
    if not 0 <= qsr <= 1 or recovery < 0 or blackout < 0:
        raise ValueError('Original ranking metric outside its domain')
    return (int(metrics['passed_contract']), qsr, -recovery, -blackout)


class Checks:
    """Retain all independently observed failures, rather than stop at the first."""
    def __init__(self):
        self.assertions = 0
        self.errors: list[dict] = []
    def check(self, condition: bool, message: str, **context):
        self.assertions += 1
        if not condition:
            self.errors.append({'message': message, **context})
        return bool(condition)
    def attempt(self, label: str, function):
        try:
            return function()
        except Exception as error:
            self.errors.append({'message': label, 'exception_type': type(error).__name__,
                                'detail': str(error)[:400]})
            return None


class OriginalOracle:
    """Independent extraction; no importing the runner or its candidate helper."""
    def __init__(self, directory: Path = LEGACY):
        namespace = {'Any': Any, 'json': json, 'CLUSTER_IDS': list(CLUSTERS),
                     'os': SimpleNamespace(environ={})}
        requested = {
            'run_uav_iot_workflow_experiment.py': {'cluster_centroid', 'route_policy'},
            'contingency_suite.py': {'_trigger', '_nominal'},
            'mixed_structural_suite.py': {'_target_from_backlog', '_target_from_blackout',
                'scripted_structure', '_route_templates', 'calibrate_structure',
                'promotion_key', 'promote_candidate_results'},
            'run_mixed_structural_llm.py': {'_rounded_evidence'},
            'llm_repair_agent.py': {'extract_json'},
        }
        self.source_hashes = {}
        for filename, names in requested.items():
            path = directory / filename
            self.source_hashes[str(path.resolve())] = sha(path)
            tree = ast.parse(path.read_text(encoding='utf-8-sig'), filename=str(path))
            selected, found = [], set()
            for node in tree.body:
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and target.id in {'CLUSTERS', 'SYSTEM', 'REPAIR_MODES'}:
                            namespace[target.id] = ast.literal_eval(node.value)
                if isinstance(node, ast.FunctionDef) and node.name in names:
                    selected.append(node)
                    found.add(node.name)
            if found != names:
                raise ValueError(f'Missing original pure functions in {filename}: {names - found}')
            exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), 'exec'), namespace)
        if tuple(x['id'] for x in namespace['CLUSTERS']) != CLUSTERS:
            raise ValueError('Original cluster order changed')
        self.ns = namespace

    def grid(self, target: str, mode: str) -> list[dict]:
        policies = []
        def fixture(_scenario, policy):
            policies.append(copy.deepcopy(policy))
            return {'metrics': {'passed_contract': False, 'qsr': 0.0,
                                'recovery_time': 159, 'max_blackout': 100}}
        self.ns['simulate_cset'] = fixture
        self.ns['calibrate_structure']({}, target, mode)
        return policies

    def replay_saved(self, target: str, mode: str, evaluations: list[dict]) -> dict:
        """Run original selection logic against its recorded results, never a simulator."""
        position = 0
        def fixture(_scenario, policy):
            nonlocal position
            if position >= len(evaluations):
                raise ValueError('Saved prefix stops before the original calibrator would stop')
            evaluation = evaluations[position]
            if policy_hash(policy) != evaluation['policy_hash']:
                raise ValueError(f'Original policy differs at prefix entry {position}')
            position += 1
            return {'metrics': copy.deepcopy(evaluation['metrics'])}
        self.ns['simulate_cset'] = fixture
        selected = self.ns['calibrate_structure']({}, target, mode)
        if position != len(evaluations):
            raise ValueError('Saved prefix continued after original first pass')
        return selected

    def structures(self, evidence: dict) -> tuple[list[tuple[str, str]], tuple[str, str]]:
        clean = {cluster: {key: evidence[cluster][key] for key in
                 ('peak_backlog', 'peak_blackout', 'peak_link_stress')} for cluster in CLUSTERS}
        for values in clean.values():
            if any(isinstance(x, bool) or not isinstance(x, (int, float))
                   or not math.isfinite(x) or x < 0 for x in values.values()):
                raise ValueError('Invalid observable evidence')
        compact = [(self.ns['_target_from_backlog'](clean), 'route_dwell'),
                   (self.ns['_target_from_blackout'](clean), 'protocol_trigger'),
                   ('east_hotspot', 'full_casp')]
        return compact, self.ns['scripted_structure'](clean)

    def prompt(self, evidence: dict) -> tuple[str, str]:
        clean = {cluster: evidence[cluster] for cluster in CLUSTERS}
        user = ('Per-cluster evidence from the nominal failed run:\n'
                + json.dumps(self.ns['_rounded_evidence'](clean), indent=2)
                + '\n\nReturn the target cluster and repair mode JSON.')
        return self.ns['SYSTEM'], user

    def promote(self, selected: list[tuple[str, dict]], method: str) -> dict:
        """Original portfolio rank/tie logic using saved selected results only."""
        return self.ns['promote_candidate_results'](selected, method)


def frozen_records(directory: Path = FROZEN) -> tuple[dict, dict, dict]:
    csv_path, cache_path = directory / 'mixed_structural_llm_per_seed.csv', directory / 'mixed_structural_llm_cache.jsonl'
    rows, records = {}, {}
    with csv_path.open(encoding='utf-8-sig', newline='') as handle:
        for row in csv.DictReader(handle):
            key = row['scenario'], int(row['seed']), row['method']
            if key in rows:
                raise ValueError(f'Duplicate historical row: {key}')
            if row['passed_contract'] not in {'True', 'False'}:
                raise ValueError('Historical pass must be True or False')
            rows[key] = row
    for line_number, line in enumerate(cache_path.read_text(encoding='utf-8-sig').splitlines(), 1):
        record = json.loads(line)
        if not isinstance(record, dict) or not isinstance(record.get('key'), str):
            raise ValueError('Historical response cache contains a malformed record')
        records[record['key']] = (line_number, record)
    sources = {str(csv_path.resolve()): sha(csv_path), str(cache_path.resolve()): sha(cache_path)}
    return rows, records, sources


def original_model_link(oracle: OriginalOracle, evidence: dict, row: dict, cache: dict) -> dict:
    """Last exact original prompt key, provider/model, parser and rounded evidence."""
    system, user = oracle.prompt(evidence)
    provider, model = row['provider'], row['model']
    full_hash = hashlib.sha256(f'{provider}\x00{model}\x00{system}\x00{user}'.encode('utf-8')).hexdigest()
    key = full_hash[:32]
    if key not in cache:
        raise ValueError('No original response matches the reconstructed nominal evidence prompt')
    line_number, record = cache[key]
    if record.get('provider') != provider or record.get('model') != model:
        raise ValueError('Matched cache backend identity differs')
    if record.get('mode') not in {'live', 'replay'} or provider.lower().startswith(('offline', 'synthetic')):
        raise ValueError('Matched cache is not a recorded model response')
    action = oracle.ns['extract_json'](record['text']) or {}
    target, mode = action.get('target_cluster'), action.get('repair_mode')
    parsed = target in CLUSTERS and mode in MODES
    if target not in CLUSTERS:
        target = max(evidence, key=lambda cluster: evidence[cluster]['peak_backlog'])
    if mode not in MODES:
        mode = 'route_dwell'
    if (target, mode) != (row['selected_target'], row['selected_mode']):
        raise ValueError('Original parser selection does not match the frozen model row')
    if str(parsed) != row['parsed_ok']:
        raise ValueError('Original parser status differs from frozen model row')
    if json.loads(row['evidence_json']) != oracle.ns['_rounded_evidence'](evidence):
        raise ValueError('Reconstructed diagnosis evidence differs from frozen rounded evidence')
    return {'cache_key': key, 'prompt_sha256': full_hash, 'cache_line': line_number,
            'target_cluster': target, 'repair_mode': mode, 'parsed_ok': parsed,
            'provider': provider, 'model': model, 'record_mode': record['mode'],
            'usage': record.get('usage', {})}


def historical_pass(rows: dict, scenario: str, seed: int, source: str) -> bool:
    return rows[scenario, seed, source]['passed_contract'] == 'True'


def finite_seconds(value: Any) -> bool:
    return (not isinstance(value, bool) and isinstance(value, (int, float))
            and math.isfinite(value) and value >= 0)


def outside_output(run_root: Path, output: Path) -> Path:
    output = output.resolve()
    if output == run_root or run_root in output.parents:
        raise ValueError('Audit output must be outside the measurement directory')
    return output


def audit_group(checks: Checks, oracle: OriginalOracle, group: dict,
                target: str, mode: str, context: dict) -> dict:
    """Audit a normalized successful group against the independent original AST.

Normalized fields: source, evaluations [{policy_hash, metrics, elapsed_seconds}],
best_policy_hash, best_metrics, raw_grid_entries, candidate_evaluations,
elapsed_seconds, simulator_seconds. The runner adapter supplies these fields.
"""
    grid = oracle.grid(target, mode)
    evaluations = group['evaluations']
    checks.check(isinstance(evaluations, list) and bool(evaluations),
                 'A completed structural slot has no evaluated candidates', **context)
    checks.check(group['raw_grid_entries'] == len(grid), 'Raw numerical grid size differs', **context)
    checks.check(group['candidate_evaluations'] == len(evaluations), 'Group candidate count differs from ledger', **context)
    checks.check(len(evaluations) <= len(grid), 'Evaluations exceed original numerical grid', **context)
    for index, evaluation in enumerate(evaluations):
        item_context = {**context, 'parameter_index': index}
        if index < len(grid):
            checks.check(evaluation['policy_hash'] == policy_hash(grid[index]),
                         'Original raw candidate prefix/hash differs', **item_context)
        checks.check(finite_seconds(evaluation['elapsed_seconds']),
                     'Invalid actual candidate simulation duration', **item_context)
        checks.check(evaluation.get('raw_index') == index,
                     'Raw candidate index skipped, reordered or repeated', **item_context)
        checks.check(evaluation.get('status') == 'complete',
                     'Successful group contains an incomplete simulator attempt', **item_context)
        if 'policy' in evaluation:
            computed_hash = checks.attempt('Recorded candidate policy is malformed',
                                          lambda x=evaluation: policy_hash(x['policy']))
            checks.check(computed_hash == evaluation['policy_hash'],
                         'Recorded policy payload and hash disagree', **item_context)
        else:
            checks.check(False, 'Actual candidate policy payload is missing', **item_context)
        checks.attempt('Candidate ranking metrics invalid', lambda x=evaluation: rank(x['metrics']))
    expected = checks.attempt('Original AST calibrator rejects saved prefix',
                             lambda: oracle.replay_saved(target, mode, evaluations))
    if expected is not None:
        checks.check(group['best_policy_hash'] == policy_hash(expected['policy']),
                     'Selected best policy differs from original first-pass/tie behavior', **context)
        checks.check(group['best_metrics'] == expected['metrics'],
                     'Selected best metrics differ from original ranking', **context)
    elapsed, simulated = group['elapsed_seconds'], group['simulator_seconds']
    checks.check(finite_seconds(elapsed) and finite_seconds(simulated), 'Invalid group durations', **context)
    total = sum(x['elapsed_seconds'] for x in evaluations
                if finite_seconds(x.get('elapsed_seconds')))
    if finite_seconds(simulated):
        checks.check(math.isclose(simulated, total, abs_tol=1e-7, rel_tol=1e-8),
                     'Group nested simulation time differs from candidate sum', **context)
    if finite_seconds(elapsed) and finite_seconds(simulated):
        checks.check(simulated <= elapsed + 1e-7,
                     'Nested simulation time exceeds calibration time', **context)
    return {'source': group['source'], 'grid_entries': len(grid),
            'evaluations': len(evaluations), 'selected': expected,
            'raw_duplicate_evaluations': len(evaluations) - len({x['policy_hash'] for x in evaluations})}


def audit_timing(checks: Checks, timing: dict, context: dict) -> None:
    """Internal normalized phase schema: exclusive phases plus a nested component."""
    phases = ('diagnosis_seconds', 'selector_seconds', 'calibration_seconds', 'promotion_seconds')
    for name in (*phases, 'method_seconds', 'worker_seconds', 'preparation_seconds',
                 'nominal_simulator_seconds', 'candidate_simulator_seconds'):
        checks.check(name in timing and finite_seconds(timing.get(name)),
                     'Missing/non-finite timing field', field=name, **context)
    if not all(finite_seconds(timing.get(name)) for name in (*phases, 'method_seconds')):
        return
    exclusive_total = sum(timing[name] for name in phases)
    checks.check(exclusive_total <= timing['method_seconds'] + 1e-6,
                 'Exclusive phases exceed method total; possible double-counting', **context)
    if finite_seconds(timing.get('nominal_simulator_seconds')):
        checks.check(timing['nominal_simulator_seconds'] <= timing['diagnosis_seconds'] + 1e-6,
                     'Nominal replay exceeds diagnosis duration', **context)
    if finite_seconds(timing.get('candidate_simulator_seconds')):
        checks.check(timing['candidate_simulator_seconds'] <= timing['calibration_seconds'] + 1e-6,
                     'Nested candidate replay exceeds calibration duration', **context)
    if all(finite_seconds(timing.get(name)) for name in ('worker_seconds', 'preparation_seconds')):
        checks.check(timing['preparation_seconds'] + timing['method_seconds'] <= timing['worker_seconds'] + 1e-5,
                     'Worker lifetime omits preparation or method interval', **context)


def original_portfolio_pass(rows: dict, scenario: str, seed: int, method: str) -> bool:
    """Use complete frozen contract flags, never rounded metric thresholds."""
    sources = list(BASE)
    if method == 'compact_plus_expert':
        sources.append('SR_scripted_mixed_reference')
    elif method == 'compact_plus_cached_model':
        sources.append('llm_only_structure')
    elif method != 'compact':
        raise ValueError(f'Unknown profiling method: {method}')
    return any(historical_pass(rows, scenario, seed, source) for source in sources)


def integer(value: Any, *, minimum: int = 0) -> bool:
    return type(value) is int and value >= minimum


def valid_hash(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(x in '0123456789abcdef' for x in value)


def audit_model_link(checks: Checks, actual: dict, expected: dict, context: dict) -> None:
    checks.check(actual.get('status') == 'hit', 'Cached proposal is not a valid exact hit', **context)
    for name in ('cache_key', 'cache_line', 'prompt_sha256', 'provider', 'model', 'record_mode', 'usage'):
        checks.check(actual.get(name) == expected[name], 'Frozen response binding differs', field=name, **context)
    for actual_name, expected_name in (('target', 'target_cluster'), ('mode', 'repair_mode'),
                                       ('target_cluster', 'target_cluster'), ('repair_mode', 'repair_mode')):
        checks.check(actual.get(actual_name) == expected[expected_name],
                     'Cached target/mode differs from original parser', field=actual_name, **context)
    checks.check(actual.get('token_usage') == expected['usage'], 'Token usage is not the matched frozen record', **context)
    checks.check(actual.get('new_model_calls') == 0, 'A cached proposal records a new model call', **context)
    checks.check(actual.get('inference_mode') == 'historical_cache_replay',
                 'Cached lookup is misidentified as inference', **context)


def audit_memory(checks: Checks, memory: dict, context: dict) -> None:
    peak, baseline, current = (memory.get(name) for name in
                              ('peak_working_set_bytes', 'baseline_working_set_bytes', 'current_working_set_bytes'))
    checks.check(integer(peak, minimum=1), 'Missing/non-positive process lifetime peak memory', **context)
    checks.check(integer(baseline, minimum=1), 'Missing/non-positive loaded-input memory baseline', **context)
    if integer(peak, minimum=1) and integer(baseline, minimum=1):
        checks.check(peak >= baseline, 'Lifetime peak is lower than its loaded-input baseline', **context)
    checks.check(integer(current, minimum=1), 'Missing/non-positive current worker memory', **context)
    if integer(peak, minimum=1) and integer(current, minimum=1):
        checks.check(peak >= current, 'Lifetime peak is lower than its current working set', **context)
    checks.check(memory.get('measurement') == 'Windows GetProcessMemoryInfo lifetime PeakWorkingSetSize',
                 'Memory measurement is not the agreed Windows lifetime working set', **context)
    checks.check(memory.get('scope') == 'absolute worker lifetime peak through validation, before artifact encoding',
                 'Memory snapshot boundary is missing or misidentified', **context)
    # A peak-minus-baseline estimate is deliberately neither computed nor audited
    # as algorithm-only allocation: two snapshots cannot establish that quantity.


def audit_cell(checks: Checks, oracle: OriginalOracle, rows: dict, cache: dict,
               cell: dict, identity: tuple[str, int, str]) -> dict | None:
    scenario, seed, method = identity
    context = {'scenario': scenario, 'seed': seed, 'method': method}
    for name, value in context.items():
        checks.check(cell.get(name) == value, 'Cell identity differs from its expected filename/task', field=name, **context)
    checks.check(cell.get('model_requests') == 0, 'Cell records new model requests', **context)
    checks.check('online_model_request_seconds' in cell and cell['online_model_request_seconds'] is None,
                 'Unmeasured online model request latency must remain null', **context)
    checks.check(cell.get('full_search') is False, 'Cell did not explicitly use original first-pass mode', **context)
    checks.check(cell.get('simulation_cache') is False, 'Cell did not explicitly disable simulation caching', **context)
    checks.check(valid_hash(cell.get('scenario_sha256')), 'Cell lacks a valid recorded scenario identity', **context)
    worker = cell.get('worker', {})
    checks.check(worker.get('start_method') == 'spawn', 'Cell lacks an independent interpreter spawn record', **context)
    checks.check(integer(worker.get('pid'), minimum=1) and integer(worker.get('parent_pid'), minimum=1)
                 and worker.get('pid') != worker.get('parent_pid'), 'Worker/parent process identity invalid', **context)
    checks.check(worker.get('spawn_id') == f'{scenario}__{seed}__{method}',
                 'Worker spawn record does not bind this unique cell', **context)
    if cell.get('status') != 'complete':
        checks.check(False, 'Cell did not complete; no missing work is treated as passing',
                     status=cell.get('status'), error_type=cell.get('error_type'), detail=cell.get('error'), **context)
        attempts = [item for group in cell.get('groups', []) for item in group.get('evaluations', [])]
        checks.check(cell.get('actual_simulator_calls', 0) >= len(attempts),
                     'Failed cell simulator attempts are not charged', **context)
        return None

    evidence = cell['evidence']
    checks.check(tuple(evidence) == CLUSTERS, 'Observable evidence changed original cluster order', **context)
    compact, expert = oracle.structures(evidence)
    checks.check(cell['evidence_rounded'] == oracle.ns['_rounded_evidence'](evidence),
                 'Rounded evidence is not the original prompt transformation', **context)
    expected_link = original_model_link(oracle, evidence, rows[scenario, seed, 'llm_only_structure'], cache)
    audit_model_link(checks, cell['model_link'], expected_link, context)
    expected_structures = [(source, target, mode) for source, (target, mode) in zip(BASE, compact)]
    if method == 'compact_plus_expert':
        expected_structures.append(('SR_scripted_mixed_reference', *expert))
    elif method == 'compact_plus_cached_model':
        expected_structures.append(('llm_only_structure', expected_link['target_cluster'], expected_link['repair_mode']))
    groups = cell['groups']
    checks.check(len(groups) == len(expected_structures), 'Portfolio has missing/extra structural slots', **context)
    selected, summaries = [], []
    for index, (source, target, mode) in enumerate(expected_structures):
        if index >= len(groups):
            continue
        group, group_context = groups[index], {**context, 'source': source, 'structure_index': index}
        for field, value in (('source', source), ('target', target), ('mode', mode), ('structure_index', index)):
            checks.check(group.get(field) == value, 'Structure mapping/order differs from original public evidence rule',
                         field=field, **group_context)
        result = checks.attempt('Structural group audit failed',
            lambda g=group, t=target, m=mode, ctx=group_context: audit_group(checks, oracle, g, t, m, ctx))
        if result is not None:
            summaries.append(result)
            if result['selected'] is not None:
                selected.append((source, result['selected']))
        expected_pass = historical_pass(rows, scenario, seed, source)
        actual_pass = group.get('best_metrics', {}).get('passed_contract')
        matches = type(actual_pass) is bool and actual_pass == expected_pass
        checks.check(matches, 'Structural contract pass differs from frozen historical flag',
                     expected_pass=expected_pass, actual_pass=actual_pass, **group_context)
        checks.check(cell.get('historical_pass_matches', {}).get(source) is matches,
                     'Runner historical-pass comparison is incorrect', **group_context)

    promotion = cell['promotion']
    if len(selected) == len(expected_structures):
        expected = oracle.promote(selected, method)
        for field, value in (('winner', expected['portfolio_winner']), ('policy_hash', policy_hash(expected['policy'])),
                             ('metrics', expected['metrics']), ('target', expected['selected_target']),
                             ('mode', expected['selected_mode'])):
            checks.check(promotion.get(field) == value, 'Portfolio differs from original four-metric/first-tie selection',
                         field=field, **context)
    expected_pass = original_portfolio_pass(rows, scenario, seed, method)
    checks.check(promotion.get('metrics', {}).get('passed_contract') is expected_pass,
                 'Portfolio contract pass differs from the frozen complete-flag OR comparison',
                 expected_pass=expected_pass, actual_pass=promotion.get('metrics', {}).get('passed_contract'), **context)
    checks.check(cell.get('historical_compact_pass') is historical_pass(rows, scenario, seed, 'rule_only_portfolio'),
                 'Recorded historical compact pass is incorrect', **context)
    checks.check(cell.get('historical_model_portfolio_pass') is historical_pass(rows, scenario, seed, 'hybrid_portfolio'),
                 'Recorded historical model-portfolio pass is incorrect', **context)
    counts, timing = cell['counts'], cell['timing']
    candidate_count = sum(len(group.get('evaluations', [])) for group in groups)
    for field, value in (('nominal_evaluations', 1), ('candidate_evaluations', candidate_count),
                         ('actual_simulator_calls', candidate_count + 1), ('simulation_cache_hits', 0)):
        checks.check(type(counts.get(field)) is int and counts[field] == value,
                     'Physical simulator accounting differs from the raw attempt ledger', field=field, **context)
    nominal = cell['nominal']
    checks.check(nominal.get('policy_hash') == policy_hash(oracle.ns['_nominal']()),
                 'Diagnostic replay did not use the original nominal policy', **context)
    checks.attempt('Nominal contract metrics invalid', lambda: rank(nominal['metrics']))
    checks.check(nominal.get('elapsed_seconds') == timing.get('nominal_simulator_seconds'),
                 'Nominal nested simulation duration differs from its ledger', **context)
    audit_timing(checks, timing, context)
    group_seconds = [g.get('elapsed_seconds') for g in groups]
    candidate_seconds = [item.get('elapsed_seconds') for g in groups for item in g.get('evaluations', [])]
    if all(finite_seconds(x) for x in (*group_seconds, timing.get('calibration_seconds'))):
        checks.check(sum(group_seconds) <= timing['calibration_seconds'] + 1e-6,
                     'Group intervals exceed calibration interval', **context)
    if all(finite_seconds(x) for x in (*candidate_seconds, timing.get('candidate_simulator_seconds'))):
        checks.check(math.isclose(sum(candidate_seconds), timing['candidate_simulator_seconds'],
                                  abs_tol=1e-7, rel_tol=1e-8),
                     'Nested candidate duration differs from all raw simulator attempts', **context)
    audit_memory(checks, cell['memory'], context)
    return {**context, 'passed_contract': promotion['metrics']['passed_contract'],
            'winner': promotion['winner'], 'candidate_evaluations': candidate_count,
            'actual_simulator_calls': candidate_count + 1,
            'raw_duplicate_evaluations': sum(g['raw_duplicate_evaluations'] for g in summaries),
            'model_cache_key': expected_link['cache_key'], 'scenario_sha256': cell['scenario_sha256'],
            'evidence': evidence, 'timing': timing, 'memory': cell['memory'], 'worker': worker}


def source_path(value: str) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (WORKSPACE / path).resolve()


def audit_runner_source(checks: Checks, path: Path) -> dict:
    """Static inspect the bound instrumentation; never import or execute it.

    Timing inequalities alone cannot establish boundaries. These checks bind
    them to the visible direct original-function calls and sequential process
    invocation, while the human-readable scope describes the actual snapshots.
    """
    tree = ast.parse(path.read_text(encoding='utf-8-sig'))
    calls = Counter(ast.unparse(node.func) for node in ast.walk(tree) if isinstance(node, ast.Call))
    attrs = {ast.unparse(node) for node in ast.walk(tree) if isinstance(node, ast.Attribute)}
    for call in ('suite.evidence_from_nominal', 'suite.calibrate_structure',
                 'suite.promote_candidate_results', 'subprocess.run', 'original_simulator'):
        checks.check(calls[call] == 1, 'Bound runner does not contain the agreed direct original-function call', call=call)
    checks.check('suite.run_method' not in calls and not any('_CAL_CACHE' in x for x in attrs),
                 'Bound runner invokes cached structural run_method or _CAL_CACHE')
    source = ast.unparse(tree)
    checks.check("suite.os = SimpleNamespace(environ={'UAV_MIXED_FULL_SEARCH': ''})" in source,
                 'Bound original calibration search mode is not explicitly the default false setting')
    checks.check('actual_calls += 1' in source and 'suite.simulate_cset = measured_simulator' in source,
                 'Bound runner does not visibly charge and wrap every original simulator call')
    forbidden = ('requests', 'httpx', 'openai', 'urllib', 'socket', 'llm_repair_agent')
    imports = {node.name.split('.')[0] for stmt in ast.walk(tree) if isinstance(stmt, ast.Import) for node in stmt.names}
    imports |= {stmt.module.split('.')[0] for stmt in ast.walk(tree)
                if isinstance(stmt, ast.ImportFrom) and stmt.module}
    checks.check(not imports.intersection(forbidden), 'Runner imports a live-client/network module', imports=sorted(imports.intersection(forbidden)))
    return {'sha256': sha(path), 'checked': 'static direct calls, cache bypass, explicit search-mode binding, simulator wrapper and sequential subprocess.run',
            'limitations': 'Source and saved accounting inspected; no process tracing or real simulator re-execution by this auditor.'}


def measurement_snapshot(run_root: Path) -> dict[str, str]:
    return {str(path.relative_to(run_root)): sha(path) for path in sorted(run_root.rglob('*')) if path.is_file()}


def audit_run(run_root: Path, mode: str = 'auto') -> dict:
    """Audit finished smoke/full output, retaining every observed failure."""
    run_root = run_root.resolve()
    checks = Checks()
    snapshot_before = measurement_snapshot(run_root)
    oracle = checks.attempt('Original pure AST definitions could not be loaded', OriginalOracle)
    frozen = checks.attempt('Frozen historical source records could not be read', frozen_records)
    manifest = checks.attempt('Measurement manifest is missing/unreadable', lambda: read_json(run_root / 'manifest.json'))
    completion = checks.attempt('Measurement completion is missing/unreadable', lambda: read_json(run_root / 'completion.json'))
    cell_summaries, binding_summaries, static_review = [], [], None
    audit_input_hashes = {str(Path(__file__).resolve()): sha(Path(__file__))}
    declared_mode = mode
    expected_identities = []
    if oracle is not None and frozen is not None:
        rows, cache, hashes = frozen
        audit_input_hashes.update(oracle.source_hashes)
        audit_input_hashes.update(hashes)
        model_rows = [(identity, row) for identity, row in rows.items() if identity[2] == 'llm_only_structure']
        checks.check(len(model_rows) == 400, 'Frozen source does not contain all original 400 model selections')
        for (scenario, seed, _), row in model_rows:
            expected = checks.attempt(f'Frozen prompt identity audit failed for {scenario} seed {seed}',
                lambda r=row: original_model_link(oracle, json.loads(r['evidence_json']), r, cache))
            if expected is not None:
                binding_summaries.append({'scenario': scenario, 'seed': seed, **expected})
        checks.check(len({x['cache_key'] for x in binding_summaries}) == 400,
                     'All original 400 model selections do not bind unique final prompt records')
        checks.check(all(x['parsed_ok'] for x in binding_summaries),
                     'Original model selections contain parser fallbacks')
        # Verify that the original pure/physical source is the submitted version,
        # separately from trusting the new run's own manifest.
        submitted_source = FROZEN.parent / 'experiments/uav_iot_workflow'
        for current, value in oracle.source_hashes.items():
            original = submitted_source / Path(current).name
            result = checks.attempt('Submitted original source is unreadable', lambda p=original: sha(p))
            checks.check(result == value, 'Legacy source differs from the submitted package', source=current)
            if result is not None:
                audit_input_hashes[str(original.resolve())] = result
        sums_path = FROZEN / 'SHA256SUMS.txt'
        recorded_sums = checks.attempt('Original frozen SHA256SUMS is unreadable', lambda: sums_path.read_text(encoding='utf-8-sig'))
        if recorded_sums is not None:
            audit_input_hashes[str(sums_path.resolve())] = sha(sums_path)
            for path, value in hashes.items():
                lines = [line.split() for line in recorded_sums.splitlines() if Path(path).name in line]
                checks.check(any(parts[0].lower() == value and
                                 Path(parts[-1].lstrip('*').replace('\\', '/')).name == Path(path).name
                                 for parts in lines),
                             'Frozen data does not match submitted SHA256SUMS', source=path)

    if isinstance(manifest, dict):
        checks.check(manifest.get('full_search') is False, 'Manifest must specify original first-pass search')
        checks.check(manifest.get('simulation_cache') is False, 'Manifest must specify no simulation-result caching')
        checks.check(manifest.get('model_requests') == 0, 'Manifest must record zero new model requests')
        checks.check('online_model_request_seconds' in manifest and manifest['online_model_request_seconds'] is None,
                     'Manifest must leave online model latency unmeasured/null')
        checks.check(manifest.get('methods') == list(METHODS), 'Manifest methods/order differ from the three fixed portfolios')
        tasks = manifest.get('tasks', [])
        task_keys = checks.attempt('Manifest tasks malformed', lambda: [(x['scenario'], x['seed']) for x in tasks]) or []
        full = [(scenario, seed) for scenario in SCENARIOS for seed in range(1, 101)]
        smoke = [(scenario, seed) for scenario in SCENARIOS for seed in range(1, 4)]
        if mode == 'auto':
            declared_mode = 'full' if task_keys == full else 'smoke' if task_keys == smoke else 'unrecognized'
        checks.check(declared_mode in {'full', 'smoke'}, 'Run task set is neither the fixed full nor smoke protocol')
        expected_tasks = full if declared_mode == 'full' else smoke
        checks.check(task_keys == expected_tasks, 'Task order/instances differ from the declared fixed protocol', mode=declared_mode)
        checks.check(len(task_keys) == len(set(task_keys)), 'Manifest has duplicate scenario/seed tasks')
        expected_identities = [(scenario, seed, method) for scenario, seed in task_keys for method in METHODS]
        checks.check(manifest.get('expected_cells') == len(expected_identities), 'Manifest expected cell count differs')
        checks.check(manifest.get('method_order') == 'rotate by zero-based task index', 'Manifest method order does not record protocol rotation')
        machine = manifest.get('machine', {})
        for field in ('os', 'python', 'processor', 'executable'):
            checks.check(isinstance(machine.get(field), str) and bool(machine[field]), 'Machine description missing', field=field)
        checks.check(integer(machine.get('logical_processors'), minimum=1), 'Machine logical processor count invalid')
        checks.check(integer(machine.get('physical_memory_bytes'), minimum=1), 'Machine physical-memory description missing')
        checks.check(machine.get('measurement_workers') == 1, 'Measurement does not declare one sequential worker')
        bound = manifest.get('source_hashes', {})
        checks.check(isinstance(bound, dict) and bool(bound), 'Manifest source hash map missing')
        bound_by_path = {}
        if isinstance(bound, dict):
            for path, value in bound.items():
                resolved = source_path(path)
                actual = checks.attempt('Bound source/input is unreadable', lambda p=resolved: sha(p))
                checks.check(actual == value and valid_hash(value), 'Bound source/input has changed since measurement', source=str(resolved))
                bound_by_path[str(resolved)] = value
                if actual is not None:
                    audit_input_hashes[str(resolved)] = actual
            for path, value in (oracle.source_hashes.items() if oracle is not None else ()):
                checks.check(bound_by_path.get(path) == value, 'Original AST source is not bound by the manifest', source=path)
            for path, value in (hashes.items() if frozen is not None else ()):
                checks.check(bound_by_path.get(path) == value, 'Frozen response/data source is not bound by the manifest', source=path)
            runner_path = WORKSPACE / 'revision/experiments/measure_original_structural_costs.py'
            helper_path = WORKSPACE / 'revision/experiments/candidate_search.py'
            protocol_path = WORKSPACE / 'revision/Original_Structural_Cost_Protocol_20261008.md'
            for path in (runner_path, helper_path, protocol_path):
                checks.check(str(path.resolve()) in bound_by_path, 'Required runner/helper/protocol not bound', source=str(path))
            checks.check(manifest.get('protocol_sha256') == bound_by_path.get(str(protocol_path.resolve())),
                         'Explicit protocol hash differs from bound protocol source')
            static_review = checks.attempt('Runner static instrumentation audit failed', lambda: audit_runner_source(checks, runner_path))

    if isinstance(completion, dict):
        checks.check(completion.get('status') == 'complete', 'Measurement has not completed successfully', status=completion.get('status'), detail=completion.get('error'))
        checks.check(completion.get('model_requests') == 0, 'Completion records new model requests')
        checks.check(completion.get('completed_cells') == len(expected_identities), 'Completion count is not the expected task count')
        checks.check(completion.get('expected_cells') == len(expected_identities), 'Completion expected count differs')
        checks.check(isinstance(manifest, dict) and completion.get('source_hashes_after') == manifest.get('source_hashes'),
                     'Bound source/input hashes differ before and after the measurement')

    cells_dir = run_root / 'cells'
    existing_cells = sorted(cells_dir.glob('*.json'))
    expected_names = {f'{scenario}__{seed:03d}__{method}.json' for scenario, seed, method in expected_identities}
    checks.check({x.name for x in existing_cells} == expected_names,
                 'Saved cells contain missing/unplanned/duplicate-task files',
                 missing=sorted(expected_names - {x.name for x in existing_cells}),
                 unexpected=sorted({x.name for x in existing_cells} - expected_names))
    raw_completed_hashes = completion.get('cell_hashes', {}) if isinstance(completion, dict) else {}
    completed_hashes = {name.replace('\\', '/'): value for name, value in raw_completed_hashes.items()}
    checks.check(len(completed_hashes) == len(raw_completed_hashes), 'Completion cell path normalization has colliding entries')
    checks.check(set(completed_hashes) == {f'cells/{name}' for name in expected_names}, 'Completion cell hash ledger is incomplete or has extra entries')
    by_instance = {}
    for identity in expected_identities:
        scenario, seed, method = identity
        name = f'{scenario}__{seed:03d}__{method}.json'
        path = cells_dir / name
        cell = checks.attempt(f'Method cell unreadable: {name}', lambda p=path: read_json(p))
        if cell is None:
            continue
        checks.check(completed_hashes.get(f'cells/{name}') == sha(path), 'Final cell payload/hash differs from completion ledger', cell=name)
        if oracle is None or frozen is None:
            continue
        summary = checks.attempt(f'Method cell audit failed: {name}', lambda c=cell, ident=identity: audit_cell(checks, oracle, rows, cache, c, ident))
        if summary is not None:
            cell_summaries.append(summary)
            by_instance.setdefault((scenario, seed), []).append(summary)
    for (scenario, seed), cells in by_instance.items():
        checks.check(len(cells) == 3, 'Instance does not have three successfully audited cells', scenario=scenario, seed=seed)
        checks.check(len({x['scenario_sha256'] for x in cells}) == 1, 'Fresh cells used inconsistent recorded scenario identities', scenario=scenario, seed=seed)
        checks.check(len({json.dumps(x['evidence'], sort_keys=True, allow_nan=False) for x in cells}) == 1,
                     'Fresh nominal evidence differs between methods', scenario=scenario, seed=seed)
        checks.check(len({x['model_cache_key'] for x in cells}) == 1, 'Cached model identity differs between methods', scenario=scenario, seed=seed)
    spawn_ids = [x['worker'].get('spawn_id') for x in cell_summaries]
    checks.check(len(spawn_ids) == len(set(spawn_ids)), 'One spawn record reused for multiple cells')
    # PIDs are intentionally not required globally unique; the OS may reuse a
    # PID after a prior independent process exits.
    checks.check(len({x['worker'].get('parent_pid') for x in cell_summaries}) <= 1,
                 'Worker spawn records identify inconsistent measurement parents')

    aggregated = []
    for scenario in SCENARIOS:
        for method in METHODS:
            selected = [x for x in cell_summaries if x['scenario'] == scenario and x['method'] == method]
            historical = ([original_portfolio_pass(rows, scenario, x['seed'], method) for x in selected]
                          if frozen is not None else [])
            aggregated.append({'scenario': scenario, 'method': method, 'cells': len(selected),
                               'passed': sum(x['passed_contract'] for x in selected),
                               'frozen_expected_passed': sum(historical),
                               'candidate_evaluations': sum(x['candidate_evaluations'] for x in selected),
                               'actual_simulator_calls': sum(x['actual_simulator_calls'] for x in selected),
                               'raw_duplicate_evaluations': sum(x['raw_duplicate_evaluations'] for x in selected)})
    for path, value in audit_input_hashes.items():
        after = checks.attempt('Audit input unavailable at final hash check', lambda p=Path(path): sha(p))
        checks.check(after == value, 'Input/source changed while audit was reading', source=path)
    snapshot_after = measurement_snapshot(run_root)
    checks.check(snapshot_after == snapshot_before, 'Measurement directory changed while being audited')
    result = {'version': VERSION, 'status': 'PASS_INDEPENDENT_ACCOUNTING_AUDIT' if not checks.errors else 'FAIL_INDEPENDENT_ACCOUNTING_AUDIT',
              'created_utc': datetime.now(timezone.utc).isoformat(), 'root': str(run_root), 'mode': declared_mode,
              'assertions': checks.assertions, 'errors': checks.errors,
              'expected_cells': len(expected_identities), 'audited_completed_cells': len(cell_summaries),
              'original_cache_bindings': len(binding_summaries), 'original_cache_unique_keys': len({x['cache_key'] for x in binding_summaries}),
              'summary': aggregated, 'runner_static_inspection': static_review,
              'input_hashes_before_after': audit_input_hashes, 'measurement_hashes_before_after': snapshot_before,
              'measurement_directory_unchanged': snapshot_before == snapshot_after,
              'new_model_requests_by_auditor': 0, 'simulator_calls_by_auditor': 0,
              'scope': ['Original AST numerical candidate order, raw duplicates, first-pass/failed-grid exhaustion, four-dimensional ranking and exact ties.',
                        'Public evidence to compact/expert/model structure mapping and all 400 original final prompt/cache identities.',
                        'Saved candidate payload/hash/metrics, portfolio selection, complete historical contract flags and physical-call accounting including nominal replay.',
                        'Bound source/input hashes before/after, recorded independent worker spawns (OS PID reuse allowed), local timing inequalities and lifetime Windows peak-memory snapshots.'],
              'limitations': ['No real simulator or model request was executed by this auditor; saved metrics are treated as recorded observations.',
                              'This is supplemental profiling of fixed historical instances with simulation caching disabled and full_search=False, not new held-out effectiveness confirmation or historical execution timing.',
                              'Candidate nested simulator durations include policy copy/hash/record instrumentation; calibration includes these durations and recording overhead. Nested durations must not be added again to method totals.',
                              'Actual online model request latency remains null; cache lookup/decode time cannot substitute for HTTP/model inference latency.',
                              'Method time excludes process/input setup, validation and artifact encoding. Parent worker duration includes interpreter start through exit; preparation starts inside the worker function.',
                              'Absolute worker lifetime peak is sampled through post-method validation before artifact encoding. Baseline/peak/current snapshots do not establish exact algorithm-only incremental memory.',
                              'Timing phase start/end stamps are not retained; inequalities plus inspection of bound runner timing code establish accounting consistency, not independent OS trace verification.',
                              'Scenario SHA256 is compared across the three workers and bound original generator code; this read-only audit does not regenerate physical scenarios or certify physical/energy reliability.',
                              'Exact historical rounded-metric winner equality is not asserted; the new recorded prefix and promotion are checked with original full-precision saved metrics.']}
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, type=Path, help='Finished measurement directory; only read')
    parser.add_argument('--mode', choices=('auto', 'smoke', 'full'), default='auto')
    parser.add_argument('--output', type=Path, help='Independent JSON result outside the measurement directory')
    args = parser.parse_args()
    run_root = args.root.resolve()
    suffix = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    output = args.output or run_root.parent / f'{run_root.name}_independent_audit_{suffix}.json'
    try:
        output = outside_output(run_root, output)
        if output.exists():
            raise ValueError('Existing audit artifacts are never overwritten; select a fresh --output')
        result = audit_run(run_root, args.mode)
    except Exception as error:
        parser.exit(2, f'AUDIT_INPUT_ERROR: {type(error).__name__}: {error}\n')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    print('AUDIT_FILE:', output)
    print('AUDIT_STATUS:', result['status'], 'assertions=', result['assertions'], 'errors=', len(result['errors']))
    if result['errors']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
