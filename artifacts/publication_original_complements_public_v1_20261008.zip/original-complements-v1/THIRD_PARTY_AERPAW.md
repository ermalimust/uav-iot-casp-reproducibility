# Third-party AERPAW AADM subset

Dataset: UAV-based wireless multi-modal measurements from AERPAW autonomous
data mule (AADM) challenge in digital twin and real-world environments.
DOI: https://doi.org/10.5061/dryad.7d7wm3898
Official dataset: https://datadryad.org/dataset/doi%3A10.5061/dryad.7d7wm3898
Dryad mission and CC0 policy: https://datadryad.org/mission

Dryad makes its published research data available under CC0. This attribution
applies to the third-party dataset subset, not a new license for the authors'
simulator/extraction/analysis code. The official dataset page and Dryad
mission/CC0 policy were checked on 2026-10-08. Preserve the dataset DOI,
these official source references and the original dataset README.

This companion carries the original, unchanged selected subset: 33 per-flight
LORAlog.csv files and vehicleOut_snr.csv / vehicleOut_download.csv from
USRP/Post-processing/other plots. Exact paths, sizes and hashes are listed in
MANIFEST.json. All_Logs.csv is deliberately excluded so it cannot double-count
the same per-flight observations. No temporary signed URL, credential or
7.70 GB outer AADM archive is included or needed for offline extraction.

The dataset describes digital-twin development and real-world outdoor AERPAW
missions, including 33 finalist-team testbed flights (11 teams x 3 flights) and
500-second data-mule missions. This subset is the paper's previously used link
variability anchor. It is not newly collected hardware validation of CASP,
calibration of its contract thresholds, or a new full protocol/flight stack.
Keep these provenance and scope limits with any redistributed subset.
