#!/usr/bin/env python3
"""Role-boundary analysis for the mixed structural LLM experiment.

This script reads ``mixed_structural_llm_per_seed.csv`` and reports the
mechanism evidence behind the manuscript-safe LLM claim:

* parity or near-parity where compact rules already cover the structure;
* held-out gain when compact rules under-cover the observed cue combination;
* whether the hybrid portfolio's additional accepted seeds actually come from
  the LLM-generated structural candidate.

It intentionally does not import the simulator, so it can run on frozen result
folders without optional plotting dependencies.
"""
from __future__ import annotations

import argparse
import csv
import math
import random
from collections import Counter
from pathlib import Path


CLUSTER_IDS = ["west_cluster", "east_hotspot", "north_cluster"]
STYPES = [
    "S1_seen_burst_east",
    "S2_seen_degrade_west",
    "S3_seen_moved_burst",
    "S4_heldout_misleading",
]
HELD_OUT = "S4_heldout_misleading"


def truth_for(stype: str, seed: int) -> tuple[str, str]:
    """Mirror mixed_structural_suite._case without importing the simulator."""
    rng = random.Random(seed * 173 + 41)
    if stype == "S1_seen_burst_east":
        return "east_hotspot", "full_casp"
    if stype == "S2_seen_degrade_west":
        return "west_cluster", "protocol_trigger"
    if stype == "S3_seen_moved_burst":
        return rng.choice(["west_cluster", "north_cluster"]), "full_casp"
    if stype == "S4_heldout_misleading":
        hot = rng.choice(CLUSTER_IDS)
        return hot, "full_casp"
    raise ValueError(stype)


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return float("nan"), float("nan")
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


def mcnemar_exact(b: int, c: int) -> float:
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    return min(1.0, 2 * sum(math.comb(n, i) for i in range(k + 1)) * (0.5**n))


def load_rows(path: Path) -> list[dict]:
    rows = list(csv.DictReader(path.open(encoding="utf-8")))
    for row in rows:
        row["seed"] = int(row["seed"])
        row["pass"] = str(row["passed_contract"]).strip().lower() == "true"
    return rows


def print_rate(label: str, rows: list[dict], method: str) -> None:
    sub = [r for r in rows if r["method"] == method]
    k = sum(1 for r in sub if r["pass"])
    n = len(sub)
    lo, hi = wilson(k, n)
    print(f"{label:14s} {method:28s} {k:3d}/{n:<3d} {k/n:5.3f} [{lo:.3f},{hi:.3f}]")


def matched(rows: list[dict], method_a: str, method_b: str) -> tuple[int, int, float]:
    left = {r["seed"]: r["pass"] for r in rows if r["method"] == method_a}
    right = {r["seed"]: r["pass"] for r in rows if r["method"] == method_b}
    keys = sorted(set(left) & set(right))
    b_only = sum(1 for key in keys if (not left[key]) and right[key])
    a_only = sum(1 for key in keys if left[key] and (not right[key]))
    return b_only, a_only, mcnemar_exact(b_only, a_only)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "csv_path",
        nargs="?",
        default="results/mixed_structural_llm_per_seed.csv",
        help="Path to mixed_structural_llm_per_seed.csv",
    )
    args = parser.parse_args()
    rows = load_rows(Path(args.csv_path))

    print("PASS RATES")
    for label, keep in [
        ("seen", lambda r: r["scenario"] != HELD_OUT),
        ("heldout", lambda r: r["scenario"] == HELD_OUT),
    ]:
        sub = [r for r in rows if keep(r)]
        for method in [
            "rule_only_portfolio",
            "llm_only_structure",
            "hybrid_portfolio",
            "SR_scripted_mixed_reference",
        ]:
            print_rate(label, sub, method)

    print("\nMATCHED HELD-OUT TESTS")
    held = [r for r in rows if r["scenario"] == HELD_OUT]
    for alt in [
        "rule_only_portfolio",
        "llm_only_structure",
        "SR_scripted_mixed_reference",
    ]:
        b, c, p = matched(held, alt, "hybrid_portfolio")
        print(f"hybrid vs {alt:28s} discordant(b={b},c={c}) p={p:.4g}")

    print("\nLLM STRUCTURE ACCURACY")
    for label, keep in [
        ("seen", lambda r: r["scenario"] != HELD_OUT),
        ("heldout", lambda r: r["scenario"] == HELD_OUT),
    ]:
        sub = [r for r in rows if keep(r) and r["method"] == "llm_only_structure"]
        target = mode = both = 0
        selected_modes = Counter()
        for row in sub:
            true_target, true_mode = truth_for(row["scenario"], row["seed"])
            target += row["selected_target"] == true_target
            mode += row["selected_mode"] == true_mode
            both += row["selected_target"] == true_target and row["selected_mode"] == true_mode
            selected_modes[row["selected_mode"]] += 1
        n = len(sub)
        for name, k in [("target", target), ("mode", mode), ("both", both)]:
            lo, hi = wilson(k, n)
            print(f"{label:14s} {name:8s} {k:3d}/{n:<3d} {k/n:5.3f} [{lo:.3f},{hi:.3f}]")
        print(f"{label:14s} selected_modes {dict(selected_modes)}")

    print("\nHYBRID PROMOTION SOURCE")
    for stype in STYPES:
        sub = [r for r in rows if r["scenario"] == stype and r["method"] == "hybrid_portfolio"]
        chosen = Counter(r["portfolio_winner"] or "(none)" for r in sub)
        passed = Counter()
        for row in sub:
            if row["pass"]:
                passed[row["portfolio_winner"] or "(none)"] += 1
        print(stype)
        for winner, count in chosen.most_common():
            print(f"  {winner:28s} {count:3d} chosen, {passed[winner]:3d} pass")

    rule = {r["seed"]: r["pass"] for r in held if r["method"] == "rule_only_portfolio"}
    llm = {r["seed"]: r for r in held if r["method"] == "llm_only_structure"}
    hybrid = {r["seed"]: r for r in held if r["method"] == "hybrid_portfolio"}
    added = [seed for seed, row in hybrid.items() if row["pass"] and not rule[seed]]
    added_from_llm = [seed for seed in added if hybrid[seed]["portfolio_winner"] == "llm_only_structure"]

    print("\nHELD-OUT LLM-ADDED SEEDS")
    print(f"hybrid passes when rule_only fails: {len(added)} seeds")
    print(f"of those, hybrid winner is LLM candidate: {len(added_from_llm)} seeds")
    print(f"llm_only itself passes among added seeds: {sum(llm[s]['pass'] for s in added)} seeds")
    print(f"first 15 added seeds: {added[:15]}")


if __name__ == "__main__":
    main()
