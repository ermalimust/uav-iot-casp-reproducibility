#!/usr/bin/env python3
"""Live LLM runner for the mixed structural-repair suite.

The model sees only per-cluster evidence from the failed nominal run. It selects
one target cluster and one repair mode. The executable repair and thresholds are
then produced by bounded calibration in mixed_structural_suite.py.
"""
from __future__ import annotations

import csv
import json
import os
import statistics
import time
from pathlib import Path
from typing import Any

from llm_repair_agent import extract_json, make_client
from mixed_structural_suite import (
    DET_METHODS,
    HELD_OUT,
    REPAIR_MODES,
    SIMPLE_RULE_METHODS,
    STYPES,
    calibrate_structure,
    evidence_from_nominal,
    make_scenario_mixed,
    promote_candidate_results,
    run_method,
)
from run_uav_iot_workflow_experiment import CLUSTERS


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
ALLOWED_CLUSTERS = [c["id"] for c in CLUSTERS]

SYSTEM = """\
You are a UAV-IoT structural repair selector. A single UAV served three IoT
device clusters. A failed nominal run produced per-cluster evidence, but the
injected failure labels are hidden.

Choose exactly one target cluster and one repair mode.

Allowed cluster ids: west_cluster, east_hotspot, north_cluster.
Allowed repair modes:
- route_dwell: emphasize route revisits and dwell for a congested target.
- protocol_trigger: emphasize degraded-aware protocol switching and a local fallback trigger.
- full_casp: combine target revisits, degraded-aware protocol switching, and a local trigger.

Return one JSON object only:
{"target_cluster": "<allowed cluster id>", "repair_mode": "<allowed repair mode>", "rationale": "<brief evidence-based reason>"}
"""


def _preflight_keys() -> None:
    provider = os.environ.get("UAV_LLM_PROVIDER", "auto").lower()
    has_openai = bool(os.environ.get("OPENAI_API_KEY"))
    has_anthropic = bool(os.environ.get("ANTHROPIC_API_KEY"))
    if provider == "openai" and not has_openai:
        raise SystemExit("OPENAI_API_KEY is not set.")
    if provider == "anthropic" and not has_anthropic:
        raise SystemExit("ANTHROPIC_API_KEY is not set.")
    if provider in {"auto", ""} and not (has_openai or has_anthropic):
        raise SystemExit(
            "No API key detected. Set OPENAI_API_KEY or ANTHROPIC_API_KEY; "
            "this script does not use the synthetic offline fallback."
        )
    os.environ.setdefault("UAV_LLM_CACHE", str(RESULTS / "mixed_structural_llm_cache.jsonl"))


def _preflight_capacity(seeds: list[int]) -> None:
    probe = seeds[: min(5, len(seeds))]
    if not probe:
        return
    hits = []
    for seed in probe:
        scenario = make_scenario_mixed(seed, HELD_OUT)
        ref = run_method("SR_scripted_mixed_reference", scenario)
        hits.append(bool(ref["metrics"]["passed_contract"]))
    rate = statistics.mean(1.0 if x else 0.0 for x in hits)
    if rate < 0.6:
        raise SystemExit(
            "Preflight stopped the LLM run: the scripted mixed reference passes "
            f"{sum(1 for x in hits if x)}/{len(hits)} held-out smoke seeds. "
            "Treat the setting as a capacity-boundary test until the deterministic "
            "backbone is redesigned and documented."
        )


def _rounded_evidence(evidence: dict[str, Any]) -> dict[str, Any]:
    return {
        cluster: {
            "peak_backlog": round(float(vals["peak_backlog"]), 3),
            "peak_blackout": int(vals["peak_blackout"]),
            "peak_link_stress": round(float(vals["peak_link_stress"]), 3),
        }
        for cluster, vals in evidence.items()
    }


def _select_structure(client: Any, evidence: dict[str, Any]) -> tuple[str, str, dict[str, Any]]:
    user = (
        "Per-cluster evidence from the nominal failed run:\n"
        + json.dumps(_rounded_evidence(evidence), indent=2)
        + "\n\nReturn the target cluster and repair mode JSON."
    )
    res = client.complete(SYSTEM, user)
    action = extract_json(res.text) or {}
    target = action.get("target_cluster")
    mode = action.get("repair_mode")
    parsed_ok = target in ALLOWED_CLUSTERS and mode in REPAIR_MODES
    if target not in ALLOWED_CLUSTERS:
        target = max(evidence, key=lambda c: evidence[c]["peak_backlog"])
    if mode not in REPAIR_MODES:
        mode = "route_dwell"
    return target, mode, {
        "provider": res.provider,
        "model": res.model,
        "mode": res.mode,
        "parsed_ok": parsed_ok,
        "rationale": str(action.get("rationale", ""))[:300],
        "usage": res.usage,
    }


def _row(stype: str, seed: int, method: str, result: dict, extra: dict | None = None) -> dict:
    m = result["metrics"]
    row = {
        "scenario": stype,
        "seed": seed,
        "method": method,
        "passed_contract": bool(m["passed_contract"]),
        "qsr": round(m["qsr"], 4),
        "recovery_time": m["recovery_time"],
        "max_blackout": m["max_blackout"],
        "selected_target": result.get("selected_target", ""),
        "selected_mode": result.get("selected_mode", ""),
        "portfolio_winner": result.get("portfolio_winner", ""),
        "portfolio_candidates": result.get("portfolio_candidates", ""),
        "held_out": stype == HELD_OUT,
    }
    if extra:
        row.update(extra)
    return row


def main() -> None:
    _preflight_keys()
    RESULTS.mkdir(parents=True, exist_ok=True)
    seeds = list(range(1, int(os.environ.get("UAV_MIXED_LLM_N", "30")) + 1))
    _preflight_capacity(seeds)
    client = make_client()
    inner = getattr(client, "inner", None)
    inner_provider = str(getattr(inner, "provider", ""))
    if inner_provider.startswith("offline"):
        raise SystemExit("No live LLM backend detected; refusing to write synthetic LLM evidence.")

    methods = DET_METHODS + ["llm_only_structure", "hybrid_portfolio"]
    rows = []
    t0 = time.time()
    print(
        f"Mixed structural suite: {len(seeds)} seeds/type; LLM backend="
        f"{getattr(inner, 'provider', '?')}/{getattr(inner, 'model', '?')}"
    )
    header = f"{'scenario':<24}" + "".join(f"{m:>28}" for m in methods)
    print(header)
    print("-" * len(header))
    for stype in STYPES:
        agg = {m: [] for m in methods}
        for seed in seeds:
            scenario = make_scenario_mixed(seed, stype)
            evidence = evidence_from_nominal(scenario)
            det_results = {}
            for method in DET_METHODS:
                result = run_method(method, scenario, evidence)
                det_results[method] = result
                agg[method].append(bool(result["metrics"]["passed_contract"]))
                rows.append(_row(stype, seed, method, result))
            target, mode, info = _select_structure(client, evidence)
            llm_result = calibrate_structure(scenario, target, mode)
            agg["llm_only_structure"].append(bool(llm_result["metrics"]["passed_contract"]))
            rows.append(
                _row(
                    stype,
                    seed,
                    "llm_only_structure",
                    llm_result,
                    {
                        "parsed_ok": info["parsed_ok"],
                        "provider": info["provider"],
                        "model": info["model"],
                        "llm_mode": info["mode"],
                        "rationale": info["rationale"],
                        "evidence_json": json.dumps(_rounded_evidence(evidence), sort_keys=True),
                    },
                )
            )
            hybrid_result = promote_candidate_results(
                [(name, det_results[name]) for name in SIMPLE_RULE_METHODS]
                + [("llm_only_structure", llm_result)],
                "hybrid_portfolio",
            )
            agg["hybrid_portfolio"].append(bool(hybrid_result["metrics"]["passed_contract"]))
            rows.append(
                _row(
                    stype,
                    seed,
                    "hybrid_portfolio",
                    hybrid_result,
                    {
                        "parsed_ok": info["parsed_ok"],
                        "provider": info["provider"],
                        "model": info["model"],
                        "llm_mode": info["mode"],
                        "rationale": info["rationale"],
                        "evidence_json": json.dumps(_rounded_evidence(evidence), sort_keys=True),
                    },
                )
            )
        print(
            f"{stype:<24}"
            + "".join(
                f"{statistics.mean(1.0 if x else 0.0 for x in agg[m]):>28.2f}"
                for m in methods
            )
        )

    outp = RESULTS / "mixed_structural_llm_per_seed.csv"
    fieldnames = [
        "scenario",
        "seed",
        "method",
        "passed_contract",
        "qsr",
        "recovery_time",
        "max_blackout",
        "selected_target",
        "selected_mode",
        "portfolio_winner",
        "portfolio_candidates",
        "held_out",
        "parsed_ok",
        "provider",
        "model",
        "llm_mode",
        "rationale",
        "evidence_json",
    ]
    with outp.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    print(f"\nwrote {outp}  [{time.time() - t0:.0f}s]")
    print("Next: inspect the held-out row before deciding whether this belongs in the paper.")


if __name__ == "__main__":
    main()
