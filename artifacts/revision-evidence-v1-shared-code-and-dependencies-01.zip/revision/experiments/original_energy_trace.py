"""Read-only trajectory instrumentation of the frozen original simulator.

Only four AST insertion sites are permitted. The inverse transformation must
restore the exact original function AST before the instrumented copy is usable.
No legacy source, service rule, recovery timer, gate, or return metric is changed.
Importing this module neither simulates nor reads configuration or API keys.
"""
from __future__ import annotations

import ast
import copy
import hashlib
import importlib
import json
import sys
from functools import lru_cache
from pathlib import Path

BASE = Path(__file__).resolve().parent
LEGACY = BASE / "legacy"
VERSION = "original-energy-trace-1"
EXPECTED_SOURCES = {
    "run_uav_iot_workflow_experiment.py": "62baf3d3763a6a38803be0a108593b2eff9fb491f9742913090020f4887fe635",
    "contingency_suite.py": "40ca703dd6ccdc964dab777fd2508ed7d83d23548592cded3eb010ec8b158155",
    "mixed_structural_suite.py": "aa082beafbd78295eb9873faf53b82854a77da20914b7a34a7b298bac18822a3",
}

INIT = "__energy_audit_trace = []"
HEAD = """__energy_audit_start_xy = tuple(uav)
__energy_audit_previous_protocol = previous_protocol
__energy_audit_switch_count = switch_count
__energy_audit_abstract_before = energy
"""
TAIL = """__energy_audit_trace.append({
    'slot': t,
    'slot_start_s': t * DT,
    'slot_end_s': (t + 1) * DT,
    'dt_s': DT,
    'start_xy_m': list(__energy_audit_start_xy),
    'end_xy_m': list(uav),
    'move_m': move,
    'speed_m_s': move / DT,
    'selected_device_index': None if selected is None else selected[1],
    'selected_device': None if selected is None else devices[selected[1]]['id'],
    'delivered_amount': 0.0 if selected is None else served[selected[1]],
    'sel_proto': sel_proto,
    'previous_protocol_before': __energy_audit_previous_protocol,
    'previous_protocol_after': previous_protocol,
    'switch_event': switch_count > __energy_audit_switch_count,
    'abstract_energy_before': __energy_audit_abstract_before,
    'abstract_energy_after': energy,
    'aff_backlog': logs[-1]['aff_backlog'],
    'aff_blackout': logs[-1]['aff_blackout'],
})
"""


def _dump(node):
    return ast.dump(node, annotate_fields=True, include_attributes=False)


def _digest(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def source_bindings():
    """Fail closed if the original model has drifted since the frozen audit."""
    actual = {str((LEGACY / name).resolve()): hashlib.sha256(
        (LEGACY / name).read_bytes()).hexdigest() for name in EXPECTED_SOURCES}
    for name, expected in EXPECTED_SOURCES.items():
        if actual[str((LEGACY / name).resolve())] != expected:
            raise ValueError(f"Frozen original source changed: {name}")
    actual[str(Path(__file__).resolve())] = hashlib.sha256(
        Path(__file__).read_bytes()).hexdigest()
    return actual


def _instrument_function():
    source_bindings()
    source = (LEGACY / "contingency_suite.py").read_text(encoding="utf-8-sig")
    module = ast.parse(source)
    original = next(node for node in module.body
                    if isinstance(node, ast.FunctionDef) and node.name == "simulate_cset")
    if any(isinstance(node, ast.Name) and node.id.startswith("__energy_audit_")
           for node in ast.walk(original)):
        raise ValueError("Instrumentation names collide with the original function")
    instrumented = copy.deepcopy(original)
    slots = [node for node in instrumented.body if isinstance(node, ast.For)
             and isinstance(node.target, ast.Name) and node.target.id == "t"
             and _dump(node.iter) == _dump(ast.parse("range(T)", mode="eval").body)]
    if len(slots) != 1:
        raise ValueError("Original slot loop no longer has the expected AST")
    loop = slots[0]
    init = ast.parse(INIT).body[0]
    heads = ast.parse(HEAD).body
    tail = ast.parse(TAIL).body[0]
    # The last original slot statement records affected backlog and blackout.
    last = loop.body[-1]
    if not (isinstance(last, ast.Expr) and isinstance(last.value, ast.Call)
            and isinstance(last.value.func, ast.Attribute)
            and isinstance(last.value.func.value, ast.Name)
            and last.value.func.value.id == "logs" and last.value.func.attr == "append"):
        raise ValueError("Original slot tail no longer records logs.append")
    loop_index = instrumented.body.index(loop)
    instrumented.body.insert(loop_index, init)
    loop.body = heads + loop.body + [tail]
    ret = instrumented.body[-1]
    if not isinstance(ret, ast.Return) or not isinstance(ret.value, ast.Dict):
        raise ValueError("Original return schema is no longer a dictionary")
    ret.value.keys.append(ast.Constant(value="energy_trace"))
    ret.value.values.append(ast.Name(id="__energy_audit_trace", ctx=ast.Load()))

    # Strip only exact whitelisted nodes; all remaining AST must match exactly.
    restored = copy.deepcopy(instrumented)
    if _dump(restored.body[loop_index]) != _dump(init):
        raise AssertionError("Unrecognized initialization mutation")
    del restored.body[loop_index]
    restored_loop = restored.body[loop_index]
    if not isinstance(restored_loop, ast.For):
        raise AssertionError("Slot loop location changed")
    if [_dump(x) for x in restored_loop.body[:len(heads)]] != [_dump(x) for x in heads]:
        raise AssertionError("Unrecognized slot-head mutation")
    if _dump(restored_loop.body[-1]) != _dump(tail):
        raise AssertionError("Unrecognized slot-tail mutation")
    restored_loop.body = restored_loop.body[len(heads):-1]
    restored_return = restored.body[-1].value
    if _dump(restored_return.keys[-1]) != _dump(ast.Constant(value="energy_trace")):
        raise AssertionError("Unrecognized added return key")
    if _dump(restored_return.values[-1]) != _dump(
            ast.Name(id="__energy_audit_trace", ctx=ast.Load())):
        raise AssertionError("Unrecognized added return value")
    restored_return.keys.pop()
    restored_return.values.pop()
    if _dump(restored) != _dump(original):
        raise AssertionError("Instrumentation altered a non-whitelisted original AST node")
    proof = {
        "version": VERSION,
        "status": "PASS_EXACT_AST_RESTORATION",
        "whitelist": ["one pre-loop trace-list assignment", "four slot-head snapshot assignments",
                      "one slot-tail trace append", "one additive return dictionary pair"],
        "original_function_ast_sha256": _digest(_dump(original)),
        "restored_function_ast_sha256": _digest(_dump(restored)),
        "instrumented_function_ast_sha256": _digest(_dump(instrumented)),
        "original_return_keys": [key.value for key in original.body[-1].value.keys],
        "added_return_key": "energy_trace",
        "model_requests": 0,
        "source_hashes": source_bindings(),
    }
    return ast.fix_missing_locations(ast.Module(body=[instrumented], type_ignores=[])), proof


@lru_cache(maxsize=1)
def _loaded():
    tree, proof = _instrument_function()
    names = ("run_uav_iot_workflow_experiment", "contingency_suite", "mixed_structural_suite")
    # Reuse only the exact frozen original imports; reject unrelated same-name modules.
    for name in names:
        existing = sys.modules.get(name)
        if existing is not None and Path(existing.__file__).resolve() != (LEGACY / (name + ".py")).resolve():
            raise ValueError(f"Unrelated module already occupies original import name: {name}")
    before_path = list(sys.path)
    try:
        sys.path.insert(0, str(LEGACY))
        canonical, original, mixed = [importlib.import_module(name) for name in names]
    finally:
        sys.path[:] = before_path
    for name, module in zip(names, (canonical, original, mixed)):
        if Path(module.__file__).resolve() != (LEGACY / (name + ".py")).resolve():
            raise ValueError(f"Original import resolved to the wrong source: {name}")
    namespace = original.__dict__.copy()
    exec(compile(tree, str(LEGACY / "contingency_suite.py") + " [trace-only AST copy]", "exec"), namespace)
    return namespace["simulate_cset"], original, mixed, proof


def instrumentation_proof():
    """AST/source proof without imports, simulation, environment, or API access."""
    return copy.deepcopy(_instrument_function()[1])


def simulate_with_energy_trace(scenario: dict, policy: dict) -> dict:
    """Execute the original simulator with additive read-only per-slot records.

    Abstract energy is the original unitless accounting proxy, not joules.
    Delivered amount is the original queue quantity, not a transmission duration.
    Protocol selection is the original one-device-per-slot observation; physical
    power and active-radio duration assumptions belong to a separate screen.
    """
    source_bindings()
    function, _, _, _ = _loaded()
    return function(scenario, policy)


def original_modules():
    """Expose the frozen original scenario/simulator modules for external audits."""
    _, original, mixed, _ = _loaded()
    return original, mixed


if __name__ == "__main__":
    print(json.dumps(instrumentation_proof(), ensure_ascii=False, indent=2))
