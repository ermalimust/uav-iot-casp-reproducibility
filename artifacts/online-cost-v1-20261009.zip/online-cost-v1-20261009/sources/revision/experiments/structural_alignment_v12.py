"""Pure alignment with the submitted target/mode structural repair interface.

The selector supplies one target and one existing repair mode. The common
program enumerates the unchanged legacy numerical grid. Default calibration
retains the original four-dimensional rank, first passing candidate, raw grid
order (including duplicate executable policies), and first-candidate tie break.
``full_search=True`` corresponds only to the legacy FULL_SEARCH=1 option.

There is no client, environment/configuration read, simulator, scenario maker,
historical experiment read, persisted cache, or holdout evaluator here. Every
execution callback is explicitly supplied by the caller. A shared in-memory
cache can save physical callback calls, but every raw candidate still charges a
logical replay. It therefore does not change the legacy prefix or early stop.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
from collections.abc import Callable, Mapping, Sequence
from pathlib import Path
from typing import Any

import candidate_search as legacy_grid

VERSION = 'submitted-structure-numerical-alignment-v12-1'
CLUSTERS = legacy_grid.CLUSTERS
MODES = legacy_grid.MODES
RANKING_RULE = ('Legacy lexicographic maximum: passed_contract, qsr, '
                '-recovery_time, -max_blackout. Strict > keeps the first exact tie.')
DEFAULT_NUMERICAL_REPLAY_BUDGET = 45
SIMPLE_RULE_METHODS = ('B1_max_backlog_route', 'B2_max_blackout_protocol',
                       'B3_scripted_east_full')


def structure_schema() -> dict[str, Any]:
    """Only target/mode affect execution; rationale is optional metadata."""
    return {'type': 'object', 'additionalProperties': False,
        'required': ['target_cluster', 'repair_mode'],
        'properties': {'target_cluster': {'type': 'string', 'enum': list(CLUSTERS)},
                       'repair_mode': {'type': 'string', 'enum': list(MODES)},
                       'rationale': {'type': 'string'}}}


def validate_structure(selection: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(selection, Mapping):
        raise ValueError('Structure must be an object')
    required, permitted = {'target_cluster', 'repair_mode'}, {'target_cluster', 'repair_mode', 'rationale'}
    if not required <= set(selection) or not set(selection) <= permitted:
        raise ValueError('Only target_cluster, repair_mode and optional rationale are allowed')
    target, mode = selection['target_cluster'], selection['repair_mode']
    if not isinstance(target, str) or target not in CLUSTERS:
        raise ValueError('Unknown target_cluster')
    if not isinstance(mode, str) or mode not in MODES:
        raise ValueError('Unknown repair_mode')
    result = {'target_cluster': target, 'repair_mode': mode}
    if 'rationale' in selection:
        if not isinstance(selection['rationale'], str):
            raise ValueError('Rationale must be a string, never executable policy content')
        result['rationale'] = selection['rationale']
    return result


def parse_structure(text: str) -> dict[str, Any]:
    """Prospective strict diagnostic, distinct from the original decoder."""
    if not isinstance(text, str):
        raise ValueError('Structure response must be text')
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('Duplicate JSON key')
            result[key] = value
        return result
    def reject_constant(_):
        raise ValueError('Non-finite JSON constant')
    return validate_structure(json.loads(text, object_pairs_hook=pairs,
                                         parse_constant=reject_constant))


def decode_legacy_response(text: str, evidence: Mapping[str, Any]) -> dict[str, Any]:
    """Original extraction/fallback path, with explicit origin accounting.

The submitted runner extracted an object from surrounding text/fences, ignored
extra fields, fell back to maximum backlog for an invalid target and route_dwell
for an invalid mode, and stringified/truncated rationale at 300 characters.
Those actions are retained here rather than silently replaced by strict parsing.
Any fallback makes the resulting candidate ineligible for model attribution.
"""
    if not isinstance(text, str):
        raise ValueError('Legacy response must be text')
    clean = legacy_grid.public_evidence(evidence)
    # Preserve the input order among the original three clusters for a backlog
    # fallback tie, while withholding any extraneous case/holdout metadata.
    ordered = {cluster: clean[cluster] for cluster in evidence if cluster in CLUSTERS}
    helpers = legacy_grid._legacy_helpers(str(legacy_grid.LEGACY_DIR.resolve()))
    action = helpers['extract_json'](text) or {}
    # A truthy non-object JSON value raised on .get in the original selector;
    # preserve that error instead of inventing an additional fallback pathway.
    target, mode = action.get('target_cluster'), action.get('repair_mode')
    parsed_ok = target in CLUSTERS and mode in MODES
    target_fallback, mode_fallback = target not in CLUSTERS, mode not in MODES
    origins = []
    if target_fallback:
        target = max(ordered, key=lambda cluster: ordered[cluster]['peak_backlog'])
        origins.append('max_backlog_rule_for_invalid_target')
    if mode_fallback:
        mode = 'route_dwell'
        origins.append('route_dwell_default_for_invalid_mode')
    rationale = str(action.get('rationale', ''))[:300]
    ignored = [key for key in action if key not in {'target_cluster', 'repair_mode', 'rationale'}]
    def has_number(value):
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return True
        if isinstance(value, Mapping):
            return any(has_number(item) for item in value.values())
        if isinstance(value, list):
            return any(has_number(item) for item in value)
        return False
    return {'selection': {'target_cluster': target, 'repair_mode': mode, 'rationale': rationale},
        'metadata': {'parsed_ok': bool(parsed_ok), 'target_fallback': bool(target_fallback),
            'mode_fallback': bool(mode_fallback), 'fallback_origin': origins,
            'ignored_fields': ignored, 'ignored_numeric_fields': [key for key in ignored if has_number(action[key])],
            'llm_attribution_eligible': bool(parsed_ok),
            'parser_path': 'original_extract_json_with_original_target_mode_fallback',
            'new_model_calls': 0, 'inference_performed_by_module': False}}


def _source_name(source: str) -> str:
    if not isinstance(source, str) or not source:
        raise ValueError('Source provenance must be a nonempty caller-supplied label')
    return source


def numerical_candidates(selection: Mapping[str, Any], *, source: str = 'unknown') -> list[dict[str, Any]]:
    """Exact original route-major/dwell-major/trigger-major grid, no dedup."""
    selected = validate_structure(selection)
    return legacy_grid.structure_candidates(selected['target_cluster'], selected['repair_mode'],
                                            source=_source_name(source))


def rule_structures(method: str, evidence: Mapping[str, Any]) -> list[dict[str, str]]:
    """Original public-evidence script decisions, no case labels or outcomes."""
    clean = legacy_grid.public_evidence(evidence)
    helpers = legacy_grid._legacy_helpers(str(legacy_grid.LEGACY_DIR.resolve()))
    compact = [
        (helpers['_target_from_backlog'](clean), 'route_dwell'),
        (helpers['_target_from_blackout'](clean), 'protocol_trigger'),
        ('east_hotspot', 'full_casp')]
    if method in SIMPLE_RULE_METHODS:
        choices = [compact[SIMPLE_RULE_METHODS.index(method)]]
    elif method in {'rule_only_portfolio', 'compact_rules'}:
        choices = compact
    elif method in {'SR_scripted_mixed_reference', 'scripted_mixed'}:
        choices = [helpers['scripted_structure'](clean)]
    elif method == 'compact_plus_mixed':
        choices = compact + [helpers['scripted_structure'](clean)]
    else:
        raise ValueError('Unknown original rule method')
    return [{'target_cluster': target, 'repair_mode': mode} for target, mode in choices]


def make_plan(structures: Sequence[Mapping[str, Any]], *, sources: Sequence[str] | None = None) -> dict[str, Any]:
    """Keep each original calibrator group and raw order, including repeats.

An extra source is a new structural slot in a portfolio, even if it selects the
same structure. Such a slot does not become a free extra inference or replay.
"""
    if isinstance(structures, (str, bytes, Mapping)) or not isinstance(structures, Sequence) or not structures:
        raise ValueError('At least one ordered structure selection is required')
    selected = [validate_structure(x) for x in structures]
    labels = ['unknown'] * len(selected) if sources is None else list(sources)
    if len(labels) != len(selected):
        raise ValueError('Exactly one independent source label per structural slot is required')
    groups, flat = [], []
    for index, (selection, source) in enumerate(zip(selected, labels)):
        source = _source_name(source)
        candidates = numerical_candidates(selection, source=source)
        groups.append({'structure_index': index, 'selection': selection, 'source': source,
                       'candidates': candidates, 'raw_grid_entries': len(candidates),
                       'unique_policy_count': len({x['policy_hash'] for x in candidates})})
        flat.extend(copy.deepcopy(candidates))
    return {'version': VERSION, 'groups': groups, 'candidates': flat,
            'structural_slots': len(groups), 'raw_grid_entries': len(flat),
            'unique_policy_count': len({x['policy_hash'] for x in flat}),
            'duplicate_raw_entries': len(flat) - len({x['policy_hash'] for x in flat}),
            'candidate_order': 'original_structure_order_then_original_numerical_grid_order',
            'deduplication_changes_prefix': False, 'ranking_rule': RANKING_RULE,
            'new_model_calls': 0, 'inference_performed_by_module': False}


def _canonical(value: Any) -> Any:
    if isinstance(value, Mapping):
        if not all(isinstance(key, str) for key in value):
            raise ValueError('Replay identity requires string mapping keys')
        return {key: _canonical(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_canonical(item) for item in value]
    if isinstance(value, (set, frozenset)):
        items = [_canonical(item) for item in value]
        return sorted(items, key=lambda item: json.dumps(item, sort_keys=True, allow_nan=False))
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float) and math.isfinite(value):
        return value
    raise ValueError('Replay identity must contain finite JSON-compatible values')


def _hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(_canonical(value), sort_keys=True,
        separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()


def _single_construction(construction_scenario: Any) -> None:
    # Missing split is intentional: the submitted legacy single scenario had no
    # split field. A caller's explicitly marked holdout must never calibrate.
    if isinstance(construction_scenario, Mapping):
        if construction_scenario.get('split', 'construction') != 'construction':
            raise ValueError('Only an explicit construction scenario may enter calibration')
    elif isinstance(construction_scenario, Sequence) and not isinstance(construction_scenario, (str, bytes)):
        raise ValueError('Multiple construction scenes would change the original ranking; use one scenario')
    _hash(construction_scenario)


def _budget(value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError('Replay budget must be a non-negative integer')
    return value


def _legacy_rank(result: Mapping[str, Any]) -> tuple[int, float, float, float]:
    if not isinstance(result, Mapping) or not isinstance(result.get('metrics'), Mapping):
        raise ValueError('Evaluator must return original metrics')
    metrics = result['metrics']
    if type(metrics.get('passed_contract')) is not bool:
        raise ValueError('Original passed_contract must be a boolean')
    values = []
    for name in ('qsr', 'recovery_time', 'max_blackout'):
        value = metrics.get(name)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError('Original ranking metrics must be finite numbers')
        values.append(float(value))
    qsr, recovery, blackout = values
    if not 0 <= qsr <= 1 or recovery < 0 or blackout < 0:
        raise ValueError('Original ranking metrics are outside their domain')
    return (int(metrics['passed_contract']), qsr, -recovery, -blackout)


class ReplayCache:
    """Caller-owned, in-memory physical reuse; one fixed evaluator per cache.

Identity covers the full supplied scenario and executable policy semantics.
No disk cache or historical/model response is ever consulted. Failed evaluator
calls and invalid metrics are not cached; every physical attempt is counted.
"""
    def __init__(self, evaluator: Callable[[Any, dict[str, Any]], dict[str, Any]], *, enabled: bool = True):
        if not callable(evaluator):
            raise ValueError('An explicit construction evaluator is required')
        self.evaluator = evaluator
        if type(enabled) is not bool:
            raise ValueError('Cache enabled must be an explicit boolean')
        self.enabled = enabled
        self.entries: dict[str, dict[str, Any]] = {}
        self.logical_calls = self.physical_calls = self.cache_hits = 0
    def replay(self, construction_scenario: Any, policy: dict[str, Any], *, evaluator: Callable) -> tuple[dict[str, Any], dict[str, Any]]:
        if evaluator is not self.evaluator:
            raise ValueError('Shared cache belongs to a different evaluator')
        _single_construction(construction_scenario)
        scenario_hash, policy_hash = _hash(construction_scenario), legacy_grid.policy_semantic_hash(policy)
        key = _hash([scenario_hash, policy_hash])
        self.logical_calls += 1
        hit = self.enabled and key in self.entries
        if hit:
            self.cache_hits += 1
        else:
            self.physical_calls += 1
            result = self.evaluator(copy.deepcopy(construction_scenario), copy.deepcopy(policy))
            _legacy_rank(result)
            if self.enabled:
                self.entries[key] = copy.deepcopy(result)
        replay_result = self.entries[key] if hit else result
        return copy.deepcopy(replay_result), {'cache_key': key, 'scenario_full_hash': scenario_hash,
            'policy_semantic_hash': policy_hash, 'cache_hit': hit,
            'logical_calls_charged': 1, 'physical_calls_this_replay': int(not hit)}


def calibrate_structure(selection: Mapping[str, Any], construction_scenario: Any, *,
                        replay_budget: int = DEFAULT_NUMERICAL_REPLAY_BUDGET,
                        evaluator: Callable | None = None, full_search: bool = False,
                        cache: ReplayCache | None = None, source: str = 'unknown') -> dict[str, Any]:
    """Original single-replay numerical calibrator under an explicit call cap.

First pass stops by default, exactly as the submitted calibrator. Invalid or
failed execution attempts remain charged and visible, then stop the calibration
as the original exception path did. They cannot supply an accepted result or
automatically advance to another candidate.
"""
    if not callable(evaluator):
        raise ValueError('No default evaluator exists; explicitly supply a construction callback')
    if type(full_search) is not bool:
        raise ValueError('full_search must be an explicit boolean')
    _single_construction(construction_scenario)
    budget = _budget(replay_budget)
    selected = validate_structure(selection)
    candidates = numerical_candidates(selected, source=source)
    shared = ReplayCache(evaluator, enabled=False) if cache is None else cache
    if not isinstance(shared, ReplayCache) or shared.evaluator is not evaluator:
        raise ValueError('Cache must be explicitly shared with this same evaluator')
    before = (shared.logical_calls, shared.physical_calls, shared.cache_hits)
    ledger, best, best_rank = [], None, None
    first_pass_calls, stopped_first_pass, execution_error = None, False, False
    for candidate in candidates:
        if len(ledger) >= budget:
            break
        entry = {key: copy.deepcopy(value) for key, value in candidate.items()}
        entry.update(selection_index=len(ledger), logical_calls_charged=1,
                     rank=None, valid_evaluation=False, accepted=False)
        physical_before = shared.physical_calls
        try:
            result, reference = shared.replay(construction_scenario, candidate['policy'], evaluator=evaluator)
            rank = _legacy_rank(result)
            entry.update(result=result, replay_reference=reference, rank=list(rank),
                valid_evaluation=True, accepted=bool(rank[0]),
                physical_calls=shared.physical_calls - physical_before)
            if best_rank is None or rank > best_rank:
                best, best_rank = copy.deepcopy(entry), rank
            if rank[0]:
                if first_pass_calls is None:
                    first_pass_calls = len(ledger) + 1
                if not full_search:
                    stopped_first_pass = True
        except Exception as error:
            entry.update(error={'exception_type': type(error).__name__,
                'message_omitted': True}, physical_calls=shared.physical_calls - physical_before)
            execution_error = True
        ledger.append(entry)
        if stopped_first_pass or execution_error:
            break
    logical = shared.logical_calls - before[0]
    physical = shared.physical_calls - before[1]
    hits = shared.cache_hits - before[2]
    if logical != len(ledger) or logical != physical + hits:
        raise RuntimeError('Calibration accounting differs from the charged raw prefix')
    return {'version': VERSION, 'status': 'execution_error' if execution_error else 'completed',
        'selection': selected, 'source': _source_name(source),
        'raw_grid_entries': len(candidates), 'unique_policy_count': len({x['policy_hash'] for x in candidates}),
        'ledger': ledger, 'best_candidate': best,
        'best_policy': copy.deepcopy(best['policy']) if best else None,
        'best_result': copy.deepcopy(best['result']) if best else None,
        'accepted': bool(not execution_error and best_rank and best_rank[0]),
        'best_rank': list(best_rank) if best_rank else None,
        'logical_calls': logical, 'physical_calls': physical, 'cache_hits': hits,
        'replay_budget': budget, 'unused_budget': budget - logical,
        'first_pass_calls': first_pass_calls, 'stopped_on_first_pass': stopped_first_pass,
        'stopped_for_budget': logical == budget and logical < len(candidates) and not stopped_first_pass and not execution_error,
        'stopped_on_execution_error': execution_error, 'automatic_retry': False,
        'full_search': full_search, 'raw_grid_exhausted': logical == len(candidates),
        'evaluation_complete_without_errors': all(x['valid_evaluation'] for x in ledger),
        'failed_or_invalid_replays': sum(not x['valid_evaluation'] for x in ledger),
        'calibration_scope': 'one construction replay per raw numerical grid entry',
        'ranking_rule': RANKING_RULE, 'new_model_calls': 0,
        'inference_performed_by_module': False}


def calibrate_legacy_response(text: str, evidence: Mapping[str, Any], construction_scenario: Any, *,
                              replay_budget: int = DEFAULT_NUMERICAL_REPLAY_BUDGET,
                              evaluator: Callable | None = None, full_search: bool = False,
                              cache: ReplayCache | None = None, source: str = 'caller_supplied_model_response') -> dict[str, Any]:
    """Method-aligned response adapter; fallback service success is not LLM success."""
    decoded = decode_legacy_response(text, evidence)
    origin = source if decoded['metadata']['parsed_ok'] else source + '+original_rule_fallback'
    calibrated = calibrate_structure(decoded['selection'], construction_scenario,
        replay_budget=replay_budget, evaluator=evaluator, full_search=full_search, cache=cache, source=origin)
    return {'decoder': decoded, 'calibration': calibrated,
            'llm_candidate_accepted': bool(decoded['metadata']['llm_attribution_eligible'] and calibrated['accepted']),
            'fallback_candidate_accepted': bool(not decoded['metadata']['llm_attribution_eligible'] and calibrated['accepted']),
            'model_inference_or_provider_provenance_verified': False, 'new_model_calls': 0}


def promotion_key(result: Mapping[str, Any]) -> tuple[int, float, float, float]:
    """Original four-metric portfolio promotion; no additional evaluation."""
    return _legacy_rank(result)


def promote_candidate_results(candidates: Sequence[tuple[str, Mapping[str, Any]]], portfolio_name: str) -> dict[str, Any]:
    """Original ordered promotion, preserving the first candidate on exact ties."""
    if not candidates:
        raise ValueError('A nonempty ordered candidate portfolio is required')
    winner_name, winner = max(candidates, key=lambda item: promotion_key(item[1]))
    result = dict(winner)
    result.update(portfolio_name=portfolio_name, portfolio_winner=winner_name,
        portfolio_candidates=';'.join(name for name, _ in candidates),
        selected_target=winner.get('selected_target', ''), selected_mode=winner.get('selected_mode', ''))
    return result


def calibrate_plan(plan: Mapping[str, Any], construction_scenario: Any, *,
                   replay_budget_per_structure: int = DEFAULT_NUMERICAL_REPLAY_BUDGET,
                   evaluator: Callable | None = None, full_search: bool = False,
                   cache: ReplayCache | None = None) -> dict[str, Any]:
    """Original ordered portfolio of independently calibrated structures.

The portfolio with more structural slots has a larger maximum logical budget.
This fact remains explicit even when its policies hit a shared physical cache.
Each group uses the same original calibrator and the same per-structure cap.
"""
    if not isinstance(plan, Mapping) or not isinstance(plan.get('groups'), list):
        raise ValueError('A generated structural plan is required')
    expected = make_plan([x['selection'] for x in plan['groups']], sources=[x['source'] for x in plan['groups']])
    if dict(plan) != expected:
        raise ValueError('Structural plan/grid was changed after generation')
    _single_construction(construction_scenario)
    budget = _budget(replay_budget_per_structure)
    if not callable(evaluator):
        raise ValueError('An explicit construction evaluator is required')
    shared = ReplayCache(evaluator, enabled=False) if cache is None else cache
    groups, winner, winner_rank, execution_error = [], None, None, False
    for group in plan['groups']:
        calibrated = calibrate_structure(group['selection'], construction_scenario,
            replay_budget=budget, evaluator=evaluator, full_search=full_search,
            cache=shared, source=group['source'])
        calibrated['structure_index'] = group['structure_index']
        groups.append(calibrated)
        if calibrated['status'] == 'execution_error':
            execution_error = True
            break
        rank = tuple(calibrated['best_rank']) if calibrated['best_rank'] is not None else None
        if rank is not None and (winner_rank is None or rank > winner_rank):
            winner, winner_rank = calibrated, rank
    promoted_inputs = []
    for calibrated in groups:
        if calibrated['status'] != 'execution_error' and calibrated['best_result'] is not None:
            result = copy.deepcopy(calibrated['best_result'])
            result.update(policy=copy.deepcopy(calibrated['best_policy']),
                selected_target=calibrated['selection']['target_cluster'],
                selected_mode=calibrated['selection']['repair_mode'])
            promoted_inputs.append((calibrated['source'], result))
    promoted = promote_candidate_results(promoted_inputs, 'caller_supplied_structural_portfolio') if promoted_inputs else None
    return {'version': VERSION, 'status': 'execution_error' if execution_error else 'completed',
        'groups': groups, 'structural_slots': len(plan['groups']),
        'evaluated_structural_slots': len(groups),
        'unexecuted_structural_slots': len(plan['groups']) - len(groups),
        'raw_grid_entries': plan['raw_grid_entries'], 'unique_policy_count': plan['unique_policy_count'],
        'allocated_logical_replay_cap': len(plan['groups']) * budget,
        'max_logical_replay_budget': sum(min(budget, x['raw_grid_entries']) for x in plan['groups']),
        'replay_budget_per_structure': budget,
        'logical_calls': sum(x['logical_calls'] for x in groups),
        'physical_calls': sum(x['physical_calls'] for x in groups),
        'cache_hits': sum(x['cache_hits'] for x in groups),
        'winner_structure_index': winner['structure_index'] if winner else None,
        'winner_source': winner['source'] if winner else None,
        'best_policy': copy.deepcopy(winner['best_policy']) if winner else None,
        'best_result': copy.deepcopy(winner['best_result']) if winner else None,
        'best_rank': list(winner_rank) if winner_rank is not None else None,
        'promoted_result': promoted,
        'accepted': bool(not execution_error and winner_rank and winner_rank[0]),
        'evaluation_complete_without_errors': all(x['evaluation_complete_without_errors'] for x in groups),
        'full_search': full_search, 'automatic_retry': False,
        'ranking_rule': RANKING_RULE, 'new_model_calls': 0,
        'portfolio_scope': 'Original ordered structure portfolio; cardinality affects its maximum replay budget'}


def portfolio_budget_report(plans: Mapping[str, Mapping[str, Any]], *,
                            replay_budget_per_structure: int = DEFAULT_NUMERICAL_REPLAY_BUDGET) -> dict[str, Any]:
    """Expose added-library coverage and maximum-budget differences, API-free."""
    budget = _budget(replay_budget_per_structure)
    if not isinstance(plans, Mapping) or not plans:
        raise ValueError('Named structural plans are required')
    rows = []
    for name, plan in plans.items():
        if not isinstance(name, str) or not name:
            raise ValueError('Portfolio names must be nonempty strings')
        expected = make_plan([x['selection'] for x in plan['groups']], sources=[x['source'] for x in plan['groups']])
        if dict(plan) != expected:
            raise ValueError('Portfolio plan contains modified numerical candidates')
        rows.append({'portfolio': name, 'structural_slots': len(plan['groups']),
            'raw_grid_entries': plan['raw_grid_entries'], 'unique_policy_count': plan['unique_policy_count'],
            'allocated_logical_replay_cap': len(plan['groups']) * budget,
            'max_logical_replay_budget': sum(min(budget, x['raw_grid_entries']) for x in plan['groups']),
            'replay_budget_per_structure': budget})
    equal_slots = len({x['structural_slots'] for x in rows}) == 1
    return {'portfolios': rows, 'same_structural_slot_count': equal_slots,
        'same_allocated_logical_replay_cap': len({x['allocated_logical_replay_cap'] for x in rows}) == 1,
        'same_maximum_logical_replay_budget': len({x['max_logical_replay_budget'] for x in rows}) == 1,
        'same_raw_grid_entry_count': len({x['raw_grid_entries'] for x in rows}) == 1,
        'interpretation': ('Equal allocated slot/cap comparison; finite-grid maxima, actual early-stop and physical replay counts may differ and must be reported'
            if equal_slots else 'Different portfolio cardinality/max budget; library extension alone is not an equal-budget model-superiority comparison'),
        'preferred_contrast': 'Common compact base plus one expert-selected structure versus the same base plus one model-selected structure',
        'simulator_calls': 0, 'new_model_calls': 0}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    print(json.dumps({'version': VERSION, 'selector_schema': structure_schema(),
        'public_structure_count': len(CLUSTERS) * len(MODES), 'ranking_rule': RANKING_RULE,
        'default_first_pass_stop': True, 'full_search_is_explicit_legacy_option': True,
        'api_calls': 0, 'configuration_reads': 0, 'simulator_calls': 0,
        'experiment_files_read': 0}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
