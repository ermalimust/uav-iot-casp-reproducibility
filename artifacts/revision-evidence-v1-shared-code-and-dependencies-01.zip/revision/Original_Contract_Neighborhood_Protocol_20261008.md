# 原固定策略的多谓词邻域敏感性：执行前协议

2026-10-08。在计算任何新阈值通过数前冻结。范围是已独立审计通过的 `original_energy_screen_20261008` 中 1200 条固定策略：S1–S4、各100种子、compact / compact+expert / compact+cached-model。400 个历史实例跨三方法，不构成新独立实验。API 与 simulator 调用均为0；不改服务动作、校准、选中策略、observer 或原 source。

## 固定对象与精确证据

所有源和 cell 由既有 energy independent audit 的 manifest/completion/每 cell SHA-256 绑定。保存的精确原 metrics 支持 QSR admission、recovery deadline 及全局 max blackout；原 `p95_latency` 是所有已服务量的 volume-weighted p95，不是每设备 `L_i^95`，不能拿它冒充 device latency sensitivity。

已有 `energy_trace` 记录每槽被服务 device index 和精确 delivered amount。通过纯 AST 提取原确定性 `_case/make_scenario_mixed/clamp/is_burst_active`（不导入执行器/API），重建 arrivals 和 scene，必须逐条匹配原 `scenario_sha256`。仅按已经实现的服务事件做 FIFO 账本重构，不选择动作、不计算无线速率、不重跑控制器。得到每设备 generated/delivered/PDR、volume-weighted p95、max blackout；重构全部原 metrics、coverage、逐槽 affected backlog/blackout 和保存日志必须逐值一致，才允许改变 device predicates。任何不一致保存失败并停止，不用 approximate/global latency 代替，也不覆盖原证据。

如果上述确定性输入或服务日志不足，latency/PDR/per-device blackout 轴标记 unavailable；最小补充为独立 trace-only AST 观察器，一次固定策略回放保存每设备数组并校对原 metrics。不得声称该轴已完成。

## 事前网格与验收

基准为 device PDR≥0.70、device p95 latency≤62槽、device blackout≤52槽、QSR≥0.70、global max blackout≤52槽、affected-region recovery≤82槽，及原结构 coverage。DT=1s。QSR 是30设备中同时满足三项 device predicate 的比例；改变 device latency/PDR/blackout 必须先重算 QSR。Blackout 轴同时改变原 common device bound 和 global bound，不只放宽 global bound 后保留旧 QSR。

全部单变量轴：

| 轴 | 完整预定值 | 主展示三点 |
|---|---|---|
| QSR admission下界 | .60/.65/.70/.75/.80/.90/.95/1.00 | .65/.70/.75 |
| device PDR下界 | .60/.65/.70/.75/.80 | .65/.70/.75 |
| device latency上界(槽) | 42/52/62/72/82 | 52/62/72 |
| common blackout上界(槽) | 46/48/50/52/54/56/58/60 | 50/52/54 |
| recovery上界(槽) | 60/72/82/92/100/120/159 | 72/82/92 |

每轴只改变一项，其余基准值保持；coverage 始终不变，不重新 promotion。小幅邻域采用基准±.05、±10槽或已有 blackout 三点；较宽值完整保留，不按哪种方法更好选择。QSR 的离散粒度为1/30；62/52/82 是本控制实验的示例服务合同，邻域不是行业标准、设备推荐或胜率调参。

159是原未恢复哨兵/全后扰动时长的诊断放宽，只在完整数据中标记 diagnostic，不作为合理deadline或主鲁棒性证据。≤比较保留原等号通过，QSR/PDR≥保留原等号；不加以改变通过数为目的的容差。

联合附录仅预定 QSR∈{.65,.70,.75} × latency∈{52,62,72} × recovery∈{72,82,92}，27格，PDR=.70、blackout=52、coverage保持。33个完整单轴条件×1200=39600条判据记录；27联合条件×1200=32400条，共72000条。每条件按S1–S4×三方法分层，n=100；分别输出canonical通过、改变后通过及matched gain/loss，不把重复阈值读取当新效果样本。

## 核验、旧表口径与交付

先核对人工已知 FIFO 服务例、每设备/全局 p95区别、单调性与精确canonical复现；全部1200条必须与原 metrics/逐槽日志/coverage一致。每 cell记录 policy/scenario/cell hash及重构设备指标；全CSV保留所有阈值和联合配置。主TeX表列四场景×五轴，共20行，固定预定三点，展示三方法100种子的通过计数。

原 `run_contract_sensitivity.py:s4_eval_methods` 在每组阈值下重新选择存量候选赢家，而本分析固定原选中赢家。因此新的结果不是旧S4表的逐值复现；旧表若继续保留，应明确 frozen-candidate re-promotion 与 fixed-selected-policy reading 的区别。原CSV/旧表/源文件都不在本任务修改。

部署阈值需要由实际任务的采样周期、最大容忍数据丢失、每设备尾等待、最长连续服务缺口及恢复deadline共同定义；现值只实例化受控合同。邻域敏感性说明在固定轨迹下验收如何变化，不能证明阈值已经适用于医疗、飞行控制或其他具体高风险业务，不能替代任务方选择服务合同。
