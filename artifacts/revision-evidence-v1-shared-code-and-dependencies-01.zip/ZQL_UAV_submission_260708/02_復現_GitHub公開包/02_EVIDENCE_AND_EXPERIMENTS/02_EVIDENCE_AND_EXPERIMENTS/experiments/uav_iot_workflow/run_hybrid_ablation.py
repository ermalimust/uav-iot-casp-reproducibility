#!/usr/bin/env python3
"""
HYBRID repair backend: the LLM proposes the repair STRUCTURE (which levers to
pull -- route, protocol mode, whether to add a local CASP trigger), and a small
BOUNDED NUMERICAL SEARCH calibrates the thresholds (dwell, queue/blackout trigger
thresholds, protocol hold). This plays to each part's strength: the LLM does the
generalizable reasoning; the search does the precise calibration the LLM is bad at.

It compares three deployable/automated backends over the same seeds and
disturbance:
    scripted CASP (no LLM)   vs   pure LLM agent   vs   hybrid (LLM structure + search)

Run exactly like run_llm_ablation.py -- set the same provider/key env vars, then:
    python run_hybrid_ablation.py

Optional:
    $env:UAV_HYBRID_SEEDS = "30"     # number of seeds (default 30)
    $env:UAV_HYBRID_OUT = "results\\hybrid_ablation_smoke.csv"
The LLM cost is the same order as run_llm_ablation.py (the calibration search is
local simulation, no extra API calls), and prompts are cached for replay.
"""
from __future__ import annotations

import itertools
import os
import statistics
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"

from run_uav_iot_workflow_experiment import (  # simulator + deterministic loop
    CONTRACT,
    build_full_policy,
    cluster_centroid,
    diagnose,
    make_scenario,
    optimize_nominal_policy,
    promotion_score,
    route_policy,
    simulate_policy,
)

# Bounded calibration grids (small; all within the validated action-space limits).
_DWELL = [10, 16, 22]
_HOLD = [0, 4]
_QTHR = [12, 18, 24]
_BTHR = [12, 16, 20]


def structure_from_policy(pol: dict) -> dict:
    """Extract only the STRUCTURE (which levers) from a policy, discarding the
    specific numeric values -- those are what the search will recalibrate."""
    trig = pol.get("local_triggers")
    route = [wp["cluster"] for wp in pol.get("route", [])] or \
        ["west_cluster", "east_hotspot", "north_cluster", "east_hotspot"]
    mode = pol.get("protocol_mode", "degraded_aware")
    if mode not in ("best_rate", "degraded_aware", "nominal"):
        mode = "degraded_aware"
    return {
        "route_clusters": route,
        "protocol_mode": mode,
        "has_trigger": isinstance(trig, dict),
        "trigger_cluster": trig.get("cluster", "east_hotspot") if isinstance(trig, dict) else "east_hotspot",
    }


def rule_structure_from_diagnosis(diagnosis: dict) -> dict:
    """No-LLM structural backend.

    It uses only the simulator diagnosis record, not hidden knowledge of the
    seed or a hand-tuned policy. The same bounded calibration and validator used
    by the hybrid backend then choose the numeric thresholds.
    """
    target = diagnosis.get("affected_cluster") or "east_hotspot"
    route = ["west_cluster", target, "north_cluster", target]
    failures = set(diagnosis.get("failure_types", []))
    needs_protocol = "protocol_mismatch_under_degradation" in failures or "regional_blackout" in failures
    needs_trigger = bool(failures - {"no_major_violation"})
    return {
        "route_clusters": route,
        "protocol_mode": "degraded_aware" if needs_protocol else "best_rate",
        "has_trigger": needs_trigger,
        "trigger_cluster": target,
    }


def calibrate(scenario: dict, struct: dict) -> tuple[dict, dict]:
    """Bounded search over the numeric knobs of a fixed structure. Returns the
    best (policy, result) by (contract pass, then promotion score)."""
    route = struct["route_clusters"]
    mode = struct["protocol_mode"]
    has = struct["has_trigger"]
    tcl = struct.get("trigger_cluster", "east_hotspot")
    if tcl not in [c for c in route]:
        tcl = "east_hotspot"
    grids = (itertools.product(_DWELL, _HOLD, _QTHR, _BTHR) if has
             else itertools.product(_DWELL, _HOLD, [18], [16]))
    best = None
    for d, hold, q, b in grids:
        dwell = [d if c == tcl else 8 for c in route]
        pol = route_policy("calibrated_repair", route, dwell, mode)
        pol["min_protocol_hold_slots"] = hold
        pol["local_triggers"] = (
            {
                "cluster": tcl, "queue_threshold": float(q), "release_threshold": 10.0,
                "max_blackout_threshold_slots": int(b),
                "fallback_waypoint": list(cluster_centroid(tcl)),
                "fallback_dwell_min_slots": 3, "cooldown_slots": 16,
            } if has else None
        )
        res = simulate_policy(scenario, pol)
        key = (1 if res["metrics"]["passed_contract"] else 0, promotion_score(res, pol))
        if best is None or key > best[0]:
            best = (key, pol, res)
    return best[1], best[2]


def _agg(results: list[dict]) -> dict:
    f = lambda k: statistics.mean(r["metrics"][k] for r in results)  # noqa: E731
    p = statistics.mean(1.0 if r["metrics"]["passed_contract"] else 0.0 for r in results)
    return {"qsr": f("qsr"), "rec": f("recovery_time"), "blk": f("max_blackout"), "pass": p}


def main() -> None:
    seeds = list(range(1, int(os.environ.get("UAV_HYBRID_SEEDS", "30")) + 1))
    provider = os.environ.get("UAV_LLM_PROVIDER", "auto")
    print("=" * 66)
    print("HYBRID ablation: scripted-CASP vs. pure-LLM vs. LLM-structure + calibration")
    print("=" * 66)
    print(f"  provider={provider}  seeds={len(seeds)}")
    if not (os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("OPENAI_API_KEY")) and provider != "offline":
        print("  [!] No API key -> LLM falls back to an offline deterministic repair (NOT a real LLM result).")

    from llm_repair_agent import make_client, run_llm_closed_loop  # lazy
    client = make_client()

    scripted, pure, hybrid = [], [], []
    accepted = clamped = 0
    t0 = time.time()
    for s in seeds:
        perturbed = make_scenario(s, perturbation=True)
        base = optimize_nominal_policy(s, make_scenario(s, perturbation=False))
        scripted.append(simulate_policy(perturbed, build_full_policy()))
        loop = run_llm_closed_loop(s, perturbed, base, client=client, max_iters=3)
        pure.append(loop["final_result"])
        for r in loop["records"][1:]:
            ra = r.get("repair_action") or {}
            if ra:
                clamped += 1 if ra.get("clamp_notes") else 0
                accepted += 0 if ra.get("clamp_notes") else 1
        _, cal_res = calibrate(perturbed, structure_from_policy(loop["final_policy"]))
        hybrid.append(cal_res)
        print(f"  seed {s:>2} done", end="\r")

    print("\n\n" + "=" * 66)
    hdr = f"{'backend':<34}{'QSR':>7}{'recov':>8}{'blackout':>10}{'pass':>7}"
    print(hdr); print("-" * len(hdr))
    for name, R in [("scripted CASP (no LLM)", scripted),
                    ("pure LLM agent", pure),
                    ("hybrid (LLM struct + calibration)", hybrid)]:
        a = _agg(R)
        print(f"{name:<34}{a['qsr']:7.3f}{a['rec']:8.2f}{a['blk']:10.2f}{a['pass']:7.2f}")
    tot = accepted + clamped
    if tot:
        print(f"\nLLM actions: accepted-as-is {accepted}/{tot} ({accepted/tot:.0%}), "
              f"clamped {clamped}/{tot} ({clamped/tot:.0%})")
    import csv as _csv
    outp = Path(os.environ.get("UAV_HYBRID_OUT", str(RESULTS / "hybrid_ablation_per_seed.csv")))
    if not outp.is_absolute():
        outp = ROOT / outp
    outp.parent.mkdir(parents=True, exist_ok=True)
    with open(outp, "w", newline="") as fh:
        w = _csv.writer(fh)
        w.writerow(["backend", "seed", "qsr", "recovery_time", "max_blackout",
                    "p95_latency", "passed_contract"])
        for name, R in [("scripted_casp", scripted), ("pure_llm", pure), ("hybrid", hybrid)]:
            for s, r in zip(seeds, R):
                m = r["metrics"]
                w.writerow([name, s, m["qsr"], m["recovery_time"], m["max_blackout"],
                            m["p95_latency"], m["passed_contract"]])
    print(f"per-seed CSV -> {outp}")
    print(f"[{time.time()-t0:.0f}s]  Copy the three rows into the hybrid table in main.tex.")


if __name__ == "__main__":
    main()
