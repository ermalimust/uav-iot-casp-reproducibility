#!/usr/bin/env python3
"""
Learned external baseline (PPO) for the revision -- the comparator Section VII-B
promises as future work.

WHAT THIS ESTABLISHES
  1. Train PPO on the canonical east-hotspot stress (same 30 seeds, same contract).
  2. Freeze the policy and evaluate on moved hotspots (west/north, 10 seeds each).
  Expected narrative: the learned policy fits the canonical disturbance but, like
  the frozen oracle, collapses when the hotspot moves -- because its target and
  structure are fixed. Whatever the outcome, report it; both results strengthen
  the paper (Sec. VII-B sentence: "Such a learned comparator is the natural
  external baseline").

WHAT YOU MUST FILL IN: the 5 methods of SimAdapter marked TODO, which bridge to
your existing Python simulator. Everything else (env, training, frozen-transfer
evaluation, output CSV in Table-V format) is complete.

DEPENDENCIES
  pip install "stable-baselines3>=2.3" gymnasium numpy pandas
"""
import argparse
import math
import sys
from collections import deque
from pathlib import Path

import numpy as np
import pandas as pd
import gymnasium as gym
from gymnasium import spaces


WORKFLOW_DIR = Path(__file__).resolve().parent / "uav_iot_workflow"
if WORKFLOW_DIR.exists():
    sys.path.insert(0, str(WORKFLOW_DIR))

from run_uav_iot_workflow_experiment import (  # noqa: E402
    CLUSTERS,
    CONTRACT,
    DT,
    N_DEVICES,
    PERTURB_START,
    PROTOCOLS,
    RECOVERY_HOLD,
    T,
    UAV_SPEED,
    UAV_START,
    cluster_centroid,
    consume_queue,
    dist,
    link_rate,
    weighted_percentile,
)
from multiscenario import degradation_ms, make_scenario_ms  # noqa: E402


# --------------------------------------------------------------------------- #
# 1. Bridge to YOUR simulator. Fill in the five TODOs.
# --------------------------------------------------------------------------- #
class SimAdapter:
    """Thin bridge to the paper's Python UAV-IoT simulator."""

    N_CLUSTERS = len(CLUSTERS)
    PROTOCOL_NAMES = list(PROTOCOLS)
    N_PROTOCOLS = len(PROTOCOL_NAMES)
    HORIZON = T
    HOTSPOT_ALIASES = {
        "east": "east_hotspot",
        "east_hotspot": "east_hotspot",
        "west": "west_cluster",
        "west_cluster": "west_cluster",
        "north": "north_cluster",
        "north_cluster": "north_cluster",
    }

    def __init__(self, hotspot: str, seed: int, burst_scale: float = 3.3):
        del burst_scale  # The restored simulator uses the canonical paper scale.
        self.hotspot = self.HOTSPOT_ALIASES.get(hotspot, hotspot)
        if self.hotspot not in {c["id"] for c in CLUSTERS}:
            raise ValueError(f"unknown hotspot '{hotspot}'")
        self.seed = seed
        self.scenario = make_scenario_ms(seed, perturbation=True, hot=self.hotspot)
        self.devices = self.scenario["devices"]
        self.arrivals = self.scenario["arrivals"]
        self.perturbation = bool(self.scenario["perturbation"])
        self.reset()

    def reset(self) -> np.ndarray:
        self.t = 0
        self.queues = [0.0] * N_DEVICES
        self.chunks = [deque() for _ in range(N_DEVICES)]
        self.generated = [0.0] * N_DEVICES
        self.delivered = [0.0] * N_DEVICES
        self.latencies = [[] for _ in range(N_DEVICES)]
        self.blackout_streak = [0] * N_DEVICES
        self.max_blackout = [0] * N_DEVICES
        self.uav = [UAV_START[0], UAV_START[1]]
        self.previous_protocol = None
        self.switch_count = 0
        self.energy = 0.0
        self.logs = []
        return self.observe()

    def apply_and_step(self, target_cluster: int, protocol: int) -> None:
        if self.t >= self.HORIZON:
            return

        t = self.t
        for i, amount in enumerate(self.arrivals[t]):
            if amount <= 0:
                continue
            self.queues[i] += amount
            self.generated[i] += amount
            self.chunks[i].append([float(t), float(amount)])

        cluster = CLUSTERS[int(target_cluster)]["id"]
        target = cluster_centroid(cluster)
        to_target = dist((self.uav[0], self.uav[1]), target)
        move = min(UAV_SPEED * DT, to_target)
        if to_target > 1e-9:
            self.uav[0] += (target[0] - self.uav[0]) / to_target * move
            self.uav[1] += (target[1] - self.uav[1]) / to_target * move
        self.energy += 0.024 * move

        proto = self.PROTOCOL_NAMES[int(protocol)]
        selected = None
        for i, device in enumerate(self.devices):
            if self.queues[i] <= 0.02:
                continue
            d = dist((self.uav[0], self.uav[1]), (device["x"], device["y"]))
            deg = degradation_ms(device, t, self.perturbation, self.hotspot)
            rate, quality = link_rate(proto, d, deg)
            if rate <= 0.015:
                continue
            score = self.queues[i] * math.sqrt(rate) + 0.18 * self.blackout_streak[i]
            if device["cluster"] == cluster:
                score *= 1.55
            score -= 0.0012 * d
            if selected is None or score > selected[0]:
                selected = (score, i, rate, quality)

        served = [0.0] * N_DEVICES
        served_device = None
        selected_quality = 0.0
        selected_rate = 0.0
        if selected is not None:
            _, i, rate, quality = selected
            amount = min(self.queues[i], rate * DT)
            self.queues[i] -= amount
            self.delivered[i] += amount
            served[i] = amount
            served_device = i
            selected_quality = quality
            selected_rate = rate
            self.energy += amount * PROTOCOLS[proto]["energy"]
            consume_queue(self.chunks[i], amount, t, self.latencies[i])

            if self.previous_protocol and proto != self.previous_protocol:
                self.switch_count += 1
                self.energy += 0.18
            self.previous_protocol = proto

        for i in range(N_DEVICES):
            if self.queues[i] > 0.05 and served[i] <= 1e-12:
                self.blackout_streak[i] += 1
            else:
                self.blackout_streak[i] = 0
            self.max_blackout[i] = max(self.max_blackout[i], self.blackout_streak[i])

        hot_indices = [i for i, d in enumerate(self.devices) if d["cluster"] == self.hotspot]
        self.logs.append({
            "t": t,
            "hot_backlog": round(sum(self.queues[i] for i in hot_indices), 5),
            "hot_blackout_streak": max(self.blackout_streak[i] for i in hot_indices),
            "served_device": served_device,
            "served_cluster": self.devices[served_device]["cluster"] if served_device is not None else "",
            "protocol": proto if served_device is not None else "idle",
            "link_quality": round(selected_quality, 5),
            "service_rate": round(selected_rate, 5),
            "queue_total": round(sum(self.queues), 5),
            "energy": round(self.energy, 5),
        })
        self.t += 1

    def observe(self) -> np.ndarray:
        cluster_backlog = []
        cluster_blackout = []
        for cluster in CLUSTERS:
            idx = [i for i, d in enumerate(self.devices) if d["cluster"] == cluster["id"]]
            cluster_backlog.append(sum(self.queues[i] for i in idx) / 100.0)
            cluster_blackout.append(max(self.blackout_streak[i] for i in idx) / self.HORIZON)
        return np.array([
            self.uav[0] / 1000.0,
            self.uav[1] / 1000.0,
            *cluster_backlog,
            *cluster_blackout,
            self.t / self.HORIZON,
            self.energy / 250.0,
        ], dtype=np.float32)

    def metrics(self) -> dict:
        device_pdr = [
            (self.delivered[i] / self.generated[i]) if self.generated[i] > 1e-9 else 1.0
            for i in range(N_DEVICES)
        ]
        device_p95 = [weighted_percentile(self.latencies[i], 0.95) for i in range(N_DEVICES)]
        for i, value in enumerate(device_p95):
            if math.isinf(value):
                device_p95[i] = float(T)

        th = CONTRACT["qos_thresholds"]
        qsr_pass = [
            device_pdr[i] >= th["device_pdr_min"]
            and device_p95[i] <= th["device_p95_latency_max_slots"]
            and self.max_blackout[i] <= th["device_max_blackout_max_slots"]
            for i in range(N_DEVICES)
        ]
        recovery_time = T - PERTURB_START + 1
        for t in range(PERTURB_START, T - RECOVERY_HOLD):
            window = self.logs[t:t + RECOVERY_HOLD]
            if len(window) == RECOVERY_HOLD and all(
                row["hot_backlog"] <= 18.0 and row["hot_blackout_streak"] <= 16
                for row in window
            ):
                recovery_time = t - PERTURB_START + 1
                break

        p95_all = weighted_percentile([x for values in self.latencies for x in values], 0.95)
        if math.isinf(p95_all):
            p95_all = float(T)
        qsr = sum(1 for ok in qsr_pass if ok) / N_DEVICES
        pc = CONTRACT["promotion_criteria"]
        contract_pass = (
            qsr >= pc["qsr_min"]
            and max(self.max_blackout) <= pc["max_blackout_max_slots"]
            and recovery_time <= pc["recovery_time_max_slots"]
        )
        return {
            "qsr": float(qsr),
            "contract_pass": bool(contract_pass),
            "recovery": float(recovery_time),
            "max_blackout": float(max(self.max_blackout)),
            "p95_latency": float(p95_all),
            "pdr": float(sum(self.delivered) / sum(self.generated)),
            "energy_used": float(self.energy),
            "switch_count": int(self.switch_count),
        }


# --------------------------------------------------------------------------- #
# 2. Gym wrapper (complete).
# --------------------------------------------------------------------------- #
class UAVIoTEnv(gym.Env):
    """Action = (target cluster, protocol). Reward mirrors the promotion-score
    shaping per slot, with the contract bonus granted terminally (eq. 14)."""

    OBS_DIM = 10

    def __init__(self, hotspot="east", seeds=range(30), burst_scale=3.3):
        super().__init__()
        self.seeds, self.hotspot, self.burst_scale = list(seeds), hotspot, burst_scale
        self.action_space = spaces.MultiDiscrete(
            [SimAdapter.N_CLUSTERS, SimAdapter.N_PROTOCOLS])
        self.observation_space = spaces.Box(-np.inf, np.inf, (self.OBS_DIM,), np.float32)
        self._ep = 0
        self.adapter = None

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        s = self.seeds[self._ep % len(self.seeds)]
        self._ep += 1
        self.adapter = SimAdapter(self.hotspot, s, self.burst_scale)
        self._t = 0
        return self.adapter.reset().astype(np.float32), {}

    def step(self, action):
        cluster, proto = int(action[0]), int(action[1])
        prev = self._slot_cost()
        self.adapter.apply_and_step(cluster, proto)
        self._t += 1
        obs = self.adapter.observe().astype(np.float32)
        reward = prev - self._slot_cost()          # backlog/blackout decrease
        terminated = self._t >= SimAdapter.HORIZON
        if terminated:
            m = self.adapter.metrics()
            reward += 105 * m["qsr"] + 12 * float(m["contract_pass"]) \
                      - 0.22 * m["recovery"] - 0.36 * m["max_blackout"]
        return obs, float(reward), terminated, False, {}

    def _slot_cost(self):
        o = self.adapter.observe()
        return float(o[2:5].sum() + o[5:8].sum())   # backlog + blackout channels


# --------------------------------------------------------------------------- #
# 3. Train on east, freeze, evaluate on moved hotspots (complete).
# --------------------------------------------------------------------------- #
def evaluate(model, hotspot, seeds, burst_scale):
    rows = []
    for s in seeds:
        env = UAVIoTEnv(hotspot, [s], burst_scale)
        obs, _ = env.reset()
        done = False
        while not done:
            act, _ = model.predict(obs, deterministic=True)
            obs, _, done, _, _ = env.step(act)
        m = env.adapter.metrics()
        m.update(hotspot=hotspot, seed=s)
        rows.append(m)
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--timesteps", type=int, default=2_000_000)
    ap.add_argument("--burst-scale", type=float, default=3.3)
    ap.add_argument("--out", default="drl_baseline_results.csv")
    ap.add_argument("--model-out", default="ppo_uav_iot_east")
    ap.add_argument("--verbose", type=int, default=1)
    ap.add_argument("--smoke-test", action="store_true",
                    help="run one deterministic rollout without importing PPO")
    a = ap.parse_args()

    if a.smoke_test:
        env = UAVIoTEnv("east", [1], a.burst_scale)
        obs, _ = env.reset()
        done = False
        while not done:
            act = np.array([1, 2], dtype=np.int64)  # east hotspot, cellular-like
            obs, _, done, _, _ = env.step(act)
        print(pd.DataFrame([env.adapter.metrics()]).round(3))
        return

    from stable_baselines3 import PPO
    train_env = UAVIoTEnv("east", range(30), a.burst_scale)
    model = PPO("MlpPolicy", train_env, verbose=a.verbose, seed=0,
                n_steps=2048, batch_size=256, gamma=0.999)
    model.learn(total_timesteps=a.timesteps)
    model.save(a.model_out)

    rows = []
    rows += evaluate(model, "east", range(30), a.burst_scale)    # fit check
    rows += evaluate(model, "west", range(10), a.burst_scale)    # frozen transfer
    rows += evaluate(model, "north", range(10), a.burst_scale)
    df = pd.DataFrame(rows)
    df.to_csv(a.out, index=False)
    print(df.groupby("hotspot")
            .agg(pass_rate=("contract_pass", "mean"), mean_qsr=("qsr", "mean"),
                 mean_recovery=("recovery", "mean")).round(3))
    print(f"\nwrote {a.out} -- add as 'Learned (PPO, frozen)' row to Table V "
          "and to the known-stress check (Table VI).")


if __name__ == "__main__":
    main()
