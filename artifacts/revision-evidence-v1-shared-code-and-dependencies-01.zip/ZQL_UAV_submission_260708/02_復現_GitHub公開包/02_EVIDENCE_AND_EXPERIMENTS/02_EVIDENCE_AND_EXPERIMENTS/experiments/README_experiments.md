# Experiment Reproducibility Index

This folder contains the simulation, replay caches, post-processing scripts, and
source CSVs used by the UAV-IoT validated-recoverability paper.  The manuscript
uses controlled simulation evidence, public-trace anchoring, and an ns-3 sanity
check; it does not claim hardware flight validation.

## Main Workflow Experiment

Location: `uav_iot_workflow/`

- `run_uav_iot_workflow_experiment.py` runs the canonical one-UAV,
  30-device burst-and-degradation experiment and writes:
  - `results/summary_metrics.csv`
  - `results/aggregate_metrics.csv`
  - `results/per_device_metrics.csv`
  - case-study policies, CASP packages, candidate records, and figures
- These files back the controlled stress-test table, capability evidence table,
  case-study plots, and threshold-sensitivity post-processing.

## Repair-Backend Ablation

Location: `uav_iot_workflow/`

- `run_hybrid_ablation.py` compares the scripted no-LLM CASP reference, pure
  Qwen-Plus repair, and the hybrid LLM-structure plus bounded-search backend.
- The manuscript's `CASP (LLM + bounded)` row is the `hybrid` backend in
  `results/hybrid_ablation_per_seed.csv`; legacy aggregate files do not contain
  this main row.
- `run_llm_ablation.py` reruns a selected live/replay LLM backend through the
  full workflow.
- LLM responses are cached under `results/llm_cache*.jsonl`; candidate records
  and CASP JSON files record the parsed repair actions and clamp notes.
- The manuscript reports aggregate Qwen rows from replayed/cached runs rather
  than requiring a fresh API call to reproduce the table values.

## Moved-Hotspot Generalization

Location: `uav_iot_workflow/`

- `multiscenario.py` contains the deterministic moved-hotspot simulator and
  diagnosis-driven reference logic.
- `run_multiscenario_llm.py` evaluates live/replay Qwen-Plus localization from
  per-cluster evidence and writes:
  - `results/multiscenario_100seed_summary.csv`
  - `results/multiscenario_llm_30seed_per_seed.csv`
  - `results/multiscenario_llm_30seed_summary.csv`
- These files back the moved-hotspot contract-pass table and the 299/300
  localization statement. The LLM summary filename is legacy; the current rows
  contain `n=100` per hotspot when run with `UAV_MULTI_LLM_N=100`.

## PPO Baseline

Location: `drl_baseline_ppo.py`

- Trains PPO on the canonical east-hotspot stress and evaluates the frozen
  policy on east, west, and north hotspots.
- Output used by the manuscript:
  - `uav_iot_workflow/results/ppo_4m.csv`
- `uav_iot_workflow/results/drl_baseline_results_2m.csv` is retained as an
  earlier exploratory run and is not the manuscript row.
- Seed counts are intentionally explicit in the paper: east uses 30 evaluation
  seeds; west and north use 10 each.

## Contract-Threshold Sensitivity

Location: `bthr_sensitivity_sweep.py`

- Recomputes contract pass rates from `per_device_metrics.csv` and
  `summary_metrics.csv` without rerunning the simulator.
- Output used by the limitations discussion:
  - `uav_iot_workflow/results/bthr_sweep_results_exact.csv`
  - `uav_iot_workflow/results/bthr_sweep_plot_exact.png`

## Public-Trace And ns-3 Anchors

- `real_trace_anchor/` contains AERPAW and LoRaWAN extraction scripts, raw-data
  notes, derived metrics, and trace-anchor figures.
- `ns3_sanity_check/` contains the ns-3.47 link sanity-check source and the
  reduced target-hotspot mini replay, with raw outputs, summary JSON files, and
  plots.  The shared Windows install used by the runners is
  `D:\tools\ns3\ns-allinone-3.47\ns-3.47`; override `NS3_ROOT` if another
  ns-3.47 tree should be used.

## Boundary

The current manuscript does not require unsupported layout or burst-intensity
claims.  When adding a new table, add both the script and the source CSV/cache
here before putting the result in the paper.
