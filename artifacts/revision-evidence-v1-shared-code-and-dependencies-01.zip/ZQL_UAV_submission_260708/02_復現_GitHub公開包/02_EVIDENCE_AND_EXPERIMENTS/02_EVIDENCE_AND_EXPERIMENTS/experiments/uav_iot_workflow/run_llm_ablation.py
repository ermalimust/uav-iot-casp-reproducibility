#!/usr/bin/env python3
"""
One-command runner for the repair-backend ablation:

        scripted CASP reference  vs.  LLM repair agent

It (1) enables the LLM method, (2) runs the full experiment, then
(3) prints a side-by-side comparison of the scripted CASP reference workflow
versus the LLM-agent workflow, plus the fraction of agent actions accepted
versus clamped and which backend actually answered (live / replay / offline).

------------------------------------------------------------------------------
HOW TO RUN  (do these in a terminal, in this folder)
------------------------------------------------------------------------------
Step 0 (once):  pip install pillow

Pick ONE backend and set its keys, then run `python run_llm_ablation.py`.

Windows PowerShell -- Claude:
    $env:UAV_LLM_PROVIDER   = "anthropic"
    $env:ANTHROPIC_API_KEY  = "sk-ant-..."          # from console.anthropic.com
    $env:UAV_LLM_MODEL      = "claude-sonnet-4-6"    # optional
    python run_llm_ablation.py

Windows PowerShell -- Qwen / Alibaba DashScope (OpenAI-compatible):
    $env:UAV_LLM_PROVIDER = "openai"
    $env:OPENAI_API_KEY   = "sk-..."                 # DashScope/Bailian key
    $env:OPENAI_BASE_URL  = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    $env:UAV_LLM_MODEL    = "qwen2.5-coder-32b-instruct"
    python run_llm_ablation.py

macOS/Linux -- Claude (use `export` instead of `$env:`):
    export UAV_LLM_PROVIDER=anthropic
    export ANTHROPIC_API_KEY=sk-ant-...
    python3 run_llm_ablation.py

Notes:
  * The first run makes ~30-90 API calls (1-3 per seed) and may take a few
    minutes. Every prompt/response is cached to results/llm_cache.jsonl, so
    re-running is fast, free, and reproducible (mode = "replay").
  * If NO key is set, the LLM step falls back to a deterministic synthetic
    offline mode. That is NOT a real LLM result; this script will warn you.
  * After it finishes, use the printed rows as the repair-backend ablation
    summary.
"""
from __future__ import annotations

import csv
import json
import os
import statistics
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"

SCRIPTED_CASP_REFERENCE = "full_closed_loop_workflow"
LLM = "full_closed_loop_workflow_llm"


def preflight() -> None:
    prov = os.environ.get("UAV_LLM_PROVIDER", "auto")
    has_anthropic = bool(os.environ.get("ANTHROPIC_API_KEY"))
    has_openai = bool(os.environ.get("OPENAI_API_KEY"))
    print("=" * 64)
    print("Repair-backend ablation: scripted CASP reference vs. LLM agent")
    print("=" * 64)
    print(f"  UAV_LLM_PROVIDER = {prov}")
    print(f"  ANTHROPIC_API_KEY set = {has_anthropic}")
    print(f"  OPENAI_API_KEY set    = {has_openai}")
    if not (has_anthropic or has_openai) and prov not in ("offline",):
        print("\n  [!] No API key detected. The LLM step will fall back to the")
        print("      synthetic offline mode, which is NOT a real LLM result. Set a key")
        print("      (see the header of this file) to get genuine LLM numbers.\n")
    print()


def run_experiment() -> None:
    os.environ["UAV_ENABLE_LLM_METHOD"] = "1"
    import run_uav_iot_workflow_experiment as exp  # noqa: WPS433
    exp.main()


def _agg(rows: list[dict], method: str) -> dict | None:
    sub = [r for r in rows if r["method"] == method]
    if not sub:
        return None
    m = lambda k: statistics.mean(float(r[k]) for r in sub)  # noqa: E731
    sd = lambda k: (statistics.stdev(float(r[k]) for r in sub) if len(sub) > 1 else 0.0)  # noqa: E731
    passrate = statistics.mean(1.0 if r["passed_contract"] == "True" else 0.0 for r in sub)
    return {
        "n": len(sub), "qsr": m("qsr"), "qsr_sd": sd("qsr"),
        "rec": m("recovery_time"), "blk": m("max_blackout"),
        "p95": m("p95_latency"), "pass": passrate,
    }


def backend_breakdown() -> tuple[Counter, int, int]:
    """Which backend answered, and accepted-vs-clamped action counts (LLM only)."""
    modes: Counter = Counter()
    accepted = clamped = 0
    cand = RESULTS / "candidate_records.jsonl"
    if cand.exists():
        for line in cand.open(encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            if not str(r.get("candidate_id", "")).startswith("llm_"):
                continue
            io = r.get("agent_io", {})
            mode = io.get("mode", "?")
            ra = r.get("repair_action")
            if ra is not None:  # a repair iteration (not the nominal cand_0)
                modes[mode] += 1
                if ra.get("clamp_notes"):
                    clamped += 1
                else:
                    accepted += 1
    return modes, accepted, clamped


def report() -> None:
    summ = RESULTS / "summary_metrics.csv"
    if not summ.exists():
        print("No results/summary_metrics.csv found -- did the run finish?")
        return
    rows = list(csv.DictReader(summ.open(encoding="utf-8")))
    scripted = _agg(rows, SCRIPTED_CASP_REFERENCE)
    llm = _agg(rows, LLM)

    print("\n" + "=" * 64)
    print("RESULT: full workflow -- scripted CASP reference vs. LLM agent")
    print("=" * 64)
    hdr = f"{'backend':<22}{'n':>3}{'QSR':>8}{'recov':>8}{'blackout':>10}{'p95':>8}{'pass':>7}"
    print(hdr)
    print("-" * len(hdr))

    def line(name: str, a: dict | None) -> None:
        if a is None:
            print(f"{name:<22}{'  (no rows -- not run)':>0}")
            return
        print(f"{name:<22}{a['n']:>3}{a['qsr']:>8.3f}{a['rec']:>8.2f}"
              f"{a['blk']:>10.2f}{a['p95']:>8.2f}{a['pass']:>7.2f}")

    line("scripted CASP", scripted)
    line("LLM agent", llm)

    modes, accepted, clamped = backend_breakdown()
    print("\nLLM backend that answered (repair iterations):",
          dict(modes) if modes else "n/a")
    total = accepted + clamped
    if total:
        print(f"agent actions: accepted-as-is = {accepted}/{total} "
              f"({accepted / total:.0%}), clamped = {clamped}/{total} "
              f"({clamped / total:.0%})")
    if modes and all(str(mode).startswith("offline_") or mode == "no_repair" for mode in modes):
        print("\n[!] These LLM rows came from the synthetic offline mode, not a real model.")
        print("    Set an API key and delete results/llm_cache.jsonl, then re-run.")

    if scripted and llm:
        d = llm["pass"] - scripted["pass"]
        print(f"\nContract pass-rate delta (LLM - scripted CASP): {d:+.2f}")
    print("\nUse these two rows as the repair-backend ablation summary.")
    print("Per-seed agent traces: results/llm_candidate_records_seed_*.json")
    print("Reproducible prompt/response cache: results/llm_cache.jsonl")


if __name__ == "__main__":
    preflight()
    run_experiment()
    report()
