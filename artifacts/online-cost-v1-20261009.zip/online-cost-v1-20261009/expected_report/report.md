# Current online repair-loop cost

Prespecified 12-task current cost illustration; no new effectiveness comparison or population tail guarantee

| Measured interval | n | Median (s) | Sample p95 (s) | Range (s) |
|---|---:|---:|---:|---:|
| Request/response | 12 | 2.346 | 2.777 | 2.069–2.845 |
| Local stages | 12 | 3.824 | 4.107 | 1.003–4.219 |
| Numerical calibration | 12 | 3.742 | 4.021 | 0.922–4.130 |
| Diagnosis to promotion | 12 | 6.268 | 7.128 | 3.695–7.298 |
| Worker startup to exit | 12 | 6.747 | 7.543 | 4.121–7.675 |

Includes online request and request/response persistence; excludes worker startup/preparation and final cell-artifact writing.

Transport call, including request encoding/construction, verified direct connection, service/generation and response transfer/handling; not pure model compute.

Actual numerical/nominal simulator calls: 759 + 12 = 771. Twelve requests, zero retries/probes. Reported tokens: 3871 prompt + 1053 completion = 4924 total. No monetary bill is inferred.
