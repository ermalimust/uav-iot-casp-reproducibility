#!/usr/bin/env python3
"""
Multi-scenario generalization test (experiment B).

Question: does a hand-tuned frozen east-scripted repair generalize to UNSEEN
hotspot locations? And does a diagnosis-driven repair (the regime the LLM
operates in)?

We build scenario variants by MOVING the burst+degradation hotspot to different
clusters, then compare two deterministic repair strategies (no API key needed):

  * frozen east script -- always repairs the EAST hotspot (the location it was
                          hand-tuned for), regardless of where the failure is.
  * diagnosis-driven   -- repairs whichever cluster the diagnosis flags as the
                          failing region (the same good repair, pointed correctly).

The frozen east-scripted repair is expected to do well only when the hotspot is
where it was tuned (east) and collapse elsewhere; the diagnosis-driven repair
should hold up across locations. The LLM is one instance of diagnosis-driven
repair, so this isolates exactly the capability the LLM contributes: adapting
the repair to the ACTUAL diagnosed failure rather than a pre-encoded one.

Run:  python multiscenario.py
"""
from __future__ import annotations

import math
import os
import random
import statistics
import csv
from collections import deque
from pathlib import Path

from run_uav_iot_workflow_experiment import (
    AREA, CLUSTERS, CONTRACT, DT, N_DEVICES, PERTURB_END, PERTURB_START,
    PROTOCOLS, RECOVERY_HOLD, T, UAV_SPEED, UAV_START,
    build_full_policy, clamp, cluster_centroid, consume_queue, dist,
    is_burst_active, link_rate, route_policy, select_protocol, sigmoid,
    weighted_percentile,
)

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


# --------------------------------------------------------------------------
# Parameterized scenario: the hotspot (burst + degradation) can be any cluster
# --------------------------------------------------------------------------
def make_devices_ms(seed: int, hot: str) -> list[dict]:
    rng = random.Random(seed * 7919 + 13)
    devices = []
    for ci, cluster in enumerate(CLUSTERS):
        cx, cy = cluster["centroid"]
        for li in range(10):
            did = ci * 10 + li
            x = clamp(cx + rng.gauss(0.0, 48.0), 40.0, AREA - 40.0)
            y = clamp(cy + rng.gauss(0.0, 48.0), 40.0, AREA - 40.0)
            base = 0.032 + 0.014 * rng.random()
            if cluster["id"] == hot:
                base += 0.006 + 0.006 * rng.random()
            devices.append({"id": did, "cluster": cluster["id"],
                            "x": x, "y": y, "base_arrival": base})
    return devices


def degradation_ms(device: dict, t: int, perturbation: bool, hot: str) -> float:
    if not perturbation or not (PERTURB_START <= t <= T):
        return 0.0
    if device["cluster"] != hot:
        return 0.0
    center = cluster_centroid(hot)
    d = dist((device["x"], device["y"]), center)
    return clamp(0.78 * sigmoid((235.0 - d) / 45.0), 0.0, 0.78)


def make_scenario_ms(seed: int, perturbation: bool, hot: str) -> dict:
    devices = make_devices_ms(seed, hot)
    rng = random.Random(seed * 12289 + (97 if perturbation else 31))
    arrivals = []
    for t in range(T):
        row = []
        for dev in devices:
            noise = 0.72 + 0.56 * rng.random()
            a = dev["base_arrival"] * noise
            if is_burst_active(t, perturbation) and dev["cluster"] == hot:
                a *= 3.30 + 0.25 * math.sin((t - PERTURB_START) / 9.0)
            row.append(a)
        arrivals.append(row)
    return {"seed": seed, "devices": devices, "arrivals": arrivals,
            "perturbation": perturbation, "hot": hot}


# --------------------------------------------------------------------------
# Parameterized simulator (adapted from simulate_policy; hotspot-generic)
# --------------------------------------------------------------------------
def simulate_ms(scenario: dict, policy: dict) -> dict:
    devices = scenario["devices"]; arrivals = scenario["arrivals"]
    perturbation = bool(scenario["perturbation"]); hot = scenario["hot"]
    queues = [0.0] * N_DEVICES; chunks = [deque() for _ in range(N_DEVICES)]
    generated = [0.0] * N_DEVICES; delivered = [0.0] * N_DEVICES
    latencies: list[list] = [[] for _ in range(N_DEVICES)]
    blackout_streak = [0] * N_DEVICES; max_blackout = [0] * N_DEVICES
    uav = [UAV_START[0], UAV_START[1]]; route_index = 0; dwell_used = 0
    trigger_hold = 0; trigger_cooldown = 0; previous_protocol = None
    protocol_hold_remaining = 0; switch_count = 0; energy = 0.0; logs = []
    peak_backlog = {c["id"]: 0.0 for c in CLUSTERS}

    for t in range(T):
        for i, amount in enumerate(arrivals[t]):
            if amount <= 0:
                continue
            queues[i] += amount; generated[i] += amount
            chunks[i].append([float(t), float(amount)])
        cluster_backlog = {c["id"]: sum(queues[i] for i in range(N_DEVICES)
                                        if devices[i]["cluster"] == c["id"]) for c in CLUSTERS}
        cluster_blackout = {c["id"]: max(blackout_streak[i] for i in range(N_DEVICES)
                                         if devices[i]["cluster"] == c["id"]) for c in CLUSTERS}
        if perturbation and t >= PERTURB_START:
            for c in CLUSTERS:
                peak_backlog[c["id"]] = max(peak_backlog[c["id"]], cluster_backlog[c["id"]])
        trigger_active = False; trigger_cfg = policy.get("local_triggers")
        if trigger_cfg:
            if trigger_cooldown > 0:
                trigger_cooldown -= 1
            cid = trigger_cfg["cluster"]
            should = (cluster_backlog[cid] >= trigger_cfg["queue_threshold"]
                      or cluster_blackout[cid] >= trigger_cfg["max_blackout_threshold_slots"])
            if should and trigger_hold <= 0 and trigger_cooldown <= 0:
                trigger_hold = max(trigger_hold, int(trigger_cfg["fallback_dwell_min_slots"]))
            if cluster_backlog[cid] <= trigger_cfg["release_threshold"] and trigger_hold <= 0:
                trigger_hold = 0
            trigger_active = trigger_hold > 0

        if trigger_active and trigger_cfg:
            target = tuple(trigger_cfg["fallback_waypoint"]); target_label = "casp_fallback"
            trigger_hold -= 1
            if trigger_hold <= 0:
                trigger_cooldown = int(trigger_cfg.get("cooldown_slots", 0))
        else:
            route = policy["route"]; wp = route[route_index]
            target = tuple(wp["xy"]); target_label = wp["cluster"]
            if dist((uav[0], uav[1]), target) <= 10.0:
                if dwell_used < int(wp["dwell"]):
                    dwell_used += 1
                else:
                    route_index = (route_index + 1) % len(route); dwell_used = 0
                    wp = route[route_index]; target = tuple(wp["xy"]); target_label = wp["cluster"]

        to_target = dist((uav[0], uav[1]), target); move = min(UAV_SPEED * DT, to_target)
        if to_target > 1e-9:
            uav[0] += (target[0] - uav[0]) / to_target * move
            uav[1] += (target[1] - uav[1]) / to_target * move
        energy += 0.024 * move

        selected = None
        for i, device in enumerate(devices):
            if queues[i] <= 0.02:
                continue
            d = dist((uav[0], uav[1]), (device["x"], device["y"]))
            deg = degradation_ms(device, t, perturbation, hot)
            protocol = select_protocol(policy["protocol_mode"], d, deg,
                                       previous_protocol, protocol_hold_remaining)
            rate, quality = link_rate(protocol, d, deg)
            if rate <= 0.015:
                continue
            score = queues[i] * math.sqrt(rate) + 0.18 * blackout_streak[i]
            if target_label in {device["cluster"], "casp_fallback"}:
                if target_label == "casp_fallback" and device["cluster"] == hot:
                    score *= 3.00
                elif target_label == "casp_fallback":
                    score *= 0.55
                elif target_label == device["cluster"]:
                    score *= 1.55
            score -= 0.0012 * d
            if selected is None or score > selected[0]:
                selected = (score, i, protocol, rate, quality)

        served = [0.0] * N_DEVICES; sel_proto = None
        if selected is not None:
            _, i, protocol, rate, quality = selected
            amount = min(queues[i], rate * DT)
            queues[i] -= amount; delivered[i] += amount; served[i] = amount
            sel_proto = protocol
            energy += amount * PROTOCOLS[protocol]["energy"]
            consume_queue(chunks[i], amount, t, latencies[i])
        if sel_proto:
            if previous_protocol and sel_proto != previous_protocol:
                switch_count += 1; energy += 0.18
                protocol_hold_remaining = int(policy.get("min_protocol_hold_slots", 0))
            previous_protocol = sel_proto
        if protocol_hold_remaining > 0:
            protocol_hold_remaining -= 1

        for i in range(N_DEVICES):
            if queues[i] > 0.05 and served[i] <= 1e-12:
                blackout_streak[i] += 1
            else:
                blackout_streak[i] = 0
            max_blackout[i] = max(max_blackout[i], blackout_streak[i])

        logs.append({
            "t": t,
            "hot_backlog": round(cluster_backlog[hot], 5),
            "hot_blackout_streak": max(blackout_streak[i] for i in range(N_DEVICES)
                                       if devices[i]["cluster"] == hot),
        })

    device_pdr = [(delivered[i] / generated[i]) if generated[i] > 1e-9 else 1.0
                  for i in range(N_DEVICES)]
    device_p95 = [weighted_percentile(latencies[i], 0.95) for i in range(N_DEVICES)]
    for i, v in enumerate(device_p95):
        if math.isinf(v):
            device_p95[i] = float(T)
    th = CONTRACT["qos_thresholds"]
    qsr_pass = [device_pdr[i] >= th["device_pdr_min"]
                and device_p95[i] <= th["device_p95_latency_max_slots"]
                and max_blackout[i] <= th["device_max_blackout_max_slots"]
                for i in range(N_DEVICES)]
    recovery_time = T - PERTURB_START + 1
    for t in range(PERTURB_START, T - RECOVERY_HOLD):
        if all(r["hot_backlog"] <= 18.0 and r["hot_blackout_streak"] <= 16
               for r in logs[t:t + RECOVERY_HOLD]):
            recovery_time = t - PERTURB_START + 1
            break
    p95_all = weighted_percentile([x for dv in latencies for x in dv], 0.95)
    if math.isinf(p95_all):
        p95_all = float(T)
    qsr = sum(1 for x in qsr_pass if x) / N_DEVICES
    pc = CONTRACT["promotion_criteria"]
    passed = (qsr >= pc["qsr_min"] and max(max_blackout) <= pc["max_blackout_max_slots"]
              and recovery_time <= pc["recovery_time_max_slots"])
    return {"metrics": {"qsr": qsr, "recovery_time": recovery_time,
                        "max_blackout": max(max_blackout), "p95_latency": p95_all,
                        "passed_contract": passed},
            "device_max_blackout": max_blackout, "peak_backlog": peak_backlog}


# --------------------------------------------------------------------------
# Generic diagnosis + diagnosis-driven repair
# --------------------------------------------------------------------------
def diagnose_ms(scenario: dict, result: dict) -> str:
    """Return the failing region: the cluster with the largest peak backlog
    after the perturbation (the burst cluster accumulates the most demand)."""
    pb = result["peak_backlog"]
    return max(pb, key=pb.get)


def build_repair_for(cluster: str) -> dict:
    """The same east-scripted repair pattern, but pointed at `cluster`."""
    others = [c["id"] for c in CLUSTERS if c["id"] != cluster]
    route = [others[0], cluster, others[1], cluster]  # visit the hotspot twice
    pol = route_policy("diag_repair", route, [8, 16, 8, 14], "degraded_aware")
    pol["min_protocol_hold_slots"] = 4
    pol["local_triggers"] = {
        "cluster": cluster, "queue_threshold": 18.0, "release_threshold": 10.0,
        "max_blackout_threshold_slots": 16,
        "fallback_waypoint": list(cluster_centroid(cluster)),
        "fallback_dwell_min_slots": 3, "cooldown_slots": 16,
    }
    return pol


def calibrate_ms(scenario: dict, cluster: str) -> dict:
    """Diagnosis-driven repair plus a small bounded search over route order and
    thresholds for the diagnosed cluster (the adaptive method used in B)."""
    others = [c["id"] for c in CLUSTERS if c["id"] != cluster]
    templates = [[others[0], cluster, others[1], cluster],
                 [cluster, others[0], cluster, others[1]],
                 [cluster, others[0], others[1], cluster]]
    best = None
    for route in templates:
        for d2 in (16, 22):
            for b in (12, 16):
                dwell = [(d2 if c == cluster else 8) for c in route]
                pol = route_policy("adapt", route, dwell, "degraded_aware")
                pol["min_protocol_hold_slots"] = 4
                pol["local_triggers"] = {
                    "cluster": cluster, "queue_threshold": 18.0, "release_threshold": 10.0,
                    "max_blackout_threshold_slots": b,
                    "fallback_waypoint": list(cluster_centroid(cluster)),
                    "fallback_dwell_min_slots": 3, "cooldown_slots": 16}
                res = simulate_ms(scenario, pol)
                m = res["metrics"]
                key = (1 if m["passed_contract"] else 0, -m["recovery_time"],
                       -m["max_blackout"], m["qsr"])
                if best is None or key > best[0]:
                    best = (key, res)
    return best[1]


# --------------------------------------------------------------------------
# Experiment
# --------------------------------------------------------------------------
def _passrate(results: list[dict]) -> float:
    return statistics.mean(1.0 if r["metrics"]["passed_contract"] else 0.0 for r in results)


def main() -> None:
    scenarios = ["east_hotspot", "west_cluster", "north_cluster"]
    seeds = list(range(1, int(os.environ.get("UAV_MULTI_N", "30")) + 1))
    nominal = route_policy("nom", ["west_cluster", "east_hotspot", "north_cluster"],
                           [12, 12, 12], "best_rate")
    print("=" * 70)
    print("Multi-scenario generalization (B): frozen scripted repair vs. diagnosis-driven")
    print("=" * 70)
    print(f"{len(seeds)} seeds per scenario. Frozen scripted repair is tuned for east_hotspot.\n")
    hdr = (
        f"{'hotspot location':<18}{'frozen pass':>14}"
        f"{'calib-only pass':>18}{'diagnosis-driven pass':>23}"
    )
    print(hdr); print("-" * len(hdr))
    rows = []
    for hot in scenarios:
        frozen, calib_only, diag, detected = [], [], [], []
        for s in seeds:
            sc = make_scenario_ms(s, True, hot)
            frozen.append(simulate_ms(sc, build_full_policy()))
            calib_only.append(calibrate_ms(sc, "east_hotspot"))
            d = diagnose_ms(sc, simulate_ms(sc, nominal))
            detected.append(d)
            diag.append(calibrate_ms(sc, d))
        fr, ca, dg = _passrate(frozen), _passrate(calib_only), _passrate(diag)
        hit = sum(1 for d in detected if d == hot)
        rows.append({
            "hotspot": hot,
            "n": len(seeds),
            "frozen_pass": fr,
            "calib_only_pass": ca,
            "diag_max_backlog_pass": dg,
            "diagnosis_hits": hit,
        })
        print(f"{hot:<18}{fr:>14.2f}{ca:>18.2f}{dg:>23.2f}   (diagnosis hit {hit}/{len(seeds)})")
    RESULTS.mkdir(parents=True, exist_ok=True)
    outp = RESULTS / f"multiscenario_{len(seeds)}seed_summary.csv"
    with outp.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print("\nReading: the frozen scripted repair only works where it was tuned (east);")
    print("the diagnosis-driven repair adapts to the actual failing region.")
    print(f"Wrote {outp}")


if __name__ == "__main__":
    main()
