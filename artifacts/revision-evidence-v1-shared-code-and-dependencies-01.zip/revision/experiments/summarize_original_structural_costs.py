"""Pure descriptive statistics for separately measured original structural costs.

This module never imports a runner, simulator, scenario generator, configuration,
or model client. It reads saved measurements only. Historical network latency is
unknown, and must not be replaced with cached-response lookup or local duration.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping


VERSION = 'original-structural-cost-statistics-1'
QUANTILE_RULE = 'linear interpolation at sorted index (n - 1) * q (R type 7)'
METRICS = ('candidate_evaluations', 'method_seconds', 'peak_working_set_mib')
PAIRED_METRICS = ('candidate_evaluations', 'method_seconds')
METHODS = ('compact', 'compact_plus_expert', 'compact_plus_cached_model')
METHOD_LABELS = {'compact': 'Compact', 'compact_plus_expert': 'Compact + expert',
                 'compact_plus_cached_model': 'Compact + cached LLM'}


def number(value: Any, *, nonnegative: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError('Measurement must be a finite numeric value')
    value = float(value)
    if not math.isfinite(value) or (nonnegative and value < 0):
        raise ValueError('Measurement must be finite and within its domain')
    return value


def quantile(values: Iterable[float], q: float) -> float | None:
    """A declared interpolation rule; no nearest-rank or success filtering."""
    q = number(q)
    if not 0 <= q <= 1:
        raise ValueError('Quantile probability must be between zero and one')
    ordered = sorted(number(value) for value in values)
    if not ordered:
        return None
    index = (len(ordered) - 1) * q
    lo, hi = math.floor(index), math.ceil(index)
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (index - lo)


def numeric_summary(values: Iterable[float | None]) -> dict[str, Any]:
    observed = list(values)
    available = [number(value) for value in observed if value is not None]
    return {
        'n': len(available), 'missing_n': len(observed) - len(available),
        'total': math.fsum(available) if available else None,
        'min': min(available) if available else None,
        'mean': math.fsum(available) / len(available) if available else None,
        'median': quantile(available, 0.5), 'p95': quantile(available, 0.95),
        'max': max(available) if available else None,
    }


def normalized_cell(cell: Mapping[str, Any]) -> dict[str, Any]:
    """Validate the narrow statistical representation, not scientific provenance."""
    scenario, method = cell.get('scenario'), cell.get('method')
    seed = cell.get('seed')
    if not isinstance(scenario, str) or not scenario or not isinstance(method, str) or not method:
        raise ValueError('Scenario and method must be nonempty strings')
    if isinstance(seed, bool) or not isinstance(seed, int) or seed < 1:
        raise ValueError('Seed must be a positive integer')
    passed = cell.get('passed_contract')
    if passed is not None and type(passed) is not bool:
        raise ValueError('Saved passed_contract must be Boolean or unknown')
    output = dict(cell)
    for metric in METRICS:
        value = cell.get(metric)
        if value is not None:
            number(value, nonnegative=True)
    candidates = cell.get('candidate_evaluations')
    if candidates is not None and (type(candidates) is not int or candidates < 0):
        raise ValueError('Actual candidate evaluations must be a nonnegative integer')
    return output


def index_cells(cells: Iterable[Mapping[str, Any]]) -> dict[tuple[str, int, str], dict]:
    indexed = {}
    for cell in cells:
        cell = normalized_cell(cell)
        key = cell['scenario'], cell['seed'], cell['method']
        if key in indexed:
            raise ValueError(f'Duplicate measured cell: {key}')
        indexed[key] = cell
    return indexed


def summarize_cells(cells: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    """Retain service failures and unknown execution results in every denominator."""
    rows = list(index_cells(cells).values())
    result = {
        'cells': len(rows),
        'service_passes': sum(row.get('passed_contract') is True for row in rows),
        'service_failures': sum(row.get('passed_contract') is False for row in rows),
        'service_result_unknown': sum(row.get('passed_contract') is None for row in rows),
        'execution_status_counts': dict(Counter(row.get('execution_status', 'unknown') for row in rows)),
        **{metric: numeric_summary(row.get(metric) for row in rows) for metric in METRICS},
    }
    # Adding peaks from separate processes is not a system memory requirement.
    result['peak_working_set_mib'].pop('total')
    result['actual_simulator_calls_total'] = sum(row.get('actual_simulator_calls', 0) for row in rows)
    result['nominal_evaluations_total'] = sum(row.get('nominal_evaluations', 0) for row in rows)
    result['simulation_cache_hits_total'] = sum(row.get('simulation_cache_hits', 0) for row in rows)
    return result


def paired_increments(cells: Iterable[Mapping[str, Any]], baseline: str,
                      augmented: str) -> dict[str, Any]:
    """Pair by exact scenario/seed; negative timing deltas are retained as jitter."""
    if baseline == augmented:
        raise ValueError('Paired methods must differ')
    indexed = index_cells(cells)
    left = {(scenario, seed): row for (scenario, seed, method), row in indexed.items()
            if method == baseline}
    right = {(scenario, seed): row for (scenario, seed, method), row in indexed.items()
             if method == augmented}
    pairs = []
    for scenario, seed in sorted(left.keys() & right.keys()):
        base, extra = left[scenario, seed], right[scenario, seed]
        pair = {'scenario': scenario, 'seed': seed, 'baseline': baseline,
                'augmented': augmented, 'baseline_passed_contract': base.get('passed_contract'),
                'augmented_passed_contract': extra.get('passed_contract')}
        for metric in PAIRED_METRICS:
            a, b = base.get(metric), extra.get(metric)
            pair['delta_' + metric] = None if a is None or b is None else number(b) - number(a)
        pairs.append(pair)
    statistics = {}
    for metric in PAIRED_METRICS:
        values = [pair['delta_' + metric] for pair in pairs]
        statistics['delta_' + metric] = {
            **numeric_summary(values),
            'negative_n': sum(value is not None and value < 0 for value in values),
        }
    return {'baseline': baseline, 'augmented': augmented, 'n_pairs': len(pairs),
            'missing_baseline_tasks': [list(key) for key in sorted(right.keys() - left.keys())],
            'missing_augmented_tasks': [list(key) for key in sorted(left.keys() - right.keys())],
            'statistics': statistics, 'pairs': pairs}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8-sig'))


def adapt_measured_cell(saved: Mapping[str, Any], path: Path) -> dict[str, Any]:
    """Adapt the runner's saved schema; do not recompute outcomes or elapsed time."""
    if saved.get('status') != 'complete':
        raise ValueError(f'Only completed measurements can enter a final report: {path}')
    if saved.get('model_requests') != 0 or saved.get('online_model_request_seconds') is not None:
        raise ValueError(f'Unexpected model request accounting or invented latency: {path}')
    counts, timing, memory = saved['counts'], saved['timing'], saved['memory']
    for field in ('candidate_evaluations', 'nominal_evaluations', 'actual_simulator_calls',
                  'simulation_cache_hits'):
        value = counts[field]
        if type(value) is not int or value < 0:
            raise ValueError(f'Invalid measured integer {field}: {path}')
    if counts['simulation_cache_hits'] != 0:
        raise ValueError(f'Timed simulation caching was enabled: {path}')
    if counts['nominal_evaluations'] != 1:
        raise ValueError(f'Expected one nominal diagnosis replay in each worker: {path}')
    if counts['actual_simulator_calls'] != counts['candidate_evaluations'] + counts['nominal_evaluations']:
        raise ValueError(f'Actual simulator accounting differs: {path}')
    peak = number(memory['peak_working_set_bytes'], nonnegative=True)
    if peak == 0:
        raise ValueError(f'Absolute peak working set is not measured: {path}')
    method_seconds = number(timing['method_seconds'], nonnegative=True)
    phases = ('diagnosis_seconds', 'selector_seconds', 'calibration_seconds', 'promotion_seconds')
    if sum(number(timing[field], nonnegative=True) for field in phases) > method_seconds + 1e-6:
        raise ValueError(f'Exclusive measured phases exceed method time: {path}')
    cell = {'scenario': saved['scenario'], 'seed': saved['seed'], 'method': saved['method'],
            'passed_contract': saved['promotion']['metrics']['passed_contract'],
            'execution_status': saved['status'], 'candidate_evaluations': counts['candidate_evaluations'],
            'actual_simulator_calls': counts['actual_simulator_calls'],
            'nominal_evaluations': counts['nominal_evaluations'],
            'simulation_cache_hits': counts['simulation_cache_hits'],
            'method_seconds': method_seconds, 'peak_working_set_mib': peak / (1024 ** 2),
            'source_path': str(path.resolve()), 'source_sha256': sha256(path)}
    if cell['method'] not in METHODS:
        raise ValueError(f'Unknown measured method: {cell["method"]}')
    return normalized_cell(cell)


def load_measurements(run_root: Path) -> tuple[list[dict], dict]:
    root = run_root.resolve()
    manifest_path, completion_path = root / 'manifest.json', root / 'completion.json'
    manifest, completion = read_json(manifest_path), read_json(completion_path)
    if completion.get('status') != 'complete':
        raise ValueError('Final descriptive report requires a complete measurement run')
    if manifest.get('full_search') is not False or manifest.get('simulation_cache') is not False:
        raise ValueError('Unexpected timed scientific profile or simulation caching')
    if manifest.get('model_requests') != 0 or completion.get('model_requests') != 0:
        raise ValueError('This report only covers no-new-model-request replay measurements')
    if list(manifest['methods']) != list(METHODS):
        raise ValueError('Manifest method set/order differs from the measured comparison')
    paths = sorted((root / 'cells').glob('*.json'))
    observed_hashes = {str(path.relative_to(root)): sha256(path) for path in paths}
    if completion.get('cell_hashes') != observed_hashes:
        raise ValueError('Measured cell inventory/hash differs from final completion')
    if completion.get('source_hashes_after') != manifest.get('source_hashes'):
        raise ValueError('Bound scientific source hashes changed during measurement')
    cells = [adapt_measured_cell(read_json(path), path) for path in paths]
    indexed = index_cells(cells)
    expected = manifest['expected_cells']
    if type(expected) is not int or len(indexed) != expected or completion['completed_cells'] != expected:
        raise ValueError('Saved final cell count differs from manifest/completion')
    tasks = {(scenario, seed) for scenario, seed, _ in indexed}
    declared_tasks = [(task['scenario'], task['seed']) for task in manifest['tasks']]
    if len(set(declared_tasks)) != len(declared_tasks) or tasks != set(declared_tasks):
        raise ValueError('Measured task identities differ from the declared manifest')
    if len(cells) != len(tasks) * len(METHODS) or any(
            (scenario, seed, method) not in indexed for scenario, seed in tasks for method in METHODS):
        raise ValueError('Every saved task must have all three measured methods')
    metadata = {
        'run_root': str(root), 'manifest_sha256': sha256(manifest_path),
        'completion_sha256': sha256(completion_path), 'expected_cells': expected,
        'observed_tasks': len(tasks), 'machine': manifest.get('machine'),
        'source_hashes': manifest.get('source_hashes'),
        'source_hashes_after': completion.get('source_hashes_after'),
        'protocol_sha256': manifest.get('protocol_sha256'),
        'model_requests': 0, 'simulation_cache_hits': 0,
        'historical_llm_latency_seconds': None,
        'historical_llm_latency_status': 'not recorded in submitted response cache',
        'timing_scope': 'local method: diagnosis + selector + calibration + promotion; excludes worker preparation and post-method validation',
        'nested_simulator_timing': 'components of diagnosis/calibration; never added again to method total',
        'measurement_profile': 'instrumented local execution; nested replay duration includes policy recording wrapper overhead, not pure simulator CPU time',
        'memory_scope': 'absolute worker lifetime peak through validation, before artifact encoding; includes interpreter/import/preparation and is not a method memory increment',
        'cached_model_scope': 'saved response lookup/decoding only; HTTP/model generation latency is unavailable',
    }
    return cells, metadata


def build_summary(cells: Iterable[Mapping[str, Any]], metadata: Mapping[str, Any] | None = None) -> dict:
    rows = list(index_cells(cells).values())
    grouped, overall = defaultdict(list), defaultdict(list)
    for row in rows:
        grouped[row['scenario'], row['method']].append(row)
        overall[row['method']].append(row)
    scenarios = sorted({row['scenario'] for row in rows})
    by_scenario = {scenario: {method: summarize_cells(grouped[scenario, method])
                             for method in METHODS} for scenario in scenarios}
    comparisons = {method: paired_increments(rows, 'compact', method) for method in METHODS[1:]}
    paired_by_scenario = {
        scenario: {method: paired_increments([row for row in rows if row['scenario'] == scenario],
                                            'compact', method) for method in METHODS[1:]}
        for scenario in scenarios}
    return {'version': VERSION, 'quantile_rule': QUANTILE_RULE,
            'population': 'all completed worker cells, including service pass and service failure',
            'metadata': dict(metadata or {}), 'totals': summarize_cells(rows),
            'by_method': {method: summarize_cells(overall[method]) for method in METHODS},
            'by_scenario': by_scenario, 'paired_overall': comparisons,
            'paired_by_scenario': paired_by_scenario,
            'source_cells': [{key: row.get(key) for key in ('scenario', 'seed', 'method',
                                                          'source_path', 'source_sha256')} for row in rows]}


def flat_statistics(scenario: str, method: str, statistics: Mapping[str, Any]) -> dict:
    row = {'scenario': scenario, 'method': method}
    for key, value in statistics.items():
        if isinstance(value, dict):
            if key in METRICS:
                row.update({f'{key}_{stat}': item for stat, item in value.items()})
        else:
            row[key] = value
    return row


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError('Cannot emit an empty statistical table')
    fieldnames = list(dict.fromkeys(key for row in rows for key in row))
    with path.open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def fmt(value: float | None, digits: int = 3) -> str:
    return 'NA' if value is None else f'{value:.{digits}f}'


def median_p95(statistics: Mapping[str, Any], digits: int = 3) -> str:
    return f'{fmt(statistics["median"], digits)} / {fmt(statistics["p95"], digits)}'


def markdown_report(summary: Mapping[str, Any]) -> str:
    meta, totals = summary['metadata'], summary['totals']
    lines = ['# 原结构校准的新增实测成本', '',
             '统计对象为新增的本地离线回放，包含全部服务通过及未通过样本。原模型响应读取自缓存；真实 LLM/HTTP 延迟没有保存，保持 null，不能由本地读取时间代替。', '',
             f'共 {totals["cells"]} 个 worker cell、{meta.get("observed_tasks", "NA")} 个 task；'
             f'候选仿真合计 {totals["candidate_evaluations"]["total"]:.0f} 次，'
             f'另有 nominal diagnosis {totals["nominal_evaluations_total"]} 次，'
             f'实际仿真合计 {totals["actual_simulator_calls_total"]} 次。新增模型请求 0，计时过程仿真 cache hit 0。', '',
             'local method 秒数覆盖 diagnosis、selector、calibration 和 promotion，排除 worker 准备及事后验证；这是带记录运行，嵌套 replay 计时包含 policy hash/复制等记录开销，不能称纯 simulator CPU 时间，且不再重复相加。内存为独立 worker 的绝对 peakWorkingSet，包含解释器/导入/准备及事后验证，采样截至 artifact 编码之前，单位 MiB；不是方法独占内存或增量内存。', '',
             f'分位数：{summary["quantile_rule"]}。', '',
             '| 场景 | 方法 | n | 服务通过/失败 | 实际候选 median / p95 | local method s median / p95 | 绝对 peak MiB median / p95 / max |',
             '|---|---|---:|---:|---:|---:|---:|']
    for scenario, methods in summary['by_scenario'].items():
        for method in METHODS:
            item, memory = methods[method], methods[method]['peak_working_set_mib']
            lines.append(f'| {scenario} | {METHOD_LABELS[method]} | {item["cells"]} | '
                         f'{item["service_passes"]}/{item["service_failures"]} | '
                         f'{median_p95(item["candidate_evaluations"], 1)} | '
                         f'{median_p95(item["method_seconds"])} | '
                         f'{median_p95(memory, 2)} / {fmt(memory["max"], 2)} |')
    lines.extend(['', '## 同 task 配对增量', '',
                  '以下为同场景、同 seed 的增强方法减 compact；各方法在独立 worker 中实测。负时间差保留，反映计时波动；这不是对单个进程额外代码段的计时。', '',
                  '| 场景 | 增强方法 | 配对 n | Δ候选 median / p95 | Δlocal s median / p95 | 负时间差 n |',
                  '|---|---|---:|---:|---:|---:|'])
    for scenario, methods in summary['paired_by_scenario'].items():
        for method in METHODS[1:]:
            pair = methods[method]
            stats = pair['statistics']
            lines.append(f'| {scenario} | {METHOD_LABELS[method]} | {pair["n_pairs"]} | '
                         f'{median_p95(stats["delta_candidate_evaluations"], 1)} | '
                         f'{median_p95(stats["delta_method_seconds"])} | '
                         f'{stats["delta_method_seconds"]["negative_n"]} |')
    lines.extend(['', '这些测量不包含原在线 API 推理时间，也不代表真实飞行任务耗时、功耗或电池可行性。'
                  '成功/失败总体和候选数量按原 first-pass 流程统计，理论 grid 上限没有代替实际执行次数。', '',
                  '完整数值、缺失计数、machine 信息和每个 measured cell 的 SHA-256 见 `summary.json`。', ''])
    return '\n'.join(lines)


def tex_escape(value: str) -> str:
    replacements = {'\\': r'\textbackslash{}', '&': r'\&', '%': r'\%', '$': r'\$',
                    '#': r'\#', '_': r'\_', '{': r'\{', '}': r'\}', '~': r'\textasciitilde{}',
                    '^': r'\textasciicircum{}'}
    return ''.join(replacements.get(character, character) for character in value)


def latex_table(summary: Mapping[str, Any]) -> str:
    lines = [r'% Generated from saved local worker measurements; no inference latency is imputed.',
             r'\begin{table*}[t]', r'\centering',
             r'\caption{New local profiling of the original structural calibration. '
             r'Candidate counts and local method seconds are median / p95; absolute process '
             r'peak working set is median / p95 / maximum (MiB). All service successes and '
             r'failures are retained. Cached LLM responses incur no new model requests; '
             r'historical generation latency is unavailable and excluded.}',
             r'\label{tab:original_structural_cost}', r'\small',
             r'\resizebox{\textwidth}{!}{%',
             r'\begin{tabular}{llrrrrr}', r'\hline',
             r'Scenario & Method & $n$ & Pass / fail & Candidates & Local method (s) & Absolute peak (MiB) \\',
             r'\hline']
    for scenario, methods in summary['by_scenario'].items():
        for method in METHODS:
            item, memory = methods[method], methods[method]['peak_working_set_mib']
            lines.append(f'{tex_escape(scenario)} & {tex_escape(METHOD_LABELS[method])} & '
                         f'{item["cells"]} & {item["service_passes"]} / {item["service_failures"]} & '
                         f'{median_p95(item["candidate_evaluations"], 1)} & '
                         f'{median_p95(item["method_seconds"])} & '
                         f'{median_p95(memory, 2)} / {fmt(memory["max"], 2)} ' + r'\\')
        lines.append(r'\hline')
    lines.extend([r'\end{tabular}}', r'\end{table*}', ''])
    return '\n'.join(lines)


def write_reports(summary: Mapping[str, Any], out: Path, run_root: Path) -> None:
    out, run_root = out.resolve(), run_root.resolve()
    if out == run_root or run_root in out.parents:
        raise ValueError('Statistical outputs must remain outside the measured run directory')
    if out in run_root.parents:
        raise ValueError('Statistical output root cannot contain the measured run directory')
    out.mkdir(parents=True, exist_ok=True)
    (out / 'by_scenario').mkdir(exist_ok=True)
    (out / 'figures').mkdir(exist_ok=True)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False,
                                               allow_nan=False) + '\n', encoding='utf-8')
    rows = []
    for scenario, methods in summary['by_scenario'].items():
        local = [flat_statistics(scenario, method, methods[method]) for method in METHODS]
        if any(character not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for character in scenario):
            raise ValueError('Unsafe scenario name for statistical output')
        write_csv(out / 'by_scenario' / (scenario + '.csv'), local)
        rows.extend(local)
    write_csv(out / 'scenario_cost_summary.csv', rows)
    write_csv(out / 'overall_cost_summary.csv', [flat_statistics('ALL', method, item)
              for method, item in summary['by_method'].items()])
    paired = [pair for result in summary['paired_overall'].values() for pair in result['pairs']]
    write_csv(out / 'paired_increments_per_seed.csv', paired)
    (out / 'original_structural_cost_report.md').write_text(markdown_report(summary), encoding='utf-8')
    (out / 'figures' / 'original_structural_cost_table.tex').write_text(latex_table(summary), encoding='utf-8')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True, help='Completed measured run directory')
    parser.add_argument('--out', type=Path, required=True, help='Independent statistical output directory')
    arguments = parser.parse_args()
    cells, metadata = load_measurements(arguments.input)
    summary = build_summary(cells, metadata)
    write_reports(summary, arguments.out, arguments.input)
    print('SUMMARY_FILE:', arguments.out.resolve() / 'summary.json')
    print('MEASURED_CELLS:', summary['totals']['cells'])
    print('MODEL_REQUESTS: 0; REAL_SIMULATOR_CALLS_IN_SUMMARIZER: 0')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
