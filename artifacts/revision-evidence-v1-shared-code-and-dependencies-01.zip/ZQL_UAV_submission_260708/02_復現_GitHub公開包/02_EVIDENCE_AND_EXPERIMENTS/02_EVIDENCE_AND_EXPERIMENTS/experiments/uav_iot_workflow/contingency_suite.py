#!/usr/bin/env python3
"""Heterogeneous Contingency Suite - clean rerun protocol.

This benchmark tests whether per-instance diagnostic evidence can drive repair
structure when compact single-target rules are insufficient. The same
per-cluster burst and degradation strengths are used for single- and
multi-hotspot cases; the held-out case is not made easier by rescaling the
physical disturbance.

See ../positive_result_experiment_design.md. The deterministic backbone (this file)
runs with NO API key; the LLM backends (pure-LLM / hybrid) are wired in
run_contingency_suite.py and need a key.

Contingency types (burst raises backlog; degradation collapses link rate -> blackout):
  C1_known_east   : single hotspot at east  (burst+degradation)   -> scripted-east works
  C2_moved        : single hotspot moved to west/north            -> needs localization
  C3_misleading   : burst in cluster B, degradation/blackout in A -> max-backlog rule aims at B (wrong)
  C4_two_hotspots : TWO simultaneous hotspots (HELD-OUT)          -> single-target repair leaves one failing

Deterministic methods:
  B1_max_backlog       : max peak-backlog cluster, single-target repair     (fails C3, C4)
  B2_scripted_east     : fixed east CASP script                             (fails C2, C3, C4)
  B3_single_target_diag: strongest diagnostic-evidence cluster, single-target repair
  MT_scripted_reference: evidence-driven multi-target scripted reference
"""
from __future__ import annotations
import os, math, random, statistics, csv, argparse
from collections import deque
from pathlib import Path

from run_uav_iot_workflow_experiment import (
    AREA, CLUSTERS, CONTRACT, DT, N_DEVICES, PERTURB_START, PERTURB_END, T,
    RECOVERY_HOLD, PROTOCOLS, UAV_SPEED, UAV_START,
    clamp, cluster_centroid, consume_queue, dist, is_burst_active, link_rate,
    route_policy, select_protocol, sigmoid, weighted_percentile,
)

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
CLUSTER_IDS = [c["id"] for c in CLUSTERS]

CTYPES = ["C1_known_east", "C2_moved", "C3_misleading", "C4_two_hotspots"]
HELD_OUT = "C4_two_hotspots"
RECOVERY_BACKLOG_STABLE_MAX = 18.0
RECOVERY_BLACKOUT_STABLE_MAX = 16
BURST_MULTIPLIER = 3.30
DEGRADATION_STRENGTH = 0.70
CTYPE_SEED_OFFSET = {
    "C1_known_east": 101,
    "C2_moved": 211,
    "C3_misleading": 307,
    "C4_two_hotspots": 419,
}


# --------------------------------------------------------------------------
# Scenario with independent burst and degradation cluster sets
# --------------------------------------------------------------------------
def contingency_clusters(ctype: str, seed: int):
    """Return (burst_clusters, degrade_clusters) for a contingency instance."""
    rng = random.Random(seed * 131 + CTYPE_SEED_OFFSET[ctype])
    if ctype == "C1_known_east":
        return ["east_hotspot"], ["east_hotspot"]
    if ctype == "C2_moved":
        hot = rng.choice(["west_cluster", "north_cluster"])
        return [hot], [hot]
    if ctype == "C3_misleading":
        a, b = rng.sample(CLUSTER_IDS, 2)   # degrade(blackout) in a, burst(backlog) in b
        return [b], [a]
    if ctype == "C4_two_hotspots":
        pair = rng.sample(CLUSTER_IDS, 2)
        return pair, pair
    raise ValueError(ctype)


def make_scenario_cset(seed: int, burst_clusters, degrade_clusters) -> dict:
    bc, dc = set(burst_clusters), set(degrade_clusters)
    rng = random.Random(seed * 7919 + 13)
    devices = []
    for ci, cluster in enumerate(CLUSTERS):
        cx, cy = cluster["centroid"]
        for li in range(10):
            did = ci * 10 + li
            x = clamp(cx + rng.gauss(0.0, 48.0), 40.0, AREA - 40.0)
            y = clamp(cy + rng.gauss(0.0, 48.0), 40.0, AREA - 40.0)
            base = 0.032 + 0.014 * rng.random()
            if cluster["id"] in bc:
                base += 0.006 + 0.006 * rng.random()
            devices.append({"id": did, "cluster": cluster["id"], "x": x, "y": y,
                            "base_arrival": base})
    arng = random.Random(seed * 12289 + 97)
    arrivals = []
    for t in range(T):
        row = []
        for dev in devices:
            a = dev["base_arrival"] * (0.72 + 0.56 * arng.random())
            if is_burst_active(t, True) and dev["cluster"] in bc:
                a *= BURST_MULTIPLIER + 0.18 * math.sin((t - PERTURB_START) / 9.0)
            row.append(a)
        arrivals.append(row)
    return {"seed": seed, "devices": devices, "arrivals": arrivals,
            "burst": bc, "degrade": dc, "affected": dc,
            "degradation_strength": DEGRADATION_STRENGTH}


def _deg(device, t, degrade_clusters, strength=0.78):
    if not (PERTURB_START <= t <= T) or device["cluster"] not in degrade_clusters:
        return 0.0
    center = cluster_centroid(device["cluster"])
    d = dist((device["x"], device["y"]), center)
    return clamp(strength * sigmoid((235.0 - d) / 45.0), 0.0, strength)


# --------------------------------------------------------------------------
# Simulator: generalized from simulate_ms; supports a LIST of local triggers
# --------------------------------------------------------------------------
def simulate_cset(scenario: dict, policy: dict) -> dict:
    devices = scenario["devices"]; arrivals = scenario["arrivals"]
    degrade = scenario["degrade"]; affected = scenario["affected"]
    degradation_strength = scenario.get("degradation_strength", 0.78)
    queues = [0.0] * N_DEVICES; chunks = [deque() for _ in range(N_DEVICES)]
    generated = [0.0] * N_DEVICES; delivered = [0.0] * N_DEVICES
    latencies = [[] for _ in range(N_DEVICES)]
    blackout_streak = [0] * N_DEVICES; max_blackout = [0] * N_DEVICES
    uav = [UAV_START[0], UAV_START[1]]; route_index = 0; dwell_used = 0
    previous_protocol = None; protocol_hold_remaining = 0; switch_count = 0; energy = 0.0
    triggers = policy.get("local_triggers") or []
    if isinstance(triggers, dict):
        triggers = [triggers]
    tstate = [{"hold": 0, "cooldown": 0} for _ in triggers]
    logs = []
    peak_backlog = {c["id"]: 0.0 for c in CLUSTERS}
    peak_blackout = {c["id"]: 0 for c in CLUSTERS}
    peak_link_stress = {c["id"]: 0.0 for c in CLUSTERS}

    for t in range(T):
        for i, amount in enumerate(arrivals[t]):
            if amount > 0:
                queues[i] += amount; generated[i] += amount
                chunks[i].append([float(t), float(amount)])
        cl_backlog = {c["id"]: sum(queues[i] for i in range(N_DEVICES)
                                   if devices[i]["cluster"] == c["id"]) for c in CLUSTERS}
        cl_blackout = {c["id"]: max((blackout_streak[i] for i in range(N_DEVICES)
                                     if devices[i]["cluster"] == c["id"]), default=0) for c in CLUSTERS}
        cl_link_stress = {
            c["id"]: max((_deg(devices[i], t, degrade, degradation_strength)
                          for i in range(N_DEVICES)
                          if devices[i]["cluster"] == c["id"]), default=0.0)
            for c in CLUSTERS
        }
        for c in CLUSTERS:
            if t >= PERTURB_START:
                peak_backlog[c["id"]] = max(peak_backlog[c["id"]], cl_backlog[c["id"]])
                peak_blackout[c["id"]] = max(peak_blackout[c["id"]], cl_blackout[c["id"]])
                peak_link_stress[c["id"]] = max(peak_link_stress[c["id"]], cl_link_stress[c["id"]])

        # choose the currently most urgent active trigger
        active_candidates = []
        for cfg, st in zip(triggers, tstate):
            if st["cooldown"] > 0:
                st["cooldown"] -= 1
            cid = cfg["cluster"]
            should = (cl_backlog[cid] >= cfg["queue_threshold"]
                      or cl_blackout[cid] >= cfg["max_blackout_threshold_slots"])
            if should and st["hold"] <= 0 and st["cooldown"] <= 0:
                st["hold"] = int(cfg["fallback_dwell_min_slots"])
            if st["hold"] > 0:
                urgency = cl_blackout[cid] * 2.0 + cl_backlog[cid]
                active_candidates.append((urgency, tuple(cfg["fallback_waypoint"]), cfg, st))

        active_target = None
        if active_candidates:
            _, waypoint, cfg, st = max(active_candidates, key=lambda x: x[0])
            active_target = (waypoint, "casp_fallback", cfg, st)

        if active_target is not None:
            target, target_label, cfg, st = active_target
            st["hold"] -= 1
            if st["hold"] <= 0:
                st["cooldown"] = int(cfg.get("cooldown_slots", 0))
        else:
            route = policy["route"]; wp = route[route_index]
            target = tuple(wp["xy"]); target_label = wp["cluster"]
            if dist((uav[0], uav[1]), target) <= 10.0:
                if dwell_used < int(wp["dwell"]):
                    dwell_used += 1
                else:
                    route_index = (route_index + 1) % len(route); dwell_used = 0
                    wp = route[route_index]; target = tuple(wp["xy"]); target_label = wp["cluster"]

        to_target = dist((uav[0], uav[1]), target); move = min(UAV_SPEED * DT, to_target)
        if to_target > 1e-9:
            uav[0] += (target[0] - uav[0]) / to_target * move
            uav[1] += (target[1] - uav[1]) / to_target * move
        energy += 0.024 * move

        selected = None
        for i, device in enumerate(devices):
            if queues[i] <= 0.02:
                continue
            d = dist((uav[0], uav[1]), (device["x"], device["y"]))
            deg = _deg(device, t, degrade, degradation_strength)
            protocol = select_protocol(policy["protocol_mode"], d, deg,
                                       previous_protocol, protocol_hold_remaining)
            rate, quality = link_rate(protocol, d, deg)
            if rate <= 0.015:
                continue
            score = queues[i] * math.sqrt(rate) + 0.18 * blackout_streak[i]
            if target_label == "casp_fallback":
                score *= 3.00 if device["cluster"] in affected else 0.55
            elif target_label == device["cluster"]:
                score *= 1.55
            score -= 0.0012 * d
            if selected is None or score > selected[0]:
                selected = (score, i, protocol, rate, quality)

        served = [0.0] * N_DEVICES; sel_proto = None
        if selected is not None:
            _, i, protocol, rate, quality = selected
            amount = min(queues[i], rate * DT)
            queues[i] -= amount; delivered[i] += amount; served[i] = amount
            sel_proto = protocol
            energy += amount * PROTOCOLS[protocol]["energy"]
            consume_queue(chunks[i], amount, t, latencies[i])
        if sel_proto:
            if previous_protocol and sel_proto != previous_protocol:
                switch_count += 1; energy += 0.18
                protocol_hold_remaining = int(policy.get("min_protocol_hold_slots", 0))
            previous_protocol = sel_proto
        if protocol_hold_remaining > 0:
            protocol_hold_remaining -= 1

        for i in range(N_DEVICES):
            if queues[i] > 0.05 and served[i] <= 1e-12:
                blackout_streak[i] += 1
            else:
                blackout_streak[i] = 0
            max_blackout[i] = max(max_blackout[i], blackout_streak[i])

        logs.append({"t": t,
                     "aff_backlog": max((cl_backlog[c] for c in affected), default=0.0),
                     "aff_blackout": max((cl_blackout[c] for c in affected), default=0)})

    device_pdr = [(delivered[i] / generated[i]) if generated[i] > 1e-9 else 1.0
                  for i in range(N_DEVICES)]
    device_p95 = [weighted_percentile(latencies[i], 0.95) for i in range(N_DEVICES)]
    device_p95 = [float(T) if math.isinf(v) else v for v in device_p95]
    th = CONTRACT["qos_thresholds"]
    qsr_pass = [device_pdr[i] >= th["device_pdr_min"]
                and device_p95[i] <= th["device_p95_latency_max_slots"]
                and max_blackout[i] <= th["device_max_blackout_max_slots"]
                for i in range(N_DEVICES)]
    recovery_time = T - PERTURB_START + 1
    for t in range(PERTURB_START, T - RECOVERY_HOLD):
        if all(r["aff_backlog"] <= RECOVERY_BACKLOG_STABLE_MAX
               and r["aff_blackout"] <= RECOVERY_BLACKOUT_STABLE_MAX
               for r in logs[t:t + RECOVERY_HOLD]):
            recovery_time = t - PERTURB_START + 1
            break
    p95_all = weighted_percentile([x for dv in latencies for x in dv], 0.95)
    if math.isinf(p95_all):
        p95_all = float(T)
    qsr = sum(1 for x in qsr_pass if x) / N_DEVICES
    pc = CONTRACT["promotion_criteria"]
    trigger_clusters = set()
    local_triggers = policy.get("local_triggers") or []
    if isinstance(local_triggers, dict):
        local_triggers = [local_triggers]
    for trig in local_triggers:
        if isinstance(trig, dict) and trig.get("cluster") in CLUSTER_IDS:
            trigger_clusters.add(trig["cluster"])
    coverage_pass = set(affected).issubset(trigger_clusters)
    passed = (qsr >= pc["qsr_min"] and max(max_blackout) <= pc["max_blackout_max_slots"]
              and recovery_time <= pc["recovery_time_max_slots"] and coverage_pass)
    return {"metrics": {"qsr": qsr, "recovery_time": recovery_time,
                        "max_blackout": max(max_blackout), "p95_latency": p95_all,
                        "coverage_pass": coverage_pass,
                        "passed_contract": passed},
            "peak_backlog": peak_backlog, "peak_blackout": peak_blackout,
            "peak_link_stress": peak_link_stress, "trace": logs}


# --------------------------------------------------------------------------
# Repairs (single-target and multi-target), with a small bounded search
# --------------------------------------------------------------------------
def _trigger(cluster, b=16, dwell=4, cooldown=12):
    return {"cluster": cluster, "queue_threshold": 18.0, "release_threshold": 10.0,
            "max_blackout_threshold_slots": b, "fallback_waypoint": list(cluster_centroid(cluster)),
            "fallback_dwell_min_slots": dwell, "cooldown_slots": cooldown}


def calibrate_targets(scenario: dict, targets: list[str]) -> dict:
    """Bounded search over route templates / thresholds that revisit every target cluster."""
    targets = list(dict.fromkeys(targets))  # dedupe, keep order
    others = [c for c in CLUSTER_IDS if c not in targets]
    if len(targets) == 1:
        c = targets[0]; o = [x for x in CLUSTER_IDS if x != c]
        templates = [[o[0], c, o[1], c], [c, o[0], c, o[1]], [c, o[0], o[1], c]]
    else:
        a, b = targets[0], targets[1]
        rest = others[0] if others else a
        templates = [
            [a, b, a, b],
            [a, b, rest, a, b],
            [rest, a, b, a, b],
            [a, rest, b, a, b],
            [b, rest, a, b, a],
        ]
    best = None
    for route in templates:
        dwell_grid = (16, 22, 28) if len(targets) == 1 else (4, 6, 8, 10, 12)
        trigger_dwell_grid = (4,) if len(targets) == 1 else (3, 4, 5)
        cooldown_grid = (12,) if len(targets) == 1 else (8, 12)
        for d2 in dwell_grid:
            for trigger_dwell in trigger_dwell_grid:
                for cooldown in cooldown_grid:
                    for bb in (12, 16):
                        dwell = [(d2 if (len(targets) > 1 or c in targets) else 8) for c in route]
                        pol = route_policy("adapt", route, dwell, "degraded_aware")
                        pol["min_protocol_hold_slots"] = 4
                        pol["local_triggers"] = [_trigger(c, bb, trigger_dwell, cooldown) for c in targets]
                        res = simulate_cset(scenario, pol)
                        m = res["metrics"]
                        key = (1 if m["passed_contract"] else 0, -m["recovery_time"],
                               -m["max_blackout"], m["qsr"])
                        if best is None or key > best[0]:
                            best = (key, res)
    return best[1]


# --------------------------------------------------------------------------
# Deterministic localizers / methods
# --------------------------------------------------------------------------
def _nominal():
    return route_policy("nom", ["west_cluster", "east_hotspot", "north_cluster"],
                        [12, 12, 12], "best_rate")


def _scripted_east():
    pol = route_policy("scripted_east", ["west_cluster", "east_hotspot", "north_cluster", "east_hotspot"],
                       [8, 16, 8, 14], "degraded_aware")
    pol["min_protocol_hold_slots"] = 4
    pol["local_triggers"] = [_trigger("east_hotspot")]
    return pol


def run_method(method: str, scenario: dict) -> dict:
    probe = simulate_cset(scenario, _nominal())
    pbk, pbl = probe["peak_backlog"], probe["peak_blackout"]
    pls = probe.get("peak_link_stress", {c: 0.0 for c in CLUSTER_IDS})
    if method == "B1_max_backlog":
        return calibrate_targets(scenario, [max(pbk, key=pbk.get)])
    if method == "B2_scripted_east":
        return simulate_cset(scenario, _scripted_east())
    if method == "B3_single_target_diag":
        if max(pls.values()) >= 0.15:
            return calibrate_targets(scenario, [max(pls, key=pls.get)])
        return calibrate_targets(scenario, [max(pbl, key=pbl.get)])
    if method == "MT_scripted_reference":
        # multi-target: every cluster whose measured link-stress evidence crosses a violation band
        flagged = [c for c, v in sorted(pls.items(), key=lambda kv: kv[1], reverse=True) if v >= 0.15]
        if not flagged:
            flagged = [max(pbl, key=pbl.get)]
        return calibrate_targets(scenario, flagged[:2])
    raise ValueError(method)


DET_METHODS = ["B1_max_backlog", "B2_scripted_east", "B3_single_target_diag", "MT_scripted_reference"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=int(os.environ.get("UAV_CSUITE_N", "30")))
    ap.add_argument("--out", default=str(RESULTS / "contingency_suite_clean_det.csv"))
    a = ap.parse_args()
    seeds = list(range(1, a.seeds + 1))
    RESULTS.mkdir(parents=True, exist_ok=True)
    rows = []
    print(f"Heterogeneous Contingency Suite - deterministic backbone ({len(seeds)} seeds/type)\n")
    header = f"{'contingency':<16}" + "".join(f"{m:>24}" for m in DET_METHODS)
    print(header); print("-" * len(header))
    for ctype in CTYPES:
        passes = {m: [] for m in DET_METHODS}
        for s in seeds:
            bc, dc = contingency_clusters(ctype, s)
            sc = make_scenario_cset(s, bc, dc)
            for m in DET_METHODS:
                r = run_method(m, sc)
                passes[m].append(1.0 if r["metrics"]["passed_contract"] else 0.0)
                rows.append({"contingency": ctype, "seed": s, "method": m,
                             "passed_contract": bool(r["metrics"]["passed_contract"]),
                             "qsr": round(r["metrics"]["qsr"], 4),
                             "recovery_time": r["metrics"]["recovery_time"],
                             "max_blackout": r["metrics"]["max_blackout"]})
        print(f"{ctype:<16}" + "".join(f"{statistics.mean(passes[m]):>24.2f}" for m in DET_METHODS))
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(f"\nwrote {a.out}")
    print("Interpretation: this clean smoke uses unrelaxed per-cluster stress. If the "
          "multi-target reference is also low, treat the suite as a capacity boundary "
          "and do not use it as a positive manuscript result.")


if __name__ == "__main__":
    main()
