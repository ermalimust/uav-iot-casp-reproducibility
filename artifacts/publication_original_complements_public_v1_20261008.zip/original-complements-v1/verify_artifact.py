"""Verify merged core-v1 and complements-v1; standard library and read-only."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath

def digest(p):
    with p.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()

def check(root, records):
    for x in records:
        r = PurePosixPath(x["path"])
        if r.is_absolute() or ".." in r.parts or "\\" in x["path"]:
            raise AssertionError("Unsafe manifest path")
        p = (root / r).resolve()
        if not p.is_relative_to(root) or not p.is_file():
            raise AssertionError("Missing/escaping manifest file")
        if p.stat().st_size != x["bytes"] or digest(p) != x["sha256"]:
            raise AssertionError("Manifest identity mismatch: " + x["path"])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    a = ap.parse_args()
    root = a.root.resolve()
    comp = json.loads((root/"original-complements-v1/MANIFEST.json").read_text(encoding="utf-8"))
    corepath = root/"MANIFEST.json"
    if digest(corepath) != comp["requires_original_core_manifest_sha256"]:
        raise AssertionError("Requires exact original-core-v1 manifest")
    core = json.loads(corepath.read_text(encoding="utf-8-sig"))
    if core["version"] != "original-core-v1" or comp["version"] != "original-complements-v1":
        raise AssertionError("Wrong versions")
    check(root, core["files"])
    check(root, comp["files"])
    print(json.dumps({"status":"PASS_MERGED_CORE_AND_COMPLEMENTS_IDENTITIES",
                      "core_files":len(core["files"]),"companion_files":len(comp["files"]),
                      "scientific_complements":comp["scientific_file_count"],"model_requests":0}))
if __name__ == "__main__":
    main()
