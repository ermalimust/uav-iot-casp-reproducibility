"""Independent auditor fixtures; no controller, simulator, API, or network runs."""
from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

import audit_original_structural_costs as audit


class OriginalAstFixtureChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.oracle = audit.OriginalOracle()

    def evaluations(self, policies, pass_index=None):
        return [{'policy_hash': audit.policy_hash(policy),
                 'metrics': {'passed_contract': index == pass_index, 'qsr': 1.0,
                             'recovery_time': 20, 'max_blackout': 40}}
                for index, policy in enumerate(policies)]

    def test_original_nine_grids_keep_all_225_raw_entries_and_165_unique_policies(self):
        policies = []
        for target in audit.CLUSTERS:
            for mode, count in zip(audit.MODES, (18, 12, 45)):
                grid = self.oracle.grid(target, mode)
                self.assertEqual(len(grid), count)
                policies.extend(grid)
        self.assertEqual(len(policies), 225)
        self.assertEqual(len({audit.policy_hash(policy) for policy in policies}), 165)

    def test_recorded_prefix_cannot_skip_raw_duplicate_policies(self):
        grid = self.oracle.grid('west_cluster', 'protocol_trigger')
        evaluations = self.evaluations(grid)
        self.assertEqual(len({row['policy_hash'] for row in evaluations}), 6)
        chosen = self.oracle.replay_saved('west_cluster', 'protocol_trigger', evaluations)
        self.assertEqual(audit.policy_hash(chosen['policy']), evaluations[0]['policy_hash'])
        with self.assertRaisesRegex(ValueError, 'before the original calibrator'):
            self.oracle.replay_saved('west_cluster', 'protocol_trigger', evaluations[:6])

    def test_first_pass_stops_at_original_position(self):
        grid = self.oracle.grid('west_cluster', 'route_dwell')
        evaluations = self.evaluations(grid, pass_index=3)
        result = self.oracle.replay_saved('west_cluster', 'route_dwell', evaluations[:4])
        self.assertEqual(audit.policy_hash(result['policy']), evaluations[3]['policy_hash'])
        with self.assertRaisesRegex(ValueError, 'continued after original first pass'):
            self.oracle.replay_saved('west_cluster', 'route_dwell', evaluations[:5])

    def test_policy_prefix_tamper_is_detected_independently(self):
        grid = self.oracle.grid('north_cluster', 'full_casp')
        evaluations = self.evaluations(grid)
        evaluations[2]['policy_hash'] = evaluations[3]['policy_hash']
        with self.assertRaisesRegex(ValueError, 'policy differs at prefix entry 2'):
            self.oracle.replay_saved('north_cluster', 'full_casp', evaluations)

    def test_original_four_metric_rank_and_first_exact_tie(self):
        grid = self.oracle.grid('east_hotspot', 'full_casp')
        evaluations = self.evaluations(grid)
        evaluations[7]['metrics']['qsr'] = 1.0
        for row in evaluations:
            row['metrics']['qsr'] = 0.8
        evaluations[7]['metrics'].update(qsr=0.9, recovery_time=40, max_blackout=50)
        evaluations[8]['metrics'].update(qsr=0.9, recovery_time=30, max_blackout=60)
        evaluations[9]['metrics'].update(qsr=0.9, recovery_time=30, max_blackout=50)
        evaluations[10]['metrics'] = copy.deepcopy(evaluations[9]['metrics'])
        result = self.oracle.replay_saved('east_hotspot', 'full_casp', evaluations)
        self.assertEqual(audit.policy_hash(result['policy']), evaluations[9]['policy_hash'])

    def test_non_boolean_pass_is_not_normalized(self):
        with self.assertRaises(ValueError):
            audit.rank({'passed_contract': 1, 'qsr': 1, 'recovery_time': 20, 'max_blackout': 40})

    def test_audit_output_cannot_modify_the_measurement_directory(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name).resolve()
            with self.assertRaises(ValueError):
                audit.outside_output(root, root / 'audit.json')
            self.assertEqual(audit.outside_output(root, root.parent / 'audit.json'), root.parent / 'audit.json')

    def test_all_failures_are_retained(self):
        checks = audit.Checks()
        checks.check(False, 'first')
        checks.check(False, 'second')
        checks.check(True, 'passes')
        self.assertEqual(checks.assertions, 3)
        self.assertEqual([x['message'] for x in checks.errors], ['first', 'second'])

    def test_all_original_400_cached_model_rows_bind_to_exact_last_prompt_records(self):
        rows, cache, _ = audit.frozen_records()
        keys = []
        for (_, _, method), row in rows.items():
            if method != 'llm_only_structure':
                continue
            linked = audit.original_model_link(self.oracle, json.loads(row['evidence_json']), row, cache)
            self.assertTrue(linked['parsed_ok'])
            keys.append(linked['cache_key'])
        self.assertEqual(len(keys), 400)
        self.assertEqual(len(set(keys)), 400)

    def recorded_group(self, target='west_cluster', mode='protocol_trigger'):
        policies = self.oracle.grid(target, mode)
        evaluations = self.evaluations(policies)
        for index, (entry, policy) in enumerate(zip(evaluations, policies)):
            entry.update(policy=copy.deepcopy(policy), raw_index=index,
                         status='complete', elapsed_seconds=0.01)
        best = self.oracle.replay_saved(target, mode, evaluations)
        return {'source': 'fixture', 'evaluations': evaluations,
                'raw_grid_entries': len(policies), 'candidate_evaluations': len(evaluations),
                'best_policy_hash': audit.policy_hash(best['policy']), 'best_metrics': best['metrics'],
                'elapsed_seconds': 0.2, 'simulator_seconds': 0.01 * len(evaluations)}

    def test_raw_physical_ledger_keeps_duplicate_entries(self):
        checks = audit.Checks()
        group = self.recorded_group()
        result = audit.audit_group(checks, self.oracle, group, 'west_cluster', 'protocol_trigger', {})
        self.assertFalse(checks.errors)
        self.assertEqual(result['evaluations'], 12)
        self.assertEqual(result['raw_duplicate_evaluations'], 6)

    def test_payload_tamper_and_multiple_inconsistent_counts_are_retained(self):
        checks = audit.Checks()
        group = self.recorded_group()
        group['evaluations'][0]['policy']['min_protocol_hold_slots'] = 100
        group['evaluations'][1]['raw_index'] = 4
        group['candidate_evaluations'] = 0
        audit.audit_group(checks, self.oracle, group, 'west_cluster', 'protocol_trigger', {})
        messages = [x['message'] for x in checks.errors]
        self.assertIn('Recorded policy payload and hash disagree', messages)
        self.assertIn('Raw candidate index skipped, reordered or repeated', messages)
        self.assertIn('Group candidate count differs from ledger', messages)

    def test_nested_duration_is_never_added_to_exclusive_method_phases(self):
        timing = dict(diagnosis_seconds=1, selector_seconds=1, calibration_seconds=4,
                      promotion_seconds=1, method_seconds=7, worker_seconds=9,
                      preparation_seconds=1, nominal_simulator_seconds=0.9,
                      candidate_simulator_seconds=3.9)
        checks = audit.Checks()
        audit.audit_timing(checks, timing, {})
        self.assertFalse(checks.errors)
        timing['method_seconds'] = 6
        audit.audit_timing(checks, timing, {})
        self.assertIn('Exclusive phases exceed method total; possible double-counting',
                      [x['message'] for x in checks.errors])

    def test_absolute_memory_scope_and_missing_baseline_cannot_be_hidden(self):
        checks = audit.Checks()
        audit.audit_memory(checks, dict(peak_working_set_bytes=100,
                           current_working_set_bytes=90, baseline_working_set_bytes=None,
                           measurement='algorithm incremental memory', scope='after all serialization'), {})
        self.assertEqual(len(checks.errors), 3)

    def test_historical_portfolio_pass_uses_boolean_or_not_rounded_metric_rank(self):
        rows = {('fixture', 1, source): {'passed_contract': 'False', 'qsr': '1.0',
                'recovery_time': '10', 'max_blackout': '10'} for source in audit.BASE}
        rows['fixture', 1, 'SR_scripted_mixed_reference'] = {'passed_contract': 'True'}
        rows['fixture', 1, 'llm_only_structure'] = {'passed_contract': 'False'}
        self.assertFalse(audit.original_portfolio_pass(rows, 'fixture', 1, 'compact'))
        self.assertTrue(audit.original_portfolio_pass(rows, 'fixture', 1, 'compact_plus_expert'))
        self.assertFalse(audit.original_portfolio_pass(rows, 'fixture', 1, 'compact_plus_cached_model'))


if __name__ == '__main__':
    unittest.main()
