"""
llm_repair_agent.py
============================================================================
LLM-in-the-loop diagnosis-and-repair agent for the UAV-IoT closed-loop design
workflow.

This module turns the previously HARD-CODED repair candidates (see
``run_closed_loop`` in run_uav_iot_workflow_experiment.py) into a genuine
language-model agent loop. Each iteration the agent:

  1. reads the QoS-aware service contract, the latest simulator *diagnosis*
     record, and a compact history of previously attempted candidates;
  2. emits a STRUCTURED, CONSTRAINED repair action (route order, dwell times,
     protocol mode, local CASP triggers, optional replanning request);
  3. has that action validated / clamped to the allowed UAV-IoT policy
     operations, then re-simulated, re-diagnosed, and recorded as a candidate.

The simulator, contract, diagnosis-evidence extractor, candidate-record store,
and promotion rule are reused unchanged from the main module: they are the
agent's TOOLS and ENVIRONMENT. Only the *generation of the next candidate* is
handed to the model.

----------------------------------------------------------------------------
Design goals
----------------------------------------------------------------------------
* Provider-agnostic   : Anthropic (Claude) OR any OpenAI-compatible endpoint
                        (Alibaba DashScope / Qwen, Codex-style gateways, ...),
                        selected purely by environment variables.
* Reproducible        : every (system,user) -> response pair is cached to
                        ``results/llm_cache.jsonl``. Reruns without an API key
                        replay deterministically from the cache. This is what
                        makes the agentic evidence re-runnable for an IEEE
                        submission.
* Safe offline path   : if there is no key AND no cache entry, a clearly
                        labelled ``offline_synthetic`` synthesises a structured
                        action from the diagnosis so the harness still runs end
                        to end. Offline-synthetic candidates are tagged
                        (mode="offline_synthetic") so they are NEVER mistaken for
                        real model evidence in the paper.
* Zero dependencies   : HTTP via the standard library (urllib) only.

----------------------------------------------------------------------------
Environment variables
----------------------------------------------------------------------------
  UAV_LLM_PROVIDER   anthropic | openai | offline       (default: auto-detect)
  UAV_LLM_MODEL      model name        (provider default used if unset)
  UAV_LLM_TEMP       sampling temperature                (default 0.2)
  UAV_LLM_MAX_ITERS  max repair iterations               (default 3)
  UAV_LLM_CACHE      cache file path     (default results/llm_cache.jsonl)
  UAV_LLM_REFRESH    "1" -> ignore cache and re-query the model

  Anthropic : ANTHROPIC_API_KEY   [, ANTHROPIC_BASE_URL]
  OpenAI/-compat: OPENAI_API_KEY  [, OPENAI_BASE_URL]
      e.g. DashScope:
        UAV_LLM_PROVIDER=openai
        OPENAI_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
        OPENAI_API_KEY=sk-xxxx
        UAV_LLM_MODEL=qwen2.5-coder-32b-instruct

----------------------------------------------------------------------------
Quick self-test (no key required -> runs in offline_synthetic mode):
    python llm_repair_agent.py --selftest
----------------------------------------------------------------------------
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable

# Reuse the simulator + contract + evidence pipeline from the main experiment.
# Importing the module does NOT run its main() (that is guarded by __main__).
from run_uav_iot_workflow_experiment import (
    CLUSTERS,
    CONTRACT,
    PROTOCOLS,
    candidate_record,
    cluster_centroid,
    diagnose,
    promotion_score,
    route_policy,
    simulate_policy,
)

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"

ALLOWED_CLUSTERS = [c["id"] for c in CLUSTERS]
# Protocol *modes* the agent may select (the simulator also supports more, but
# we restrict the agent to the service-relevant ones).
ALLOWED_PROTOCOL_MODES = ["best_rate", "degraded_aware", "nominal"]

# Bounds for every numeric field. The validator CLAMPS to these, so the model
# can never push the policy outside the allowed UAV-IoT operation envelope.
BOUNDS = {
    "route_len": (2, 6),
    "dwell": (3, 30),
    "min_protocol_hold_slots": (0, 12),
    "queue_threshold": (5.0, 60.0),
    "release_threshold": (0.0, 40.0),
    "max_blackout_threshold_slots": (4, 40),
    "fallback_dwell_min_slots": (1, 12),
    "cooldown_slots": (0, 40),
}

DEFAULT_MODELS = {
    "anthropic": "claude-sonnet-4-6",
    "openai": "qwen2.5-coder-32b-instruct",
}


# ===========================================================================
# 1. LLM clients (provider-agnostic, stdlib HTTP only)
# ===========================================================================
class LLMResult:
    def __init__(self, text: str, *, provider: str, model: str, mode: str,
                 raw: Any = None, usage: dict | None = None) -> None:
        self.text = text
        self.provider = provider
        self.model = model
        self.mode = mode  # "live" | "replay" | "offline_synthetic"
        self.raw = raw
        self.usage = usage or {}


def _http_post_json(url: str, headers: dict[str, str], payload: dict[str, Any],
                    timeout: float = 60.0) -> dict[str, Any]:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        # Surface the provider's error body (e.g. DashScope "InvalidApiKey",
        # "model not found", "Arrearage") instead of a bare HTTPError.
        body = ""
        try:
            body = e.read().decode("utf-8", "replace")
        except Exception:
            pass
        raise RuntimeError(f"HTTP {e.code} from {url}: {body[:800]}") from None


class AnthropicClient:
    """Anthropic Messages API (Claude)."""

    provider = "anthropic"

    def __init__(self, model: str | None = None, temperature: float = 0.2) -> None:
        self.api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        self.base_url = os.environ.get("ANTHROPIC_BASE_URL", "https://api.anthropic.com").rstrip("/")
        self.model = model or os.environ.get("UAV_LLM_MODEL") or DEFAULT_MODELS["anthropic"]
        self.temperature = temperature

    def available(self) -> bool:
        return bool(self.api_key)

    def complete(self, system: str, user: str) -> LLMResult:
        body = {
            "model": self.model,
            "max_tokens": 1024,
            "temperature": self.temperature,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        }
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        raw = _http_post_json(f"{self.base_url}/v1/messages", headers, body)
        parts = raw.get("content", [])
        text = "".join(p.get("text", "") for p in parts if p.get("type") == "text")
        return LLMResult(text, provider=self.provider, model=self.model,
                         mode="live", raw=raw, usage=raw.get("usage"))


class OpenAICompatibleClient:
    """Any OpenAI-compatible /chat/completions endpoint (DashScope/Qwen, etc.)."""

    provider = "openai"

    def __init__(self, model: str | None = None, temperature: float = 0.2) -> None:
        self.api_key = os.environ.get("OPENAI_API_KEY", "")
        self.base_url = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
        self.model = model or os.environ.get("UAV_LLM_MODEL") or DEFAULT_MODELS["openai"]
        self.temperature = temperature

    def available(self) -> bool:
        return bool(self.api_key)

    def complete(self, system: str, user: str) -> LLMResult:
        body = {
            "model": self.model,
            "temperature": self.temperature,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "content-type": "application/json",
        }
        raw = _http_post_json(f"{self.base_url}/chat/completions", headers, body)
        try:
            text = raw["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            raise RuntimeError(
                f"Unexpected response from {self.base_url}/chat/completions: "
                f"{json.dumps(raw)[:800]}"
            ) from None
        return LLMResult(text, provider=self.provider, model=self.model,
                         mode="live", raw=raw, usage=raw.get("usage"))


class OfflineSyntheticFallback:
    """
    Deterministic fallback used ONLY when no API key and no cache entry exist.

    It returns a *structured action string* (same JSON contract the real model
    must follow), synthesised from the diagnosis. This lets the full pipeline --
    prompt building, schema validation, simulation, recording, promotion -- run
    and be unit-tested without a network call. Every candidate it produces is
    tagged mode="offline_synthetic" so it is never confused with model evidence.
    """

    provider = "offline_synthetic"
    model = "rule_synthesis_v1"

    def available(self) -> bool:
        return True

    def complete(self, system: str, user: str) -> LLMResult:
        try:
            ctx = json.loads(user)  # offline path packs a JSON context
        except json.JSONDecodeError:
            l, r = user.find("{"), user.rfind("}")
            ctx = json.loads(user[l:r + 1]) if (l != -1 and r > l) else {}
        diag = ctx.get("latest_diagnosis", {})
        iteration = int(ctx.get("iteration", 1))
        failures = set(diag.get("failure_types", []))
        action: dict[str, Any] = {
            "rationale": "offline_synthetic: synthesised from diagnosis evidence",
            "route_clusters": ["west_cluster", "east_hotspot", "north_cluster", "east_hotspot"],
            "request_replanning": False,
        }
        if iteration <= 1:
            # First repair: targeted dwell increase on the failing hotspot only.
            action["dwell_times"] = [9, 18, 9, 14]
            action["protocol_mode"] = "best_rate"
            action["min_protocol_hold_slots"] = 0
            action["local_triggers"] = None
        else:
            # Later repair: degradation-aware protocol + local CASP trigger.
            action["dwell_times"] = [8, 16, 8, 14]
            action["protocol_mode"] = "degraded_aware"
            action["min_protocol_hold_slots"] = 4
            action["local_triggers"] = {
                "cluster": "east_hotspot",
                "queue_threshold": 18.0,
                "release_threshold": 10.0,
                "max_blackout_threshold_slots": 16,
                "fallback_dwell_min_slots": 3,
                "cooldown_slots": 16,
            }
        if "protocol_mismatch_under_degradation" in failures:
            action["protocol_mode"] = "degraded_aware"
        return LLMResult(json.dumps(action), provider=self.provider,
                         model=self.model, mode="offline_synthetic", raw=action)


class CachingClient:
    """
    Wraps a live client with a JSONL prompt/response cache for reproducibility.

    On complete(system,user): if a cache entry for the hash exists (and refresh
    is off), replay it. Otherwise, if the inner live client is available, query
    it and persist. If nothing is available, fall back to the OfflineSyntheticFallback.
    """

    def __init__(self, inner: Any, cache_path: Path, refresh: bool = False) -> None:
        self.inner = inner
        self.cache_path = cache_path
        self.refresh = refresh
        self.synthetic_fallback = OfflineSyntheticFallback()
        self._cache: dict[str, dict[str, Any]] = {}
        if cache_path.exists():
            for line in cache_path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                    self._cache[rec["key"]] = rec
                except (json.JSONDecodeError, KeyError):
                    continue

    @staticmethod
    def _key(provider: str, model: str, system: str, user: str) -> str:
        h = hashlib.sha256()
        h.update(f"{provider}\x00{model}\x00{system}\x00{user}".encode("utf-8"))
        return h.hexdigest()[:32]

    def _persist(self, rec: dict[str, Any]) -> None:
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        with self.cache_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    def complete(self, system: str, user: str) -> LLMResult:
        provider = getattr(self.inner, "provider", "offline_synthetic")
        model = getattr(self.inner, "model", "rule_synthesis_v1")
        key = self._key(provider, model, system, user)

        if not self.refresh and key in self._cache:
            rec = self._cache[key]
            return LLMResult(rec["text"], provider=rec.get("provider", provider),
                             model=rec.get("model", model), mode="replay",
                             raw=rec.get("raw"), usage=rec.get("usage"))

        # No cache hit. For a real provider, surface failures clearly instead of
        # silently degrading to the offline synthetic fallback (which would fake results).
        is_real = (not isinstance(self.inner, OfflineSyntheticFallback)
                   and hasattr(self.inner, "available") and self.inner.available())
        if is_real:
            try:
                res = self.inner.complete(system, user)
            except Exception as exc:
                raise RuntimeError(
                    f"LLM call failed for provider "
                    f"'{getattr(self.inner, 'provider', '?')}' / model "
                    f"'{getattr(self.inner, 'model', '?')}': {exc}\n"
                    f"  Check: (1) the API key is valid and from the SAME region as "
                    f"OPENAI_BASE_URL (Beijing vs. Singapore/intl vs. US);\n"
                    f"         (2) the model name exists on your account;\n"
                    f"         (3) the account is activated and has quota/credit."
                ) from None
        else:
            res = self.synthetic_fallback.complete(system, user)

        self._cache[key] = {
            "key": key, "provider": res.provider, "model": res.model,
            "mode": res.mode, "text": res.text, "usage": res.usage,
        }
        self._persist(self._cache[key])
        return res


def make_client() -> CachingClient:
    """Build the client stack from environment variables."""
    provider = os.environ.get("UAV_LLM_PROVIDER", "auto").lower()
    temp = float(os.environ.get("UAV_LLM_TEMP", "0.2"))
    cache_path = Path(os.environ.get("UAV_LLM_CACHE", str(RESULTS / "llm_cache.jsonl")))
    refresh = os.environ.get("UAV_LLM_REFRESH", "") == "1"

    if provider == "anthropic":
        inner: Any = AnthropicClient(temperature=temp)
    elif provider == "openai":
        inner = OpenAICompatibleClient(temperature=temp)
    elif provider == "offline":
        inner = OfflineSyntheticFallback()
    else:  # auto
        anthropic = AnthropicClient(temperature=temp)
        openai = OpenAICompatibleClient(temperature=temp)
        if anthropic.available():
            inner = anthropic
        elif openai.available():
            inner = openai
        else:
            inner = OfflineSyntheticFallback()
    return CachingClient(inner, cache_path, refresh=refresh)


# ===========================================================================
# 2. Prompt construction
# ===========================================================================
SYSTEM_PROMPT = """\
You are a UAV-IoT service-policy REPAIR agent inside an offline closed-loop \
design workflow. A single UAV serves ground IoT device clusters. After a \
simulation run, you receive the QoS-aware service contract, a diagnosis of how \
the current policy failed under a traffic burst + regional link degradation, \
and the history of policies already tried. Your job is to propose the NEXT \
candidate policy as a single repair action.

You may ONLY use these UAV-IoT policy operations (anything else is ignored):
- route_clusters: an ordered visit list over {west_cluster, east_hotspot, north_cluster}; \
the hotspot may appear twice. 2-6 entries.
- dwell_times: integer slots per route stop, one per route entry, each 3-30.
- protocol_mode: one of best_rate | degraded_aware | nominal. \
degraded_aware avoids the short-range high-rate link inside degraded regions.
- min_protocol_hold_slots: 0-12, hysteresis to suppress protocol thrashing.
- local_triggers: null, OR an execution-time CASP rule on a cluster with fields \
queue_threshold(5-60), release_threshold(0-40), max_blackout_threshold_slots(4-40), \
fallback_dwell_min_slots(1-12), cooldown_slots(0-40). The fallback waypoint is \
fixed to that cluster's centroid automatically.
- request_replanning: true only if local repairs cannot plausibly clear the violation.

Rules:
1. Justify the action from the diagnosis EVIDENCE (which metric failed, where, why).
2. Do NOT repeat a change that already failed in the history.
3. Prefer the smallest change that addresses the diagnosed cause.
4. Respond with a SINGLE JSON object and nothing else.

Required JSON shape:
{"rationale": str, "route_clusters": [str], "dwell_times": [int], \
"protocol_mode": str, "min_protocol_hold_slots": int, \
"local_triggers": null|{...}, "request_replanning": bool}
"""

# Optional improved guidance (opt-in via UAV_LLM_PROMPT=v2). It adds general
# domain CONTROL PRINCIPLES without leaking the reference-specific values, so the
# comparison stays fair. v1 (default) preserves the original prompt/results.
_PROMPT_V2_SUFFIX = """

Guidance (important):
- recovery_time and max_blackout are usually the hardest constraints; prioritise them.
- A local trigger only helps if it fires EARLY. Set its thresholds well BELOW the \
contract limits so the rule acts preventively (before a violation), not after: a \
max-blackout trigger threshold should be a small fraction of the contract's \
max-blackout limit, and the queue threshold a fraction of the observed peak backlog.
- When a region shows blackout or slow recovery, prefer adding a local trigger for \
that region with tight thresholds plus enough fallback dwell, rather than only \
enlarging global dwell.
"""

if os.environ.get("UAV_LLM_PROMPT", "v1").lower() == "v2":
    SYSTEM_PROMPT = SYSTEM_PROMPT + _PROMPT_V2_SUFFIX


def _policy_view(policy: dict[str, Any]) -> dict[str, Any]:
    return {
        "route_clusters": [wp["cluster"] for wp in policy.get("route", [])],
        "dwell_times": [wp["dwell"] for wp in policy.get("route", [])],
        "protocol_mode": policy.get("protocol_mode"),
        "min_protocol_hold_slots": policy.get("min_protocol_hold_slots", 0),
        "local_triggers": policy.get("local_triggers"),
    }


def build_prompt_context(iteration: int, policy: dict[str, Any],
                         diagnosis: dict[str, Any], metrics: dict[str, Any],
                         history: list[dict[str, Any]]) -> dict[str, Any]:
    """Compact JSON context. Used verbatim by the offline synthetic fallback and embedded
    into the human-readable user message for real models."""
    return {
        "iteration": iteration,
        "contract": {
            "qos_thresholds": CONTRACT["qos_thresholds"],
            "promotion_criteria": CONTRACT["promotion_criteria"],
            "perturbation": CONTRACT["perturbation"],
        },
        "current_policy": _policy_view(policy),
        "current_metrics": metrics,
        "latest_diagnosis": {
            "failure_types": diagnosis.get("failure_types"),
            "affected_cluster": diagnosis.get("affected_cluster"),
            "time_window": diagnosis.get("time_window"),
            "evidence": diagnosis.get("evidence"),
            "likely_cause": diagnosis.get("likely_cause"),
        },
        "history": history,
    }


def build_user_message(ctx: dict[str, Any]) -> str:
    """Human-readable framing wrapped around the JSON context for real models."""
    return (
        "Repair iteration "
        f"{ctx['iteration']}. Here is the current state as JSON.\n\n"
        + json.dumps(ctx, ensure_ascii=False, indent=2)
        + "\n\nReturn the next repair action as a single JSON object."
    )


# ===========================================================================
# 3. Parse + validate + apply (the safety boundary around the model)
# ===========================================================================
def extract_json(text: str) -> dict[str, Any] | None:
    text = text.strip()
    if "```" in text:  # strip a fenced block if present
        start = text.find("```")
        end = text.find("```", start + 3)
        if end != -1:
            block = text[start + 3:end]
            if block.lstrip().lower().startswith("json"):
                block = block.lstrip()[4:]
            text = block.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    l, r = text.find("{"), text.rfind("}")
    if l != -1 and r != -1 and r > l:
        try:
            return json.loads(text[l:r + 1])
        except json.JSONDecodeError:
            return None
    return None


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def validate_and_apply(prev_policy: dict[str, Any], action: dict[str, Any] | None,
                       new_policy_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    """Coerce the model's action into a legal policy; record what was clamped."""
    prev_view = _policy_view(prev_policy)
    notes: list[str] = []
    action = action or {}

    # --- route clusters ---
    raw_route = action.get("route_clusters") or prev_view["route_clusters"]
    route = [c for c in raw_route if c in ALLOWED_CLUSTERS]
    if not route:
        route = prev_view["route_clusters"] or ["west_cluster", "east_hotspot", "north_cluster"]
        notes.append("route_clusters empty/invalid -> kept previous")
    lo, hi = BOUNDS["route_len"]
    if len(route) > hi:
        route = route[:hi]; notes.append(f"route truncated to {hi}")
    if len(route) < lo:
        route = (route + ["east_hotspot"] * lo)[:lo]; notes.append("route padded to min length")

    # --- dwell times ---
    raw_dwell = action.get("dwell_times") or prev_view["dwell_times"] or []
    dwell: list[int] = []
    dlo, dhi = BOUNDS["dwell"]
    for i in range(len(route)):
        val = raw_dwell[i] if i < len(raw_dwell) else 10
        try:
            val = int(round(float(val)))
        except (TypeError, ValueError):
            val = 10; notes.append(f"dwell[{i}] non-numeric -> 10")
        c = int(_clamp(val, dlo, dhi))
        if c != val:
            notes.append(f"dwell[{i}] {val}->{c}")
        dwell.append(c)

    # --- protocol mode ---
    mode = action.get("protocol_mode")
    if mode not in ALLOWED_PROTOCOL_MODES:
        if mode is not None:
            notes.append(f"protocol_mode '{mode}' invalid -> {prev_view['protocol_mode']}")
        mode = prev_view["protocol_mode"] if prev_view["protocol_mode"] in ALLOWED_PROTOCOL_MODES else "best_rate"

    # --- protocol hold ---
    hlo, hhi = BOUNDS["min_protocol_hold_slots"]
    try:
        hold = int(round(float(action.get("min_protocol_hold_slots", prev_view["min_protocol_hold_slots"]))))
    except (TypeError, ValueError):
        hold = prev_view["min_protocol_hold_slots"]
    hold = int(_clamp(hold, hlo, hhi))

    # --- build base policy ---
    policy = route_policy(new_policy_id, route, dwell, mode)
    policy["min_protocol_hold_slots"] = hold

    # --- local triggers ---
    trig = action.get("local_triggers")
    applied_trig = None
    if isinstance(trig, dict):
        cluster = trig.get("cluster")
        if cluster not in ALLOWED_CLUSTERS:
            cluster = "east_hotspot"; notes.append("trigger cluster -> east_hotspot")

        def cnum(field: str, default: float) -> float:
            try:
                v = float(trig.get(field, default))
            except (TypeError, ValueError):
                v = default
            lo_, hi_ = BOUNDS[field]
            cv = _clamp(v, lo_, hi_)
            if cv != v:
                notes.append(f"{field} {v}->{cv}")
            return cv

        q = cnum("queue_threshold", 18.0)
        rel = cnum("release_threshold", 10.0)
        if rel > q:
            rel = q * 0.55; notes.append("release_threshold > queue_threshold -> lowered")
        applied_trig = {
            "cluster": cluster,
            "queue_threshold": q,
            "release_threshold": rel,
            "max_blackout_threshold_slots": int(cnum("max_blackout_threshold_slots", 16)),
            # waypoint is FORCED to the cluster centroid; the model cannot place arbitrary points
            "fallback_waypoint": list(cluster_centroid(cluster)),
            "fallback_dwell_min_slots": int(cnum("fallback_dwell_min_slots", 3)),
            "cooldown_slots": int(cnum("cooldown_slots", 16)),
        }
    elif trig not in (None,):
        notes.append("local_triggers not an object -> null")
    policy["local_triggers"] = applied_trig

    applied = {
        "rule": "llm_repair",
        "rationale": str(action.get("rationale", ""))[:500],
        "route_clusters": route,
        "dwell_times": dwell,
        "protocol_mode": mode,
        "min_protocol_hold_slots": hold,
        "local_triggers": applied_trig,
        "request_replanning": bool(action.get("request_replanning", False)),
        "clamp_notes": notes,
        "changed_policy_fields": _changed_fields(prev_view, _policy_view(policy)),
    }
    return policy, applied


def _changed_fields(a: dict[str, Any], b: dict[str, Any]) -> list[str]:
    return [k for k in a if a.get(k) != b.get(k)]


# ===========================================================================
# 4. The agent loop
# ===========================================================================
def propose_repair(client: Any, iteration: int, policy: dict[str, Any],
                   diagnosis: dict[str, Any], metrics: dict[str, Any],
                   history: list[dict[str, Any]]) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    ctx = build_prompt_context(iteration, policy, diagnosis, metrics, history)
    # Real models get the human-readable message; the offline synthetic fallback reads the
    # raw JSON context (so we hand it the JSON string as the user payload).
    inner_provider = getattr(getattr(client, "inner", None), "provider", "offline_synthetic")
    user = json.dumps(ctx, ensure_ascii=False) if inner_provider == "offline_synthetic" else build_user_message(ctx)

    res = client.complete(SYSTEM_PROMPT, user)
    action = extract_json(res.text)
    agent_io = {
        "provider": res.provider,
        "model": res.model,
        "mode": res.mode,
        "parsed_ok": action is not None,
        "prompt_hash": CachingClient._key(res.provider, res.model, SYSTEM_PROMPT, user),
        "rationale": (action or {}).get("rationale", "")[:300] if isinstance(action, dict) else "",
        "raw_response_preview": res.text[:600],
        "usage": res.usage,
    }
    return action, agent_io


def _history_entry(candidate_id: str, applied: dict[str, Any] | None,
                   metrics: dict[str, Any]) -> dict[str, Any]:
    return {
        "candidate_id": candidate_id,
        "change": (applied or {}).get("changed_policy_fields", "nominal"),
        "qsr": metrics["qsr"],
        "max_blackout": metrics["max_blackout"],
        "recovery_time": metrics["recovery_time"],
        "passed_contract": metrics["passed_contract"],
    }


def run_llm_closed_loop(seed: int, scenario: dict[str, Any], base_policy: dict[str, Any],
                        client: Any | None = None, max_iters: int | None = None) -> dict[str, Any]:
    """
    LLM-in-the-loop counterpart of run_closed_loop().

    Returns the SAME keys (records, final_policy, final_result, casp,
    stage_results) so the main experiment's exports and figures work unchanged.
    Each repair candidate is generated by the model, validated, re-simulated,
    re-diagnosed, and recorded together with the agent's I/O.
    """
    if client is None:
        client = make_client()
    if max_iters is None:
        max_iters = int(os.environ.get("UAV_LLM_MAX_ITERS", "3"))

    records: list[dict[str, Any]] = []
    history: list[dict[str, Any]] = []

    # candidate 0: nominal (no repair) -- identical role to the scripted loop
    cand0 = json.loads(json.dumps(base_policy))
    cand0["policy_id"] = "workflow_llm_cand_0_nominal"
    res0 = simulate_policy(scenario, cand0)
    diag0 = diagnose(seed, scenario, res0)
    rec0 = candidate_record(seed, "llm_cand_0_nominal", cand0, res0, diag0, None)
    rec0["agent_io"] = {"mode": "no_repair", "provider": "none", "model": "none"}
    records.append(rec0)
    history.append(_history_entry("llm_cand_0_nominal", None, res0["metrics"]))

    candidates: list[tuple[str, dict[str, Any], dict[str, Any]]] = [("llm_cand_0_nominal", cand0, res0)]
    prev_policy, cur_diag, cur_metrics = cand0, diag0, res0["metrics"]
    stage_results = [res0]

    for k in range(1, max_iters + 1):
        action, agent_io = propose_repair(client, k, prev_policy, cur_diag, cur_metrics, history)
        new_policy, applied = validate_and_apply(prev_policy, action, f"workflow_llm_cand_{k}")
        res = simulate_policy(scenario, new_policy)
        diag = diagnose(seed, scenario, res)
        cid = f"llm_cand_{k}_repair"
        rec = candidate_record(seed, cid, new_policy, res, diag, applied)
        rec["agent_io"] = agent_io
        records.append(rec)
        history.append(_history_entry(cid, applied, res["metrics"]))
        candidates.append((cid, new_policy, res))
        stage_results.append(res)

        prev_policy, cur_diag, cur_metrics = new_policy, diag, res["metrics"]

        # Stop early on a validated contract pass, or if the agent escalates.
        if res["metrics"]["passed_contract"] or applied.get("request_replanning"):
            break

    # promotion: same rule as the scripted loop (global best candidate)
    promoted_id, promoted_policy, promoted_result = max(
        candidates, key=lambda item: promotion_score(item[2], item[1])
    )
    by_id = {cid: pol for cid, pol, _ in candidates}
    for record in records:
        cid = record["candidate_id"]
        pol = by_id.get(cid, prev_policy)
        record["decision"]["promotion_score"] = round(
            promotion_score({"metrics": record["metrics"]}, pol), 4
        )
        record["decision"]["promoted"] = (cid == promoted_id)

    casp = {
        "seed": seed,
        "scenario_id": CONTRACT["scenario_id"],
        "generator": "llm_closed_loop",
        "agent_backend": {
            "provider": getattr(getattr(client, "inner", None), "provider", "offline_synthetic"),
            "model": getattr(getattr(client, "inner", None), "model", "rule_synthesis_v1"),
            "modes_used": sorted({r.get("agent_io", {}).get("mode", "?") for r in records[1:]}),
        },
        "nominal_policy": {
            "route_clusters": [wp["cluster"] for wp in promoted_policy["route"]],
            "route_waypoints": [wp["xy"] for wp in promoted_policy["route"]],
            "dwell_times": [wp["dwell"] for wp in promoted_policy["route"]],
        },
        "protocol_rules": {
            "mode": promoted_policy.get("protocol_mode"),
            "min_hold_slots": promoted_policy.get("min_protocol_hold_slots", 0),
        },
        "local_triggers": promoted_policy.get("local_triggers"),
        "repair_rules": [
            r["repair_action"] for r in records if r.get("repair_action")
        ],
        "candidate_records": [r["candidate_id"] for r in records],
        "promoted_candidate": promoted_id,
        "validation_evidence": promoted_result["metrics"],
    }

    return {
        "records": records,
        "final_policy": promoted_policy,
        "final_result": promoted_result,
        "casp": casp,
        "stage_results": stage_results,
    }


# ===========================================================================
# 5. Self-test
# ===========================================================================
def _selftest() -> None:
    from run_uav_iot_workflow_experiment import make_scenario, optimize_nominal_policy

    print("=== llm_repair_agent self-test (offline-synthetic unless keys are set) ===")
    client = make_client()
    inner = getattr(client, "inner", None)
    print(f"backend provider = {getattr(inner, 'provider', '?')}, "
          f"model = {getattr(inner, 'model', '?')}")

    seed = 5
    perturbed = make_scenario(seed, perturbation=True)
    nominal = make_scenario(seed, perturbation=False)
    static_policy = optimize_nominal_policy(seed, nominal)

    loop = run_llm_closed_loop(seed, perturbed, static_policy, client=client, max_iters=3)

    print(f"\ncandidates generated: {len(loop['records'])}")
    for r in loop["records"]:
        m = r["metrics"]
        io = r.get("agent_io", {})
        ra = r.get("repair_action") or {}
        print(f"  {r['candidate_id']:24} mode={io.get('mode','-'):14} "
              f"parsed_ok={io.get('parsed_ok','-')!s:5} "
              f"QSR={m['qsr']:.3f} Bmax={m['max_blackout']:>3} "
              f"Trec={m['recovery_time']:>3} pass={m['passed_contract']!s:5} "
              f"promoted={r['decision'].get('promoted')} "
              f"changed={ra.get('changed_policy_fields','-')}")
    fm = loop["final_result"]["metrics"]
    print(f"\npromoted = {loop['casp']['promoted_candidate']}  "
          f"QSR={fm['qsr']:.3f} pass={fm['passed_contract']}")
    print(f"agent backend in CASP = {loop['casp']['agent_backend']}")

    # Validate that a hostile/garbage action is clamped, never crashes.
    bad = {"route_clusters": ["MARS", "east_hotspot"], "dwell_times": [999, -5],
           "protocol_mode": "telepathy", "min_protocol_hold_slots": 99,
           "local_triggers": {"cluster": "MARS", "queue_threshold": 9999}}
    pol, applied = validate_and_apply(static_policy, bad, "test_clamp")
    assert all(c in ALLOWED_CLUSTERS for c in [wp["cluster"] for wp in pol["route"]])
    assert all(3 <= wp["dwell"] <= 30 for wp in pol["route"])
    assert pol["protocol_mode"] in ALLOWED_PROTOCOL_MODES
    assert 0 <= pol["min_protocol_hold_slots"] <= 12
    assert pol["local_triggers"]["cluster"] in ALLOWED_CLUSTERS
    assert pol["local_triggers"]["queue_threshold"] <= 60.0
    print(f"\nadversarial-action clamp test PASSED; clamp_notes={len(applied['clamp_notes'])} fixes")
    print("=== self-test OK ===")


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        _selftest()
    else:
        print("Import this module, or run:  python llm_repair_agent.py --selftest")
