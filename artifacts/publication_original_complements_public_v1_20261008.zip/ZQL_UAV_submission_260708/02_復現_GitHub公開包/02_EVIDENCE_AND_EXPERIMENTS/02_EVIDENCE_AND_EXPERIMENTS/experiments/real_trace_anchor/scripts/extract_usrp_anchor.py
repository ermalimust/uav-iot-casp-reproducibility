from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from statistics import mean
from typing import Iterable


SCRIPT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = SCRIPT_ROOT / "data" / "raw" / "aerpaw_aadm"
DEFAULT_OUT = SCRIPT_ROOT / "results"


def norm(name: str) -> str:
    return name.strip().lower().replace(" ", "_").replace("-", "_")


def parse_float(value: str | None) -> float | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.lower() in {"nan", "none", "null"}:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def quantiles(values: list[float]) -> dict[str, float | None]:
    if not values:
        return {
            "count": 0,
            "min": None,
            "p05": None,
            "p25": None,
            "p50": None,
            "p75": None,
            "p95": None,
            "max": None,
            "mean": None,
        }
    ordered = sorted(values)

    def q(prob: float) -> float:
        idx = round((len(ordered) - 1) * prob)
        return ordered[idx]

    return {
        "count": len(ordered),
        "min": ordered[0],
        "p05": q(0.05),
        "p25": q(0.25),
        "p50": q(0.50),
        "p75": q(0.75),
        "p95": q(0.95),
        "max": ordered[-1],
        "mean": mean(ordered),
    }


def discover_csvs(paths: list[Path], names: Iterable[str]) -> list[Path]:
    wanted = {name.lower() for name in names}
    found: list[Path] = []
    for path in paths:
        if path.is_file() and path.name.lower() in wanted:
            found.append(path)
        elif path.is_dir():
            for name in wanted:
                found.extend(path.rglob(name))
    return sorted(set(found))


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = []
        for row in reader:
            row["_source_file"] = str(path)
            rows.append(row)
        return rows


def find_time_col(fieldnames: list[str]) -> str | None:
    normalized = {norm(name): name for name in fieldnames}
    for candidate in ["mission_time", "elapsed_time", "num", "time", "timestamp"]:
        if candidate in normalized:
            return normalized[candidate]
    return None


def find_columns(fieldnames: list[str], prefix: str) -> list[str]:
    pattern = re.compile(rf"^{re.escape(prefix)}_?lw\d+$", re.IGNORECASE)
    return [name for name in fieldnames if pattern.match(norm(name))]


def ordered_time_rows(rows: list[dict[str, str]], time_col: str | None) -> list[dict[str, str]]:
    if not time_col:
        return rows
    return sorted(rows, key=lambda row: parse_float(row.get(time_col)) if parse_float(row.get(time_col)) is not None else float("inf"))


def outage_runs(rows: list[dict[str, str]], col: str, time_col: str | None, threshold: float) -> dict[str, float | int | None]:
    ordered = ordered_time_rows(rows, time_col)
    runs: list[float] = []
    current_start: float | None = None
    current_last: float | None = None
    fallback_step = 1.0
    for index, row in enumerate(ordered):
        value = parse_float(row.get(col))
        t = parse_float(row.get(time_col)) if time_col else float(index)
        if t is None:
            t = float(index)
        is_outage = value is None or value < threshold
        if is_outage and current_start is None:
            current_start = t
            current_last = t
        elif is_outage:
            current_last = t
        elif current_start is not None:
            runs.append((current_last if current_last is not None else t) - current_start + fallback_step)
            current_start = None
            current_last = None
    if current_start is not None:
        runs.append((current_last if current_last is not None else current_start) - current_start + fallback_step)
    return {
        "threshold_db": threshold,
        "num_outage_runs": len(runs),
        "max_outage_seconds": max(runs) if runs else 0.0,
        "mean_outage_seconds": mean(runs) if runs else 0.0,
    }


def download_increment_summary(rows: list[dict[str, str]], col: str, time_col: str | None) -> dict[str, object]:
    ordered = ordered_time_rows(rows, time_col)
    increments: list[float] = []
    last_value: float | None = None
    last_time: float | None = None
    for index, row in enumerate(ordered):
        value = parse_float(row.get(col))
        t = parse_float(row.get(time_col)) if time_col else float(index)
        if value is None or t is None:
            continue
        if last_value is not None and last_time is not None:
            dt = max(t - last_time, 1e-9)
            dv = max(value - last_value, 0.0)
            increments.append(dv / dt)
        last_value = value
        last_time = t
    return {"increment_per_second": quantiles(increments)}


def summarize_snr(files: list[Path], threshold: float) -> dict[str, object]:
    per_file = []
    all_values_by_col: dict[str, list[float]] = {}
    outage_by_col = []
    for file in files:
        rows = load_csv(file)
        if not rows:
            continue
        fieldnames = list(rows[0].keys())
        time_col = find_time_col(fieldnames)
        snr_cols = find_columns(fieldnames, "snr")
        for col in snr_cols:
            values = [value for value in (parse_float(row.get(col)) for row in rows) if value is not None]
            all_values_by_col.setdefault(norm(col), []).extend(values)
            outage_by_col.append(
                {
                    "file": str(file),
                    "column": col,
                    **outage_runs(rows, col, time_col, threshold),
                }
            )
        per_file.append({"file": str(file), "rows": len(rows), "time_col": time_col, "snr_cols": snr_cols})
    return {
        "files": per_file,
        "snr_by_link": {col: quantiles(values) for col, values in all_values_by_col.items()},
        "outage_by_file_link": outage_by_col,
    }


def summarize_download(files: list[Path]) -> dict[str, object]:
    per_file = []
    increments = []
    for file in files:
        rows = load_csv(file)
        if not rows:
            continue
        fieldnames = list(rows[0].keys())
        time_col = find_time_col(fieldnames)
        dl_cols = find_columns(fieldnames, "dl")
        for col in dl_cols:
            increments.append(
                {
                    "file": str(file),
                    "column": col,
                    **download_increment_summary(rows, col, time_col),
                }
            )
        per_file.append({"file": str(file), "rows": len(rows), "time_col": time_col, "download_cols": dl_cols})
    return {"files": per_file, "download_increment_by_file_link": increments}


def write_metric_csv(summary: dict[str, object], out_dir: Path) -> None:
    path = out_dir / "usrp_anchor_metrics.csv"
    rows = []
    snr = summary.get("snr", {})
    if isinstance(snr, dict):
        snr_by_link = snr.get("snr_by_link", {})
        if isinstance(snr_by_link, dict):
            for link, block in snr_by_link.items():
                if isinstance(block, dict):
                    for metric, value in block.items():
                        rows.append({"block": f"snr:{link}", "metric": metric, "value": value})
    download = summary.get("download", {})
    if isinstance(download, dict):
        increments = download.get("download_increment_by_file_link", [])
        if isinstance(increments, list):
            for item in increments:
                if not isinstance(item, dict):
                    continue
                block = f"download:{Path(str(item.get('file', 'unknown'))).name}:{item.get('column')}"
                metrics = item.get("increment_per_second", {})
                if isinstance(metrics, dict):
                    for metric, value in metrics.items():
                        rows.append({"block": block, "metric": metric, "value": value})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["block", "metric", "value"])
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract AERPAW AADM USRP processed trace anchors.")
    parser.add_argument("--input", nargs="+", type=Path, default=[DEFAULT_INPUT], help="CSV file(s) or directories")
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT, help="Output directory")
    parser.add_argument("--snr-outage-threshold", type=float, default=0.0, help="SNR below this value counts as low-SNR outage")
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    snr_files = discover_csvs(args.input, ["vehicleOut_snr.csv"])
    down_files = discover_csvs(args.input, ["vehicleOut_down.csv", "vehicleOut_download.csv"])
    summary = {
        "dataset": "AERPAW AADM USRP processed traces",
        "snr_files": len(snr_files),
        "download_files": len(down_files),
        "snr": summarize_snr(snr_files, args.snr_outage_threshold),
        "download": summarize_download(down_files),
        "paper_boundary": (
            "Use these values to anchor SNR and download-variation ranges. "
            "They do not validate the proposed workflow as a hardware system."
        ),
    }
    (args.out_dir / "usrp_anchor_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    write_metric_csv(summary, args.out_dir)
    print(f"Loaded {len(snr_files)} SNR file(s) and {len(down_files)} download file(s).")
    print(f"Wrote {args.out_dir / 'usrp_anchor_summary.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
