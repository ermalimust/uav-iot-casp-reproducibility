from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from statistics import mean
from typing import Iterable


SCRIPT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = SCRIPT_ROOT / "data" / "raw" / "aerpaw_aadm"
DEFAULT_OUT = SCRIPT_ROOT / "results"


def norm(name: str) -> str:
    return name.strip().lower().replace(" ", "_").replace("-", "_")


def find_col(fieldnames: list[str], candidates: Iterable[str]) -> str | None:
    by_norm = {norm(name): name for name in fieldnames}
    for candidate in candidates:
        found = by_norm.get(norm(candidate))
        if found:
            return found
    return None


def parse_float(value: str | None) -> float | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def parse_int(value: str | None) -> int | None:
    parsed = parse_float(value)
    if parsed is None:
        return None
    return int(parsed)


def parse_time(value: str | None) -> datetime | None:
    if not value:
        return None
    text = value.strip()
    formats = [
        "%Y-%m-%d %H:%M:%S.%f%z",
        "%Y-%m-%d %H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%d %H:%M:%S.%f",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S",
    ]
    cleaned = text.replace("Z", "+0000")
    if len(cleaned) >= 6 and cleaned[-3] == ":" and cleaned[-6] in ["+", "-"]:
        cleaned = cleaned[:-3] + cleaned[-2:]
    for fmt in formats:
        try:
            return datetime.strptime(cleaned, fmt)
        except ValueError:
            continue
    return None


def quantiles(values: list[float]) -> dict[str, float | None]:
    if not values:
        return {
            "count": 0,
            "min": None,
            "p05": None,
            "p25": None,
            "p50": None,
            "p75": None,
            "p95": None,
            "max": None,
            "mean": None,
        }
    ordered = sorted(values)

    def q(prob: float) -> float:
        idx = round((len(ordered) - 1) * prob)
        return ordered[idx]

    return {
        "count": len(ordered),
        "min": ordered[0],
        "p05": q(0.05),
        "p25": q(0.25),
        "p50": q(0.50),
        "p75": q(0.75),
        "p95": q(0.95),
        "max": ordered[-1],
        "mean": mean(ordered),
    }


def discover_csvs(paths: list[Path]) -> list[Path]:
    found: list[Path] = []
    for path in paths:
        if path.is_file() and path.suffix.lower() == ".csv":
            found.append(path)
        elif path.is_dir():
            for pattern in ["All_Logs.csv", "LORAlog.csv", "*.csv"]:
                found.extend(path.rglob(pattern))
    return sorted(set(found))


def load_rows(files: list[Path]) -> tuple[list[dict[str, str]], dict[str, object]]:
    rows: list[dict[str, str]] = []
    file_counts: dict[str, int] = {}
    skipped: dict[str, str] = {}
    for file in files:
        try:
            with file.open("r", encoding="utf-8-sig", newline="") as handle:
                reader = csv.DictReader(handle)
                if not reader.fieldnames:
                    skipped[str(file)] = "missing header"
                    continue
                count = 0
                for row in reader:
                    row["_source_file"] = str(file)
                    rows.append(row)
                    count += 1
                file_counts[str(file)] = count
        except UnicodeDecodeError:
            skipped[str(file)] = "encoding error"
        except OSError as exc:
            skipped[str(file)] = str(exc)
    return rows, {"file_counts": file_counts, "skipped": skipped}


def frame_gap_summary(rows: list[dict[str, str]], fields: dict[str, str | None]) -> dict[str, object]:
    fcnt_col = fields.get("frame_counter")
    if not fcnt_col:
        return {"available": False, "reason": "frame counter column not found"}
    device_col = fields.get("device_id")
    gateway_col = fields.get("gateway_id")
    time_col = fields.get("time")
    groups: dict[tuple[str, str, str], list[tuple[datetime | None, int]]] = defaultdict(list)
    for row in rows:
        fcnt = parse_int(row.get(fcnt_col))
        if fcnt is None:
            continue
        device = row.get(device_col, "unknown_device") if device_col else "unknown_device"
        gateway = row.get(gateway_col, "all_gateways") if gateway_col else "all_gateways"
        source = row.get("_source_file", "unknown_file")
        timestamp = parse_time(row.get(time_col)) if time_col else None
        groups[(source or "unknown_file", device or "unknown_device", gateway or "all_gateways")].append((timestamp, fcnt))

    missing_total = 0
    observed_pairs = 0
    group_summaries = []
    for key, values in groups.items():
        values = sorted(values, key=lambda item: (item[0] is None, item[0] or datetime.min, item[1]))
        missing = 0
        transitions = 0
        last_fcnt = None
        for _, fcnt in values:
            if last_fcnt is not None and fcnt > last_fcnt:
                gap = fcnt - last_fcnt
                if gap > 1:
                    missing += gap - 1
                transitions += 1
            last_fcnt = fcnt
        missing_total += missing
        observed_pairs += max(0, len(values) - 1)
        group_summaries.append(
            {
                "source_file": key[0],
                "device": key[1],
                "gateway": key[2],
                "packets": len(values),
                "missing_by_fcnt": missing,
                "transitions": transitions,
            }
        )

    observed_packets = sum(len(values) for values in groups.values())
    denominator = observed_packets + missing_total
    return {
        "available": True,
        "groups": len(groups),
        "observed_packets": observed_packets,
        "observed_transitions": observed_pairs,
        "missing_by_fcnt": missing_total,
        "loss_ratio_proxy": (missing_total / denominator) if denominator else None,
        "top_groups_by_missing": sorted(group_summaries, key=lambda item: item["missing_by_fcnt"], reverse=True)[:10],
    }


def interarrival_summary(rows: list[dict[str, str]], fields: dict[str, str | None]) -> dict[str, object]:
    time_col = fields.get("time")
    if not time_col:
        return {"available": False, "reason": "time column not found"}
    device_col = fields.get("device_id")
    gateway_col = fields.get("gateway_id")
    groups: dict[tuple[str, str, str], list[datetime]] = defaultdict(list)
    for row in rows:
        timestamp = parse_time(row.get(time_col))
        if timestamp is None:
            continue
        device = row.get(device_col, "unknown_device") if device_col else "unknown_device"
        gateway = row.get(gateway_col, "all_gateways") if gateway_col else "all_gateways"
        source = row.get("_source_file", "unknown_file")
        groups[(source or "unknown_file", device or "unknown_device", gateway or "all_gateways")].append(timestamp)
    intervals: list[float] = []
    for values in groups.values():
        ordered = sorted(values)
        for before, after in zip(ordered, ordered[1:]):
            delta = (after - before).total_seconds()
            if delta >= 0:
                intervals.append(delta)
    return {"available": True, "interval_seconds": quantiles(intervals)}


def summarize(rows: list[dict[str, str]], file_meta: dict[str, object]) -> dict[str, object]:
    if not rows:
        return {
            "dataset": "AERPAW AADM LoRa trace",
            "rows": 0,
            "error": "No rows loaded. Place selected LORAlog.csv or All_Logs.csv files under data/raw/aerpaw_aadm.",
            "file_meta": file_meta,
        }

    fieldnames = list(rows[0].keys())
    fields = {
        "rssi": find_col(fieldnames, ["rx_info_rssi", "rssi", "RSSI"]),
        "snr": find_col(fieldnames, ["rx_info_snr", "snr", "SNR"]),
        "time": find_col(fieldnames, ["rx_info_time", "rx_info_timeSinceGpsEpoch", "time"]),
        "data_rate": find_col(fieldnames, ["dr", "data_rate", "datarate"]),
        "spreading_factor": find_col(
            fieldnames,
            ["tx_info_modulation_spreadingFactor", "spreadingFactor", "sf"],
        ),
        "frame_counter": find_col(fieldnames, ["f_cnt", "fcnt", "frame_counter"]),
        "gateway_id": find_col(fieldnames, ["rx_info_gatewayId", "gateway_id", "gateway"]),
        "device_id": find_col(fieldnames, ["dev_eui", "device_eui", "device_id"]),
    }

    rssi_values = [value for value in (parse_float(row.get(fields["rssi"])) for row in rows) if value is not None] if fields["rssi"] else []
    snr_values = [value for value in (parse_float(row.get(fields["snr"])) for row in rows) if value is not None] if fields["snr"] else []

    data_rate_counts = Counter(row.get(fields["data_rate"], "").strip() for row in rows) if fields["data_rate"] else Counter()
    sf_counts = Counter(row.get(fields["spreading_factor"], "").strip() for row in rows) if fields["spreading_factor"] else Counter()
    gateway_counts = Counter(row.get(fields["gateway_id"], "").strip() for row in rows) if fields["gateway_id"] else Counter()

    return {
        "dataset": "AERPAW AADM LoRa trace",
        "rows": len(rows),
        "loaded_files": file_meta,
        "detected_columns": fields,
        "rssi_dbm": quantiles(rssi_values),
        "snr_db": quantiles(snr_values),
        "data_rate_counts": dict(data_rate_counts.most_common(20)),
        "spreading_factor_counts": dict(sf_counts.most_common(20)),
        "gateway_counts": dict(gateway_counts.most_common(20)),
        "frame_counter_gap": frame_gap_summary(rows, fields),
        "interarrival": interarrival_summary(rows, fields),
        "paper_boundary": (
            "Use these values as empirical anchors for link-quality ranges and outage proxies. "
            "Do not describe them as hardware validation of the proposed workflow."
        ),
    }


def write_metric_csv(summary: dict[str, object], out_dir: Path) -> None:
    path = out_dir / "lora_anchor_metrics.csv"
    rows = []
    for block_name in ["rssi_dbm", "snr_db"]:
        block = summary.get(block_name, {})
        if isinstance(block, dict):
            for metric, value in block.items():
                rows.append({"block": block_name, "metric": metric, "value": value})
    frame_gap = summary.get("frame_counter_gap", {})
    if isinstance(frame_gap, dict):
        for metric in ["observed_packets", "missing_by_fcnt", "loss_ratio_proxy"]:
            rows.append({"block": "frame_counter_gap", "metric": metric, "value": frame_gap.get(metric)})
    interarrival = summary.get("interarrival", {})
    if isinstance(interarrival, dict) and isinstance(interarrival.get("interval_seconds"), dict):
        for metric, value in interarrival["interval_seconds"].items():
            rows.append({"block": "interarrival_seconds", "metric": metric, "value": value})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["block", "metric", "value"])
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract AERPAW AADM LoRa trace anchors.")
    parser.add_argument("--input", nargs="+", type=Path, default=[DEFAULT_INPUT], help="CSV file(s) or directories")
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT, help="Output directory")
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    files = discover_csvs(args.input)
    per_flight_logs = [file for file in files if file.name.lower() == "loralog.csv"]
    lora_files = per_flight_logs or [file for file in files if file.name.lower() == "all_logs.csv"]
    if not lora_files:
        lora_files = files
    rows, file_meta = load_rows(lora_files)
    summary = summarize(rows, file_meta)
    (args.out_dir / "lora_anchor_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    write_metric_csv(summary, args.out_dir)
    print(f"Loaded {summary.get('rows', 0)} LoRa rows from {len(lora_files)} file(s).")
    print(f"Wrote {args.out_dir / 'lora_anchor_summary.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
