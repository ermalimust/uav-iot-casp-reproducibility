"""User-run DNS, selected-route and verified TLS checks; never call a model or read API keys."""
import argparse
import http.client
import ipaddress
import json
import os
import socket
import subprocess
import time
import winreg
from datetime import datetime, timezone
from pathlib import Path

HOST = "dashscope.aliyuncs.com"
FAKE_IP_RANGE = ipaddress.ip_network("198.18.0.0/15")


def safe_error(error):
    return {"type": type(error).__name__, "errno": getattr(error, "errno", None),
            "winerror": getattr(error, "winerror", None),
            "verify_code": getattr(error, "verify_code", None)}


def powershell_json(command):
    binary = Path(os.environ.get("SystemRoot", "C:/Windows")) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    prefix = "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[Text.UTF8Encoding]::new(); "
    try:
        result = subprocess.run([str(binary), "-NoProfile", "-NonInteractive", "-Command", prefix + command],
                                capture_output=True, timeout=20, encoding="utf-8", errors="replace")
        if result.returncode:
            return {"ok": False, "exit_code": result.returncode}
        return {"ok": True, "data": json.loads(result.stdout.strip())}
    except (OSError, ValueError, subprocess.TimeoutExpired) as error:
        return {"ok": False, "error": safe_error(error)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--flush-dns", action="store_true",
                        help="Explicitly clear the Windows local DNS cache; never elevate automatically.")
    args = parser.parse_args()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output = Path(__file__).resolve().parent / "results/network_repair_20261006" / ("manual_" + stamp)
    output.mkdir(parents=True, exist_ok=False)
    path = output / "connection_check.json"
    record = {"checked_at_utc": datetime.now(timezone.utc).isoformat(), "target": HOST,
              "role": "manual_network_diagnostic_not_model_authentication_or_performance",
              "model_requests": 0, "http_requests": 0, "api_key_variables_read": False,
              "dns_servers_routes_or_application_settings_changed": False,
              "automatic_elevation": False, "dns_cache_flush_requested": args.flush_dns}
    print("Checking DNS, selected route and TLS; no API key or model request.", flush=True)
    try:
        if args.flush_dns:
            binary = Path(os.environ.get("SystemRoot", "C:/Windows")) / "System32/ipconfig.exe"
            try:
                result = subprocess.run([str(binary), "/flushdns"], capture_output=True, timeout=15)
                record["dns_cache_flush"] = {"ok": result.returncode == 0, "exit_code": result.returncode}
            except (OSError, subprocess.TimeoutExpired) as error:
                record["dns_cache_flush"] = {"ok": False, "error": safe_error(error)}
        record["proxy_environment_variables_present"] = {
            name: bool(os.environ.get(name))
            for name in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY",
                         "http_proxy", "https_proxy", "all_proxy", "no_proxy")}
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                r"Software\Microsoft\Windows\CurrentVersion\Internet Settings") as key:
                record["wininet_proxy_enabled"] = bool(winreg.QueryValueEx(key, "ProxyEnable")[0])
        except OSError:
            record["wininet_proxy_enabled"] = None
        record["socket_tls_note"] = "Socket TLS uses the OS-selected route; this is not an urllib proxy or API authentication test."
        record["flyshadow_adapters"] = powershell_json(
            "@{adapters=@(Get-NetAdapter | Where-Object { $_.Name -match 'FlyShadow' -or $_.InterfaceDescription -match 'FlyShadow' } "
            "| Select-Object Name,Status,ifIndex)} | ConvertTo-Json -Depth 3 -Compress")
        started = time.perf_counter()
        try:
            addresses = sorted({item[4][0] for item in socket.getaddrinfo(HOST, 443, type=socket.SOCK_STREAM)})
            record["dns"] = {"ok": True, "addresses": [
                {"ip": address, "is_global": ipaddress.ip_address(address).is_global,
                 "is_fake_ip_range": ipaddress.ip_address(address) in FAKE_IP_RANGE}
                for address in addresses]}
        except OSError as error:
            addresses = []
            record["dns"] = {"ok": False, "error": safe_error(error)}
        record["selected_routes"] = []
        for address in addresses:
            # ipaddress validates the only interpolated value; no user input or credentials in shell code.
            safe_address = str(ipaddress.ip_address(address))
            family = "IPv4" if ipaddress.ip_address(address).version == 4 else "IPv6"
            route = powershell_json(
                "@{routes=@(Find-NetRoute -RemoteIPAddress '" + safe_address + "' | "
                "Where-Object { $null -ne $_.DestinationPrefix } | "
                "Select-Object InterfaceAlias,InterfaceIndex,DestinationPrefix,RouteMetric,"
                "@{Name='InterfaceMetric';Expression={(Get-NetIPInterface -InterfaceIndex $_.InterfaceIndex "
                "-AddressFamily " + family + " | Select-Object -First 1).InterfaceMetric}})} "
                "| ConvertTo-Json -Depth 3 -Compress")
            record["selected_routes"].append({"target_ip": safe_address, "lookup": route})
        if addresses:
            ipv4 = [address for address in addresses if ipaddress.ip_address(address).version == 4]
            selected = (ipv4 or addresses)[0]
            record["tls_connect_ip"] = selected
            record["virtual_address_cannot_establish_real_origin_reachability"] = ipaddress.ip_address(selected) in FAKE_IP_RANGE
            try:
                with socket.create_connection((selected, 443), timeout=15) as sock:
                    record["tcp"] = {"ok": True, "peer_ip": sock.getpeername()[0]}
                    try:
                        with http.client._create_https_context(11).wrap_socket(sock, server_hostname=HOST) as tls:
                            record["tls"] = {"ok": True, "version": tls.version(),
                                             "alpn": tls.selected_alpn_protocol(),
                                             "certificate_and_hostname_verification": True}
                    except OSError as error:
                        record["tls"] = {"ok": False, "error": safe_error(error)}
            except OSError as error:
                record["tcp"] = {"ok": False, "error": safe_error(error)}
        else:
            record["tcp"] = {"attempted": False, "reason": "DNS unavailable; no retry"}
            record["tls"] = {"attempted": False, "reason": "DNS unavailable; no retry"}
        record["network_elapsed_seconds"] = time.perf_counter() - started
    except Exception as error:
        record["diagnostic_error"] = safe_error(error)
    finally:
        path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record, ensure_ascii=False, indent=2))
    print("\nRESULT_FILE: " + str(path))


if __name__ == "__main__":
    main()
