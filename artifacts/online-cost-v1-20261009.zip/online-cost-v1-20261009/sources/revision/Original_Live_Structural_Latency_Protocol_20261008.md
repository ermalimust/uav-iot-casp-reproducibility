# 原结构接口的在线时延补充实验

2026-10-08。状态：可执行准备包，尚未授权 live。默认入口和纯检查不读取模型配置/密钥、不执行模型请求或正式模拟；一手接口文档已只读核查。最终准备工件绑定源 hash，由 root 确认新预算、目的地和允许发送的数据后方可 live。

## 科学对象与边界

固定 S1–S4、seed 1–3，共 12 个分层任务；每任务只发一次 fresh generation。模型收到与原 `run_mixed_structural_llm.py` 相同的 SYSTEM 和 `_rounded_evidence` user 消息，选择 target/mode；不收到任务标签、seed、几何、历史模型选择、正文、审稿意见或后续候选结果。程序执行原 B1–B3 和该模型结构的原网格校准、原四维 promotion。必须实际完成本次 hybrid loop，不能把新 HTTP 时长与旧 local median 相加。

保持原 raw grid 顺序、重复候选和首次通过早停；不读取环境中的 FULL_SEARCH，也不使用模拟结果缓存。最多 120 个 numerical replays，加一次名义诊断；实际调用逐项记录。新输出目录不得复用原实验目录。

原缓存元数据只能确认 provider=`openai`、model alias=`qwen-plus`；没有保存历史后端版本、temperature 或请求时延。本次请求记录 requested model、response model/id/created 和时间戳，不能宣称当前 alias 与历史物理模型版本相同。12 个任务用于当前成本例子，不重证 LLM 优势、不形成新的 100-seed 效果结论，也不支持正式 p95 尾部保证。

## 当前请求设置与官方依据

固定北京 DashScope OpenAI-compatible endpoint，temperature 0.2；新增显式 `max_tokens=1024`、`enable_thinking=false`、非流式单响应。输出 cap 和显式思考设置是本次计量条件，不能追认为历史保存设置。socket timeout 60 秒；独立 worker 总超时 180 秒。socket timeout 不是完整请求的严格 60 秒墙钟保证。

官方 [Chat API 参考](https://help.aliyun.com/zh/model-studio/qwen-api-via-openai-chat-completions) 说明旧北京域名仍可使用、`max_tokens` 即将废弃但仍限制回答部分、`usage` 提供输入/输出/总 token 及可选详细字段；新的 `max_completion_tokens` 支持列表没有把旧 qwen-plus alias 列为通用替代。官方 [思考模式说明](https://help.aliyun.com/zh/model-studio/deep-thinking) 列明 qwen-plus 默认非思考。本包因此固定非思考并保存原始 usage，避免将 reasoning 或 provider cached tokens 漏计。

最多 12 次请求、0 probe、0 retry，输出请求 cap 合计 12,288 tokens；原匹配的 12 条使用量仅用作输入/通常输出的估计参考，不是新模型分词、最终账单或硬费用上限。HTTP/格式/仿真/保存错误均停止整个 run。timeout 或丢失响应的 usage 为 unknown，不能记为零，也不能自动再调用。非法 target/mode 的原 parser fallback 信息保留，但本实验停止，不把规则替代标为模型成功。

旧 V11 completion 已记录 30 次新 attempt 加 5 次 prior attempt；其旧预算不自动授权此包。root 应提供针对本协议、准备工件 hash 和固定输出目录的新显式授权。

## 分项计时与工件

每个独立 worker 记录 preparation、nominal diagnosis、local selector/prompt/parser、HTTP open/read、response JSON decoding、四个结构的 calibration、promotion、本次 local stages 合计、inclusive hybrid wall。HTTP open/read 包含 DNS/TLS、服务端等待、生成及下载，不是纯模型计算时间。嵌套 simulator 秒数包含记录 wrapper，不与 calibration 重复相加。

本次 local stages 不含 HTTP，也不以旧的计量值替代；inclusive hybrid wall 覆盖这一次 diagnosis 至 promotion，并包含必要请求日志/响应保存开销。父进程的 worker wall 单列，含启动/准备/退出。记录全部 service success/failure、请求尝试/响应/格式/用量缺失次数；失败耗时保留，未执行后续任务明确列示。

energy 默认关闭。启用时先完成原服务 hybrid loop，再对选定策略调用冻结的 `original_energy_trace.simulate_with_energy_trace` 和 `original_energy_screen.evaluate_all`；另计 energy trace 与 screen wall，并单列一次额外轨迹模拟。此后处理不进入原 local-stage 或 hybrid wall，不改变模型选择、校准、promotion 或 service metrics。启用 flag、energy 源与配置 hash 必须纳入本次 preparation 和授权。

输出包括 manifest/preparation/authorization 副本、逐请求 before/after 记录、清理密钥后的原始响应、逐候选 ledger、完整成功或失败 cell、completion、纯统计 summary。请求 before 记录先落盘才进入 HTTP；失败或中断后保留启动 reservation，不允许删除目录后重跑或自动 resume。TLS 验证开启，禁代理 HTTP opener、拒绝重定向，避免隐式追加请求或转发 Authorization 到新目的地。

正式 JSON 以独占 `.writing` 文件写完再发布，kill 后半写记录保留为 unknown。父进程按固定顺序为当前任务授予一次性 reservation；worker 核验父进程身份并独占 claim，已停止的 run 不再接受 worker。Token 按输入/输出/总数分别给出观测总和与未知请求数，缺字段不是 0；全部未知时总和为 null。

## 用户运行入口

`run_original_structural_latency_direct.ps1` 默认只做离线 check。只有提供 preparation 与 root 确认的 authorization 后，用户显式 `-Run` 才先执行无模型/密钥的既有 direct-path 检查，再进入 live runner。用户可先关闭 FlyShadow/TUN。准备阶段不会调用此网络诊断，也不会访问 Windows API-key registry。

默认/check-only 和纯测试必须显示 model/config/key/network/real-simulator calls 均为 0。正式 live 命令待授权文件存在后才可执行。

离线检查命令：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File F:\my-project\iotj\revision\experiments\run_original_structural_latency_direct.ps1
```

新授权确认、文件落盘且代理断开后，运行同一命令加 `-Run`。遇到任何错误保留所有目录和 reservation，交回 `completion.json`；不要重复执行 live。
