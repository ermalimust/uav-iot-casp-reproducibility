import csv, hashlib, json
from collections import defaultdict
from pathlib import Path
root = Path(__file__).resolve().parent
manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
for record in manifest["files"]:
    path = root / record["path"]
    if hashlib.sha256(path.read_bytes()).hexdigest() != record["sha256"]:
        raise AssertionError("Hash mismatch: " + record["path"])
ledger = root / "ZQL_UAV_submission_260708/02_復現_GitHub公開包/02_EVIDENCE_AND_EXPERIMENTS/02_EVIDENCE_AND_EXPERIMENTS/results_frozen_mixed_structural_100seed_20260617/mixed_structural_llm_per_seed.csv"
counts = defaultdict(lambda: [0, 0])
seen = set()
with ledger.open(encoding="utf-8-sig", newline="") as stream:
    for row in csv.DictReader(stream):
        identity = row["scenario"], int(row["seed"]), row["method"]
        if identity in seen or row["passed_contract"] not in ("True", "False"):
            raise AssertionError("Invalid/duplicate seed ledger")
        seen.add(identity)
        counts[(identity[0], identity[2])][0] += 1
        counts[(identity[0], identity[2])][1] += row["passed_contract"] == "True"
for identity, count in sorted(counts.items()):
    if count[0] != 100:
        raise AssertionError("Incomplete method-case")
    print(identity[0], identity[1], str(count[1]) + "/" + str(count[0]))
print("PASS", len(manifest["files"]), "file hashes; API calls=0")
