# Original study complements

Version: **original-complements-v1**, 2026-10-08. This versioned snapshot
preserves the original study complements. Public availability, repository commit
and archive identity are recorded by the repository publication receipt.

This companion adds 51 byte-preserved scientific/source files omitted from
original-core-v1: PPO source and its 4M-target frozen checkpoint, the original
blackout postprocessor, the missing old ns-3 link source and four saved outputs,
and the AERPAW extraction/plot sources, 33 LoRa plus two processed USRP inputs,
four derived results, and the dataset's original README.

Extract the original-core-v1 archive and this companion into the **same new
directory**, retaining their paths. The 51 scientific paths do not overlap the
core. Companion administrative files are under original-complements-v1/, so
README/MANIFEST/VERSION/verifier files also do not overwrite the core. Do not
replace either archive. The companion requires the exact core manifest digest
recorded in original-complements-v1/MANIFEST.json.

From the merged extraction, standard-library hash verification is:

    python -I -S -B original-complements-v1/verify_artifact.py --root .

It checks the entire core and companion file lists. No model key is required.
For the AERPAW anchor, set E to the retained directory:
ZQL_UAV_submission_260708/02_復現_GitHub公開包/02_EVIDENCE_AND_EXPERIMENTS/02_EVIDENCE_AND_EXPERIMENTS.
From E, run extract_lora_anchor.py and extract_usrp_anchor.py under
experiments/real_trace_anchor/scripts/ with --input set to
experiments/real_trace_anchor/data/raw/aerpaw_aadm/extracted and --out-dir set
to a separate fresh directory. Both extractors use only Python's standard
library. A plot requires matplotlib and the generated summary JSON files.
Source-path metadata may be canonicalized only to the original 35 input paths;
all other structure, quantities and CSV fields must match the original records.

The frozen checkpoint is experiments/uav_iot_workflow/results/ppo_4m.zip:
SB3 2.8.0 metadata, 4,001,792 actual steps for a 4M target in complete 2048-step
rollouts. Loading/evaluating it requires gymnasium, stable-baselines3/PyTorch,
numpy/pandas and the original core. The legacy PPO CLI defaults to retraining
2M steps; it is not a frozen-checkpoint evaluation entry point. No checkpoint
has been loaded, retrained or evaluated in preparing/checking this companion.

The bthr postprocessor uses the core's per_device_metrics.csv and
summary_metrics.csv, with numpy/pandas (matplotlib is optional). Old ns-3
runners and mini-replay source already reside in the core; the original
Windows ns-3.47/MinGW/CMake/Ninja runtime is still required. These are reduced
two-node anchors, not the new 31-node CASP extension. They were not rerun here.

Generic legacy model clients can call live providers or use synthetic fallback
on cache misses, and some legacy runners require key presence. Use separately
checked strict fail-on-miss offline entry points. Merely supplying a cache does
not make every old entry point key-free. This companion does not modify those
sources or claim all of them have been replayed. The core's checked strict
cached S1-S4 entry point remains separate.

The clean check performed fresh merged extraction, verified every core and
companion file identity, and reran the standard-library LoRa/USRP extractors.
Both JSON summaries and both metric CSVs were byte-identical to the original
saved results. PPO model loading/evaluation, native simulation, plots and
training were not executed; their sources/weights remain available. Additional energy, multi-predicate,
online timing and full-native evidence are distinct extensions, not part of
these preserved original results.

See THIRD_PARTY_AERPAW.md for Dryad DOI, CC0 data provenance and mission scope.
No additional license is granted for the authors' code by this companion.
