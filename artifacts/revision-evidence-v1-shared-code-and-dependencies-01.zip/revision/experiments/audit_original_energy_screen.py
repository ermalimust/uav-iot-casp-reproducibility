"""Independent mathematical audit of the original-policy energy screen.

This module imports neither the energy-screen implementation nor the trace
adapter, simulator, model client or configuration. It integrates saved geometry
and protocol observations with an independent implementation of the frozen
rotary-wing equations. It never executes a physical/service simulation.
"""
from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import json
import math
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


WORKSPACE = Path(__file__).resolve().parents[2]
VERSION = 'independent-original-energy-screen-audit-1'
SLOTS, DT_S, SPEED_M_S = 230, 1.0, 42.0
HOME_M = (120.0, 120.0)  # Newly declared screen assumption, not original RTH logic.
MOTIONS = ('average_speed', 'fixed_speed_then_hover')
NONPROP_W = (50.0, 100.0)
FLIGHT_SCALES = (1.0, 1.25)
CAPACITY_ALPHAS = (0.75, 1.0, 1.25, 1.5, 2.0)
RESERVE_FRACTIONS = (0.0, 0.1, 0.2)
MOTION_NAMES = {'mean_speed': 'average_speed', 'travel_then_hover': 'fixed_speed_then_hover'}
PROTOCOL_ABSTRACT = {'wifi_like': 0.068, 'lora_like': 0.030, 'cellular_like': 0.095}
ABS_J = 1e-7
REL = 1e-11
SCENARIOS = ('S1_seen_burst_east', 'S2_seen_degrade_west', 'S3_seen_moved_burst', 'S4_heldout_misleading')
METHODS = ('compact', 'compact_plus_expert', 'compact_plus_cached_model')
FROZEN_ORIGINAL_HASHES = {
    'run_uav_iot_workflow_experiment.py': '62baf3d3763a6a38803be0a108593b2eff9fb491f9742913090020f4887fe635',
    'contingency_suite.py': '40ca703dd6ccdc964dab777fd2508ed7d83d23548592cded3eb010ec8b158155',
    'mixed_structural_suite.py': 'aa082beafbd78295eb9873faf53b82854a77da20914b7a34a7b298bac18822a3',
    'original_energy_trace.py': 'ddef82a566fd0788f54690d15e3803d5a77b5f23d781d54fcbacef68262fe575'}


@dataclass(frozen=True)
class RotaryParameters:
    """Zeng et al., arXiv:1804.02238v1 Eq.(6)/(61), Table I.

    A=0.79 is the published table's rounded area. U_tip and v0 are derived
    consistently from the locked Omega/R and W/rho/A, not separately rounded.
    Weight is in newtons; power is in watts.
    """
    weight_n: float = 100.0
    rho_kg_m3: float = 1.225
    area_m2: float = 0.79
    radius_m: float = 0.5
    omega_rad_s: float = 400.0
    solidity: float = 0.05
    delta: float = 0.012
    d0: float = 0.3
    k: float = 0.1

    @property
    def tip_speed_m_s(self) -> float:
        return self.omega_rad_s * self.radius_m

    @property
    def induced_hover_speed_m_s(self) -> float:
        return math.sqrt(self.weight_n / (2.0 * self.rho_kg_m3 * self.area_m2))

    @property
    def profile_hover_w(self) -> float:
        return (self.delta / 8.0) * self.rho_kg_m3 * self.solidity * self.area_m2 * self.tip_speed_m_s ** 3

    @property
    def induced_hover_w(self) -> float:
        return (1.0 + self.k) * self.weight_n ** 1.5 / math.sqrt(2.0 * self.rho_kg_m3 * self.area_m2)


PARAMETERS = RotaryParameters()


def nonnegative(value: Any) -> bool:
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value) and value >= 0


def finite_number(value: Any) -> bool:
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)


def close(actual: Any, expected: float, abs_tol: float = ABS_J) -> bool:
    return finite_number(actual) and math.isclose(actual, expected, rel_tol=REL, abs_tol=abs_tol)


def rotary_power_w(speed_m_s: float, parameters: RotaryParameters = PARAMETERS) -> float:
    if not nonnegative(speed_m_s) or speed_m_s > 60.0:
        raise ValueError('Horizontal speed must be in the locked [0,60] m/s numerical domain')
    # Rationalized induced term is algebraically identical to Eq.(6), avoiding
    # subtraction of nearly equal values in sqrt(1+x*x)-x.
    x = speed_m_s ** 2 / (2.0 * parameters.induced_hover_speed_m_s ** 2)
    induced = parameters.induced_hover_w / math.sqrt(math.hypot(1.0, x) + x)
    profile = parameters.profile_hover_w * (1.0 + 3.0 * speed_m_s ** 2 / parameters.tip_speed_m_s ** 2)
    parasite = 0.5 * parameters.d0 * parameters.rho_kg_m3 * parameters.solidity * parameters.area_m2 * speed_m_s ** 3
    return profile + induced + parasite


def reference_energy_j() -> float:
    return SLOTS * DT_S * (PARAMETERS.profile_hover_w + PARAMETERS.induced_hover_w + 50.0)


class Checks:
    def __init__(self):
        self.assertions = 0
        self.errors: list[dict] = []

    def check(self, condition: bool, message: str, **context) -> bool:
        self.assertions += 1
        if not condition:
            self.errors.append({'message': message, **context})
        return bool(condition)

    def near(self, actual: Any, expected: float, message: str, **context) -> bool:
        return self.check(close(actual, expected), message, actual=actual, expected=expected, **context)

    def attempt(self, label: str, fn):
        try:
            return fn()
        except Exception as error:
            self.errors.append({'message': label, 'exception_type': type(error).__name__, 'detail': str(error)[:500]})
            return None


def coordinates(value: Any) -> tuple[float, float]:
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError('Position must contain exactly two coordinates')
    if any(isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) for x in value):
        raise ValueError('Position coordinates must be finite numbers')
    return float(value[0]), float(value[1])


def distance_m(a: Any, b: Any) -> float:
    ax, ay = coordinates(a)
    bx, by = coordinates(b)
    return math.hypot(ax - bx, ay - by)


def audit_trace(checks: Checks, trace: list[dict], original_trace: list[dict] | None = None,
                context: dict | None = None) -> dict:
    """Conservation/continuity checks on saved original observations only.

    Protocol coefficients remain abstract units. They never contribute joules
    to the new constant-load model. Delivered queue quantity is not airtime.
    """
    context = context or {}
    checks.check(isinstance(trace, list) and len(trace) == SLOTS, 'Saved original trajectory must contain all 230 slots', **context)
    previous_xy, previous_protocol, previous_abstract = HOME_M, None, 0.0
    distance_total, delivered_total, switches = 0.0, 0.0, 0
    abstract_movement = abstract_service = abstract_switching = 0.0
    protocol_slots = {key: 0 for key in PROTOCOL_ABSTRACT}
    protocol_slots['none'] = 0
    for index, row in enumerate(trace):
        here = {**context, 'slot': index}
        checks.check(row.get('slot') == index, 'Original trace slot index is missing/reordered', **here)
        for field, expected in (('dt_s', DT_S), ('slot_start_s', index * DT_S), ('slot_end_s', (index + 1) * DT_S)):
            checks.near(row.get(field), expected, 'Original trace time/duration differs', field=field, **here)
        start, end = coordinates(row['start_xy_m']), coordinates(row['end_xy_m'])
        checks.near(distance_m(start, previous_xy), 0.0, 'Original trajectory has a position gap', **here)
        move = row['move_m']
        checks.check(nonnegative(move) and move <= SPEED_M_S * DT_S + ABS_J,
                     'Original trajectory movement outside locked speed/time range', **here)
        checks.near(move, distance_m(start, end), 'Saved movement differs from Euclidean endpoint displacement', **here)
        checks.near(row.get('speed_m_s'), move / DT_S, 'Original average slot speed differs', **here)
        proto, amount = row.get('sel_proto'), row.get('delivered_amount')
        checks.check(proto is None or proto in PROTOCOL_ABSTRACT, 'Unknown saved original protocol', **here)
        checks.check(nonnegative(amount), 'Original delivered amount invalid', **here)
        selected = row.get('selected_device_index')
        checks.check((selected is None and proto is None and amount == 0.0) or
                     (type(selected) is int and 0 <= selected < 30 and proto in PROTOCOL_ABSTRACT and amount > 0),
                     'Protocol/service observation does not bind the selected device', **here)
        checks.check(row.get('previous_protocol_before') == previous_protocol,
                     'Previous protocol has a gap between slots', **here)
        next_protocol = proto if proto is not None else previous_protocol
        expected_switch = previous_protocol is not None and proto is not None and proto != previous_protocol
        checks.check(type(row.get('switch_event')) is bool and row['switch_event'] == expected_switch,
                     'Saved switching event disagrees with the original transition semantics', **here)
        checks.check(row.get('previous_protocol_after') == next_protocol,
                     'Saved post-slot protocol disagrees with original persistence', **here)
        abstract_move = 0.024 * move
        abstract_delivered = amount * PROTOCOL_ABSTRACT[proto] if proto is not None else 0.0
        abstract_switch = 0.18 if expected_switch else 0.0
        expected_abstract = previous_abstract + abstract_move + abstract_delivered + abstract_switch
        checks.near(row.get('abstract_energy_before'), previous_abstract, 'Abstract proxy has a cumulative gap', **here)
        checks.near(row.get('abstract_energy_after'), expected_abstract,
                    'Abstract original movement/service/switch cost is not conserved', **here)
        if original_trace is not None and index < len(original_trace):
            saved = original_trace[index]
            checks.check(saved.get('t') == index, 'Original service-log index differs', **here)
            for field in ('aff_backlog', 'aff_blackout'):
                checks.check(row.get(field) == saved.get(field), 'Additive trace differs from its original service log', field=field, **here)
        previous_xy, previous_protocol, previous_abstract = end, next_protocol, expected_abstract
        distance_total += move
        delivered_total += amount
        switches += int(expected_switch)
        abstract_movement += abstract_move
        abstract_service += abstract_delivered
        abstract_switching += abstract_switch
        protocol_slots[proto or 'none'] += 1
    if original_trace is not None:
        checks.check(len(original_trace) == len(trace), 'Original service-log and additive trajectory lengths differ', **context)
    return {'slots': len(trace), 'duration_s': len(trace) * DT_S,
            'distance_m': distance_total, 'delivered_queue_amount': delivered_total,
            'switch_count': switches, 'protocol_slots': protocol_slots,
            'abstract_movement': abstract_movement, 'abstract_service': abstract_service,
            'abstract_switching': abstract_switching, 'abstract_total': previous_abstract}


def motion_segments(row: dict, motion: str) -> list[dict]:
    """Independent segment construction from saved slot endpoint geometry."""
    if motion not in MOTIONS:
        raise ValueError('Unknown frozen within-slot motion interpretation')
    start, end = coordinates(row['start_xy_m']), coordinates(row['end_xy_m'])
    length, start_s = distance_m(start, end), float(row['slot_start_s'])
    if not close(length, row['move_m']) or length > SPEED_M_S * DT_S + ABS_J:
        raise ValueError('Invalid saved segment geometry/movement')
    if motion == 'average_speed':
        return [{'kind': 'average', 'start_s': start_s, 'duration_s': DT_S,
                 'start_xy_m': start, 'end_xy_m': end, 'speed_m_s': length / DT_S}]
    travel_s = min(DT_S, length / SPEED_M_S)
    result = []
    if travel_s > 0:
        result.append({'kind': 'travel', 'start_s': start_s, 'duration_s': travel_s,
                       'start_xy_m': start, 'end_xy_m': end, 'speed_m_s': SPEED_M_S})
    hover_s = DT_S - travel_s
    if hover_s > 0:
        result.append({'kind': 'hover', 'start_s': start_s + travel_s, 'duration_s': hover_s,
                       'start_xy_m': end, 'end_xy_m': end, 'speed_m_s': 0.0})
    return result


def independent_profile(trace: list[dict], motion: str, nonprop_w: float,
                        flight_scale: float) -> dict:
    """Integrate all saved segments and independently close a straight return.

    Eused + c*distance(home) is convex on each straight constant-power segment;
    its maximum is attained at segment endpoints. Return at the same constant
    speed/power makes that required-energy quantity constant throughout return.
    This is a model-relative statement, not wind, maneuver or landing safety.
    """
    if motion not in MOTIONS or nonprop_w not in NONPROP_W or flight_scale not in FLIGHT_SCALES:
        raise ValueError('Profile is outside the locked motion/load/scale grid')
    if len(trace) != SLOTS:
        raise ValueError('A complete 230-slot trajectory is required')
    return_power_w = flight_scale * rotary_power_w(SPEED_M_S) + nonprop_w
    flight_j, load_j, travel_s, hover_s = 0.0, 0.0, 0.0, 0.0
    checkpoints = []

    def point(time_s: float, xy: tuple, kind: str, slot: int | None):
        used_j = flight_j + load_j
        return_j = return_power_w * distance_m(xy, HOME_M) / SPEED_M_S
        checkpoints.append({'time_s': time_s, 'xy_m': list(xy), 'kind': kind, 'slot': slot,
                            'flight_used_j': flight_j, 'nonpropulsive_used_j': load_j,
                            'used_j': used_j, 'return_seconds': distance_m(xy, HOME_M) / SPEED_M_S,
                            'return_j': return_j, 'required_j': used_j + return_j})

    point(0.0, coordinates(trace[0]['start_xy_m']), 'initial', None)
    for index, row in enumerate(trace):
        for segment in motion_segments(row, motion):
            seconds, speed = segment['duration_s'], segment['speed_m_s']
            if speed > 0:
                travel_s += seconds
            else:
                hover_s += seconds
            flight_j += flight_scale * rotary_power_w(speed) * seconds
            load_j += nonprop_w * seconds
            point(segment['start_s'] + seconds, segment['end_xy_m'], segment['kind'] + '_end', index)
    end_xy = coordinates(trace[-1]['end_xy_m'])
    terminal_return_s = distance_m(end_xy, HOME_M) / SPEED_M_S
    return_flight_j = flight_scale * rotary_power_w(SPEED_M_S) * terminal_return_s
    return_load_j = nonprop_w * terminal_return_s
    terminal_total_j = flight_j + load_j + return_flight_j + return_load_j
    checkpoints.append({'time_s': SLOTS * DT_S + terminal_return_s, 'xy_m': list(HOME_M),
                        'kind': 'returned_home', 'slot': None, 'used_j': terminal_total_j,
                        'flight_used_j': flight_j + return_flight_j,
                        'nonpropulsive_used_j': load_j + return_load_j,
                        'return_seconds': 0.0, 'return_j': 0.0, 'required_j': terminal_total_j})
    critical = max(checkpoints, key=lambda x: x['required_j'])
    return {'motion': motion, 'nonprop_w': nonprop_w, 'flight_scale': flight_scale,
            'mission_flight_j': flight_j, 'mission_nonprop_j': load_j,
            'mission_total_j': flight_j + load_j, 'mission_duration_s': SLOTS * DT_S,
            'travel_s': travel_s, 'hover_s': hover_s,
            'terminal_return_duration_s': terminal_return_s,
            'terminal_return_flight_j': return_flight_j, 'terminal_return_nonprop_j': return_load_j,
            'terminal_return_j': return_flight_j + return_load_j,
            'terminal_total_j': terminal_total_j,
            'max_required_j': critical['required_j'], 'critical_checkpoint': critical,
            'checkpoints': checkpoints}


def gate(profile: dict, initial_j: float, reserve_fraction: float, service_pass: bool = True) -> dict:
    if not nonnegative(initial_j) or initial_j <= 0 or reserve_fraction not in RESERVE_FRACTIONS:
        raise ValueError('Invalid initial capacity or locked reserve fraction')
    if type(service_pass) is not bool:
        raise ValueError('Service contract flag must remain boolean')
    available = (1.0 - reserve_fraction) * initial_j
    required = profile['max_required_j']
    # Equality passes. The tiny comparison tolerance is numerical roundoff only,
    # never a physical reserve, uncertainty bound or adjustable admission budget.
    passed = available >= required or math.isclose(available, required, abs_tol=ABS_J, rel_tol=0.0)
    first = next((x for x in profile['checkpoints']
                  if x['required_j'] > available and not math.isclose(x['required_j'], available, abs_tol=ABS_J, rel_tol=0.0)), None)
    return {'initial_j': initial_j, 'reserve_fraction': reserve_fraction,
            'available_j': available, 'reserve_j': reserve_fraction * initial_j,
            'energy_pass': passed, 'service_pass': service_pass, 'joint_pass': service_pass and passed,
            'minimum_margin_j': available - required,
            'terminal_remaining_j': initial_j - profile['terminal_total_j'],
            'break_even_capacity_j': required / (1.0 - reserve_fraction),
            'break_even_alpha': required / ((1.0 - reserve_fraction) * reference_energy_j()),
            'first_violation': copy.deepcopy(first)}


def audit_config(checks: Checks, cfg: dict) -> None:
    expected_parameters = {'weight_n': 100.0, 'rho_kg_m3': 1.225, 'area_m2': 0.79,
                           'radius_m': 0.5, 'omega_rad_s': 400.0, 'solidity': 0.05,
                           'delta': 0.012, 'drag_ratio': 0.3, 'induced_correction': 0.1}
    checks.check(cfg.get('parameters') == expected_parameters,
                 'Rotary-wing parameters differ from the complete frozen v1 table group')
    for field, expected in (('dt_s', DT_S), ('mission_slots', SLOTS), ('mission_speed_m_s', SPEED_M_S),
                            ('return_speed_m_s', SPEED_M_S), ('power_speed_domain_max_m_s', 60.0),
                            ('home_xy_m', list(HOME_M)), ('motion_interpretations', list(MOTION_NAMES)),
                            ('propulsion_scales', list(FLIGHT_SCALES)), ('constant_nonpropulsive_w', list(NONPROP_W)),
                            ('capacity_multipliers', list(CAPACITY_ALPHAS)), ('reserve_fractions', list(RESERVE_FRACTIONS)),
                            ('gate_epsilon_j', ABS_J), ('model_requests', 0), ('energy_equality_passes', True),
                            ('power_source', 'https://arxiv.org/pdf/1804.02238v1')):
        checks.check(cfg.get(field) == expected, 'Frozen energy assumption/grid differs', field=field)
    checks.check(type(cfg.get('mission_slots')) is int, 'Mission horizon must remain integer 230 slots')
    checks.check(cfg.get('energy_equality_passes') is True, 'Exact admission equality must pass')


def original_boundary(point: dict) -> str:
    return {'initial': 'mission_start', 'average_end': 'mean_speed_end',
            'returned_home': 'return_complete'}.get(point['kind'], point['kind'])


def audit_energy(checks: Checks, saved: dict, trace: list[dict], service_pass: bool,
                 config_sha256: str, context: dict) -> dict:
    """Audit the actual screen's returned schema without importing its code."""
    checks.check(saved.get('config_sha256') == config_sha256, 'Energy record does not bind the frozen configuration', **context)
    checks.near(saved.get('reference_energy_j'), reference_energy_j(), 'Reference capacity differs from the predeclared hover/load horizon', **context)
    constants = saved.get('power_constants', {})
    for field, expected in (('tip_speed_m_s', PARAMETERS.tip_speed_m_s),
                            ('hover_induced_speed_m_s', PARAMETERS.induced_hover_speed_m_s),
                            ('profile_hover_w', PARAMETERS.profile_hover_w), ('induced_hover_w', PARAMETERS.induced_hover_w),
                            ('hover_propulsion_w', rotary_power_w(0.0))):
        checks.near(constants.get(field), expected, 'Derived power constant differs from independent Eq61', field=field, **context)
    profiles, gates = saved.get('profiles', []), saved.get('gates', [])
    checks.check(len(profiles) == 8, 'All eight predeclared motion/load/scale profiles must be present', **context)
    checks.check(len(gates) == 120, 'All 120 predeclared capacity/reserve conditions must be present', **context)
    profile_map, gate_map = {}, {}
    for index, (motion_name, scale, load) in enumerate(
            (motion, scale, load) for motion in MOTION_NAMES for scale in FLIGHT_SCALES for load in NONPROP_W):
        here = {**context, 'profile_index': index}
        if index >= len(profiles):
            continue
        actual = profiles[index]
        for field, value in (('profile_index', index), ('motion', motion_name),
                             ('propulsion_scale', scale), ('constant_nonpropulsive_w', load)):
            checks.check(actual.get(field) == value, 'Profile identity/order differs from the predeclared grid', field=field, **here)
        expected = independent_profile(trace, MOTION_NAMES[motion_name], load, scale)
        profile_map[motion_name, scale, load] = expected
        for actual_name, expected_value in (
            ('mission_flight_j', expected['mission_flight_j']), ('mission_nonpropulsive_j', expected['mission_nonprop_j']),
            ('mission_used_j', expected['mission_total_j']), ('terminal_return_j', expected['terminal_return_j']),
            ('terminal_return_seconds', expected['terminal_return_duration_s']),
            ('flight_with_return_j', expected['mission_flight_j'] + expected['terminal_return_flight_j']),
            ('nonpropulsive_with_return_j', expected['mission_nonprop_j'] + expected['terminal_return_nonprop_j']),
            ('energy_with_return_j', expected['terminal_total_j']), ('required_peak_j', expected['max_required_j'])):
            checks.near(actual.get(actual_name), expected_value, 'Integrated energy/return/profile differs from independent equations', field=actual_name, **here)
        # Independent conservation checks are explicit rather than hidden inside
        # agreement between two implementations of a scalar formula.
        checks.near(expected['mission_nonprop_j'], SLOTS * DT_S * load, 'Always-on load horizon is not conserved', **here)
        checks.near(expected['travel_s'] + expected['hover_s'], SLOTS * DT_S, 'Within-slot motion duration partition is not conserved', **here)
        checks.near(expected['terminal_total_j'], expected['mission_total_j'] + expected['terminal_return_j'],
                    'Mission and terminal-return components do not conserve joules', **here)
        endpoints = actual.get('endpoints', [])
        points = expected['checkpoints']
        checks.check(len(endpoints) == len(points), 'Endpoint set omitted/added a motion join, slot boundary or terminal return', **here)
        for position, point in enumerate(points):
            if position >= len(endpoints):
                continue
            recorded = endpoints[position]
            point_context = {**here, 'checkpoint': position}
            slot = -1 if point['kind'] == 'initial' else SLOTS if point['kind'] == 'returned_home' else point['slot']
            checks.check(recorded.get('slot') == slot and recorded.get('boundary') == original_boundary(point),
                         'Endpoint boundary identity/order differs', **point_context)
            checks.near(distance_m(recorded['xy_m'], point['xy_m']), 0.0, 'Endpoint position differs from the saved original trajectory', **point_context)
            for field in ('time_s', 'flight_used_j', 'nonpropulsive_used_j', 'used_j',
                          'return_seconds', 'return_j', 'required_j'):
                checks.near(recorded.get(field), point[field], 'Endpoint energy/time differs from independent segment integration', field=field, **point_context)
        maxima = [p for p in points if close(p['required_j'], expected['max_required_j'])]
        checks.check(any(close(actual.get('required_peak_time_s'), p['time_s']) for p in maxima),
                     'Reported peak time does not identify a maximal required-energy checkpoint', **here)
        checks.near(points[-1]['return_j'], 0.0, 'Closed return endpoint retains a return requirement', **here)
        checks.near(points[-1]['required_j'], points[-2]['required_j'],
                    'Same-speed/power straight return fails required-energy closure', **here)
        for alpha_index, alpha in enumerate(CAPACITY_ALPHAS):
            for reserve_index, reserve in enumerate(RESERVE_FRACTIONS):
                gate_index = index * 15 + alpha_index * 3 + reserve_index
                if gate_index >= len(gates):
                    continue
                recorded = gates[gate_index]
                gate_context = {**here, 'capacity_multiplier': alpha, 'reserve_fraction': reserve}
                checks.check(recorded.get('profile_index') == index and recorded.get('capacity_multiplier') == alpha
                             and recorded.get('reserve_fraction') == reserve,
                             'Gate identity/order differs from the complete frozen grid', **gate_context)
                computed = gate(expected, alpha * reference_energy_j(), reserve, service_pass)
                gate_map[motion_name, scale, load, alpha, reserve] = recorded
                for field in ('energy_pass', 'service_pass', 'joint_pass'):
                    checks.check(type(recorded.get(field)) is bool and recorded[field] == computed[field],
                                 'Model-relative gate or unchanged service flag differs', field=field, **gate_context)
                for field, value in (
                    ('capacity_j', computed['initial_j']), ('capacity_wh', computed['initial_j'] / 3600.0),
                    ('reserve_j', computed['reserve_j']), ('usable_above_reserve_j', computed['available_j']),
                    ('required_peak_j', expected['max_required_j']), ('minimum_return_margin_j', computed['minimum_margin_j']),
                    ('remaining_after_return_j', computed['terminal_remaining_j']),
                    ('end_reserve_margin_j', computed['terminal_remaining_j'] - computed['reserve_j']),
                    ('break_even_capacity_j', computed['break_even_capacity_j']),
                    ('break_even_capacity_wh', computed['break_even_capacity_j'] / 3600.0)):
                    checks.near(recorded.get(field), value, 'Capacity/reserve/Wh conversion or break-even requirement differs', field=field, **gate_context)
                first = computed['first_violation']
                if first is None:
                    checks.check(recorded.get('first_violation_time_s') is None and recorded.get('first_violation_boundary') is None,
                                 'Passing gate records a violation boundary', **gate_context)
                else:
                    checks.near(recorded.get('first_violation_time_s'), first['time_s'],
                                'First violating boundary time differs', **gate_context)
                    checks.check(recorded.get('first_violation_boundary') == original_boundary(first),
                                 'First violating boundary identity differs', **gate_context)
    # These monotonicities concern fixed geometry/strategy. No property of speed
    # versus propulsion power is asserted; rotary-wing power is non-monotonic.
    for motion in MOTION_NAMES:
        for scale in FLIGHT_SCALES:
            for load in NONPROP_W:
                for reserve in RESERVE_FRACTIONS:
                    statuses = [gate_map.get((motion, scale, load, alpha, reserve), {}).get('energy_pass') for alpha in CAPACITY_ALPHAS]
                    if all(type(x) is bool for x in statuses):
                        checks.check(statuses == sorted(statuses), 'Capacity increase reduces recorded fixed-policy energy feasibility',
                                     motion=motion, scale=scale, load=load, reserve=reserve, **context)
                for alpha in CAPACITY_ALPHAS:
                    statuses = [gate_map.get((motion, scale, load, alpha, reserve), {}).get('energy_pass') for reserve in RESERVE_FRACTIONS]
                    if all(type(x) is bool for x in statuses):
                        checks.check(statuses == sorted(statuses, reverse=True), 'Reserve increase improves recorded fixed-policy feasibility',
                                     motion=motion, scale=scale, load=load, alpha=alpha, **context)
        for load in NONPROP_W:
            low, high = profile_map.get((motion, 1.0, load)), profile_map.get((motion, 1.25, load))
            if low is not None and high is not None:
                checks.check(high['max_required_j'] >= low['max_required_j'], 'Propulsion sensitivity multiplier reduces required energy', **context)
        for scale in FLIGHT_SCALES:
            low, high = profile_map.get((motion, scale, 50.0)), profile_map.get((motion, scale, 100.0))
            if low is not None and high is not None:
                checks.check(high['max_required_j'] >= low['max_required_j'], 'Constant nonpropulsive load increase reduces required energy', **context)
    return {'profiles': len(profiles), 'gates': len(gates),
            'service_pass': service_pass, 'energy_pass_count': sum(g.get('energy_pass') is True for g in gates),
            'joint_pass_count': sum(g.get('joint_pass') is True for g in gates),
            'reference_energy_j': reference_energy_j(),
            'model_relative_checkpoints': sum(len(p.get('endpoints', [])) for p in profiles)}


def core_self_checks() -> dict:
    """Synthetic math fixtures only: no physical or service simulator calls."""
    checks = Checks()
    checks.near(PARAMETERS.tip_speed_m_s, 200.0, 'Derived tip speed differs')
    checks.near(rotary_power_w(0.0), PARAMETERS.profile_hover_w + PARAMETERS.induced_hover_w, 'Hover formula differs')
    checks.check(rotary_power_w(0.0) > 0, 'Stationary hovering must consume positive propulsion power')
    for speed in (0.0, 1.0, 7.0, 42.0, 60.0):
        v0 = PARAMETERS.induced_hover_speed_m_s
        direct = (PARAMETERS.profile_hover_w * (1 + 3 * speed ** 2 / PARAMETERS.tip_speed_m_s ** 2)
                  + PARAMETERS.induced_hover_w * math.sqrt(math.sqrt(1 + speed ** 4 / (4 * v0 ** 4)) - speed ** 2 / (2 * v0 ** 2))
                  + 0.5 * PARAMETERS.d0 * PARAMETERS.rho_kg_m3 * PARAMETERS.solidity * PARAMETERS.area_m2 * speed ** 3)
        checks.near(rotary_power_w(speed), direct, 'Independent rationalized/direct Eq6 disagree', speed_m_s=speed)
    for invalid in (-1, 61, float('inf'), True):
        try:
            rotary_power_w(invalid)
            checks.check(False, 'Invalid speed accepted', speed=repr(invalid))
        except ValueError:
            checks.check(True, 'Invalid speed correctly rejected')
    trace = []
    for index in range(SLOTS):
        trace.append({'slot': index, 'slot_start_s': float(index), 'slot_end_s': float(index + 1), 'dt_s': 1.0,
                      'start_xy_m': list(HOME_M), 'end_xy_m': list(HOME_M), 'move_m': 0.0,
                      'speed_m_s': 0.0, 'selected_device_index': None, 'delivered_amount': 0.0,
                      'sel_proto': None, 'previous_protocol_before': None, 'previous_protocol_after': None,
                      'switch_event': False, 'abstract_energy_before': 0.0, 'abstract_energy_after': 0.0})
    proxy = audit_trace(checks, trace)
    checks.near(proxy['abstract_total'], 0.0, 'Abstract proxy and physical hover must remain distinct')
    profiles = {}
    for motion in MOTIONS:
        for load in NONPROP_W:
            for scale in FLIGHT_SCALES:
                profile = independent_profile(trace, motion, load, scale)
                profiles[motion, load, scale] = profile
                checks.near(profile['mission_flight_j'], SLOTS * scale * rotary_power_w(0), 'Stationary flight integration differs')
                checks.near(profile['mission_nonprop_j'], SLOTS * load, 'Constant nonprop load integration differs')
                checks.near(profile['travel_s'] + profile['hover_s'], 230.0, 'Motion partition not conserved')
                for reserve in RESERVE_FRACTIONS:
                    exact = profile['max_required_j'] / (1 - reserve)
                    checks.check(gate(profile, exact, reserve)['energy_pass'], 'Exact break-even equality must pass')
                    checks.check(not gate(profile, exact - 1.0, reserve)['energy_pass'], 'Below break-even capacity must fail')
                    values = [gate(profile, alpha * reference_energy_j(), reserve)['energy_pass'] for alpha in CAPACITY_ALPHAS]
                    checks.check(values == sorted(values), 'Increasing capacity cannot reduce fixed-trajectory feasibility')
    short = dict(trace[0], end_xy_m=[HOME_M[0] + 21.0, HOME_M[1]], move_m=21.0, speed_m_s=21.0)
    split = motion_segments(short, 'fixed_speed_then_hover')
    checks.check([x['kind'] for x in split] == ['travel', 'hover'], 'Partial movement requires travel/hover join')
    checks.near(split[0]['duration_s'], 0.5, 'Fixed-speed travel time differs')
    checks.near(split[1]['duration_s'], 0.5, 'Fixed-speed hover time differs')
    for motion in MOTIONS:
        low, high_load, high_flight = profiles[motion, 50.0, 1.0], profiles[motion, 100.0, 1.0], profiles[motion, 50.0, 1.25]
        checks.check(high_load['max_required_j'] >= low['max_required_j'], 'Increasing constant load improves energy requirement')
        checks.check(high_flight['max_required_j'] >= low['max_required_j'], 'Increasing propulsion scale improves energy requirement')
    return {'status': 'PASS_INDEPENDENT_MATH_FIXTURES' if not checks.errors else 'FAIL_INDEPENDENT_MATH_FIXTURES',
            'assertions': checks.assertions, 'errors': checks.errors,
            'P0_w': PARAMETERS.profile_hover_w, 'Pi_w': PARAMETERS.induced_hover_w,
            'v0_m_s': PARAMETERS.induced_hover_speed_m_s, 'P_hover_w': rotary_power_w(0),
            'P_42_w': rotary_power_w(42), 'reference_j': reference_energy_j(),
            'model_requests': 0, 'physical_simulator_calls': 0}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8-sig'))


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode('utf-8')).hexdigest()


def policy_hash(value: dict) -> str:
    fields = ('controller', 'route', 'protocol_mode', 'local_triggers', 'min_protocol_hold_slots')
    semantic = {name: copy.deepcopy(value.get(name)) for name in fields}
    semantic['controller'] = semantic['controller'] or 'route'
    semantic['min_protocol_hold_slots'] = semantic['min_protocol_hold_slots'] or 0
    semantic['local_triggers'] = semantic['local_triggers'] or []
    if isinstance(semantic['local_triggers'], dict):
        semantic['local_triggers'] = [semantic['local_triggers']]
    def normalize(item):
        if isinstance(item, dict):
            return {key: normalize(val) for key, val in item.items()}
        if isinstance(item, (tuple, list)):
            return [normalize(val) for val in item]
        if isinstance(item, float):
            if not math.isfinite(item):
                raise ValueError('Non-finite recorded policy field')
            return int(item) if item.is_integer() else item
        return item
    return canonical_hash(normalize(semantic))


def normalized_hashes(values: dict) -> dict:
    return {str(Path(path).resolve()): value for path, value in values.items()}


def normalized_cells(values: dict) -> dict:
    return {path.replace('\\', '/'): value for path, value in values.items()}


def snapshot(directory: Path) -> dict:
    return {str(path.relative_to(directory)).replace('\\', '/'): digest(path)
            for path in sorted(directory.rglob('*')) if path.is_file()}


def expected_policy(checks: Checks, cost_cell: dict, context: dict) -> dict:
    promotion = cost_cell['promotion']
    matches = [entry for group in cost_cell['groups'] for entry in group['evaluations']
               if entry['policy_hash'] == promotion['policy_hash']]
    checks.check(bool(matches), 'Frozen promoted policy cannot be located in the original cost ledger', **context)
    if not matches:
        raise ValueError('No original promoted policy exists in the recorded cost ledger')
    policy = matches[0]['policy']
    checks.check(policy_hash(policy) == promotion['policy_hash'], 'Frozen original cost policy payload/hash differs', **context)
    checks.check(all(entry['metrics'] == promotion['metrics'] for entry in matches),
                 'Repeated promoted-policy ledger entries conflict on original metrics', **context)
    return policy


def audit_cell(checks: Checks, cell: dict, cost_cell: dict, expected_cost_hash: str,
               identity: tuple, config_hash: str) -> dict:
    scenario, seed, method = identity
    context = {'scenario': scenario, 'seed': seed, 'method': method}
    for field, value in context.items():
        checks.check(cell.get(field) == value and cost_cell.get(field) == value,
                     'Energy/cost task identity differs from the fixed filename', field=field, **context)
    checks.check(cell.get('status') == 'complete' and cost_cell.get('status') == 'complete',
                 'Incomplete energy or original-cost cell', **context)
    checks.check(cell.get('cost_cell_sha256') == expected_cost_hash, 'Energy record does not bind the exact cost cell', **context)
    checks.check(cell.get('scenario_sha256') == cost_cell.get('scenario_sha256'),
                 'Rebuilt scenario identity differs from the frozen cost input', **context)
    for field, expected in (('simulator_calls', 1), ('model_requests', 0), ('simulation_cache_hits', 0)):
        checks.check(type(cell.get(field)) is int and cell[field] == expected,
                     'Fixed-policy replay or cache/API accounting differs', field=field, **context)
    policy = expected_policy(checks, cost_cell, context)
    checks.check(cell.get('policy') == policy, 'Energy screening changed/reselected the original fixed policy', **context)
    checks.check(cell.get('policy_hash') == cost_cell['promotion']['policy_hash'] == policy_hash(cell['policy']),
                 'Energy policy semantic identity differs', **context)
    checks.check(cell.get('policy_full_sha256') == canonical_hash(policy),
                 'Full energy policy payload identity differs', **context)
    checks.check(cell.get('original_promotion') == cost_cell['promotion'],
                 'Energy screen altered the recorded original promotion', **context)
    metrics = cost_cell['promotion']['metrics']
    checks.check(cell.get('original_metrics') == metrics and cell['simulation'].get('metrics') == metrics,
                 'Additional fixed-policy replay changed the complete original service metrics', **context)
    service_pass = metrics['passed_contract']
    checks.check(type(service_pass) is bool, 'Original service predicate is not boolean', **context)
    result = cell['simulation']
    trace = result['energy_trace']
    trace_summary = audit_trace(checks, trace, result['trace'], context)
    energy_summary = audit_energy(checks, cell['energy'], trace, service_pass, config_hash, context)
    return {**context, **trace_summary, **energy_summary,
            'profile_rows': [{key: profile[key] for key in
                              ('motion', 'propulsion_scale', 'constant_nonpropulsive_w',
                               'required_peak_j', 'mission_used_j', 'energy_with_return_j')}
                             for profile in cell['energy']['profiles']],
            'gate_rows': [{key: gate[key] for key in
                          ('profile_index', 'capacity_multiplier', 'reserve_fraction', 'energy_pass', 'joint_pass')}
                         for gate in cell['energy']['gates']]}


def audit_run(root: Path, mode: str) -> dict:
    root = root.resolve()
    checks = Checks()
    before_snapshot = snapshot(root)
    input_hashes = {str(Path(__file__).resolve()): digest(Path(__file__))}
    manifest = checks.attempt('Energy manifest missing/unreadable', lambda: read(root / 'manifest.json'))
    completion = checks.attempt('Energy completion missing/unreadable', lambda: read(root / 'completion.json'))
    manifest = manifest if isinstance(manifest, dict) else {}
    completion = completion if isinstance(completion, dict) else {}
    cfg = manifest.get('config', {})
    checks.attempt('Frozen energy assumptions malformed', lambda: audit_config(checks, cfg))
    checks.check(completion.get('status') == 'complete', 'Energy screen has not completed successfully', status=completion.get('status'))
    for field, value in (('scenarios', list(SCENARIOS)), ('methods', list(METHODS)),
                         ('one_fixed_policy_replay_per_cell', True), ('recalibration', False),
                         ('simulation_cache_hits', 0), ('model_requests', 0), ('workers', 1), ('original_cost_cells', 1200)):
        checks.check(manifest.get(field) == value, 'Energy protocol execution declaration differs', field=field)
    seeds = manifest.get('seeds')
    if mode == 'auto':
        mode = 'smoke' if seeds == [1, 3] else 'full' if seeds == [1, 100] else 'unrecognized'
    checks.check(mode in {'smoke', 'full'}, 'Energy seed set is neither fixed smoke nor full protocol')
    expected_seeds = [1, 3] if mode == 'smoke' else [1, 100]
    checks.check(seeds == expected_seeds, 'Energy seed set differs from declared audit mode', mode=mode)
    identities = [(scenario, seed, method) for scenario in SCENARIOS
                  for seed in range(expected_seeds[0], expected_seeds[1] + 1) for method in METHODS]
    expected_count = len(identities)
    checks.check(manifest.get('expected_cells') == expected_count, 'Energy manifest expected count differs')
    checks.check(completion.get('expected_cells') == expected_count, 'Energy completion expected count differs')
    for field, value in (('completed_cells', expected_count), ('simulator_attempts', expected_count),
                         ('energy_profiles', expected_count * 8), ('gate_records', expected_count * 120),
                         ('model_requests', 0), ('simulation_cache_hits', 0), ('all_original_metrics_exact', True)):
        checks.check(completion.get(field) == value, 'Energy completion accounting differs', field=field)

    source_before = manifest.get('source_hashes_before', {})
    input_before = manifest.get('input_hashes_before', {})
    checks.check(source_before == completion.get('source_hashes_after'), 'Energy sources changed before/after execution')
    checks.check(input_before == completion.get('input_hashes_after'), 'Bound cost inputs changed before/after execution')
    source_bindings = normalized_hashes(source_before)
    input_bindings = normalized_hashes(input_before)
    for bindings in (source_bindings, input_bindings):
        for path, expected in bindings.items():
            actual = checks.attempt('Bound source/input unreadable', lambda p=Path(path): digest(p))
            checks.check(actual == expected, 'Bound source/input has changed since the energy screen', source=path)
            if actual is not None:
                input_hashes[path] = actual
    base = WORKSPACE / 'revision/experiments'
    for filename, expected in FROZEN_ORIGINAL_HASHES.items():
        path = base / filename if filename == 'original_energy_trace.py' else base / 'legacy' / filename
        checks.check(source_bindings.get(str(path.resolve())) == expected,
                     'Original source/additive trace adapter is not bound to the locked byte identity', source=str(path))
    for path in (base / 'original_energy_screen.py', base / 'run_original_energy_screen.py',
                 base / 'candidate_search.py', base / 'original_energy_screen_config.json',
                 WORKSPACE / 'revision/Original_Energy_Screen_Protocol_20261008.md'):
        checks.check(str(path.resolve()) in source_bindings, 'Required frozen energy source/config/protocol binding missing', source=str(path))
    config_path = base / 'original_energy_screen_config.json'
    config_hash = source_bindings.get(str(config_path.resolve()))
    actual_config = checks.attempt('Frozen energy configuration unreadable', lambda: read(config_path))
    checks.check(actual_config == cfg, 'Manifest energy assumptions differ from the bound configuration file')

    proof = manifest.get('instrumentation', {})
    original_path = base / 'legacy/contingency_suite.py'
    tree = ast.parse(original_path.read_text(encoding='utf-8-sig'))
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'simulate_cset')
    original_ast_hash = hashlib.sha256(ast.dump(function, annotate_fields=True, include_attributes=False).encode('utf-8')).hexdigest()
    checks.check(proof.get('status') == 'PASS_EXACT_AST_RESTORATION'
                 and proof.get('original_function_ast_sha256') == original_ast_hash
                 and proof.get('restored_function_ast_sha256') == original_ast_hash,
                 'Recorded additive trace restoration proof does not bind the frozen original function AST')
    checks.check(proof.get('model_requests') == 0 and proof.get('added_return_key') == 'energy_trace',
                 'Instrumentation proof changes the API/return boundary')
    proof_bindings = normalized_hashes(proof.get('source_hashes', {}))
    checks.check(all(source_bindings.get(path) == value for path, value in proof_bindings.items()),
                 'Instrumentation proof/source manifest identities disagree')

    cost_root = Path(manifest.get('cost_root', str(base / 'results/original_structural_cost_20261008'))).resolve()
    expected_cost_root = (base / 'results/original_structural_cost_20261008').resolve()
    checks.check(cost_root == expected_cost_root, 'Energy screen does not use the fixed original 1200-cell cost run')
    cost_manifest_path, cost_completion_path = cost_root / 'manifest.json', cost_root / 'completion.json'
    cost_audit_path = base / 'results/original_structural_cost_20261008_independent_audit.json'
    for path in (cost_manifest_path, cost_completion_path, cost_audit_path):
        checks.check(str(path.resolve()) in input_bindings, 'Required original cost manifest/completion/audit binding missing', source=str(path))
    cost_completion = checks.attempt('Original cost completion unreadable', lambda: read(cost_completion_path)) or {}
    cost_audit = checks.attempt('Original cost independent audit unreadable', lambda: read(cost_audit_path)) or {}
    checks.check(cost_completion.get('status') == 'complete' and cost_completion.get('completed_cells') == 1200,
                 'Original cost evidence is incomplete')
    checks.check(cost_audit.get('status') == 'PASS_INDEPENDENT_ACCOUNTING_AUDIT'
                 and cost_audit.get('errors') == [] and cost_audit.get('audited_completed_cells') == 1200
                 and cost_audit.get('measurement_directory_unchanged') is True,
                 'Original 1200-cell cost audit is not a preserved independent PASS')
    old_snapshot = normalized_cells(cost_audit.get('measurement_hashes_before_after', {}))
    for name in ('manifest.json', 'completion.json'):
        checks.check(old_snapshot.get(name) == input_bindings.get(str((cost_root / name).resolve())),
                     'Current bound cost top-level artifact differs from the independently audited one', artifact=name)
    cost_hashes = normalized_cells(cost_completion.get('cell_hashes', {}))
    expected_cost_names = {f'cells/{scenario}__{seed:03d}__{method}.json' for scenario in SCENARIOS
                           for seed in range(1, 101) for method in METHODS}
    checks.check(set(cost_hashes) == expected_cost_names, 'Original cost cell ledger lacks the fixed 1200 identities')
    for name, expected in cost_hashes.items():
        checks.check(old_snapshot.get(name) == expected, 'Cost completion/cell hash differs from its independent accounting audit', cell=name)
    energy_hashes = normalized_cells(completion.get('cell_hashes', {}))
    expected_energy_names = {f'cells/{scenario}__{seed:03d}__{method}.json' for scenario, seed, method in identities}
    checks.check(set(energy_hashes) == expected_energy_names, 'Energy completion cell ledger missing/extra entries')
    saved_names = {f'cells/{path.name}' for path in (root / 'cells').glob('*.json')}
    checks.check(saved_names == expected_energy_names, 'Saved energy files missing/unplanned',
                 missing=sorted(expected_energy_names - saved_names), unexpected=sorted(saved_names - expected_energy_names))

    summaries = []
    for position, identity in enumerate(identities):
        scenario, seed, method = identity
        name = f'cells/{scenario}__{seed:03d}__{method}.json'
        cell_path, cost_path = root / name, cost_root / name
        cell = checks.attempt(f'Energy cell unreadable: {name}', lambda p=cell_path: read(p))
        cost_cell = checks.attempt(f'Original cost cell unreadable: {name}', lambda p=cost_path: read(p))
        if cell is None or cost_cell is None:
            continue
        cell_hash, cost_hash = digest(cell_path), digest(cost_path)
        checks.check(energy_hashes.get(name) == cell_hash, 'Energy cell payload changed since completion', cell=name)
        checks.check(cost_hashes.get(name) == cost_hash, 'Original cost cell changed since completion/accounting audit', cell=name)
        input_hashes[str(cost_path)] = cost_hash
        summary = checks.attempt(f'Energy cell mathematics/identity audit failed: {name}',
                                lambda c=cell, cost=cost_cell, h=cost_hash, ident=identity:
                                audit_cell(checks, c, cost, h, ident, config_hash))
        if summary is not None:
            summaries.append(summary)
        if (position + 1) % 100 == 0:
            print(f'AUDITED_ENERGY_CELLS: {position + 1}/{expected_count}', flush=True)
    checks.check(len(summaries) == expected_count, 'Not all fixed energy cells could be independently audited')
    grouped = []
    for scenario in SCENARIOS:
        for method in METHODS:
            selected = [x for x in summaries if x['scenario'] == scenario and x['method'] == method]
            required = [p['required_peak_j'] for cell in selected for p in cell['profile_rows']]
            grouped.append({'scenario': scenario, 'method': method, 'cells': len(selected),
                            'service_pass': sum(x['service_pass'] for x in selected),
                            'energy_pass_conditions': sum(x['energy_pass_count'] for x in selected),
                            'joint_pass_conditions': sum(x['joint_pass_count'] for x in selected),
                            'required_peak_range_j': [min(required), max(required)] if required else None})
    for path, expected in input_hashes.items():
        actual = checks.attempt('Audit input unavailable at final read-only check', lambda p=Path(path): digest(p))
        checks.check(actual == expected, 'Input/source changed while the independent energy audit was reading', source=path)
    after_snapshot = snapshot(root)
    checks.check(after_snapshot == before_snapshot, 'Energy measurement directory changed during independent audit')
    powers = [rotary_power_w(speed) for speed in (0.0, SPEED_M_S)]
    return {'version': VERSION, 'status': 'PASS_INDEPENDENT_ENERGY_SCREEN_AUDIT' if not checks.errors else 'FAIL_INDEPENDENT_ENERGY_SCREEN_AUDIT',
            'created_utc': datetime.now(timezone.utc).isoformat(), 'root': str(root), 'mode': mode,
            'assertions': checks.assertions, 'errors': checks.errors,
            'expected_cells': expected_count, 'audited_cells': len(summaries), 'audited_completed_cells': len(summaries),
            'manifest_sha256': before_snapshot.get('manifest.json'), 'completion_sha256': before_snapshot.get('completion.json'),
            'cell_hashes': completion.get('cell_hashes', {}),
            'profiles': sum(x['profiles'] for x in summaries), 'gate_records': sum(x['gates'] for x in summaries),
            'checked_model_endpoints': sum(x['model_relative_checkpoints'] for x in summaries),
            'summary': grouped,
            'independent_power_constants': {'P0_w': PARAMETERS.profile_hover_w, 'Pi_w': PARAMETERS.induced_hover_w,
                                            'v0_m_s': PARAMETERS.induced_hover_speed_m_s, 'U_tip_m_s': PARAMETERS.tip_speed_m_s,
                                            'P_hover_w': powers[0], 'P_42_w': powers[1], 'reference_j': reference_energy_j()},
            'input_hashes_before_after': input_hashes, 'measurement_hashes_before_after': before_snapshot,
            'measurement_directory_unchanged': before_snapshot == after_snapshot,
            'physical_simulator_calls_by_auditor': 0, 'model_requests_by_auditor': 0,
            'scope': ['Independent Eq6/Eq61 power constants, geometry/time/protocol/abstract-cost conservation, all eight motion/load/scale profiles and 120 gates per fixed policy.',
                      'Every initial, travel/hover join, slot endpoint and completed straight-return endpoint; Joules/Wh, capacity/reserve, break-even and first violated boundary.',
                      'Original 1200-cell independent-cost PASS binding; frozen original promoted policy, complete original service metrics and scenario identity remain intact.',
                      'Source/input/cell hashes and one replay per cell accounting are compared against preserved manifest/completion records.'],
            'limitations': ['No real simulator, model request or energy-screen implementation was imported/executed by this independent mathematical auditor.',
                            'New model-relative fixed-policy sensitivity on historical instances; not measured battery endurance, live admission feedback, online RTH or new held-out effectiveness.',
                            'Literature table parameters, stipulated home and 50/100 W always-on nonpropulsive loads are declared assumptions; propulsion scale 1.25 is sensitivity, not a validated maneuver/wind bound.',
                            'Already-airborne ideal horizontal quasi-steady mission plus same-altitude straight return; no takeoff/landing, acceleration, wind, obstacle, battery aging or calibrated payload dynamics.',
                            'Original protocol observations and queue delivery conserve only the abstract cost; the new constant-load Joules are not physical per-protocol measurements.',
                            'The additive trace adapter is bound to its frozen source/restoration proof and preserved observations; this audit does not rerun the original simulator to establish physical reliability.']}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-check', action='store_true', help='Run only synthetic independent mathematical fixtures')
    parser.add_argument('--root', type=Path, help='Finished energy-screen measurement directory, read only')
    parser.add_argument('--mode', choices=('auto', 'smoke', 'full'), default='auto')
    parser.add_argument('--output', type=Path, help='Fresh independent audit JSON outside measurement directory')
    args = parser.parse_args()
    if args.self_check:
        result = core_self_checks()
        print(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False))
    else:
        if args.root is None:
            parser.error('--root or --self-check is required')
        root = args.root.resolve()
        output = (args.output or root.parent / f'{root.name}_independent_audit_{datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")}.json').resolve()
        if output == root or root in output.parents:
            parser.error('Audit output must be outside the measurement directory')
        if output.exists():
            parser.error('Prior audit artifacts must not be overwritten; select a fresh --output')
        result = audit_run(root, args.mode)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
        print('AUDIT_FILE:', output)
        print('AUDIT_STATUS:', result['status'], 'assertions=', result['assertions'], 'errors=', len(result['errors']))
    if result['errors']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
