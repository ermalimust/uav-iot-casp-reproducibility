#!/usr/bin/env python3
"""Statistics + clean analysis checks for the Heterogeneous Contingency Suite.

Reads results/contingency_suite_clean_per_seed.csv and reports, per contingency group:
  - pass rate + Wilson 95% CI for every method
  - matched-seed exact McNemar (Holm-corrected) for hybrid_casp vs each alternative,
    on the HELD-OUT contingency and on the seen-pooled set
  - PASS/FAIL readouts for the locked clean rerun analysis checks.

numpy/pandas only. Usage: python contingency_stats.py [results_dir]
"""
import sys, math, csv
from collections import defaultdict
from pathlib import Path

RES = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "results"
CSV = RES / "contingency_suite_clean_per_seed.csv"
HELD_OUT = "C4_two_hotspots"
SEEN = ["C1_known_east", "C2_moved", "C3_misleading"]


def wilson(k, n, z=1.96):
    if n == 0:
        return float("nan"), float("nan")
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


def mcnemar_exact(b, c):
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    return min(1.0, 2 * sum(math.comb(n, i) for i in range(k + 1)) * (0.5 ** n))


def holm(pairs):
    s = sorted(pairs, key=lambda kv: kv[1]); m = len(s); out = {}; run = 0.0
    for i, (nm, p) in enumerate(s):
        run = max(run, min(1.0, (m - i) * p)); out[nm] = run
    return out


def load():
    rows = list(csv.DictReader(open(CSV, encoding="utf-8")))
    for r in rows:
        r["pass"] = str(r["passed_contract"]).strip().lower() == "true"
        r["seed"] = int(r["seed"])
    return rows


def passes(rows, ctypes, method):
    sub = [r for r in rows if r["method"] == method and r["contingency"] in ctypes]
    k = sum(1 for r in sub if r["pass"])
    return k, len(sub)


def matched(rows, ctypes, m_a, m_b):
    A = {(r["contingency"], r["seed"]): r["pass"] for r in rows
         if r["method"] == m_a and r["contingency"] in ctypes}
    B = {(r["contingency"], r["seed"]): r["pass"] for r in rows
         if r["method"] == m_b and r["contingency"] in ctypes}
    keys = set(A) & set(B)
    b = sum(1 for k in keys if (not A[k]) and B[k])   # a fail, b pass
    c = sum(1 for k in keys if A[k] and (not B[k]))
    return b, c, mcnemar_exact(b, c), len(keys)


def main():
    if not CSV.exists():
        print(f"missing {CSV}; run run_contingency_suite.py first"); return
    rows = load()
    methods = ["B1_max_backlog", "B2_scripted_east", "B3_single_target_diag",
               "pure_llm", "hybrid_casp", "MT_scripted_reference"]
    methods = [m for m in methods if any(r["method"] == m for r in rows)]
    ctypes = sorted({r["contingency"] for r in rows})

    print("Per-group pass rate (Wilson 95% CI)\n" + "=" * 60)
    groups = [("seen_pooled", SEEN)] + [(c, [c]) for c in ctypes] + [("HELD_OUT", [HELD_OUT])]
    out_rows = []
    for gname, gtypes in groups:
        print(f"\n[{gname}]")
        for m in methods:
            k, n = passes(rows, gtypes, m)
            if n == 0:
                continue
            lo, hi = wilson(k, n)
            print(f"  {m:18s} {k/n:.3f}  [{lo:.2f},{hi:.2f}]  (n={n})")
            out_rows.append({"group": gname, "method": m, "n": n,
                             "pass_rate": round(k / n, 3), "ci_lo": round(lo, 3), "ci_hi": round(hi, 3)})

    print("\nHeld-out C4: hybrid_casp vs alternatives (matched exact McNemar, Holm)\n" + "=" * 60)
    heldout_comps = []
    for alt in ["B1_max_backlog", "B2_scripted_east", "B3_single_target_diag",
                "pure_llm", "MT_scripted_reference"]:
        if not any(r["method"] == alt for r in rows):
            continue
        b, c, p, nn = matched(rows, [HELD_OUT], alt, "hybrid_casp")
        heldout_comps.append((f"hybrid_casp_vs_{alt}", p))
        print(f"  hybrid_casp vs {alt:24s} discordant(b={b},c={c}) n={nn}  p={p:.4g}")
    heldout_adj = holm(heldout_comps)
    for nm, p in heldout_comps:
        print(f"  {nm:28s} Holm_adj={heldout_adj[nm]:.4g}")

    print("\nSeen-pooled: hybrid_casp vs single-target rules (matched exact McNemar, Holm)\n" + "=" * 60)
    seen_comps = []
    for alt in ["B1_max_backlog", "B2_scripted_east", "B3_single_target_diag"]:
        if not any(r["method"] == alt for r in rows):
            continue
        b, c, p, nn = matched(rows, SEEN, alt, "hybrid_casp")
        seen_comps.append((f"seen_hybrid_casp_vs_{alt}", p))
        print(f"  hybrid_casp vs {alt:24s} discordant(b={b},c={c}) n={nn}  p={p:.4g}")
    seen_adj = holm(seen_comps)
    for nm, p in seen_comps:
        print(f"  {nm:33s} Holm_adj={seen_adj[nm]:.4g}")

    # Locked clean-rerun analysis checks. MT_scripted_reference is reported as a
    # strong hand-enumerated reference, not a pass/fail target for the hybrid row.
    def pr(g, m):
        k, n = passes(rows, g, m); return k / n if n else float("nan")
    print("\nClean rerun analysis checks\n" + "=" * 60)
    c1 = (seen_adj.get("seen_hybrid_casp_vs_B3_single_target_diag", 1) > 0.05
          and pr(SEEN, "hybrid_casp") > pr(SEEN, "B1_max_backlog")
          and pr(SEEN, "hybrid_casp") > pr(SEEN, "B2_scripted_east"))
    sig = lambda a: heldout_adj.get(f"hybrid_casp_vs_{a}", 1) < 0.05 and pr([HELD_OUT], "hybrid_casp") > pr([HELD_OUT], a)
    c2 = all(sig(a) for a in ["B1_max_backlog", "B2_scripted_east", "B3_single_target_diag"])
    c3 = (heldout_adj.get("hybrid_casp_vs_pure_llm", 1) < 0.05) or (pr([HELD_OUT], "hybrid_casp") > pr([HELD_OUT], "pure_llm"))
    print(f"  Success 1 seen-pooled: hybrid_casp comparable to B3 and >B1,B2 .... {'PASS' if c1 else 'no'}")
    print(f"  Success 2 held-out C4: hybrid_casp>B1,B2,B3 single-target rules . {'PASS' if c2 else 'no'}")
    print(f"  Success 3 hybrid_casp>pure_llm .................................... {'PASS' if c3 else 'no'}")
    if any(r["method"] == "MT_scripted_reference" for r in rows):
        print(f"  Reference: held-out hybrid_casp={pr([HELD_OUT], 'hybrid_casp'):.3f}, "
              f"MT_scripted_reference={pr([HELD_OUT], 'MT_scripted_reference'):.3f}")
    print("\n=> POSITIVE RESULT" if (c1 and c2) else
          "\n=> clean checks not satisfied; report as boundary evidence, not as a win")
    with open(RES / "contingency_clean_stats_summary.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(out_rows[0].keys())); w.writeheader(); w.writerows(out_rows)
    print(f"wrote {RES/'contingency_clean_stats_summary.csv'}")


if __name__ == "__main__":
    main()
