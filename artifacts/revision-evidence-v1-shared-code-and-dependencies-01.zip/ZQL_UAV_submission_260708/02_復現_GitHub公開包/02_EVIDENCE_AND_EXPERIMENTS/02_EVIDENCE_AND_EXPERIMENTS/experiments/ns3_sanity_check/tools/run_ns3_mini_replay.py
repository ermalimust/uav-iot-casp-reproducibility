from __future__ import annotations

import csv
import json
import os
import shutil
import statistics
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRATCH_SRC = ROOT / "scratch" / "uav_iot_mini_replay.cc"
RESULTS = ROOT / "results"
TARGET = "scratch_uav_iot_mini_replay"
DEFAULT_NS3_ROOT = Path(r"D:\tools\ns3\ns-allinone-3.47\ns-3.47")
DEFAULT_MSYS_BIN = Path(r"D:\tools\ns3\msys64\mingw64\bin")
DEFAULT_MSYS_USR_BIN = Path(r"D:\tools\ns3\msys64\usr\bin")
DEFAULT_CLEAN_TOOL_ROOT = Path(r"D:\tools\ns3")
DEFAULT_BUILD_ROOT = Path(r"C:\tmp\ns3_uav_iot_mini_replay_build")


def detect_gcc_version(mingw_root: Path, env: dict[str, str]) -> str:
    if "NS3_GCC_VERSION" in env:
        return env["NS3_GCC_VERSION"]
    gcc_dir = mingw_root / "lib" / "gcc" / "x86_64-w64-mingw32"
    versions = [path.name for path in gcc_dir.iterdir() if path.is_dir()] if gcc_dir.exists() else []
    if not versions:
        return "15.2.0"

    def version_key(value: str) -> tuple[int, ...]:
        parts = []
        for token in value.split("."):
            try:
                parts.append(int(token))
            except ValueError:
                parts.append(0)
        return tuple(parts)

    return sorted(versions, key=version_key)[-1]


def make_env() -> dict[str, str]:
    env = os.environ.copy()
    tool_root = Path(env.get("NS3_TOOL_ROOT", str(DEFAULT_CLEAN_TOOL_ROOT)))
    if tool_root.exists():
        mingw_bin = Path(env.get("NS3_MINGW_BIN", str(tool_root / "msys64" / "mingw64" / "bin")))
        usr_bin = Path(env.get("NS3_USR_BIN", str(tool_root / "msys64" / "usr" / "bin")))
    else:
        mingw_bin = Path(env.get("NS3_MINGW_BIN", str(DEFAULT_MSYS_BIN)))
        usr_bin = Path(env.get("NS3_USR_BIN", str(DEFAULT_MSYS_USR_BIN)))
    extra = [str(mingw_bin), str(usr_bin)]
    env["PATH"] = ";".join(extra + [env.get("PATH", "")])
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    mingw_root = mingw_bin.parent
    gcc_version = detect_gcc_version(mingw_root, env)
    env["NS3_GCC_VERSION"] = gcc_version
    env["C_INCLUDE_PATH"] = str(mingw_root / "include")
    env["CPLUS_INCLUDE_PATH"] = ";".join(
        [
            str(mingw_root / "include" / "c++" / gcc_version),
            str(mingw_root / "include" / "c++" / gcc_version / "x86_64-w64-mingw32"),
            str(mingw_root / "include"),
        ]
    )
    env["LIBRARY_PATH"] = ";".join(
        [
            str(mingw_root / "lib"),
            str(mingw_root / "x86_64-w64-mingw32" / "lib"),
            str(mingw_root / "lib" / "gcc" / "x86_64-w64-mingw32" / gcc_version),
        ]
    )
    env["COMPILER_PATH"] = str(mingw_root / "libexec" / "gcc" / "x86_64-w64-mingw32" / gcc_version)
    env["CMAKE_PREFIX_PATH"] = str(mingw_root)
    return env


def resolve_source_root() -> tuple[Path | None, dict[str, str], Path]:
    env = make_env()
    tool_root = Path(os.environ.get("NS3_TOOL_ROOT", str(DEFAULT_CLEAN_TOOL_ROOT)))
    if "NS3_ROOT" in os.environ:
        source_root = Path(os.environ["NS3_ROOT"])
    elif tool_root.exists():
        source_root = tool_root / "ns-allinone-3.47" / "ns-3.47"
    else:
        source_root = DEFAULT_NS3_ROOT
    build_root = Path(os.environ.get("NS3_MINI_REPLAY_BUILD_ROOT", str(DEFAULT_BUILD_ROOT)))
    return (source_root if source_root.exists() else None), env, build_root


def run_cmd(cmd: list[str], cwd: Path, env: dict[str, str], timeout: int = 300) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        cwd=str(cwd),
        env=env,
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )


def configure_direct(source_root: Path, build_root: Path, env: dict[str, str]) -> None:
    cmake = Path(env["NS3_CMAKE"]) if "NS3_CMAKE" in env else Path(env["PATH"].split(";")[0]) / "cmake.exe"
    cxx = Path(env["NS3_CXX"]) if "NS3_CXX" in env else Path(env["PATH"].split(";")[0]) / "c++.exe"
    cc = Path(env["NS3_CC"]) if "NS3_CC" in env else Path(env["PATH"].split(";")[0]) / "gcc.exe"
    ninja = Path(env["NS3_NINJA"]) if "NS3_NINJA" in env else Path(env["PATH"].split(";")[0]) / "ninja.exe"
    mingw_root = Path(env["CMAKE_PREFIX_PATH"])
    gcc_version = env.get("NS3_GCC_VERSION", "15.2.0")
    gcc_start = mingw_root / "lib" / "gcc" / "x86_64-w64-mingw32" / gcc_version
    bflags = f"-B{gcc_start.as_posix()}/ -B{(mingw_root / 'lib').as_posix()}/"
    lflags = " ".join(
        [
            bflags,
            f"-L{gcc_start.as_posix()}",
            f"-L{(mingw_root / 'lib').as_posix()}",
            f"-L{(mingw_root / 'x86_64-w64-mingw32' / 'lib').as_posix()}",
        ]
    )
    build_root.mkdir(parents=True, exist_ok=True)
    if (build_root / "CMakeCache.txt").exists():
        return
    configure = run_cmd(
        [
            str(cmake),
            "-S",
            str(source_root),
            "-B",
            str(build_root),
            "-G",
            "Ninja",
            f"-DCMAKE_MAKE_PROGRAM={ninja}",
            f"-DCMAKE_C_COMPILER={cc}",
            f"-DCMAKE_CXX_COMPILER={cxx}",
            "-DCMAKE_BUILD_TYPE=Release",
            f"-DCMAKE_C_FLAGS={bflags}",
            f"-DCMAKE_CXX_FLAGS={bflags}",
            f"-DCMAKE_EXE_LINKER_FLAGS={lflags}",
            f"-DCMAKE_SHARED_LINKER_FLAGS={lflags}",
            "-DNS3_ASSERT=OFF",
            "-DNS3_LOG=OFF",
            "-DNS3_WARNINGS_AS_ERRORS=OFF",
            "-DNS3_NATIVE_OPTIMIZATIONS=OFF",
            "-DNS3_EXAMPLES=OFF",
            "-DNS3_TESTS=OFF",
            "-DNS3_ENABLED_MODULES=core,network,mobility,propagation,wifi,internet,applications",
        ],
        source_root,
        env,
        timeout=600,
    )
    if configure.returncode != 0:
        (RESULTS / "ns3_mini_replay_configure_failed.log").write_text(configure.stdout, encoding="utf-8")
        raise RuntimeError("ns-3 configure failed; see results/ns3_mini_replay_configure_failed.log")


def write_pending(source_hint: str) -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    pending = {
        "status": "pending_ns3_runtime",
        "reason": "No ns-3.47 source root was found at NS3_ROOT, NS3_TOOL_ROOT, or the default local path.",
        "source_hint_checked": source_hint,
        "how_to_run": [
            "Set NS3_ROOT to the ns-3.47 source directory.",
            "Optionally set NS3_MINI_REPLAY_BUILD_ROOT to an empty build directory.",
            "Run: python tools/run_ns3_mini_replay.py",
        ],
        "intended_evidence": (
            "Reduced ns-3 replay of a target-hotspot burst: static, route-only, "
            "protocol-only, and route+protocol skeletons are compared under the "
            "same packet stack. Metrics are target PDR, target max receive-blackout, "
            "and a reduced pass predicate."
        ),
    }
    (RESULTS / "ns3_mini_replay_pending.json").write_text(json.dumps(pending, indent=2), encoding="utf-8")


def build_replay(source_root: Path, build_root: Path, env: dict[str, str]) -> Path:
    scratch_dst = source_root / "scratch" / SCRATCH_SRC.name
    shutil.copy2(SCRATCH_SRC, scratch_dst)
    configure_direct(source_root, build_root, env)
    cmake = Path(env["NS3_CMAKE"]) if "NS3_CMAKE" in env else Path(env["PATH"].split(";")[0]) / "cmake.exe"
    build = run_cmd([str(cmake), "--build", str(build_root), "--target", TARGET, "-j", "4"], build_root, env, timeout=900)
    if build.returncode != 0:
        (RESULTS / "ns3_mini_replay_build_failed.log").write_text(build.stdout, encoding="utf-8")
        raise RuntimeError("ns-3 mini replay build failed; see results/ns3_mini_replay_build_failed.log")
    matches = list(build_root.rglob("*uav_iot_mini_replay*.exe"))
    matches.extend((source_root / "build").rglob("*uav_iot_mini_replay*.exe"))
    if not matches:
        raise RuntimeError(f"Could not find built mini replay executable under {build_root}")
    return matches[0]


def parse_row(line: str) -> dict[str, str] | None:
    if not line.startswith("NS3_REPLAY,"):
        return None
    parts = line.strip().split(",")
    keys = [
        "tag",
        "method",
        "profile",
        "run",
        "sim_stop_s",
        "burst_start_s",
        "burst_stop_s",
        "base_mbps",
        "burst_mbps",
        "rx_mbps",
        "pdr",
        "rx_bytes",
        "expected_bytes",
        "max_blackout_s",
        "data_mode",
        "tx_power_dbm",
        "path_loss_exponent",
        "reference_loss_db",
        "passed",
    ]
    if len(parts) != len(keys):
        return None
    return dict(zip(keys, parts))


def run_replay(exe: Path, source_root: Path, build_root: Path, env: dict[str, str]) -> list[dict[str, str]]:
    env = env.copy()
    env["PATH"] = ";".join(
        [
            str(source_root / "build" / "lib"),
            str(source_root / "build" / "bin"),
            str(build_root / "lib"),
            str(build_root / "bin"),
            env.get("PATH", ""),
        ]
    )
    runs = int(os.environ.get("NS3_MINI_REPLAY_RUNS", "30"))
    rows: list[dict[str, str]] = []
    logs: list[str] = []
    methods = ["static", "route_only", "protocol_only", "route_protocol"]
    for method in methods:
        for run in range(1, runs + 1):
            cmd = [str(exe), f"--method={method}", f"--run={run}"]
            proc = run_cmd(cmd, build_root, env, timeout=120)
            logs.append("$ " + " ".join(cmd) + "\n" + proc.stdout + "\n")
            if proc.returncode != 0:
                (RESULTS / "ns3_mini_replay_run_failed.log").write_text("\n".join(logs), encoding="utf-8")
                raise RuntimeError("ns-3 mini replay run failed; see results/ns3_mini_replay_run_failed.log")
            for line in proc.stdout.splitlines():
                row = parse_row(line)
                if row:
                    rows.append(row)
    (RESULTS / "ns3_mini_replay_run.log").write_text("\n".join(logs), encoding="utf-8")
    return rows


def write_csv(rows: list[dict[str, str]]) -> None:
    path = RESULTS / "ns3_mini_replay_raw.csv"
    fieldnames = [
        "method",
        "profile",
        "run",
        "sim_stop_s",
        "burst_start_s",
        "burst_stop_s",
        "base_mbps",
        "burst_mbps",
        "rx_mbps",
        "pdr",
        "rx_bytes",
        "expected_bytes",
        "max_blackout_s",
        "data_mode",
        "tx_power_dbm",
        "path_loss_exponent",
        "reference_loss_db",
        "passed",
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row[k] for k in fieldnames})


def summarize(rows: list[dict[str, str]], source_root: Path, build_root: Path) -> None:
    by_method: dict[str, list[dict[str, str]]] = {}
    for row in rows:
        by_method.setdefault(row["method"], []).append(row)
    methods = {}
    for method, mr in by_method.items():
        pdr_values = [float(r["pdr"]) for r in mr]
        blackout_values = [float(r["max_blackout_s"]) for r in mr]
        pass_values = [1.0 if r["passed"] == "1" else 0.0 for r in mr]
        methods[method] = {
            "n": len(mr),
            "mean_pdr": statistics.mean(pdr_values),
            "pdr_range": [min(pdr_values), max(pdr_values)],
            "mean_max_blackout_s": statistics.mean(blackout_values),
            "max_blackout_s_range": [min(blackout_values), max(blackout_values)],
            "pass_rate": statistics.mean(pass_values),
            "passes": int(sum(pass_values)),
        }
    summary = {
        "status": "complete",
        "ns3_source_root": str(source_root),
        "ns3_build_root": str(build_root),
        "ns3_version": (source_root / "VERSION").read_text(encoding="utf-8").strip(),
        "rows": len(rows),
        "contract": {
            "target_pdr_min": 0.55,
            "target_max_blackout_s_max": 5,
            "note": "Reduced target-hotspot predicate, not the full Python-simulator CASP contract.",
        },
        "methods": methods,
        "interpretation": (
            "The mini replay checks whether route return, a long-range robust protocol profile, "
            "and their composition move target-hotspot packet delivery and blackout in the "
            "directions assumed by the contract experiments. It is an external mechanism anchor, "
            "not a replacement for the controlled simulator experiments."
        ),
    }
    (RESULTS / "ns3_mini_replay_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")


def main() -> int:
    RESULTS.mkdir(parents=True, exist_ok=True)
    source_root, env, build_root = resolve_source_root()
    if source_root is None:
        source_hint = os.environ.get("NS3_ROOT") or os.environ.get("NS3_TOOL_ROOT") or str(DEFAULT_NS3_ROOT)
        write_pending(source_hint)
        print(f"No ns-3 source root found. Wrote {RESULTS / 'ns3_mini_replay_pending.json'}")
        return 2
    exe = build_replay(source_root, build_root, env)
    rows = run_replay(exe, source_root, build_root, env)
    write_csv(rows)
    summarize(rows, source_root, build_root)
    print(f"Wrote {len(rows)} rows to {RESULTS / 'ns3_mini_replay_raw.csv'}")
    print(f"Wrote summary to {RESULTS / 'ns3_mini_replay_summary.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
