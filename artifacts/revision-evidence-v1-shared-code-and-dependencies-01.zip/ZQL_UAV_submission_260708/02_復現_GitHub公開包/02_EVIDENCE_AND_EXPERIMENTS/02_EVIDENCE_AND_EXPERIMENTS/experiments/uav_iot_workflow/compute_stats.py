#!/usr/bin/env python3
"""A7 statistics for the UAV-IoT validated-recoverability paper.

Computes, from the per-seed result CSVs:
  - contract pass rate + Wilson 95% CI
  - QSR / recovery-time median, IQR, mean, and bootstrap 95% CI of the mean
  - pairwise exact McNemar tests on matched seeds (pass), Holm-corrected

Runs unchanged at n=30 or n=100 after the re-runs.
Dependencies: numpy + pandas only (NO scipy required).

Usage:
    python compute_stats.py [results_dir]
        results_dir defaults to ./results next to this script.
"""
import sys, math
import numpy as np
import pandas as pd
from pathlib import Path

RES = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "results"


def wilson(k, n, z=1.96):
    if n == 0:
        return float("nan"), float("nan")
    p = k / n
    d = 1 + z * z / n
    center = (p + z * z / (2 * n)) / d
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, center - half), min(1.0, center + half)


def boot_ci_mean(x, B=10000, seed=0):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    if len(x) == 0:
        return float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(x), size=(B, len(x)))
    means = x[idx].mean(axis=1)
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def mcnemar_exact(b, c):
    """Two-sided exact McNemar on discordant counts b, c."""
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    tail = sum(math.comb(n, i) for i in range(0, k + 1)) * (0.5 ** n)
    return min(1.0, 2 * tail)


def holm(pairs):
    """Holm-Bonferroni. pairs: list of (name, p). Returns {name: adj_p}."""
    s = sorted(pairs, key=lambda kv: kv[1])
    m = len(s)
    out, running = {}, 0.0
    for i, (name, p) in enumerate(s):
        running = max(running, min(1.0, (m - i) * p))
        out[name] = running
    return out


def tobool(s):
    return s.astype(str).str.strip().str.lower().eq("true")


# ---- load ----
hy_path = RES / "hybrid_ablation_per_seed.csv"
hy = pd.read_csv(hy_path)
hy["pass"] = tobool(hy["passed_contract"])
sm = pd.read_csv(RES / "summary_metrics.csv")
sm["pass"] = tobool(sm["passed_contract"])

# canonical display names (see RESULTS_NAMING.md)
CANON = {
    "lawn_mower": "Lawn-mower",
    "nearest_backlog_greedy": "Greedy backlog",
    "static_nominal_optimizer": "Static optimizer",
    "one_shot_agent_policy": "One-shot",
    "workflow_no_repair": "No repair",
    "workflow_generic_repair": "Generic repair",
    "workflow_no_casp_triggers": "No CASP trigger",
    "scripted_casp": "Scripted CASP (no LLM)",
    "hybrid": "Hybrid CASP (main)",
    "pure_llm": "Pure LLM (Qwen-Plus)",
}

units = []
for m in ["lawn_mower", "nearest_backlog_greedy", "static_nominal_optimizer",
          "one_shot_agent_policy", "workflow_no_repair", "workflow_generic_repair",
          "workflow_no_casp_triggers"]:
    units.append((CANON[m], sm[sm.method == m]))
for b in ["scripted_casp", "pure_llm", "hybrid"]:
    d = hy[hy.backend == b]
    if len(d):
        units.append((CANON[b], d))

rows = []
for name, d in units:
    n = len(d)
    k = int(d["pass"].sum())
    lo, hi = wilson(k, n)
    qsr = pd.to_numeric(d["qsr"], errors="coerce").to_numpy()
    rec = pd.to_numeric(d["recovery_time"], errors="coerce").to_numpy()
    rlo, rhi = boot_ci_mean(rec)
    rows.append(dict(
        method=name, n=n, pass_rate=round(k / n, 3),
        pass_wilson95=f"[{lo:.2f},{hi:.2f}]",
        qsr_median=round(float(np.median(qsr)), 3),
        qsr_IQR=f"[{np.percentile(qsr,25):.3f},{np.percentile(qsr,75):.3f}]",
        rec_median=round(float(np.median(rec)), 1),
        rec_IQR=f"[{np.percentile(rec,25):.0f},{np.percentile(rec,75):.0f}]",
        rec_mean=round(float(np.mean(rec)), 1),
        rec_mean_boot95=f"[{rlo:.1f},{rhi:.1f}]",
    ))

out = pd.DataFrame(rows)
pd.set_option("display.width", 200, "display.max_columns", 20)
print(out.to_string(index=False))
out.to_csv(RES / "stats_summary.csv", index=False)


def matched_disc(a_df, a_col, a_val, b_df, b_col, b_val):
    A = a_df[a_df[a_col] == a_val].set_index("seed")["pass"]
    B = b_df[b_df[b_col] == b_val].set_index("seed")["pass"]
    j = A.index.intersection(B.index)
    A, B = A.loc[j], B.loc[j]
    b = int((~A & B).sum())   # a fails, b passes
    c = int((A & ~B).sum())   # a passes, b fails
    return b, c, mcnemar_exact(b, c), len(j)


comparison_specs = {
    "static_vs_scripted_casp": (sm, "method", "static_nominal_optimizer", hy, "backend", "scripted_casp"),
    "static_vs_hybrid": (sm, "method", "static_nominal_optimizer", hy, "backend", "hybrid"),
    "scripted_casp_vs_hybrid": (hy, "backend", "scripted_casp", hy, "backend", "hybrid"),
}
comps = []
for label, (adf, ac, av, bdf, bc, bv) in comparison_specs.items():
    if adf[adf[ac] == av].empty or bdf[bdf[bc] == bv].empty:
        continue
    bb, cc, p, nn = matched_disc(adf, ac, av, bdf, bc, bv)
    comps.append((label, p))
    print(f"# {label}: discordant b={bb} c={cc} (matched n={nn}) exact McNemar p={p:.4g}")

if comps:
    adj = holm(comps)
    print("\nPairwise McNemar (exact), Holm-adjusted:")
    for name, p in comps:
        print(f"  {name:22s} p={p:.4g}  Holm_adj={adj[name]:.4g}")
print(f"\nwrote {RES/'stats_summary.csv'}")
