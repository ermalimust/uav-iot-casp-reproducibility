"""One fixed-policy replay per cell; additional energy admission only, API zero."""
from __future__ import annotations
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time
sys.dont_write_bytecode = True

from original_energy_trace import original_modules, simulate_with_energy_trace, instrumentation_proof, source_bindings
from original_energy_screen import CONFIG, load_config, evaluate_all
from candidate_search import policy_semantic_hash

BASE = Path(__file__).resolve().parent
COST = BASE/'results/original_structural_cost_20261008'
AUDIT = BASE/'results/original_structural_cost_20261008_independent_audit.json'
PROTOCOL = BASE.parent/'Original_Energy_Screen_Protocol_20261008.md'
SCENARIOS = ['S1_seen_burst_east','S2_seen_degrade_west','S3_seen_moved_burst','S4_heldout_misleading']
METHODS = ['compact','compact_plus_expert','compact_plus_cached_model']

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def clean(value):
    if isinstance(value, dict): return {str(k):clean(v) for k,v in value.items()}
    if isinstance(value, (list,tuple)): return [clean(v) for v in value]
    if isinstance(value, set): return sorted(clean(v) for v in value)
    return value

def canonical_hash(value):
    return hashlib.sha256(json.dumps(clean(value),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def save(path, value):
    # Exclusive creation preserves prior/partial records; no retry or overwrite.
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(clean(value),stream,ensure_ascii=False,separators=(',',':'),allow_nan=False)
        stream.write('\n')

def source_hashes():
    values = source_bindings()
    for path in (Path(__file__),BASE/'original_energy_screen.py',CONFIG,PROTOCOL,BASE/'candidate_search.py'):
        values[str(path.resolve())] = digest(path)
    return values

def fixed_policy(cell):
    wanted = cell['promotion']['policy_hash']
    matches = [e for g in cell['groups'] for e in g['evaluations'] if e['policy_hash']==wanted]
    if not matches: raise AssertionError('Promoted policy absent from original ledger')
    policy = matches[0]['policy']
    if policy_semantic_hash(policy)!=wanted: raise AssertionError('Original policy identity differs')
    if any(e['metrics']!=cell['promotion']['metrics'] for e in matches):
        raise AssertionError('Original promoted metrics conflict')
    return copy.deepcopy(policy)

def run(out, start, stop):
    if out.exists(): raise FileExistsError('Use a fresh output directory; no overwrite/retry')
    cfg = load_config()
    cost_completion, cost_manifest, cost_audit = read(COST/'completion.json'),read(COST/'manifest.json'),read(AUDIT)
    if cost_completion['status']!='complete' or cost_completion['completed_cells']!=1200:
        raise AssertionError('Original cost evidence incomplete')
    if cost_audit['status']!='PASS_INDEPENDENT_ACCOUNTING_AUDIT' or cost_audit['errors']:
        raise AssertionError('Original cost accounting not independently audited')
    inputs = {str(p.resolve()):digest(p) for p in (COST/'manifest.json',COST/'completion.json',AUDIT)}
    before = source_hashes()
    identities = [(s,n,m) for s in SCENARIOS for n in range(start,stop+1) for m in METHODS]
    out.mkdir(parents=True)
    (out/'cells').mkdir()
    manifest = {'version':cfg['version'],'created_utc':datetime.now(timezone.utc).isoformat(),
                'expected_cells':len(identities),'seeds':[start,stop],'scenarios':SCENARIOS,'methods':METHODS,
                'config':cfg,'source_hashes_before':before,'input_hashes_before':inputs,
                'cost_root':str(COST.resolve()),'original_cost_cells':1200,
                'one_fixed_policy_replay_per_cell':True,'recalibration':False,'simulation_cache_hits':0,
                'model_requests':0,'workers':1,'instrumentation':instrumentation_proof()}
    save(out/'manifest.json',manifest)
    _, mixed = original_modules()
    counts = {'simulator_attempts':0,'completed_cells':0,'energy_profiles':0,'gate_records':0,'model_requests':0,'simulation_cache_hits':0}
    hashes = {}
    began = time.perf_counter()
    try:
        for scenario,seed,method in identities:
            filename = f'{scenario}__{seed:03d}__{method}.json'
            cost_path = COST/'cells'/filename
            expected = cost_completion['cell_hashes'][str(Path('cells')/filename)]
            if digest(cost_path)!=expected: raise AssertionError('Original cost cell hash changed')
            cost_cell = read(cost_path)
            if (cost_cell['scenario'],cost_cell['seed'],cost_cell['method'])!=(scenario,seed,method):
                raise AssertionError('Cost cell identity differs')
            policy = fixed_policy(cost_cell)
            scene = mixed.make_scenario_mixed(seed,scenario)
            if canonical_hash(scene)!=cost_cell['scenario_sha256']: raise AssertionError('Original scenario hash differs')
            scene_hash, policy_hash = canonical_hash(scene),canonical_hash(policy)
            counts['simulator_attempts'] += 1
            result = simulate_with_energy_trace(scene,policy)
            if canonical_hash(scene)!=scene_hash or canonical_hash(policy)!=policy_hash:
                raise AssertionError('Replay mutated its input')
            if result['metrics']!=cost_cell['promotion']['metrics']:
                raise AssertionError('Instrumented replay changed original service metrics')
            energy = evaluate_all(result['energy_trace'],result['metrics']['passed_contract'],cfg)
            cell = {'version':cfg['version'],'status':'complete','scenario':scenario,'seed':seed,'method':method,
                    'cost_cell_sha256':expected,'scenario_sha256':scene_hash,'policy':policy,
                    'policy_hash':cost_cell['promotion']['policy_hash'],'policy_full_sha256':policy_hash,
                    'original_metrics':cost_cell['promotion']['metrics'],'original_promotion':cost_cell['promotion'],
                    'simulator_calls':1,'model_requests':0,'simulation_cache_hits':0,
                    'simulation':result,'energy':energy}
            path = out/'cells'/filename
            save(path,cell)
            hashes[str(path.relative_to(out))] = digest(path)
            counts['completed_cells'] += 1
            counts['energy_profiles'] += len(energy['profiles'])
            counts['gate_records'] += len(energy['gates'])
            if counts['completed_cells']%30==0:
                print(f"ENERGY_CELLS: {counts['completed_cells']}/{len(identities)}",flush=True)
        after = source_hashes()
        after_inputs = {path:digest(path) for path in inputs}
        if before!=after or inputs!=after_inputs: raise AssertionError('Frozen source/input changed during screen')
        completion = {'version':cfg['version'],'status':'complete','expected_cells':len(identities),**counts,
                      'source_hashes_after':after,'input_hashes_after':after_inputs,'cell_hashes':hashes,
                      'wall_seconds':time.perf_counter()-began,'all_original_metrics_exact':True}
        save(out/'completion.json',completion)
        print(f'RESULT_FILE: {out / "completion.json"}',flush=True)
        return 0
    except Exception as error:
        save(out/'failure.json',{'status':'failed_preserved','error_type':type(error).__name__,
              'message':str(error),**counts,'cell_hashes':hashes,'wall_seconds':time.perf_counter()-began})
        raise

if __name__=='__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--seeds',default='1:100')
    args = parser.parse_args()
    lo,hi = map(int,args.seeds.split(':'))
    if not 1<=lo<=hi<=100: parser.error('Original seeds must stay in 1:100')
    sys.exit(run(args.out.resolve(),lo,hi))
