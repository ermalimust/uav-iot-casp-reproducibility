"""Summarize independently audited fixed-policy energy records; never simulate.

All predeclared profiles/capacity/reserve conditions remain in the outputs.
The compact LaTeX display fixes r=0.1 and shows every profile, without selecting
a condition from the observed ordering of methods. Standard library only.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = BASE / 'results/original_energy_screen_20261008'
AUDIT = BASE / 'results/original_energy_screen_20261008_independent_audit.json'
OUT = BASE / 'results/original_energy_screen_analysis_20261008'
SCENARIOS = ('S1_seen_burst_east', 'S2_seen_degrade_west',
             'S3_seen_moved_burst', 'S4_heldout_misleading')
METHODS = ('compact', 'compact_plus_expert', 'compact_plus_cached_model')
LABELS = {'compact': 'Compact', 'compact_plus_expert': 'Compact + expert',
          'compact_plus_cached_model': 'Compact + cached LLM'}
COUNTS = ('n', 'service_pass', 'energy_pass', 'joint_pass',
          'rejected_service_pass', 'energy_pass_service_fail',
          'energy_fail_service_fail')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def number(value, name):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError(f'Missing/nonfinite numeric field {name}: {value!r}')
    return float(value)


def quantile(values, fraction):
    ordered = sorted(values)
    if not ordered:
        raise ValueError('Cannot summarize an empty sample')
    index = (len(ordered) - 1) * fraction
    low, high = math.floor(index), math.ceil(index)
    return ordered[low] + (ordered[high] - ordered[low]) * (index - low)


def stats(values):
    return {'n': len(values), 'min': min(values), 'median': quantile(values, .5),
            'p95': quantile(values, .95), 'max': max(values)}


def blank_counts():
    return {key: 0 for key in COUNTS}


def add_counts(target, service, energy, joint):
    if any(type(flag) is not bool for flag in (service, energy, joint)):
        raise ValueError('Gate flags must be strict booleans')
    if joint != (service and energy):
        raise ValueError('Joint gate differs from unchanged service AND energy')
    target['n'] += 1
    target['service_pass'] += service
    target['energy_pass'] += energy
    target['joint_pass'] += joint
    target['rejected_service_pass'] += service and not energy
    target['energy_pass_service_fail'] += energy and not service
    target['energy_fail_service_fail'] += not energy and not service


def resolve_relative(root, relative):
    # Manifest paths were produced on Windows; retain identical serialized keys.
    path = (root / Path(relative.replace('\\', '/'))).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError('Cell path escapes measured root')
    return path


def require_audited(root, audit_path):
    """Bind the PASS to the exact complete records, rejecting stale reports."""
    root = root.resolve()
    audit = read(audit_path)
    if audit.get('status') != 'PASS_INDEPENDENT_ENERGY_SCREEN_AUDIT' or audit.get('errors') != []:
        raise ValueError('A formal independent energy audit PASS is required')
    if audit.get('mode') != 'full' or Path(audit.get('root', '')).resolve() != root:
        raise ValueError('Independent PASS scope is not this full energy run')
    if audit.get('audited_completed_cells') != 1200:
        raise ValueError('Independent audit must cover all 1200 original cells')
    for name in ('manifest', 'completion'):
        path = root / f'{name}.json'
        if audit.get(f'{name}_sha256') != digest(path):
            raise ValueError(f'Independent PASS does not bind current {name}')
    manifest, completion = read(root / 'manifest.json'), read(root / 'completion.json')
    if completion.get('status') != 'complete' or completion.get('completed_cells') != 1200:
        raise ValueError('Measured energy run is incomplete')
    if manifest.get('seeds') != [1, 100] or manifest.get('scenarios') != list(SCENARIOS):
        raise ValueError('Full original scenario/seed scope changed')
    if manifest.get('methods') != list(METHODS) or manifest.get('expected_cells') != 1200:
        raise ValueError('Original three-method/full-cell scope changed')
    if manifest.get('recalibration') is not False:
        raise ValueError('Only frozen-policy energy screening is authorized here')
    for key, expected in (('simulator_attempts', 1200), ('energy_profiles', 9600),
                          ('gate_records', 144000), ('model_requests', 0),
                          ('simulation_cache_hits', 0)):
        if completion.get(key) != expected:
            raise ValueError(f'Complete energy accounting differs: {key}')
    if not completion.get('all_original_metrics_exact'):
        raise ValueError('Original service metrics are not confirmed exact')
    if manifest['source_hashes_before'] != completion['source_hashes_after']:
        raise ValueError('Source hashes changed within the energy run')
    if manifest['input_hashes_before'] != completion['input_hashes_after']:
        raise ValueError('Input hashes changed within the energy run')
    # Current source hashes are deliberately not required to remain unedited
    # after a completed/frozen run; the audit binds its historical artifacts.
    cells = completion['cell_hashes']
    if len(cells) != 1200 or audit.get('cell_hashes') != cells:
        raise ValueError('Independent PASS does not bind all current cell hashes')
    for relative, wanted in cells.items():
        if digest(resolve_relative(root, relative)) != wanted:
            raise ValueError(f'Current energy cell differs from independently audited bytes: {relative}')
    cfg = manifest['config']
    expected_grid = {
        'motion_interpretations': ['mean_speed', 'travel_then_hover'],
        'propulsion_scales': [1.0, 1.25], 'constant_nonpropulsive_w': [50.0, 100.0],
        'capacity_multipliers': [.75, 1.0, 1.25, 1.5, 2.0],
        'reserve_fractions': [0.0, .1, .2],
    }
    if any(cfg.get(k) != v for k, v in expected_grid.items()):
        raise ValueError('Analysis requires the complete predeclared 120-condition grid')
    return manifest, completion, audit


def profile_id(index, motion, beta, auxiliary):
    return {'profile_index': index, 'motion': motion,
            'propulsion_scale': beta, 'constant_nonpropulsive_w': auxiliary}


def write_csv(path, rows, fields):
    with path.open('x', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def flatten_stat(target, prefix, values):
    for key, value in stats(values).items():
        target[f'{prefix}_{key}'] = value


def latex_table(rows, eligible):
    low_all_zero = all(row['joint_by_capacity_r_0_1'][str(alpha)] == 0
                       for row in rows for alpha in (.75, 1.0))
    capacity_columns = (1.25, 1.5, 2.0) if low_all_zero else (.75, 1.0, 1.25, 1.5, 2.0)
    lines = [r'\begin{table*}[t]', r'\centering', r'\footnotesize',
             r'\caption{Fixed-policy model-relative energy sensitivity at the predeclared reserve fraction $r=0.1$. All eight profiles are included. Capacity requirements and joint service--energy counts describe 1,200 fixed trajectories from 400 matched historical instances across three methods, not new independent effectiveness observations.}',
             r'\label{tab:original-fixed-policy-energy}',
             r'\setlength{\tabcolsep}{4pt}',
             r'\begin{tabular}{l' + 'r' * (4 + len(capacity_columns)) + '}', r'\hline',
             r'Motion & $\beta$ & $P_{\rm aux}$ (W) & Required Wh: median [min,max] & p95 Wh & '
             + ' & '.join(r'Joint: $\alpha=' + f'{alpha:g}' + '$' for alpha in capacity_columns) + r' \\',
             r'\hline']
    for row in rows:
        motion = 'Mean speed' if row['motion'] == 'mean_speed' else 'Travel then hover'
        values = [motion, f"{row['propulsion_scale']:g}", f"{row['constant_nonpropulsive_w']:g}",
                  f"{row['break_even_wh_median']:.2f} [{row['break_even_wh_min']:.2f},{row['break_even_wh_max']:.2f}]",
                  f"{row['break_even_wh_p95']:.2f}",
                  *(str(row['joint_by_capacity_r_0_1'][str(alpha)]) for alpha in capacity_columns)]
        lines.append(' & '.join(values) + r' \\')
    low_note = (r' At $r=0.1$, joint counts at $\alpha=0.75$ and $\alpha=1$ are zero for every profile.'
                if low_all_zero else '')
    lines.extend([r'\hline', r'\end{tabular}', r'\par\smallskip',
                  r'\parbox{0.98\textwidth}{\scriptsize The unchanged service-eligible total is '
                  + str(eligible) + r'/1,200.' + low_note
                  + r' $\beta\in\{1,1.25\}$ scales the entire modeled propulsion power; $P_{\rm aux}\in\{50,100\}$ W is an assumed constant non-propulsive budget. Neither is a hardware bound. Capacity is $\alpha E_{\rm ref}$, $\alpha\in\{0.75,1,1.25,1.5,2\}$, and $r\in\{0,0.1,0.2\}$. All 120 conditions remain in the companion CSV. The ideal horizontal model excludes takeoff/landing, acceleration and wind; screening preserves original service trajectories and does not implement online return-to-home.}',
                  r'\end{table*}', ''])
    return '\n'.join(lines)


def report_markdown(summary):
    lines = ['# 固定原策略的能量与返航验收：完整敏感性汇总', '',
             '这是独立审计通过后的固定轨迹分析，未新增模型请求、重新校准或重新选优。原服务通过结果保持，能量门作为新增、模型相对的验收条件单独报告。', '',
             f"范围：{summary['scope']['cells']} 个固定策略（400 个历史实例 × 三组合），{summary['scope']['profiles_per_cell']} 个预定功率/运动 profile，每个 profile 的五容量 × 三 reserve；合计 {summary['scope']['gate_records']} 条门记录。重复方法与预算条件不是新的独立效果观测。", '',
             '容量基准是执行前固定的 230 秒悬停推进功率加 50 W 负载；容量与 reserve 网格不代表电池型号或操作建议。边界包含初始点、每移动/悬停连接点、槽末端及终端同高度直线归航。', '',
             '下表固定展示 r=0.1 的连续可用容量需求，并包括全部八个预定 profile 及五档容量的联合通过计数。这里的 1,200 是固定轨迹计数。', '',
             '| 运动解释 | 推进倍率 | 负载 W | 需求 Wh min / median / p95 / max | α=.75 | α=1 | α=1.25 | α=1.5 | α=2 |',
             '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for row in summary['main_display_all_profiles_r_0_1']:
        motion = '每槽平均速度' if row['motion'] == 'mean_speed' else '42 m/s 移动后悬停'
        values = ' / '.join(f"{row[f'break_even_wh_{key}']:.3f}" for key in ('min', 'median', 'p95', 'max'))
        counts = ' | '.join(str(row['joint_by_capacity_r_0_1'][str(alpha)]) for alpha in (.75, 1.0, 1.25, 1.5, 2.0))
        lines.append(f"| {motion} | {row['propulsion_scale']:g} | {row['constant_nonpropulsive_w']:g} | {values} | {counts} |")
    lines.extend(['', '原服务通过计数：', '',
                  '| 场景 | Compact | Compact + expert | Compact + cached LLM |',
                  '|---|---:|---:|---:|'])
    for scenario in SCENARIOS:
        counts = [summary['unchanged_service_counts'][scenario][method]['passed'] for method in METHODS]
        lines.append(f"| {scenario} | " + ' | '.join(f'{n}/100' for n in counts) + ' |')
    findings = summary['conditional_admission_findings']
    lines.extend(['',
                  f"全网格中，有 {findings['conditions_rejecting_any_service_pass']}/120 个条件至少拒绝一条原本服务通过的轨迹；每条件服务通过但能量拒绝计数范围为 {findings['rejected_service_pass_min']}–{findings['rejected_service_pass_max']} / {summary['scope']['unchanged_service_eligible_total']}。这说明服务证据与模型电量可容纳性需要分别检查。", '',
                  f"有 {findings['conditions_retaining_all_service_pass']}/120 个条件保留全部原服务通过轨迹；完整条件清单见 summary.json 与 gate_condition_totals.csv。服务未通过的轨迹即使能量通过，也不计联合通过。", '',
                  '上述计数只是预定预算范围内的条件变化。不能把高容量格的全部通过推广到其他容量，也不能把低容量格的拒绝当作方法整体无效。均未按某方法更有利来挑选配置。', '',
                  '全部 120 条件 × 四场景 × 三方法的计数在 gate_summary.csv（1,440 行）；三种 reserve 的连续容量需求在 profile_requirement_summary.csv，逐轨迹数据分别保存在 gate_records.csv 和 profile_requirement_records.csv。J 与 Wh 都保留；min、median、p95、max 采用 R type 7 分位数。', '',
                  '边界：旋翼文献参数、每槽运动的两种解释、全时 50/100 W 非推进负载和 1/1.25 推进倍率均为声明的理想模型/敏感性条件。没有机型或电池标定，没有起降、风、加速度、障碍物或实际 API/协议 duty 电量测量。结果不能称实机安全、在线低电量返航闭环或新能量感知策略；原策略未被能量反馈改变。', '',
                  '独立审计及 manifest/completion/全部 cell 的 SHA-256 已绑定到 summary.json。分析本身调用 simulator/API 均为零。', ''])
    return '\n'.join(lines)


def run(root, audit_path, out):
    root, audit_path, out = root.resolve(), audit_path.resolve(), out.resolve()
    if out.exists() or out.is_relative_to(root):
        raise ValueError('Use a fresh analysis directory outside the measured run')
    manifest, completion, audit = require_audited(root, audit_path)
    cfg = manifest['config']
    profile_grid = list(itertools.product(cfg['motion_interpretations'], cfg['propulsion_scales'],
                                         cfg['constant_nonpropulsive_w']))
    original_inputs = {str(root / 'manifest.json'): digest(root / 'manifest.json'),
                       str(root / 'completion.json'): digest(root / 'completion.json'),
                       str(audit_path): digest(audit_path)}
    condition_counts, total_counts = {}, {}
    requirements, total_requirements = {}, {}
    observed_service = {(s, m): [] for s in SCENARIOS for m in METHODS}
    out.mkdir(parents=True)
    gate_fields = ['scenario', 'seed', 'method', 'cell_sha256', 'policy_hash', 'profile_index',
                   'motion', 'propulsion_scale', 'constant_nonpropulsive_w',
                   'capacity_multiplier', 'reserve_fraction', 'capacity_j', 'capacity_wh',
                   'service_pass', 'energy_pass', 'joint_pass', 'rejected_service_pass',
                   'minimum_return_margin_j', 'remaining_after_return_j', 'end_reserve_margin_j',
                   'first_violation_time_s', 'first_violation_boundary',
                   'break_even_capacity_j', 'break_even_capacity_wh']
    requirement_fields = ['scenario', 'seed', 'method', 'cell_sha256', 'policy_hash',
                          'profile_index', 'motion', 'propulsion_scale', 'constant_nonpropulsive_w',
                          'reserve_fraction', 'service_pass', 'reference_energy_j',
                          'mission_flight_j', 'mission_nonpropulsive_j', 'mission_used_j',
                          'terminal_return_j', 'terminal_return_seconds', 'energy_with_return_j',
                          'required_peak_j', 'required_peak_time_s', 'break_even_capacity_j',
                          'break_even_capacity_wh', 'break_even_capacity_multiplier']
    processed, gate_rows, requirement_rows = 0, 0, 0
    try:
        with (out / 'gate_records.csv').open('x', encoding='utf-8', newline='') as gstream, \
                (out / 'profile_requirement_records.csv').open('x', encoding='utf-8', newline='') as pstream:
            gw, pw = csv.DictWriter(gstream, fieldnames=gate_fields), csv.DictWriter(pstream, fieldnames=requirement_fields)
            gw.writeheader(); pw.writeheader()
            for scenario, seed, method in itertools.product(SCENARIOS, range(1, 101), METHODS):
                filename = f'{scenario}__{seed:03d}__{method}.json'
                path = root / 'cells' / filename
                relative = next((key for key in completion['cell_hashes'] if key.replace('\\', '/') == f'cells/{filename}'), None)
                if relative is None:
                    raise ValueError(f'Expected cell absent: {filename}')
                wanted = completion['cell_hashes'][relative]
                # Recheck as consumed, after formal audit prerequisite validation.
                if digest(path) != wanted:
                    raise ValueError('Cell changed while consuming audited data')
                cell = read(path)
                if (cell['scenario'], cell['seed'], cell['method']) != (scenario, seed, method):
                    raise ValueError('Consumed cell identity differs')
                service = cell['original_metrics']['passed_contract']
                if type(service) is not bool or cell['simulation']['metrics'] != cell['original_metrics']:
                    raise ValueError('Original service result changed')
                observed_service[scenario, method].append(service)
                energy = cell['energy']
                ref = number(energy['reference_energy_j'], 'reference_energy_j')
                if len(energy['profiles']) != 8 or len(energy['gates']) != 120:
                    raise ValueError('Profile/gate scope is incomplete')
                ids = {'scenario': scenario, 'seed': seed, 'method': method,
                       'cell_sha256': wanted, 'policy_hash': cell['policy_hash']}
                for index, (motion, beta, auxiliary) in enumerate(profile_grid):
                    profile = energy['profiles'][index]
                    identity = profile_id(index, motion, beta, auxiliary)
                    if any(profile[k] != v for k, v in identity.items()):
                        raise ValueError('Profile identity/order differs')
                    peak = number(profile['required_peak_j'], 'required_peak_j')
                    for reserve in cfg['reserve_fractions']:
                        required = peak / (1 - reserve)
                        row = {**ids, **identity, 'reserve_fraction': reserve,
                               'service_pass': service, 'reference_energy_j': ref,
                               **{key: number(profile[key], key) for key in
                                  ('mission_flight_j', 'mission_nonpropulsive_j', 'mission_used_j',
                                   'terminal_return_j', 'terminal_return_seconds', 'energy_with_return_j',
                                   'required_peak_j', 'required_peak_time_s')},
                               'break_even_capacity_j': required,
                               'break_even_capacity_wh': required / 3600,
                               'break_even_capacity_multiplier': required / ref}
                        pw.writerow(row); requirement_rows += 1
                        requirements.setdefault((scenario, method, index, reserve), []).append(required)
                        total_requirements.setdefault((index, reserve), []).append(required)
                for gate in energy['gates']:
                    index = gate['profile_index']
                    if not 0 <= index < len(profile_grid):
                        raise ValueError('Unknown profile in gate')
                    motion, beta, auxiliary = profile_grid[index]
                    alpha, reserve = gate['capacity_multiplier'], gate['reserve_fraction']
                    if gate['service_pass'] is not service:
                        raise ValueError('Gate changed original service flag')
                    ident = profile_id(index, motion, beta, auxiliary)
                    row = {**ids, **ident, **{key: gate[key] for key in gate_fields if key in gate},
                           'rejected_service_pass': service and not gate['energy_pass']}
                    gw.writerow(row); gate_rows += 1
                    key = scenario, method, index, alpha, reserve
                    add_counts(condition_counts.setdefault(key, blank_counts()), service, gate['energy_pass'], gate['joint_pass'])
                    add_counts(total_counts.setdefault((index, alpha, reserve), blank_counts()), service, gate['energy_pass'], gate['joint_pass'])
                processed += 1
                if processed % 300 == 0:
                    print(f'ENERGY_ANALYSIS_CELLS: {processed}/1200', flush=True)
        if processed != 1200 or gate_rows != 144000 or requirement_rows != 28800:
            raise ValueError('Complete data row counts differ')
        condition_rows, total_rows, requirement_summary, requirement_totals = [], [], [], []
        for scenario, method, index, alpha, reserve in itertools.product(
                SCENARIOS, METHODS, range(8), cfg['capacity_multipliers'], cfg['reserve_fractions']):
            counts = condition_counts[scenario, method, index, alpha, reserve]
            if counts['n'] != 100:
                raise ValueError('Condition summary is missing scenario/method seeds')
            identity = profile_id(index, *profile_grid[index])
            condition_rows.append({'scenario': scenario, 'method': method, **identity,
                                   'capacity_multiplier': alpha, 'reserve_fraction': reserve, **counts})
        for index, alpha, reserve in itertools.product(range(8), cfg['capacity_multipliers'], cfg['reserve_fractions']):
            counts = total_counts[index, alpha, reserve]
            if counts['n'] != 1200:
                raise ValueError('Pooled condition summary missing fixed trajectories')
            total_rows.append({**profile_id(index, *profile_grid[index]),
                               'capacity_multiplier': alpha, 'reserve_fraction': reserve, **counts})
        for scenario, method, index, reserve in itertools.product(SCENARIOS, METHODS, range(8), cfg['reserve_fractions']):
            values = requirements[scenario, method, index, reserve]
            row = {'scenario': scenario, 'method': method, **profile_id(index, *profile_grid[index]),
                   'reserve_fraction': reserve}
            flatten_stat(row, 'break_even_j', values)
            flatten_stat(row, 'break_even_wh', [v / 3600 for v in values])
            requirement_summary.append(row)
        for index, reserve in itertools.product(range(8), cfg['reserve_fractions']):
            values = total_requirements[index, reserve]
            row = {**profile_id(index, *profile_grid[index]), 'reserve_fraction': reserve}
            flatten_stat(row, 'break_even_j', values)
            flatten_stat(row, 'break_even_wh', [v / 3600 for v in values])
            requirement_totals.append(row)
        service_counts = {s: {m: {'n': len(observed_service[s, m]), 'passed': sum(observed_service[s, m]),
                                  'failed': len(observed_service[s, m])-sum(observed_service[s, m])}
                              for m in METHODS} for s in SCENARIOS}
        eligible = sum(sum(flags) for flags in observed_service.values())
        displays = []
        for index in range(8):
            row = next(dict(v) for v in requirement_totals if v['profile_index'] == index and v['reserve_fraction'] == .1)
            counts = [v['joint_pass'] for v in total_rows if v['profile_index'] == index]
            row.update(joint_count_min=min(counts), joint_count_max=max(counts))
            row['joint_by_capacity_r_0_1'] = {str(alpha): total_counts[index, alpha, .1]['joint_pass']
                                             for alpha in cfg['capacity_multipliers']}
            displays.append(row)
        summary = {
            'version': 'audited-original-energy-summary-1', 'status': 'complete',
            'created_utc': datetime.now(timezone.utc).isoformat(),
            'scope': {'cells': 1200, 'historical_tasks': 400, 'methods': list(METHODS),
                      'profiles_per_cell': 8, 'conditions_per_cell': 120,
                      'gate_records': gate_rows, 'profile_requirement_records': requirement_rows,
                      'unchanged_service_eligible_total': eligible, 'new_model_requests': 0,
                      'analysis_simulator_calls': 0, 'analysis_api_calls': 0,
                      'new_independent_effectiveness_observations': 0},
            'quantile_method': 'R type 7; sorted index (n-1)*q, linear interpolation',
            'full_predeclared_config': cfg, 'reference_energy_j': ref,
            'reference_energy_wh': ref / 3600, 'input_hashes': original_inputs,
            'audited_cell_hashes': completion['cell_hashes'],
            'independent_audit': {'path': str(audit_path), 'status': audit['status'],
                                  'assertions': audit.get('assertions')},
            'unchanged_service_counts': service_counts,
            'gate_summary': condition_rows, 'gate_condition_totals': total_rows,
            'profile_requirement_summary': requirement_summary,
            'profile_requirement_totals': requirement_totals,
            'main_display_all_profiles_r_0_1': displays,
            'conditional_admission_findings': {
                'conditions_rejecting_any_service_pass': sum(row['rejected_service_pass'] > 0 for row in total_rows),
                'conditions_retaining_all_service_pass': sum(row['joint_pass'] == eligible for row in total_rows),
                'rejected_service_pass_min': min(row['rejected_service_pass'] for row in total_rows),
                'rejected_service_pass_max': max(row['rejected_service_pass'] for row in total_rows),
                'conditions_retaining_all_service_pass_full_list': [row for row in total_rows if row['joint_pass'] == eligible],
                'conditions_rejecting_any_service_pass_full_list': [row for row in total_rows if row['rejected_service_pass'] > 0]},
            'limits': ('Model-relative fixed-policy admission, not hardware battery safety or online RTH; '
                       'no recalibration or strategy feedback. All predeclared conditions preserved; '
                       'pooled 1200 trajectories repeat the same 400 tasks across methods. '
                       'Ancillary loads/power scaling and budget grid are assumptions, not validated bounds.')}
        for filename, rows in (('gate_summary.csv', condition_rows), ('gate_condition_totals.csv', total_rows),
                               ('profile_requirement_summary.csv', requirement_summary),
                               ('profile_requirement_totals.csv', requirement_totals)):
            write_csv(out / filename, rows, list(rows[0]))
        (out / 'findings.md').write_text(report_markdown(summary), encoding='utf-8')
        (out / 'original_fixed_policy_energy_table.tex').write_text(latex_table(displays, eligible), encoding='utf-8')
        after = {path: digest(path) for path in original_inputs}
        if after != original_inputs:
            raise ValueError('Audit/manifest/completion changed during analysis')
        summary['output_hashes'] = {str(path.relative_to(out)): digest(path) for path in sorted(out.iterdir()) if path.is_file()}
        summary['analyzer_sha256'] = digest(Path(__file__))
        with (out / 'summary.json').open('x', encoding='utf-8') as stream:
            json.dump(summary, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write('\n')
        print(f'ENERGY_ANALYSIS_FILE: {out / "summary.json"}', flush=True)
        return summary
    except Exception as error:
        with (out / 'analysis_failure.json').open('x', encoding='utf-8') as stream:
            json.dump({'status': 'failed_preserved', 'error_type': type(error).__name__,
                       'message': str(error), 'processed_cells': processed,
                       'gate_records_written': gate_rows, 'requirement_records_written': requirement_rows},
                      stream, ensure_ascii=False, indent=2)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--audit', type=Path, default=AUDIT)
    parser.add_argument('--out', type=Path, default=OUT)
    args = parser.parse_args()
    run(args.root, args.audit, args.out)
