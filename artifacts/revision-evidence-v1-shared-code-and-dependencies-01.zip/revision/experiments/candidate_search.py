"""Public finite-grid candidate search with construction-only admission.

No scenario labels are accepted by the proposal interface. All methods use the
same numerical grids, semantic deduplication and construction ranking. The full
enumeration is a finite-grid reference, not a global optimum or a test-set oracle.
Cached proposals are exact historical prompt replays; this module has no client,
network call, synthetic fallback, or capability to make new model inferences.
"""
from __future__ import annotations

import ast
import copy
import hashlib
import json
import math
import random
from functools import lru_cache
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence


LEGACY_DIR = Path(__file__).resolve().parent / "legacy"
CLUSTERS = ("west_cluster", "east_hotspot", "north_cluster")
MODES = ("route_dwell", "protocol_trigger", "full_casp")
METHODS = (
    "nominal", "robust_fixed", "scripted_mixed", "compact_rules",
    "compact_plus_mixed", "compact_plus_cached_llm", "enumeration_budget",
    "enumeration_full", "random_budget", "cached_llm_only",
)
EVIDENCE_FIELDS = ("peak_backlog", "peak_blackout", "peak_link_stress")
# Same route-major, target-dwell-major, trigger-minor order as the legacy grid.
NUMERICAL_GRIDS = {
    "route_dwell": ((16, 22), ((3, 12, 12), (6, 12, 12), (3, 16, 12))),
    "protocol_trigger": ((10, 14), ((4, 12, 12), (3, 10, 16), (4, 10, 16))),
    "full_casp": ((16, 22, 28), ((3, 10, 16), (3, 16, 12), (6, 12, 12),
                                   (4, 12, 12), (3, 12, 12))),
}
# Only keys read by the route executor, plus controller type, define semantics.
POLICY_FIELDS = (
    "controller", "route", "protocol_mode", "local_triggers",
    "min_protocol_hold_slots",
)
RANKING_RULE = (
    "lexicographic maximum: all construction replays service-pass; minimum QSR; "
    "negative maximum recovery; negative maximum blackout; mean QSR; negative "
    "mean recovery; negative mean blackout. Exact ties retain first candidate."
)


@lru_cache(maxsize=4)
def _legacy_helpers(legacy_dir: str) -> dict[str, Any]:
    """Load only named pure definitions, without importing live-model runners.

    This preserves historical route templates, rules, JSON parsing and exact
    prompt formatting. Neither module imports nor their main functions execute.
    """
    directory = Path(legacy_dir)
    names = {
        "run_uav_iot_workflow_experiment.py": {"cluster_centroid", "route_policy"},
        "contingency_suite.py": {"_trigger", "_nominal"},
        "mixed_structural_suite.py": {
            "_target_from_backlog", "_target_from_blackout", "scripted_structure",
            "_route_templates",
        },
        "run_mixed_structural_llm.py": {"_rounded_evidence"},
        "llm_repair_agent.py": {"extract_json"},
    }
    namespace: dict[str, Any] = {"Any": Any, "json": json, "CLUSTER_IDS": list(CLUSTERS)}
    for filename, wanted in names.items():
        path = directory / filename
        tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        selected = []
        found = set()
        for node in tree.body:
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id in {"CLUSTERS", "SYSTEM"}:
                        namespace[target.id] = ast.literal_eval(node.value)
            if isinstance(node, ast.FunctionDef) and node.name in wanted:
                selected.append(node)
                found.add(node.name)
        if found != wanted:
            raise ValueError(f"Missing legacy pure definitions in {filename}: {wanted - found}")
        exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), "exec"), namespace)
    if [item["id"] for item in namespace["CLUSTERS"]] != list(CLUSTERS):
        raise ValueError("Legacy cluster order changed; prompt/grid compatibility needs review")
    return namespace


def public_evidence(evidence: Mapping[str, Any]) -> dict[str, dict[str, float | int]]:
    """Whitelist observable fields; ignore all labels and extraneous metadata."""
    result = {}
    for cluster in CLUSTERS:
        values = {}
        for field in EVIDENCE_FIELDS:
            value = evidence[cluster][field]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError(f"Non-numeric evidence: {cluster}.{field}")
            if not math.isfinite(value) or value < 0:
                raise ValueError(f"Invalid evidence: {cluster}.{field}")
            values[field] = value
        result[cluster] = values
    return result


def _normalize_numbers(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _normalize_numbers(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_normalize_numbers(item) for item in value]
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Policy cannot contain non-finite numbers")
        return int(value) if value.is_integer() else value
    return value


def policy_semantic_hash(policy: Mapping[str, Any]) -> str:
    """SHA256 of executable policy content; names and training notes are excluded."""
    semantic = {key: copy.deepcopy(policy.get(key)) for key in POLICY_FIELDS}
    semantic["controller"] = semantic["controller"] or "route"
    semantic["min_protocol_hold_slots"] = semantic["min_protocol_hold_slots"] or 0
    semantic["local_triggers"] = semantic["local_triggers"] or []
    if isinstance(semantic["local_triggers"], dict):
        semantic["local_triggers"] = [semantic["local_triggers"]]
    # Trigger order is preserved: it may affect simultaneous-trigger dispatch.
    payload = json.dumps(_normalize_numbers(semantic), sort_keys=True,
                         separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def cached_llm_selection(
    evidence: Mapping[str, Any], *, legacy_dir: str | Path = LEGACY_DIR,
    cache_path: str | Path | None = None, provider: str = "openai", model: str = "qwen-plus",
) -> dict[str, Any]:
    """Return only a valid exact historical cache hit, never a fallback proposal."""
    directory = Path(legacy_dir).resolve()
    helpers = _legacy_helpers(str(directory))
    clean = public_evidence(evidence)
    system = helpers["SYSTEM"]
    user = ("Per-cluster evidence from the nominal failed run:\n"
            + json.dumps(helpers["_rounded_evidence"](clean), indent=2)
            + "\n\nReturn the target cluster and repair mode JSON.")
    full_hash = hashlib.sha256(
        f"{provider}\x00{model}\x00{system}\x00{user}".encode("utf-8")
    ).hexdigest()
    path = Path(cache_path) if cache_path is not None else directory / "results/mixed_structural_llm_cache.jsonl"
    result: dict[str, Any] = {
        "status": "missing", "reason": "exact_prompt_key_not_found", "cache_key": full_hash[:32],
        "prompt_sha256": full_hash, "provider": provider, "model": model,
        "token_usage": {}, "usage": {}, "cache_path": str(path),
        "inference_mode": "historical_cache_replay", "new_model_calls": 0,
        "target": None, "mode": None,
    }
    if not path.is_file():
        result["reason"] = "cache_file_not_found"
        return result
    match = None
    # Last exact-key record wins, matching the original CachingClient behavior.
    for line_number, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(record, dict) and record.get("key") == result["cache_key"]:
            match = (line_number, record)
    if match is None:
        return result
    line_number, record = match
    result.update({"cache_line": line_number, "record_mode": record.get("mode")})
    if (record.get("provider") != provider or record.get("model") != model
            or record.get("mode") not in {"live", "replay"}
            or provider.lower().startswith(("offline", "synthetic"))):
        result.update(status="invalid", reason="unverified_or_synthetic_cache_provenance")
        return result
    if not isinstance(record.get("text"), str):
        result.update(status="invalid", reason="cache_response_not_text")
        return result
    action = helpers["extract_json"](record["text"])
    if (not isinstance(action, dict) or action.get("target_cluster") not in CLUSTERS
            or action.get("repair_mode") not in MODES):
        result.update(status="invalid", reason="invalid_cached_structure_no_fallback")
        return result
    usage = record.get("usage", {})
    result.update(status="hit", reason="exact_historical_prompt_match",
                  target=action["target_cluster"], mode=action["repair_mode"],
                  target_cluster=action["target_cluster"], repair_mode=action["repair_mode"],
                  token_usage=usage, usage=usage,
                  rationale=str(action.get("rationale", "")))
    return result


def structure_candidates(target: str, mode: str, *, legacy_dir: str | Path = LEGACY_DIR,
                         source: str = "finite_grid") -> list[dict[str, Any]]:
    """Every numerical grid entry for one public structure; no simulation."""
    if target not in CLUSTERS or mode not in MODES:
        raise ValueError("Unknown public target or repair mode")
    helpers = _legacy_helpers(str(Path(legacy_dir).resolve()))
    dwells, triggers = NUMERICAL_GRIDS[mode]
    candidates = []
    for route_index, route in enumerate(helpers["_route_templates"](target, mode)):
        for target_dwell in dwells:
            for trigger_dwell, blackout_threshold, cooldown in triggers:
                index = len(candidates)
                policy = helpers["route_policy"](
                    f"mixed_{mode}", route,
                    [target_dwell if cluster == target else 8 for cluster in route], "degraded_aware")
                policy["min_protocol_hold_slots"] = 4
                policy["local_triggers"] = [helpers["_trigger"](
                    target, b=blackout_threshold, dwell=trigger_dwell, cooldown=cooldown)]
                metadata = {
                    "structure": f"{target}:{mode}", "target": target, "mode": mode,
                    "parameter_index": index, "source": source, "route_index": route_index,
                    "target_dwell": target_dwell, "trigger_dwell": trigger_dwell,
                    "blackout_threshold": blackout_threshold, "cooldown": cooldown,
                }
                candidates.append({
                    "policy": policy, "policy_hash": policy_semantic_hash(policy),
                    **metadata, "sources": [source], "structure_aliases": [metadata],
                })
    return candidates


def _round_robin_deduplicate(groups: Sequence[Sequence[dict[str, Any]]]) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    by_hash: dict[str, dict[str, Any]] = {}
    for index in range(max((len(group) for group in groups), default=0)):
        for group in groups:
            if index >= len(group):
                continue
            entry = copy.deepcopy(group[index])
            old = by_hash.get(entry["policy_hash"])
            if old is not None:
                old["sources"] = list(dict.fromkeys(old["sources"] + entry["sources"]))
                for alias in entry["structure_aliases"]:
                    if alias not in old["structure_aliases"]:
                        old["structure_aliases"].append(alias)
                continue
            entry["candidate_index"] = len(candidates)
            candidates.append(entry)
            by_hash[entry["policy_hash"]] = entry
    return candidates


def generate_candidates(
    method: str, evidence: Mapping[str, Any], *, legacy_dir: str | Path = LEGACY_DIR,
    cache_path: str | Path | None = None, random_seed: int = 0,
    provider: str = "openai", model: str = "qwen-plus",
) -> dict[str, Any]:
    """Return an ordered, deduplicated candidate plan using only public evidence.

    On cache miss/invalid, compact candidates are kept for inspection but the
    plan is marked unavailable. Callers must not report it as an LLM result.
    Budgeted methods share the same construction call budget at selection time.
    """
    if method not in METHODS:
        raise ValueError(f"Unknown method: {method}")
    directory = Path(legacy_dir).resolve()
    helpers = _legacy_helpers(str(directory))
    plan: dict[str, Any] = {
        "method": method, "status": "ready", "cache": {"status": "not_applicable"}, "candidates": [],
        "candidate_order": "round_robin_structure_then_parameter_index",
        "grid_scope": "legacy_finite_grid", "ranking_rule": RANKING_RULE,
        "budget_exempt": method == "enumeration_full", "new_model_calls": 0,
    }
    if method in {"nominal", "robust_fixed"}:
        policy = (helpers["_nominal"]() if method == "nominal" else json.loads(
            (directory / "results/strong_baseline_robust_policy.json").read_text(encoding="utf-8-sig")))
        entry = {"policy": policy, "policy_hash": policy_semantic_hash(policy),
                 "structure": method, "target": None, "mode": None, "parameter_index": 0,
                 "candidate_index": 0, "sources": [method], "structure_aliases": []}
        plan["candidates"] = [entry]
        plan["raw_grid_entries"] = 1
        return plan
    clean = public_evidence(evidence)
    compact = [
        (helpers["_target_from_backlog"](clean), "route_dwell", "max_backlog_rule"),
        (helpers["_target_from_blackout"](clean), "protocol_trigger", "max_blackout_rule"),
        ("east_hotspot", "full_casp", "fixed_east_rule"),
    ]
    mixed_target, mixed_mode = helpers["scripted_structure"](clean)
    mixed = (mixed_target, mixed_mode, "mixed_signal_rule")
    if method == "scripted_mixed":
        structures = [mixed]
    elif method == "compact_rules":
        structures = compact
    elif method == "compact_plus_mixed":
        structures = compact + [mixed]
    elif method in {"compact_plus_cached_llm", "cached_llm_only"}:
        cache = cached_llm_selection(clean, legacy_dir=directory, cache_path=cache_path,
                                     provider=provider, model=model)
        plan["cache"] = cache
        structures = list(compact) if method == "compact_plus_cached_llm" else []
        if cache["status"] == "hit":
            structures.append((cache["target"], cache["mode"], "historical_cached_llm"))
        else:
            plan["status"] = "missing" if cache["status"] == "missing" else "invalid"
            plan["unavailable_reason"] = cache["reason"]
    else:
        structures = [(target, mode, "finite_grid") for target in CLUSTERS for mode in MODES]
    groups = [structure_candidates(target, mode, legacy_dir=directory, source=source)
              for target, mode, source in structures]
    if method == "random_budget":
        rng = random.Random(random_seed)
        rng.shuffle(groups)
        for group in groups:
            rng.shuffle(group)
        plan["candidate_order"] = "seeded_structure_and_parameter_shuffle_round_robin"
        plan["random_seed"] = random_seed
    plan["raw_grid_entries"] = sum(map(len, groups))
    plan["candidates"] = _round_robin_deduplicate(groups)
    plan["structures"] = [{"target": target, "mode": mode, "source": source}
                          for target, mode, source in structures]
    return plan


def _construction_summary(metrics: Sequence[dict[str, Any]]) -> tuple[dict[str, Any], tuple]:
    count = len(metrics)
    summary = {
        "all_service_pass": all(item["service_pass"] for item in metrics),
        "service_pass_count": sum(item["service_pass"] for item in metrics),
        "construction_replays": count,
        "min_qsr": min(item["qsr"] for item in metrics),
        "max_recovery_time": max(item["recovery_time"] for item in metrics),
        "max_blackout": max(item["max_blackout"] for item in metrics),
        "mean_qsr": sum(item["qsr"] for item in metrics) / count,
        "mean_recovery_time": sum(item["recovery_time"] for item in metrics) / count,
        "mean_blackout": sum(item["max_blackout"] for item in metrics) / count,
    }
    rank = (int(summary["all_service_pass"]), summary["min_qsr"],
            -summary["max_recovery_time"], -summary["max_blackout"],
            summary["mean_qsr"], -summary["mean_recovery_time"], -summary["mean_blackout"])
    return summary, rank


def select_candidate(
    candidates: Iterable[dict[str, Any]], construction_scenarios: Sequence[Any],
    budget: int | None, simulate_fn: Callable[[Any, dict[str, Any]], dict[str, Any]],
) -> dict[str, Any]:
    """Evaluate complete candidates under one call budget, including all failures.

    One candidate costs exactly len(construction_scenarios) simulator calls.
    A caller's shared evidence-probe cost must be subtracted before passing the
    remaining budget. None is reserved for the separately reported full grid.
    No evaluation/held-out scenarios or ground-truth labels enter ranking.
    """
    scenarios = list(construction_scenarios)
    if not scenarios:
        raise ValueError("At least one construction replay is required")
    if budget is not None and (isinstance(budget, bool) or not isinstance(budget, int) or budget < 0):
        raise ValueError("Budget must be a non-negative integer number of calls, or None")
    ledger = []
    curve = []
    calls = 0
    first_pass_calls = None
    best = None
    best_rank = None
    seen: set[str] = set()
    skipped_duplicates = 0
    stopped_for_budget = False
    for candidate in candidates:
        semantic_hash = policy_semantic_hash(candidate["policy"])
        if candidate.get("policy_hash", semantic_hash) != semantic_hash:
            raise ValueError("Candidate policy hash does not match executable content")
        if semantic_hash in seen:
            skipped_duplicates += 1
            continue
        if budget is not None and calls + len(scenarios) > budget:
            stopped_for_budget = True
            break
        seen.add(semantic_hash)
        replay_records = []
        valid_metrics = []
        for replay_index, scenario in enumerate(scenarios):
            calls += 1
            try:
                replay = simulate_fn(scenario, copy.deepcopy(candidate["policy"]))
                raw = replay["metrics"]
                passed = raw["service_pass"]
                if not isinstance(passed, bool):
                    raise ValueError("service_pass must be a boolean")
                measured = {key: float(raw[key]) for key in ("qsr", "recovery_time", "max_blackout")}
                if any(not math.isfinite(value) for value in measured.values()):
                    raise ValueError("Non-finite construction metrics")
                measured["service_pass"] = passed
                for key in ("qsr_pass", "blackout_pass", "recovery_pass", "recovered",
                            "recovery_required", "recovery_censored", "structural_coverage_pass",
                            "energy_proxy", "pdr", "p95_latency"):
                    if key in raw:
                        measured[key] = copy.deepcopy(raw[key])
                valid_metrics.append(measured)
                record = {"replay_index": replay_index, "metrics": measured}
                if isinstance(scenario, Mapping):
                    record.update({key: scenario[key] for key in
                                   ("scenario_fingerprint", "split", "nominal") if key in scenario})
                replay_records.append(record)
            except Exception as error:
                replay_records.append({"replay_index": replay_index,
                                       "error": f"{type(error).__name__}: {error}"})
        valid = len(valid_metrics) == len(scenarios)
        summary, rank = _construction_summary(valid_metrics) if valid else (None, None)
        item = {key: copy.deepcopy(value) for key, value in candidate.items() if key != "policy"}
        item.update({"policy_hash": semantic_hash, "policy": copy.deepcopy(candidate["policy"]),
                     "selection_index": len(ledger), "simulator_calls": len(scenarios),
                     "cumulative_calls": calls, "replays": replay_records,
                     "valid_evaluation": valid, "summary": summary,
                     "all_service_pass": bool(valid and summary["all_service_pass"]),
                     "rank": list(rank) if rank is not None else None})
        ledger.append(item)
        if rank is not None and (best_rank is None or rank > best_rank):
            best, best_rank = item, rank
        if valid and summary["all_service_pass"] and first_pass_calls is None:
            first_pass_calls = calls
        curve.append({"simulation_calls": calls, "evaluated_candidates": len(ledger),
                      "best_policy_hash": best["policy_hash"] if best else None,
                      "best_summary": copy.deepcopy(best["summary"]) if best else None,
                      "first_pass_calls": first_pass_calls})
    return {
        "best_policy": copy.deepcopy(best["policy"]) if best else None,
        "best_candidate": copy.deepcopy(best), "accepted": bool(best and best["summary"]["all_service_pass"]),
        "ledger": ledger, "simulation_calls": calls, "simulator_calls": calls,
        "prefix_curve": curve, "first_pass_calls": first_pass_calls,
        "budget": budget, "unused_budget": None if budget is None else budget - calls,
        "stopped_for_budget": stopped_for_budget, "skipped_duplicate_candidates": skipped_duplicates,
        "ranking_rule": RANKING_RULE,
    }
