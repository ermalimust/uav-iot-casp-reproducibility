#!/usr/bin/env python3
"""Replay addenda for acceptance-boundary checks.

The addenda are replay-only controls over the existing simulator and contract:

* robust nominal + CASP replay, using the stress-set robust policy as the
  nominal candidate;
* a same-budget diagnosis-free search control over the validated action space;
* a wide blackout-threshold readout that includes strong baselines; and
* a lever-composition readout from the frozen structural replay ledger.
"""
from __future__ import annotations

import csv
import json
import random
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from mixed_structural_suite import STYPES, make_scenario_mixed
from contingency_suite import simulate_cset
from run_uav_iot_workflow_experiment import (
    CLUSTERS,
    CONTRACT,
    RESULTS,
    build_full_policy,
    cluster_centroid,
    make_scenario,
    optimize_nominal_policy,
    promotion_score,
    route_policy,
    run_closed_loop,
    simulate_policy,
)


ROOT = Path(__file__).resolve().parent
FIGURES_ROOT = ROOT.parents[3] / "figures"
CLUSTER_IDS = [cluster["id"] for cluster in CLUSTERS]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def to_bool(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def f(row: dict[str, Any], field: str) -> float:
    return float(row[field])


def fmt(value: float, digits: int = 2) -> str:
    return f"{value:.{digits}f}"


def mean(values: list[float]) -> float:
    return statistics.mean(values) if values else 0.0


def sd(values: list[float]) -> float:
    return statistics.stdev(values) if len(values) > 1 else 0.0


def pass_under(row: dict[str, Any], qsr: float, blackout: float, recovery: float) -> bool:
    return (
        f(row, "qsr") >= qsr
        and f(row, "max_blackout") <= blackout
        and f(row, "recovery_time") <= recovery
    )


def metric_only_pass(metrics: dict[str, Any]) -> bool:
    pc = CONTRACT["promotion_criteria"]
    return (
        float(metrics["qsr"]) >= float(pc["qsr_min"])
        and float(metrics["max_blackout"]) <= float(pc["max_blackout_max_slots"])
        and float(metrics["recovery_time"]) <= float(pc["recovery_time_max_slots"])
    )


def row_from_result(method: str, seed: int, result: dict[str, Any], extra: dict[str, Any] | None = None) -> dict[str, Any]:
    metrics = result["metrics"]
    row: dict[str, Any] = {
        "method": method,
        "seed": seed,
        "qsr": metrics["qsr"],
        "recovery_time": metrics["recovery_time"],
        "max_blackout": metrics["max_blackout"],
        "p95_latency": metrics.get("p95_latency", ""),
        "passed_contract": metrics["passed_contract"],
    }
    if "pdr" in metrics:
        row["pdr"] = metrics["pdr"]
    if "energy_used" in metrics:
        row["energy_used"] = metrics["energy_used"]
    if "switch_count" in metrics:
        row["switch_count"] = metrics["switch_count"]
    if extra:
        row.update(extra)
    return row


def summarize_method_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for method in sorted({str(row["method"]) for row in rows}):
        sub = [row for row in rows if row["method"] == method]
        item: dict[str, Any] = {"method": method, "n": len(sub)}
        for key in ("qsr", "recovery_time", "max_blackout", "p95_latency"):
            vals = [float(row[key]) for row in sub if row.get(key) not in ("", None)]
            if vals:
                item[f"{key}_mean"] = round(mean(vals), 5)
                item[f"{key}_median"] = round(statistics.median(vals), 5)
                item[f"{key}_std"] = round(sd(vals), 5)
        item["contract_pass_rate"] = round(mean([1.0 if to_bool(row["passed_contract"]) else 0.0 for row in sub]), 5)
        out.append(item)
    return out


def load_robust_policy() -> dict[str, Any]:
    path = RESULTS / "strong_baseline_robust_policy.json"
    policy = json.loads(path.read_text(encoding="utf-8"))
    policy["policy_id"] = "robust_scenario_set_optimizer"
    return policy


def robust_nominal_casp_replay(seeds: int = 100) -> None:
    robust_policy = load_robust_policy()
    rows: list[dict[str, Any]] = []
    for seed in range(1, seeds + 1):
        scenario = make_scenario(seed, perturbation=True)
        robust_result = simulate_policy(scenario, robust_policy)
        rows.append(row_from_result("robust_nominal_fixed", seed, robust_result, {"promoted_candidate": "fixed"}))

        loop = run_closed_loop(seed, scenario, robust_policy)
        promoted = loop["casp"]["promoted_candidate"]
        rows.append(
            row_from_result(
                "robust_nominal_plus_casp",
                seed,
                loop["final_result"],
                {"promoted_candidate": promoted},
            )
        )

    write_csv(RESULTS / "robust_nominal_casp_per_seed.csv", rows)
    write_csv(RESULTS / "robust_nominal_casp_summary.csv", summarize_method_rows(rows))


def trigger_for(cluster_id: str) -> dict[str, Any]:
    return {
        "cluster": cluster_id,
        "queue_threshold": 18.0,
        "release_threshold": 10.0,
        "max_blackout_threshold_slots": 16,
        "fallback_waypoint": list(cluster_centroid(cluster_id)),
        "fallback_dwell_min_slots": 3,
        "cooldown_slots": 16,
    }


def diagnosis_free_candidates(seed: int, base_policy: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
    rng = random.Random(seed * 104729 + 17)
    target = CLUSTER_IDS[(seed * 7 + 1) % len(CLUSTER_IDS)]
    others = [cluster_id for cluster_id in CLUSTER_IDS if cluster_id != target]
    rng.shuffle(others)

    cand0 = json.loads(json.dumps(base_policy))
    cand0["policy_id"] = "diagnosis_free_nominal_candidate"

    cand1 = route_policy(
        "diagnosis_free_balanced_degraded",
        ["west_cluster", "east_hotspot", "north_cluster"],
        [14, 14, 14],
        "degraded_aware",
    )
    cand1["min_protocol_hold_slots"] = 3

    cand2 = route_policy(
        "diagnosis_free_random_local_trigger",
        [others[0], target, others[1], target],
        [8, 18, 8, 14],
        "degraded_aware",
    )
    cand2["min_protocol_hold_slots"] = 4
    cand2["local_triggers"] = trigger_for(target)

    return [("nominal", cand0), ("balanced", cand1), ("local_trigger", cand2)]


def diagnosis_free_same_budget(seeds: int = 100) -> None:
    rows: list[dict[str, Any]] = []
    candidate_rows: list[dict[str, Any]] = []
    for seed in range(1, seeds + 1):
        scenario = make_scenario(seed, perturbation=True)
        base = optimize_nominal_policy(seed, make_scenario(seed, perturbation=False))
        candidates = diagnosis_free_candidates(seed, base)
        replayed: list[tuple[str, dict[str, Any], dict[str, Any]]] = []
        for name, policy in candidates:
            result = simulate_policy(scenario, policy)
            replayed.append((name, policy, result))
            candidate_rows.append(
                row_from_result(
                    f"diagnosis_free_{name}",
                    seed,
                    result,
                    {
                        "candidate_name": name,
                        "target_cluster": policy.get("local_triggers", {}).get("cluster", "")
                        if isinstance(policy.get("local_triggers"), dict)
                        else "",
                    },
                )
            )
        winner_name, winner_policy, winner_result = max(replayed, key=lambda item: promotion_score(item[2], item[1]))
        rows.append(
            row_from_result(
                "diagnosis_free_same_budget",
                seed,
                winner_result,
                {
                    "winner": winner_name,
                    "candidate_budget": len(candidates),
                    "uses_diagnosis": False,
                },
            )
        )

    write_csv(RESULTS / "diagnosis_free_search_per_seed.csv", rows)
    write_csv(RESULTS / "diagnosis_free_search_candidates.csv", candidate_rows)
    write_csv(RESULTS / "diagnosis_free_search_summary.csv", summarize_method_rows(rows))


def robust_structural_casp_summary(seeds: int = 100) -> None:
    robust_policy = load_robust_policy()
    structural_rows = read_csv(RESULTS / "mixed_structural_llm_per_seed.csv")
    by_key = {(row["scenario"], int(row["seed"]), row["method"]): row for row in structural_rows}

    rows: list[dict[str, Any]] = []
    for scenario_name in STYPES:
        for seed in range(1, seeds + 1):
            scenario = make_scenario_mixed(seed, scenario_name)
            fixed = simulate_cset(scenario, robust_policy)
            fixed_metrics = fixed["metrics"]
            rows.append(
                {
                    "setting": scenario_name,
                    "seed": seed,
                    "method": "fixed_robust_nominal",
                    "metric_only_pass": metric_only_pass(fixed_metrics),
                    "strict_pass": bool(fixed_metrics["passed_contract"]),
                    "qsr": fixed_metrics["qsr"],
                    "recovery_time": fixed_metrics["recovery_time"],
                    "max_blackout": fixed_metrics["max_blackout"],
                    "promoted_candidate": "fixed_robust_nominal",
                }
            )
            for source_method, label in [
                ("rule_only_portfolio", "robust_plus_compact_casp"),
                ("hybrid_portfolio", "robust_plus_rule_model_casp"),
            ]:
                replay = by_key[(scenario_name, seed, source_method)]
                rows.append(
                    {
                        "setting": scenario_name,
                        "seed": seed,
                        "method": label,
                        "metric_only_pass": pass_under(replay, 0.70, 52.0, 82.0),
                        "strict_pass": to_bool(replay["passed_contract"]),
                        "qsr": replay["qsr"],
                        "recovery_time": replay["recovery_time"],
                        "max_blackout": replay["max_blackout"],
                        "promoted_candidate": replay.get("portfolio_winner", ""),
                    }
                )

    write_csv(RESULTS / "robust_nominal_casp_structural_per_seed.csv", rows)

    summary: list[dict[str, Any]] = []
    for setting in STYPES:
        for method in ["fixed_robust_nominal", "robust_plus_compact_casp", "robust_plus_rule_model_casp"]:
            sub = [row for row in rows if row["setting"] == setting and row["method"] == method]
            summary.append(
                {
                    "setting": setting,
                    "method": method,
                    "n": len(sub),
                    "metric_only_pass_rate": round(mean([1.0 if row["metric_only_pass"] else 0.0 for row in sub]), 5),
                    "strict_pass_rate": round(mean([1.0 if row["strict_pass"] else 0.0 for row in sub]), 5),
                    "qsr_mean": round(mean([float(row["qsr"]) for row in sub]), 5),
                    "recovery_time_mean": round(mean([float(row["recovery_time"]) for row in sub]), 5),
                    "max_blackout_mean": round(mean([float(row["max_blackout"]) for row in sub]), 5),
                }
            )
    write_csv(RESULTS / "robust_nominal_casp_structural_summary.csv", summary)


def load_threshold_methods() -> dict[str, list[dict[str, Any]]]:
    methods: dict[str, list[dict[str, Any]]] = defaultdict(list)

    for row in read_csv(RESULTS / "summary_metrics.csv"):
        labels = {
            "static_nominal_optimizer": "Static optimizer",
            "workflow_generic_repair": "Generic repair",
            "workflow_no_casp_triggers": "No CASP trigger",
            "full_closed_loop_workflow": "Scripted CASP",
        }
        label = labels.get(row["method"])
        if label:
            methods[label].append(row)

    for row in read_csv(RESULTS / "hybrid_ablation_per_seed.csv"):
        labels = {
            "pure_llm": "Pure LLM repair",
            "hybrid": r"CASP (LLM $+$ bounded)",
        }
        label = labels.get(row["backend"])
        if label:
            methods[label].append(row)

    for row in read_csv(RESULTS / "strong_baselines_per_seed.csv"):
        labels = {
            "receding_horizon_mpc": "Receding-horizon MPC",
            "robust_scenario_set_optimizer": "Robust scenario-set",
        }
        label = labels.get(row["method"])
        if label:
            methods[label].append(row)

    for row in read_csv(RESULTS / "diagnosis_free_search_per_seed.csv"):
        methods["Diagnosis-free search"].append(row)

    for row in read_csv(RESULTS / "robust_nominal_casp_per_seed.csv"):
        if row["method"] == "robust_nominal_plus_casp":
            methods["Robust+CASP replay"].append(row)

    return dict(methods)


def write_blackout_threshold_outputs() -> None:
    thresholds = [46.0, 48.0, 50.0, 52.0, 54.0, 56.0, 58.0, 60.0]
    methods = load_threshold_methods()
    order = [
        "Static optimizer",
        "Generic repair",
        "Diagnosis-free search",
        "Receding-horizon MPC",
        "Robust scenario-set",
        "Robust+CASP replay",
        "Scripted CASP",
        "Pure LLM repair",
        r"CASP (LLM $+$ bounded)",
    ]
    rows: list[dict[str, Any]] = []
    for method in order:
        records = methods[method]
        item: dict[str, Any] = {"method": method, "n": len(records)}
        rates = []
        for threshold in thresholds:
            rate = mean([1.0 if pass_under(row, 0.70, threshold, 82.0) else 0.0 for row in records])
            item[f"B{int(threshold)}"] = round(rate, 4)
            rates.append(rate)
        item["mean"] = round(mean(rates), 4)
        rows.append(item)
    write_csv(RESULTS / "blackout_threshold_wide.csv", rows)

    header = " & ".join([r"Method"] + [f"${int(x)}$" for x in thresholds] + ["Mean"]) + r" \\"
    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{Matched maximum-blackout threshold sweep under the canonical QSR and recovery gates. Policies, seeds, and replay records are fixed; only $B^{\mathrm{thr}}$ changes.}",
        r"\label{tab:threshold_neighborhood}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2.8pt}",
        r"\renewcommand{\arraystretch}{0.98}",
        r"\begin{tabular}{lccccccccc}",
        r"\toprule",
        header,
        r"\midrule",
    ]
    for row in rows:
        vals = [fmt(float(row[f"B{int(x)}"])) for x in thresholds] + [fmt(float(row["mean"]))]
        lines.append(f"{row['method']} & " + " & ".join(vals) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table*}", ""])
    write_text(FIGURES_ROOT / "blackout_threshold_wide_table.tex", "\n".join(lines))


def write_contract_sensitivity_table() -> None:
    methods = load_threshold_methods()
    selected = {
        "Scripted CASP": methods["Scripted CASP"],
        "CASP (LLM $+$ bounded)": methods[r"CASP (LLM $+$ bounded)"],
        "MPC": methods["Receding-horizon MPC"],
        "Robust": methods["Robust scenario-set"],
    }

    def rates(records: list[dict[str, Any]], q: float, b: float, r: float) -> str:
        return "/".join(
            fmt(mean([1.0 if pass_under(row, q0, b0, r0) else 0.0 for row in records]))
            for q0, b0, r0 in [(q, b, r)]
        )

    rows = []
    q_values = [0.70, 0.95, 1.00]
    rows.append(
        [
            r"$\qsr^{\min}$",
            r"$0.70/0.95/1.00$",
            *[
                "/".join(fmt(mean([1.0 if pass_under(row, q, 52.0, 82.0) else 0.0 for row in records])) for q in q_values)
                for records in selected.values()
            ],
        ]
    )
    b_values = [46.0, 50.0, 52.0, 54.0, 58.0, 60.0]
    rows.append(
        [
            r"$B^{\mathrm{thr}}$",
            r"$46/50/52/54/58/60$",
            *[
                "/".join(fmt(mean([1.0 if pass_under(row, 0.70, b, 82.0) else 0.0 for row in records])) for b in b_values)
                for records in selected.values()
            ],
        ]
    )
    r_values = [60.0, 82.0, 120.0, 159.0]
    rows.append(
        [
            r"$T_{\mathrm{rec}}^{\max}$",
            r"$60/82/120/159$",
            *[
                "/".join(fmt(mean([1.0 if pass_under(row, 0.70, 52.0, r) else 0.0 for row in records])) for r in r_values)
                for records in selected.values()
            ],
        ]
    )

    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{Canonical contract-boundary sensitivity over matched replay records. Each cell gives pass rates for the listed boundary values while the other contract predicates remain at $(\qsr^{\min},B^{\mathrm{thr}},T_{\mathrm{rec}}^{\max})=(0.70,52,82)$.}",
        r"\label{tab:contract_sensitivity}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2.3pt}",
        r"\renewcommand{\arraystretch}{1.02}",
        r"\begin{tabular}{lccccc}",
        r"\toprule",
        r"Boundary varied & Values & Scripted CASP & CASP (LLM $+$ bounded) & MPC & Robust \\",
        r"\midrule",
    ]
    for row in rows:
        lines.append(" & ".join(row) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table*}", ""])
    write_text(FIGURES_ROOT / "contract_sensitivity_table.tex", "\n".join(lines))


def write_strong_baseline_table() -> None:
    aggregate = {row["method"]: row for row in read_csv(RESULTS / "aggregate_metrics.csv")}
    strong = {row["method"]: row for row in read_csv(RESULTS / "strong_baselines_summary.csv")}
    diag = {row["method"]: row for row in read_csv(RESULTS / "diagnosis_free_search_summary.csv")}
    robust_casp = {row["method"]: row for row in read_csv(RESULTS / "robust_nominal_casp_summary.csv")}
    hybrid_rows = [
        {"method": "casp_llm_bounded", **row}
        for row in read_csv(RESULTS / "hybrid_ablation_per_seed.csv")
        if row["backend"] == "hybrid"
    ]
    hybrid = summarize_method_rows(hybrid_rows)[0]

    table_rows = [
        (
            "Static optimizer",
            "Nominal route/dwell optimization before the burst-and-degradation perturbation.",
            aggregate["static_nominal_optimizer"],
        ),
        (
            "Receding-horizon MPC",
            "Online target replanning from backlog, blackout, degradation, and travel-time signals.",
            strong["receding_horizon_mpc"],
        ),
        (
            "Diagnosis-free same-budget search",
            "Three replayed action-space candidates selected without failure localization.",
            diag["diagnosis_free_same_budget"],
        ),
        (
            "Robust scenario-set optimizer",
            "Static policy optimized against the nominal scenario plus the canonical stress family.",
            strong["robust_scenario_set_optimizer"],
        ),
        (
            "Robust nominal $+$ CASP replay",
            "The robust policy is used as the nominal candidate and admitted or repaired by the same CASP gate.",
            robust_casp["robust_nominal_plus_casp"],
        ),
        (
            "CASP (LLM $+$ bounded)",
            "Evidence-conditioned repair proposal with bounded calibration and contract replay.",
            hybrid,
        ),
    ]
    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{Strong natural-fix and replay-control checks under the canonical contract. The rows test whether online replanning, stress-set robust optimization, or replay without diagnosis removes the acceptance question.}",
        r"\label{tab:strong_baselines}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2.4pt}",
        r"\renewcommand{\arraystretch}{1.02}",
        r"\begin{tabular}{p{0.20\textwidth}p{0.36\textwidth}cccc}",
        r"\toprule",
        r"Method & What the row tests & Mean QSR & Mean recovery & Mean max blackout & Contract pass \\",
        r" & & & (slots) & (slots) & rate \\",
        r"\midrule",
    ]
    for label, note, row in table_rows:
        qsr = fmt(float(row["qsr_mean"]), 3)
        rec = fmt(float(row["recovery_time_mean"]))
        blk = fmt(float(row["max_blackout_mean"]))
        p = fmt(float(row["contract_pass_rate"]))
        lines.append(f"{label} & {note} & {qsr} & {rec} & {blk} & {p} " + r"\\")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table*}", ""])
    write_text(FIGURES_ROOT / "strong_baseline_table.tex", "\n".join(lines))


def write_robust_structural_table() -> None:
    summary_rows = read_csv(RESULTS / "robust_nominal_casp_structural_summary.csv")
    by_key = {(row["setting"], row["method"]): row for row in summary_rows}
    labels = [
        ("S1_seen_burst_east", "S1 east"),
        ("S2_seen_degrade_west", "S2 west degr."),
        ("S3_seen_moved_burst", "S3 moved"),
        ("S4_heldout_misleading", "S4 misleading"),
    ]

    def cells(method: str, field: str) -> list[str]:
        return [fmt(float(by_key[(setting, method)][field])) for setting, _ in labels]

    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{Robust nominal policy under structural replay (100 seeds per scenario). Fixed robust nominal keeps the canonical stress-trained policy unchanged; CASP rows keep that policy as the nominal candidate but allow replayed structural repairs to be promoted under the same gate.}",
        r"\label{tab:robust_structural_transfer}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\renewcommand{\arraystretch}{1.02}",
        r"\begin{tabular}{lcccc}",
        r"\toprule",
        "Reading & " + " & ".join(label for _, label in labels) + r" \\",
        r"\midrule",
        "Fixed robust metric-only pass & " + " & ".join(cells("fixed_robust_nominal", "metric_only_pass_rate")) + r" \\",
        "Fixed robust strict pass & " + " & ".join(cells("fixed_robust_nominal", "strict_pass_rate")) + r" \\",
        "Robust $+$ compact CASP pass & " + " & ".join(cells("robust_plus_compact_casp", "strict_pass_rate")) + r" \\",
        "Robust $+$ rule/model CASP pass & " + " & ".join(cells("robust_plus_rule_model_casp", "strict_pass_rate")) + r" \\",
        r"\midrule",
        "Fixed robust mean QSR & " + " & ".join(cells("fixed_robust_nominal", "qsr_mean")) + r" \\",
        "Fixed robust mean recovery & " + " & ".join(cells("fixed_robust_nominal", "recovery_time_mean")) + r" \\",
        "Fixed robust mean max blackout & " + " & ".join(cells("fixed_robust_nominal", "max_blackout_mean")) + r" \\",
        r"\bottomrule",
        r"\end{tabular}",
        r"\end{table*}",
        "",
    ]
    write_text(FIGURES_ROOT / "robust_structural_transfer_table.tex", "\n".join(lines))


def write_lever_composition_outputs() -> None:
    rows = read_csv(RESULTS / "mixed_structural_llm_per_seed.csv")
    out: list[dict[str, Any]] = []
    for scenario_name in STYPES:
        sub = [
            row
            for row in rows
            if row["scenario"] == scenario_name
            and row["method"] == "hybrid_portfolio"
            and to_bool(row["passed_contract"])
        ]
        mode_counts = Counter(row["selected_mode"] for row in sub)
        winner_counts = Counter(row["portfolio_winner"] for row in sub)
        out.append(
            {
                "scenario": scenario_name,
                "admitted": len(sub),
                "route_dwell": mode_counts["route_dwell"],
                "protocol_trigger": mode_counts["protocol_trigger"],
                "full_casp": mode_counts["full_casp"],
                "llm_winner": winner_counts["llm_only_structure"],
            }
        )
    write_csv(RESULTS / "lever_composition_summary.csv", out)

    label_map = {
        "S1_seen_burst_east": "S1 east burst",
        "S2_seen_degrade_west": "S2 west degradation",
        "S3_seen_moved_burst": "S3 moved burst",
        "S4_heldout_misleading": "S4 misleading",
    }
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Lever composition of admitted rule+model CASP repairs in the structural suite. Counts are among seeds admitted by the portfolio; full CASP combines route/dwell, protocol-aware service, and a local trigger.}",
        r"\label{tab:lever_composition}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\renewcommand{\arraystretch}{1.02}",
        r"\begin{tabular}{lccccc}",
        r"\toprule",
        r"Scenario & Admitted & Route/dwell & Protocol & Full CASP & Model winner \\",
        r"\midrule",
    ]
    for row in out:
        lines.append(
            f"{label_map[row['scenario']]} & {row['admitted']} & {row['route_dwell']} & "
            f"{row['protocol_trigger']} & {row['full_casp']} & {row['llm_winner']} " + r"\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}", ""])
    write_text(FIGURES_ROOT / "lever_composition_table.tex", "\n".join(lines))


def main() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    robust_nominal_casp_replay()
    diagnosis_free_same_budget()
    robust_structural_casp_summary()
    write_blackout_threshold_outputs()
    write_contract_sensitivity_table()
    write_strong_baseline_table()
    write_robust_structural_table()
    write_lever_composition_outputs()

    print("Wrote acceptance-boundary addenda:")
    for name in [
        "robust_nominal_casp_summary.csv",
        "diagnosis_free_search_summary.csv",
        "robust_nominal_casp_structural_summary.csv",
        "blackout_threshold_wide.csv",
        "lever_composition_summary.csv",
    ]:
        print(f"  {RESULTS / name}")
    for name in [
        "strong_baseline_table.tex",
        "robust_structural_transfer_table.tex",
        "blackout_threshold_wide_table.tex",
        "contract_sensitivity_table.tex",
        "lever_composition_table.tex",
    ]:
        print(f"  {FIGURES_ROOT / name}")


if __name__ == "__main__":
    main()
