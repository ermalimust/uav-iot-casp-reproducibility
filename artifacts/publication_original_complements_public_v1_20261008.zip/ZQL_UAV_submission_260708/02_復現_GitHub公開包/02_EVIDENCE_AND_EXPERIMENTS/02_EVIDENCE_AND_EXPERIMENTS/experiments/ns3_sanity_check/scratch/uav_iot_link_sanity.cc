#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/network-module.h"
#include "ns3/wifi-module.h"

#include <cmath>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("UavIotLinkSanity");

static std::string
MbpsString(double value)
{
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3) << value << "Mbps";
    return oss.str();
}

int
main(int argc, char* argv[])
{
    std::string profile = "short_high_rate";
    double distance = 50.0;
    bool degraded = false;
    double duration = 12.0;
    uint32_t packetSize = 512;
    bool printHeader = false;

    CommandLine cmd(__FILE__);
    cmd.AddValue("profile", "short_high_rate or robust_low_rate", profile);
    cmd.AddValue("distance", "distance between sender and receiver in meters", distance);
    cmd.AddValue("degraded", "whether to apply the degraded-region loss setting", degraded);
    cmd.AddValue("duration", "application sending duration in seconds", duration);
    cmd.AddValue("packetSize", "UDP payload size in bytes", packetSize);
    cmd.AddValue("printHeader", "print CSV header before the result row", printHeader);
    cmd.Parse(argc, argv);

    bool robust = profile == "robust_low_rate";
    double offeredMbps = robust ? 0.80 : 16.00;
    double txPowerDbm = robust ? 22.0 : 17.0;
    double exponent = degraded ? 3.45 : 2.45;
    double referenceLoss = degraded ? 49.0 : 44.0;
    std::string dataMode = robust ? "DsssRate1Mbps" : "ErpOfdmRate54Mbps";
    std::string controlMode = robust ? "DsssRate1Mbps" : "ErpOfdmRate6Mbps";

    Config::SetDefault("ns3::WifiRemoteStationManager::NonUnicastMode", StringValue(controlMode));

    NodeContainer nodes;
    nodes.Create(2);

    WifiHelper wifi;
    wifi.SetStandard(robust ? WIFI_STANDARD_80211b : WIFI_STANDARD_80211g);
    wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                 "DataMode",
                                 StringValue(dataMode),
                                 "ControlMode",
                                 StringValue(controlMode));

    YansWifiChannelHelper channel;
    channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    channel.AddPropagationLoss("ns3::LogDistancePropagationLossModel",
                               "Exponent",
                               DoubleValue(exponent),
                               "ReferenceDistance",
                               DoubleValue(1.0),
                               "ReferenceLoss",
                               DoubleValue(referenceLoss));

    YansWifiPhyHelper phy;
    phy.SetChannel(channel.Create());
    phy.Set("TxPowerStart", DoubleValue(txPowerDbm));
    phy.Set("TxPowerEnd", DoubleValue(txPowerDbm));
    phy.Set("RxGain", DoubleValue(0.0));

    WifiMacHelper mac;
    mac.SetType("ns3::AdhocWifiMac");
    NetDeviceContainer devices = wifi.Install(phy, mac, nodes);

    MobilityHelper mobility;
    Ptr<ListPositionAllocator> positions = CreateObject<ListPositionAllocator>();
    positions->Add(Vector(0.0, 0.0, 0.0));
    positions->Add(Vector(distance, 0.0, 0.0));
    mobility.SetPositionAllocator(positions);
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(nodes);

    InternetStackHelper internet;
    internet.Install(nodes);

    Ipv4AddressHelper ipv4;
    ipv4.SetBase("10.10.0.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);

    uint16_t port = 9000;
    PacketSinkHelper sinkHelper("ns3::UdpSocketFactory",
                                InetSocketAddress(Ipv4Address::GetAny(), port));
    ApplicationContainer sinkApps = sinkHelper.Install(nodes.Get(1));
    sinkApps.Start(Seconds(0.0));
    sinkApps.Stop(Seconds(duration + 2.0));

    OnOffHelper sourceHelper("ns3::UdpSocketFactory",
                             InetSocketAddress(interfaces.GetAddress(1), port));
    sourceHelper.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1]"));
    sourceHelper.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
    sourceHelper.SetAttribute("PacketSize", UintegerValue(packetSize));
    sourceHelper.SetAttribute("DataRate", DataRateValue(DataRate(MbpsString(offeredMbps))));
    ApplicationContainer sourceApps = sourceHelper.Install(nodes.Get(0));
    sourceApps.Start(Seconds(1.0));
    sourceApps.Stop(Seconds(1.0 + duration));

    Simulator::Stop(Seconds(duration + 2.0));
    Simulator::Run();

    Ptr<PacketSink> sink = DynamicCast<PacketSink>(sinkApps.Get(0));
    uint64_t rxBytes = sink->GetTotalRx();
    double rxMbps = (static_cast<double>(rxBytes) * 8.0) / (duration * 1000000.0);
    double expectedBytes = offeredMbps * 1000000.0 * duration / 8.0;
    double pdr = expectedBytes > 0.0 ? std::min(1.0, static_cast<double>(rxBytes) / expectedBytes) : 0.0;

    if (printHeader)
    {
        std::cout << "profile,distance_m,degraded,offered_mbps,rx_mbps,pdr,rx_bytes,"
                     "tx_power_dbm,path_loss_exponent,reference_loss_db,data_mode"
                  << std::endl;
    }
    std::cout << "NS3_SANITY," << profile << "," << std::fixed << std::setprecision(2)
              << distance << "," << (degraded ? 1 : 0) << "," << offeredMbps << ","
              << std::setprecision(6) << rxMbps << "," << pdr << "," << rxBytes << ","
              << txPowerDbm << "," << exponent << "," << referenceLoss << "," << dataMode
              << std::endl;

    Simulator::Destroy();
    return 0;
}
