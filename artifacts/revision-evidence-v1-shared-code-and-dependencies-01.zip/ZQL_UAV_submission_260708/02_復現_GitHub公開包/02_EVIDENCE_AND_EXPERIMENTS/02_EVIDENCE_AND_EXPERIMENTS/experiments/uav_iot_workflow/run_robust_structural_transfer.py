#!/usr/bin/env python3
"""Transfer the canonical robust baseline into the structural S1-S4 suite.

This is a boundary check for the strong-baseline result.  The robust policy is
the static route/dwell/protocol policy selected over the canonical east
burst-and-degradation stress family.  We replay that same policy without
retuning in the mixed structural scenarios, and report both:

* metric-only pass: the same QSR/blackout/recovery gates used by the canonical
  contract; and
* strict structural-contract pass: the mixed-suite gate, which additionally
  requires evidence-covered local triggers for the affected cluster.
"""
from __future__ import annotations

import argparse
import csv
import json
import statistics
from pathlib import Path
from typing import Any

from mixed_structural_suite import STYPES, make_scenario_mixed
from contingency_suite import simulate_cset
from run_uav_iot_workflow_experiment import CONTRACT, RESULTS


ROOT = Path(__file__).resolve().parent


def metric_only_pass(metrics: dict[str, Any]) -> bool:
    criteria = CONTRACT["promotion_criteria"]
    return (
        float(metrics["qsr"]) >= float(criteria["qsr_min"])
        and float(metrics["max_blackout"]) <= float(criteria["max_blackout_max_slots"])
        and float(metrics["recovery_time"]) <= float(criteria["recovery_time_max_slots"])
    )


def load_policy(path: Path) -> dict[str, Any]:
    policy = json.loads(path.read_text(encoding="utf-8"))
    policy["policy_id"] = "canonical_robust_transfer"
    return policy


def summarize(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for scenario in STYPES:
        sub = [r for r in rows if r["scenario"] == scenario]
        item: dict[str, Any] = {"scenario": scenario, "n": len(sub)}
        for key in ("qsr", "recovery_time", "max_blackout"):
            vals = [float(r[key]) for r in sub]
            item[f"{key}_mean"] = round(statistics.mean(vals), 5)
            item[f"{key}_median"] = round(statistics.median(vals), 5)
            item[f"{key}_iqr"] = round(
                statistics.quantiles(vals, n=4)[2] - statistics.quantiles(vals, n=4)[0],
                5,
            )
        for key in ("metric_only_pass", "strict_contract_pass", "coverage_pass"):
            item[f"{key}_rate"] = round(
                statistics.mean(1.0 if r[key] else 0.0 for r in sub),
                5,
            )
        out.append(item)
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=int, default=100)
    parser.add_argument(
        "--policy",
        default=str(RESULTS / "strong_baseline_robust_policy.json"),
        help="Canonical robust policy JSON from run_strong_baselines.py",
    )
    parser.add_argument(
        "--out-dir",
        default=str(RESULTS),
        help="Directory for per-seed and summary CSV outputs.",
    )
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    policy = load_policy(Path(args.policy))

    rows: list[dict[str, Any]] = []
    for scenario_name in STYPES:
        for seed in range(1, args.seeds + 1):
            scenario = make_scenario_mixed(seed, scenario_name)
            result = simulate_cset(scenario, policy)
            metrics = result["metrics"]
            rows.append(
                {
                    "scenario": scenario_name,
                    "seed": seed,
                    "qsr": metrics["qsr"],
                    "recovery_time": metrics["recovery_time"],
                    "max_blackout": metrics["max_blackout"],
                    "p95_latency": metrics["p95_latency"],
                    "metric_only_pass": metric_only_pass(metrics),
                    "strict_contract_pass": bool(metrics["passed_contract"]),
                    "coverage_pass": bool(metrics.get("coverage_pass", False)),
                    "true_target": scenario["target"],
                    "expected_mode": scenario["expected_mode"],
                }
            )

    per_seed_path = out_dir / "robust_structural_transfer_per_seed.csv"
    with per_seed_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    summary = summarize(rows)
    summary_path = out_dir / "robust_structural_transfer_summary.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary[0].keys()))
        writer.writeheader()
        writer.writerows(summary)

    print("Canonical robust transfer into structural S1-S4 suite")
    print(f"policy  -> {args.policy}")
    print(f"per-seed -> {per_seed_path}")
    print(f"summary  -> {summary_path}")
    print(
        f"{'scenario':<24}{'metric-pass':>14}{'strict-pass':>14}"
        f"{'QSR':>10}{'recovery':>12}{'Bmax':>10}"
    )
    for item in summary:
        print(
            f"{item['scenario']:<24}"
            f"{item['metric_only_pass_rate']:>14.2f}"
            f"{item['strict_contract_pass_rate']:>14.2f}"
            f"{item['qsr_mean']:>10.3f}"
            f"{item['recovery_time_mean']:>12.2f}"
            f"{item['max_blackout_mean']:>10.2f}"
        )


if __name__ == "__main__":
    main()
