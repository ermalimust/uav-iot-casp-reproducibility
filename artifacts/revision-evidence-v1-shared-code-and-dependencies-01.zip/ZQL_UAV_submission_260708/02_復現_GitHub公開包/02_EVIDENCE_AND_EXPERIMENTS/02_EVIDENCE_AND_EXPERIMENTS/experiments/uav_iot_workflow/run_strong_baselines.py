#!/usr/bin/env python3
"""Run stronger natural-fix baselines for the CASP acceptance question.

The two baselines intentionally do not produce CASP evidence:

* receding_horizon_mpc observes queues/blackouts online and replans the target
  cluster, but it does not emit a pre-deployment evidence package.
* robust_scenario_set_optimizer selects one static route/dwell/protocol policy
  over a nominal+stress training set, but it has no diagnosis record or trigger.
"""
from __future__ import annotations

import csv
import json
import os
import statistics
import time
from itertools import permutations
from pathlib import Path
from typing import Any

from run_uav_iot_workflow_experiment import (
    CLUSTERS,
    RESULTS,
    make_scenario,
    route_policy,
    simulate_policy,
)


CLUSTER_IDS = [c["id"] for c in CLUSTERS]


def build_receding_horizon_mpc() -> dict[str, Any]:
    return {
        "policy_id": "receding_horizon_mpc",
        "controller": "receding_horizon",
        "route": [],
        "protocol_mode": "degraded_aware",
        "local_triggers": None,
        "min_protocol_hold_slots": 3,
        "replan_interval_slots": 4,
        "commit_slots": 5,
        "horizon_slots": 24,
        "baseline_note": (
            "Online receding-horizon target selection from observed backlog, "
            "blackout, travel time, and degradation evidence; no CASP package."
        ),
    }


def _candidate_routes() -> list[list[str]]:
    routes: set[tuple[str, ...]] = set(permutations(CLUSTER_IDS))
    routes.update(
        {
            ("west_cluster", "east_hotspot", "north_cluster", "east_hotspot"),
            ("east_hotspot", "west_cluster", "east_hotspot", "north_cluster"),
            ("east_hotspot", "north_cluster", "east_hotspot", "west_cluster"),
            ("west_cluster", "north_cluster", "east_hotspot", "east_hotspot"),
            ("north_cluster", "west_cluster", "east_hotspot", "east_hotspot"),
            ("west_cluster", "west_cluster", "east_hotspot", "north_cluster"),
            ("north_cluster", "north_cluster", "east_hotspot", "west_cluster"),
        }
    )
    return [list(r) for r in sorted(routes)]


def _dwell_for(route: list[str], nonhot: int, hot: int, repeated_bonus: int = 0) -> list[int]:
    counts = {c: route.count(c) for c in set(route)}
    dwells = []
    for c in route:
        base = hot if c == "east_hotspot" else nonhot
        if counts.get(c, 0) > 1:
            base += repeated_bonus
        dwells.append(base)
    return dwells


def _robust_candidates() -> list[dict[str, Any]]:
    candidates = []
    dwell_patterns = [(10, 14, 0), (8, 18, 0), (10, 20, 0), (8, 16, 2)]
    for route in _candidate_routes():
        for mode in ("best_rate", "degraded_aware"):
            for nonhot, hot, bonus in dwell_patterns:
                pol = route_policy(
                    "robust_scenario_set_optimizer",
                    route,
                    _dwell_for(route, nonhot, hot, bonus),
                    mode,
                )
                pol["min_protocol_hold_slots"] = 3 if mode == "degraded_aware" else 0
                pol["optimizer_note"] = (
                    "Static route/dwell/protocol policy selected over a "
                    "nominal+stress scenario set; no local trigger."
                )
                candidates.append(pol)
    return candidates


def _score_result(result: dict[str, Any], stress: bool) -> float:
    m = result["metrics"]
    score = (
        75.0 * float(m["qsr"])
        + 18.0 * float(m["pdr"])
        - 0.12 * float(m["p95_latency"])
        - 0.18 * float(m["max_blackout"])
        - 0.0025 * float(m["energy_used"])
    )
    if stress:
        score += 14.0 * (1.0 if m["passed_contract"] else 0.0)
        score -= 0.09 * float(m["recovery_time"])
        score -= 0.18 * float(m["max_blackout"])
    return score


def train_robust_policy(train_start: int, train_n: int) -> dict[str, Any]:
    train_seeds = list(range(train_start, train_start + train_n))
    scenarios = []
    for seed in train_seeds:
        scenarios.append((False, make_scenario(seed, perturbation=False)))
        scenarios.append((True, make_scenario(seed, perturbation=True)))

    best_policy: dict[str, Any] | None = None
    best_score = -1e18
    for idx, pol in enumerate(_robust_candidates(), start=1):
        scores = [_score_result(simulate_policy(sc, pol), stress) for stress, sc in scenarios]
        score = statistics.mean(scores)
        if score > best_score:
            best_score = score
            best_policy = json.loads(json.dumps(pol))
        if idx % 150 == 0:
            print(f"  robust search checked {idx} candidates", end="\r")
    assert best_policy is not None
    best_policy["robust_training"] = {
        "train_seed_start": train_start,
        "train_seed_count": train_n,
        "scenario_set": "nominal + canonical burst/degradation stress",
        "selected_score": round(best_score, 5),
    }
    return best_policy


def _row(method: str, seed: int, result: dict[str, Any]) -> dict[str, Any]:
    m = result["metrics"]
    return {
        "method": method,
        "seed": seed,
        "pdr": m["pdr"],
        "p95_latency": m["p95_latency"],
        "max_blackout": m["max_blackout"],
        "qsr": m["qsr"],
        "recovery_time": m["recovery_time"],
        "energy_used": m["energy_used"],
        "switch_count": m["switch_count"],
        "passed_contract": m["passed_contract"],
    }


def _aggregate(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for method in sorted({r["method"] for r in rows}):
        sub = [r for r in rows if r["method"] == method]
        item: dict[str, Any] = {"method": method, "n": len(sub)}
        for key in ("pdr", "p95_latency", "max_blackout", "qsr", "recovery_time", "energy_used", "switch_count"):
            vals = [float(r[key]) for r in sub]
            item[f"{key}_mean"] = round(statistics.mean(vals), 5)
            item[f"{key}_median"] = round(statistics.median(vals), 5)
            item[f"{key}_std"] = round(statistics.stdev(vals), 5) if len(vals) > 1 else 0.0
        item["contract_pass_rate"] = round(
            statistics.mean(1.0 if str(r["passed_contract"]) == "True" else 0.0 for r in sub),
            5,
        )
        out.append(item)
    return out


def main() -> None:
    t0 = time.time()
    eval_n = int(os.environ.get("UAV_STRONG_BASELINE_SEEDS", "100"))
    train_start = int(os.environ.get("UAV_ROBUST_TRAIN_START", "101"))
    train_n = int(os.environ.get("UAV_ROBUST_TRAIN_N", "6"))
    out_dir = RESULTS
    out_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 72)
    print("Strong natural-fix baselines: receding-horizon MPC and robust optimizer")
    print("=" * 72)
    print(f"  evaluation seeds = 1..{eval_n}")
    print(f"  robust training seeds = {train_start}..{train_start + train_n - 1}")

    mpc_policy = build_receding_horizon_mpc()
    robust_policy = train_robust_policy(train_start, train_n)
    (out_dir / "strong_baseline_robust_policy.json").write_text(
        json.dumps(robust_policy, indent=2),
        encoding="utf-8",
    )

    rows: list[dict[str, Any]] = []
    for seed in range(1, eval_n + 1):
        scenario = make_scenario(seed, perturbation=True)
        rows.append(_row("receding_horizon_mpc", seed, simulate_policy(scenario, mpc_policy)))
        rows.append(_row("robust_scenario_set_optimizer", seed, simulate_policy(scenario, robust_policy)))
        if seed % 10 == 0:
            print(f"  evaluated seed {seed}/{eval_n}", end="\r")
    print()

    per_seed_path = out_dir / "strong_baselines_per_seed.csv"
    with per_seed_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    summary = _aggregate(rows)
    summary_path = out_dir / "strong_baselines_summary.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
        w.writeheader()
        w.writerows(summary)

    print(f"per-seed CSV -> {per_seed_path}")
    print(f"summary CSV  -> {summary_path}")
    for item in summary:
        print(
            f"  {item['method']:<31} QSR={item['qsr_mean']:.3f} "
            f"rec={item['recovery_time_mean']:.2f} "
            f"Bmax={item['max_blackout_mean']:.2f} "
            f"pass={item['contract_pass_rate']:.2f}"
        )
    print(f"[{time.time() - t0:.1f}s]")


if __name__ == "__main__":
    main()
