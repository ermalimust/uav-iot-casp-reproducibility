#!/usr/bin/env python3
"""Mixed structural-repair suite: no-key deterministic preflight.

This suite tests a narrower and cleaner question than the earlier two-hotspot
contingency stress: can a repair backend choose the *kind* of repair structure
from per-cluster evidence, while the simulator/contract still decides whether
the candidate is admissible?

It is a design-preflight script, not manuscript evidence by itself. Use it to
check whether the mixed structural setting is recoverable under a scripted
reference before spending live LLM calls.
"""
from __future__ import annotations

import argparse
import csv
import math
import os
import random
import statistics
from pathlib import Path

from contingency_suite import CLUSTER_IDS, _nominal, _trigger, simulate_cset
from run_uav_iot_workflow_experiment import (
    AREA,
    CLUSTERS,
    PERTURB_START,
    T,
    clamp,
    cluster_centroid,
    is_burst_active,
    route_policy,
)


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"

STYPES = [
    "S1_seen_burst_east",
    "S2_seen_degrade_west",
    "S3_seen_moved_burst",
    "S4_heldout_misleading",
]
HELD_OUT = "S4_heldout_misleading"
REPAIR_MODES = ["route_dwell", "protocol_trigger", "full_casp"]
SIMPLE_RULE_METHODS = [
    "B1_max_backlog_route",
    "B2_max_blackout_protocol",
    "B3_scripted_east_full",
]
REFERENCE_METHODS = [
    "SR_scripted_mixed_reference",
]
DET_METHODS = SIMPLE_RULE_METHODS + ["rule_only_portfolio"] + REFERENCE_METHODS


def _case(stype: str, seed: int) -> dict:
    rng = random.Random(seed * 173 + 41)
    if stype == "S1_seen_burst_east":
        hot = "east_hotspot"
        return {
            "target": hot,
            "burst": [hot],
            "degrade": [hot],
            "burst_multiplier": 3.30,
            "degradation_strength": 0.78,
            "expected_mode": "full_casp",
        }
    if stype == "S2_seen_degrade_west":
        hot = "west_cluster"
        return {
            "target": hot,
            "burst": [],
            "degrade": [hot],
            "burst_multiplier": 1.00,
            "degradation_strength": 0.92,
            "expected_mode": "protocol_trigger",
        }
    if stype == "S3_seen_moved_burst":
        hot = rng.choice(["west_cluster", "north_cluster"])
        return {
            "target": hot,
            "burst": [hot],
            "degrade": [hot],
            "burst_multiplier": 3.30,
            "degradation_strength": 0.78,
            "expected_mode": "full_casp",
        }
    if stype == "S4_heldout_misleading":
        hot = rng.choice(CLUSTER_IDS)
        distractor = rng.choice([c for c in CLUSTER_IDS if c != hot])
        return {
            "target": hot,
            "burst": [distractor],
            "degrade": [hot],
            "burst_multipliers": {distractor: 2.20},
            "affected": [hot],
            "degradation_strength": 0.84,
            "expected_mode": "full_casp",
        }
    raise ValueError(stype)


def make_scenario_mixed(seed: int, stype: str) -> dict:
    spec = _case(stype, seed)
    burst = set(spec["burst"])
    degrade = set(spec["degrade"])
    affected = set(spec.get("affected", list(burst | degrade)))
    rng = random.Random(seed * 7919 + 13)
    devices = []
    for ci, cluster in enumerate(CLUSTERS):
        cx, cy = cluster["centroid"]
        for li in range(10):
            did = ci * 10 + li
            x = clamp(cx + rng.gauss(0.0, 48.0), 40.0, AREA - 40.0)
            y = clamp(cy + rng.gauss(0.0, 48.0), 40.0, AREA - 40.0)
            base = 0.032 + 0.014 * rng.random()
            if cluster["id"] in affected:
                base += 0.006 + 0.006 * rng.random()
            devices.append(
                {
                    "id": did,
                    "cluster": cluster["id"],
                    "x": x,
                    "y": y,
                    "base_arrival": base,
                }
            )
    arng = random.Random(seed * 12289 + 97)
    arrivals = []
    for t in range(T):
        row = []
        for dev in devices:
            a = dev["base_arrival"] * (0.72 + 0.56 * arng.random())
            if is_burst_active(t, True) and dev["cluster"] in burst:
                multipliers = spec.get("burst_multipliers")
                mult = multipliers.get(dev["cluster"], 1.0) if isinstance(multipliers, dict) else spec["burst_multiplier"]
                a *= mult + 0.18 * math.sin((t - PERTURB_START) / 9.0)
            row.append(a)
        arrivals.append(row)
    return {
        "seed": seed,
        "stype": stype,
        "devices": devices,
        "arrivals": arrivals,
        "burst": burst,
        "degrade": degrade,
        "affected": affected,
        "target": spec["target"],
        "expected_mode": spec["expected_mode"],
        "degradation_strength": spec["degradation_strength"],
    }


def evidence_from_nominal(scenario: dict) -> dict:
    probe = simulate_cset(scenario, _nominal())
    return {
        c: {
            "peak_backlog": float(probe["peak_backlog"][c]),
            "peak_blackout": int(probe["peak_blackout"][c]),
            "peak_link_stress": float(probe["peak_link_stress"][c]),
        }
        for c in CLUSTER_IDS
    }


def _target_from_backlog(evidence: dict) -> str:
    return max(CLUSTER_IDS, key=lambda c: evidence[c]["peak_backlog"])


def _target_from_blackout(evidence: dict) -> str:
    return max(
        CLUSTER_IDS,
        key=lambda c: (evidence[c]["peak_blackout"], evidence[c]["peak_link_stress"]),
    )


def scripted_structure(evidence: dict) -> tuple[str, str]:
    """Hand-written reference: choose one target and one structural mode."""
    best = max(
        CLUSTER_IDS,
        key=lambda c: (
            evidence[c]["peak_link_stress"],
            evidence[c]["peak_blackout"],
            evidence[c]["peak_backlog"],
        ),
    )
    if evidence[best]["peak_link_stress"] >= 0.15 and evidence[best]["peak_backlog"] >= 14.0:
        return best, "full_casp"
    if evidence[best]["peak_link_stress"] >= 0.15:
        return best, "protocol_trigger"
    return _target_from_backlog(evidence), "route_dwell"


def _route_templates(target: str, mode: str) -> list[list[str]]:
    others = [c for c in CLUSTER_IDS if c != target]
    if mode == "protocol_trigger":
        return [
            ["west_cluster", "east_hotspot", "north_cluster"],
            [target, others[0], others[1]],
        ]
    return [
        [others[0], target, others[1], target],
        [target, others[0], target, others[1]],
        [target, others[0], others[1], target],
    ]


def calibrate_structure(scenario: dict, target: str, mode: str) -> dict:
    if target not in CLUSTER_IDS:
        target = "east_hotspot"
    if mode not in REPAIR_MODES:
        mode = "route_dwell"
    best = None
    full_search = os.environ.get("UAV_MIXED_FULL_SEARCH", "") == "1"
    for route in _route_templates(target, mode):
        if mode == "route_dwell":
            protocol_grid = ["degraded_aware"]
            target_dwell_grid = (16, 22)
            trigger_grid = [(3, 12, 12), (6, 12, 12), (3, 16, 12)]
        elif mode == "protocol_trigger":
            protocol_grid = ["degraded_aware"]
            target_dwell_grid = (10, 14)
            trigger_grid = [(4, 12, 12), (3, 10, 16), (4, 10, 16)]
        else:
            protocol_grid = ["degraded_aware"]
            target_dwell_grid = (16, 22, 28)
            trigger_grid = [(3, 10, 16), (3, 16, 12), (6, 12, 12), (4, 12, 12), (3, 12, 12)]
        for protocol in protocol_grid:
            for target_dwell in target_dwell_grid:
                for trig_dwell, blackout_thr, cooldown in trigger_grid:
                    dwell = [target_dwell if c == target else 8 for c in route]
                    pol = route_policy(f"mixed_{mode}", route, dwell, protocol)
                    pol["min_protocol_hold_slots"] = 4 if protocol == "degraded_aware" else 0
                    pol["local_triggers"] = [
                        _trigger(target, b=blackout_thr, dwell=trig_dwell, cooldown=cooldown)
                    ]
                    res = simulate_cset(scenario, pol)
                    m = res["metrics"]
                    key = (
                        1 if m["passed_contract"] else 0,
                        m["qsr"],
                        -m["recovery_time"],
                        -m["max_blackout"],
                    )
                    if best is None or key > best[0]:
                        best = (key, res, pol)
                    if m["passed_contract"] and not full_search:
                        out = res
                        out["policy"] = pol
                        out["selected_target"] = target
                        out["selected_mode"] = mode
                        return out
    assert best is not None
    out = best[1]
    out["policy"] = best[2]
    out["selected_target"] = target
    out["selected_mode"] = mode
    return out


_CAL_CACHE: dict[tuple[str, int, str, str], dict] = {}


def promotion_key(result: dict) -> tuple:
    """Contract-first promotion key used by rule and hybrid portfolios."""
    m = result["metrics"]
    return (
        1 if m["passed_contract"] else 0,
        m["qsr"],
        -m["recovery_time"],
        -m["max_blackout"],
    )


def promote_candidate_results(candidates: list[tuple[str, dict]], portfolio_name: str) -> dict:
    """Select the best already-validated candidate without changing thresholds."""
    winner_name, winner = max(candidates, key=lambda item: promotion_key(item[1]))
    out = dict(winner)
    out["portfolio_name"] = portfolio_name
    out["portfolio_winner"] = winner_name
    out["portfolio_candidates"] = ";".join(name for name, _ in candidates)
    out["selected_target"] = winner.get("selected_target", "")
    out["selected_mode"] = winner.get("selected_mode", "")
    return out


def run_method(method: str, scenario: dict, evidence: dict | None = None) -> dict:
    if evidence is None:
        evidence = evidence_from_nominal(scenario)
    if method == "B1_max_backlog_route":
        target, mode = _target_from_backlog(evidence), "route_dwell"
    elif method == "B2_max_blackout_protocol":
        target, mode = _target_from_blackout(evidence), "protocol_trigger"
    elif method == "B3_scripted_east_full":
        target, mode = "east_hotspot", "full_casp"
    elif method == "rule_only_portfolio":
        return promote_candidate_results(
            [(name, run_method(name, scenario, evidence)) for name in SIMPLE_RULE_METHODS],
            method,
        )
    elif method == "SR_scripted_mixed_reference":
        target, mode = scripted_structure(evidence)
    else:
        raise ValueError(method)
    key = (scenario["stype"], int(scenario["seed"]), target, mode)
    if key not in _CAL_CACHE:
        _CAL_CACHE[key] = calibrate_structure(scenario, target, mode)
    return _CAL_CACHE[key]


def _passrate(rows: list[bool]) -> float:
    return statistics.mean(1.0 if x else 0.0 for x in rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=int(os.environ.get("UAV_MIXED_N", "30")))
    ap.add_argument("--out", default=str(RESULTS / "mixed_structural_clean_det.csv"))
    args = ap.parse_args()
    seeds = list(range(1, args.seeds + 1))
    RESULTS.mkdir(parents=True, exist_ok=True)

    rows = []
    print(f"Mixed structural-repair suite - deterministic preflight ({len(seeds)} seeds/type)\n")
    header = f"{'scenario':<24}" + "".join(f"{m:>28}" for m in DET_METHODS)
    print(header)
    print("-" * len(header))
    for stype in STYPES:
        passes = {m: [] for m in DET_METHODS}
        for seed in seeds:
            scenario = make_scenario_mixed(seed, stype)
            evidence = evidence_from_nominal(scenario)
            for method in DET_METHODS:
                result = run_method(method, scenario, evidence)
                m = result["metrics"]
                ok = bool(m["passed_contract"])
                passes[method].append(ok)
                rows.append(
                    {
                        "scenario": stype,
                        "seed": seed,
                        "method": method,
                        "passed_contract": ok,
                        "qsr": round(m["qsr"], 4),
                        "recovery_time": m["recovery_time"],
                        "max_blackout": m["max_blackout"],
                        "selected_target": result["selected_target"],
                        "selected_mode": result["selected_mode"],
                        "portfolio_winner": result.get("portfolio_winner", ""),
                        "portfolio_candidates": result.get("portfolio_candidates", ""),
                        "true_target": scenario["target"],
                        "expected_mode": scenario["expected_mode"],
                        "held_out": stype == HELD_OUT,
                    }
                )
        print(
            f"{stype:<24}"
            + "".join(f"{_passrate(passes[m]):>28.2f}" for m in DET_METHODS)
        )
    with open(args.out, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"\nwrote {args.out}")
    print(
        "Reading: only spend live LLM calls if SR_scripted_mixed_reference is high "
        "on the held-out case. If it is low, the setting is a capacity "
        "boundary rather than a positive structural-backend test."
    )


if __name__ == "__main__":
    main()
