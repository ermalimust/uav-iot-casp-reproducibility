"""Verify this package and reproduce four reports from saved measurements only."""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPORTER_SHA = 'dc99a89e27904637f9e6a12aa66c7774d6b43d240ab92e34700b25a891833e91'
REPORT_NAMES = {'summary.json', 'per_task.csv', 'report.md', 'original_structural_online_cost_table.tex'}
sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def identity(path):
    require(path.is_file() and not path.is_symlink() and not path.is_junction(), 'Missing/unsafe file: ' + str(path))
    return {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def member(relative):
    pure = PurePosixPath(relative)
    require(not pure.is_absolute() and '..' not in pure.parts and '\\' not in relative, 'Unsafe member name')
    path = ROOT.joinpath(*pure.parts)
    require(path.resolve().is_relative_to(ROOT), 'Member escapes package')
    return path


def verify_package():
    require(sys.version_info >= (3, 12), 'Use Python 3.12 or later; no third-party packages are required')
    manifest_path = ROOT / 'MANIFEST.json'
    manifest_identity = identity(manifest_path)
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    require(manifest['package'] == 'online-cost-v1-20261009', 'Unexpected package identity')
    expected = set(manifest['files']) | {'MANIFEST.json'}
    actual = set()
    for path in ROOT.rglob('*'):
        require(not path.is_symlink() and not path.is_junction(), 'Reparse member rejected')
        require(path.resolve().is_relative_to(ROOT), 'Unexpected member resolution')
        if path.is_file():
            actual.add(path.relative_to(ROOT).as_posix())
    require(actual == expected == set(manifest['all_members']), 'Missing or unknown package member')
    observed = {}
    for relative, bound in manifest['files'].items():
        observed[relative] = identity(member(relative))
        require(observed[relative] == {k: bound[k] for k in ('bytes', 'sha256')}, 'Member identity differs: ' + relative)
    live = ROOT / 'saved_live'
    preparation = json.loads((live / 'preparation.json').read_text(encoding='utf-8'))
    completion = json.loads((live / 'completion.json').read_text(encoding='utf-8'))
    mapping = json.loads((ROOT / 'PATH_MAP.json').read_text(encoding='utf-8'))['sources']
    require(len(mapping) == len(preparation['source_hashes']) == 17, 'Original source scope differs')
    require({item['original_path'] for item in mapping} == set(preparation['source_hashes']), 'Source path map differs')
    require(completion['source_hashes_after'] == preparation['source_hashes'], 'Original run source protection differs')
    for item in mapping:
        pin = preparation['source_hashes'][item['original_path']]
        require(item['sha256'] == pin and identity(member(item['package_path']))['sha256'] == pin, 'Original source copy differs')
    require(len(completion['cell_hashes']) == 48, 'Saved-record scope differs')
    for relative, pin in completion['cell_hashes'].items():
        path = member('saved_live/' + relative.replace('\\', '/'))
        require(identity(path)['sha256'] == pin, 'Original completed record differs')
    reporter = ROOT / 'tools/report_original_structural_online_cost.py'
    require(identity(reporter)['sha256'] == REPORTER_SHA, 'Original reporter differs')
    tree = ast.parse(reporter.read_text(encoding='utf-8'))
    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.add(node.module)
    require(imports == {'argparse', 'csv', 'hashlib', 'json', 'math', 'pathlib'}, 'Reporter import scope differs')
    require({p.name for p in (ROOT / 'expected_report').iterdir()} == REPORT_NAMES, 'Expected report scope differs')
    return {'manifest': manifest_identity, 'verified_payload_files': observed, 'source_copies_verified': 17,
            'live_record_files_verified': 64, 'completed_request_artifacts_verified': 48}


def run(output):
    output = output.resolve()
    require(not output.exists() and not output.is_relative_to(ROOT), 'Choose a fresh output outside the package')
    require(not output.is_symlink() and not output.is_junction(), 'Unsafe output')
    output.mkdir(parents=True, exist_ok=False)
    receipt = {'status': 'RUNNING_SAVED_RECORD_REPORT_ONLY', 'started_utc': datetime.now(timezone.utc).isoformat(),
               'entry_identity': identity(Path(__file__)), 'reporter_invocations': 0, 'new_model_requests': 0,
               'network_calls': 0, 'new_simulator_or_native_calls': 0, 'experiment_modules_imported': False,
               'configuration_or_credentials_read': False, 'automatic_retries': 0, 'package_written': False,
               'new_effectiveness_comparison': False, 'population_tail_guarantee': False}
    try:
        receipt['package_before'] = verify_package()
        reporter = ROOT / 'tools/report_original_structural_online_cost.py'
        command = [sys.executable, '-I', '-S', '-B', str(reporter), '--result-root', str(ROOT / 'saved_live'),
                   '--output', str(output / 'report')]
        receipt['reporter_command'] = command
        receipt['reporter_invocations'] = 1
        with (output / 'reporter_stdout.log').open('xb') as stdout, (output / 'reporter_stderr.log').open('xb') as stderr:
            result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=60, check=False)
        receipt['reporter_exit_code'] = result.returncode
        require(result.returncode == 0, 'Saved reporter failed; preserve first attempt without retry')
        require({p.name for p in (output / 'report').iterdir()} == REPORT_NAMES, 'Actual four-output scope differs')
        receipt['four_report_comparisons'] = {}
        for name in sorted(REPORT_NAMES):
            actual = identity(output / 'report' / name)
            expected = identity(ROOT / 'expected_report' / name)
            require(actual == expected, 'Saved report bytes differ: ' + name)
            receipt['four_report_comparisons'][name] = {'expected': expected, 'actual': actual, 'byte_identical': True}
        receipt['package_after'] = verify_package()
        require(receipt['package_before'] == receipt['package_after'], 'Package changed during saved analysis')
        receipt['status'] = 'PASS_ALL_PACKAGE_IDENTITIES_AND_FOUR_BYTE_IDENTICAL_SAVED_REPORTS'
    except Exception as error:
        receipt['status'] = 'STOPPED_FIRST_FAILURE_PRESERVE_NO_RETRY'
        receipt['first_failure'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        for name in ('reporter_stdout.log', 'reporter_stderr.log'):
            path = output / name
            if path.is_file():
                receipt[name] = identity(path)
        receipt['completed_utc'] = datetime.now(timezone.utc).isoformat()
        with (output / 'OFFLINE_CHECK_RECEIPT.json').open('x', encoding='utf-8', newline='\n') as stream:
            json.dump(receipt, stream, indent=2)
            stream.write('\n')
    print(receipt['status'])
    return 0 if receipt['status'].startswith('PASS_') else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True, help='Fresh output outside the extracted package')
    raise SystemExit(run(parser.parse_args().output))
