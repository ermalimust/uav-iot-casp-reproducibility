"""Exact fixed-policy contract sensitivity from saved realized-service events.

No controller, link-rate selection, simulator invocation, proposal, calibration,
environment/API/key access or promotion. Pure original scene generation is
extracted with AST; its hash must equal each saved scenario. FIFO accounting
then reconstructs exact device predicates and all saved original service metrics.
"""
from __future__ import annotations

import argparse
import ast
from collections import deque
import copy
import csv
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import sys

sys.dont_write_bytecode = True
from summarize_original_energy_screen import ROOT, AUDIT, SCENARIOS, METHODS, require_audited

BASE = Path(__file__).resolve().parent
PROTOCOL = BASE.parent / 'Original_Contract_Neighborhood_Protocol_20261008.md'
OUT = BASE / 'results/original_contract_neighborhood_analysis_20261008'
AXES = {
    'qsr_min': {'values': [.60, .65, .70, .75, .80, .90, .95, 1.0], 'main': [.65, .70, .75], 'unit': 'fraction'},
    'device_pdr_min': {'values': [.60, .65, .70, .75, .80], 'main': [.65, .70, .75], 'unit': 'fraction'},
    'device_latency_max': {'values': [42, 52, 62, 72, 82], 'main': [52, 62, 72], 'unit': 'slot'},
    'blackout_max': {'values': [46, 48, 50, 52, 54, 56, 58, 60], 'main': [50, 52, 54], 'unit': 'slot'},
    'recovery_max': {'values': [60, 72, 82, 92, 100, 120, 159], 'main': [72, 82, 92], 'unit': 'slot'},
}
CANONICAL = dict(qsr_min=.70, device_pdr_min=.70, device_latency_max=62, blackout_max=52, recovery_max=82)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def clean(value):
    if isinstance(value, dict): return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [clean(v) for v in value]
    if isinstance(value, set): return sorted(clean(v) for v in value)
    return value


def canonical_hash(value):
    return hashlib.sha256(json.dumps(clean(value), sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def pure_original_namespace(manifest):
    canonical = BASE / 'legacy/run_uav_iot_workflow_experiment.py'
    mixed = BASE / 'legacy/mixed_structural_suite.py'
    contingency = BASE / 'legacy/contingency_suite.py'
    namespace = {'math': math, 'random': random}
    extracted, source_hashes = [], {}
    selections = [
        (canonical, {'N_DEVICES', 'T', 'DT', 'AREA', 'UAV_START', 'UAV_SPEED', 'PERTURB_START',
                     'PERTURB_END', 'RECOVERY_HOLD', 'CLUSTERS', 'PROTOCOLS', 'CONTRACT'}, {'clamp', 'is_burst_active'}),
        (contingency, {'CLUSTER_IDS', 'RECOVERY_BACKLOG_STABLE_MAX', 'RECOVERY_BLACKOUT_STABLE_MAX'}, set()),
        (mixed, set(), {'_case', 'make_scenario_mixed'}),
    ]
    for path, constants, functions in selections:
        sha = digest(path)
        if manifest['source_hashes_before'].get(str(path.resolve())) != sha:
            raise ValueError('Pure accounting source does not match the audited original source')
        source_hashes[str(path.resolve())] = sha
        tree = ast.parse(path.read_text(encoding='utf-8-sig'))
        kept = []
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in constants for t in node.targets):
                kept.append(node)
            elif isinstance(node, ast.FunctionDef) and node.name in functions:
                if any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id.startswith('simulate') for n in ast.walk(node)):
                    raise ValueError('Pure scene generator unexpectedly calls a simulator')
                kept.append(node)
        found_constants = {t.id for n in kept if isinstance(n, ast.Assign) for t in n.targets if isinstance(t, ast.Name)}
        found_functions = {n.name for n in kept if isinstance(n, ast.FunctionDef)}
        if found_constants != constants or found_functions != functions:
            raise ValueError('Exact pure-source whitelist extraction failed')
        extracted.extend(kept)
    module = ast.fix_missing_locations(ast.Module(body=copy.deepcopy(extracted), type_ignores=[]))
    exec(compile(module, '[pure original scenario input only]', 'exec'), namespace)
    if namespace['N_DEVICES'] != 30 or namespace['T'] != 230 or namespace['DT'] != 1:
        raise ValueError('Original scope/units changed')
    c = namespace['CONTRACT']
    original_contract = dict(qsr_min=c['promotion_criteria']['qsr_min'],
                            device_pdr_min=c['qos_thresholds']['device_pdr_min'],
                            device_latency_max=c['qos_thresholds']['device_p95_latency_max_slots'],
                            blackout_max=c['qos_thresholds']['device_max_blackout_max_slots'],
                            recovery_max=c['promotion_criteria']['recovery_time_max_slots'])
    if original_contract != CANONICAL or c['promotion_criteria']['max_blackout_max_slots'] != 52:
        raise ValueError('Canonical predicates differ from the frozen original contract')
    proof = {'source_hashes': source_hashes,
             'pure_whitelist_function_names': ['clamp', 'is_burst_active', '_case', 'make_scenario_mixed'],
             'pure_extracted_ast_sha256': hashlib.sha256(ast.dump(module, include_attributes=False).encode()).hexdigest(),
             'no_imported_original_runtime': True, 'simulator_calls': 0, 'model_requests': 0}
    return namespace, proof


def weighted_p95(pairs, empty_value):
    if not pairs:
        return float(empty_value)
    target = .95 * sum(volume for delay, volume in pairs)
    accumulated = 0.0
    for delay, volume in sorted(pairs, key=lambda p: p[0]):
        accumulated += volume
        if accumulated >= target:
            return delay
    return pairs[-1][0]


def reconstruct(scene, policy, trace, ns):
    n, horizon = ns['N_DEVICES'], ns['T']
    if len(scene['arrivals']) != horizon or len(trace) != horizon or len(scene['devices']) != n:
        raise ValueError('Saved realized-service scope is incomplete')
    generated = [0.0] * n; delivered = [0.0] * n; queues = [0.0] * n
    fifo = [deque() for _ in range(n)]; delays = [[] for _ in range(n)]
    streak = [0] * n; maximum = [0] * n; logs = []
    comparisons = 0
    for slot, events in enumerate(trace):
        if events['slot'] != slot:
            raise ValueError('Realized service event time/order changed')
        for device, amount in enumerate(scene['arrivals'][slot]):
            if amount > 0:
                generated[device] += amount
                queues[device] += amount
                fifo[device].append([float(slot), float(amount)])
        cluster_queues = {c['id']: sum(queues[i] for i in range(n) if scene['devices'][i]['cluster'] == c['id'])
                          for c in ns['CLUSTERS']}
        cluster_streak = {c['id']: max((streak[i] for i in range(n) if scene['devices'][i]['cluster'] == c['id']), default=0)
                          for c in ns['CLUSTERS']}
        affected_queue = max((cluster_queues[c] for c in scene['affected']), default=0.0)
        affected_streak = max((cluster_streak[c] for c in scene['affected']), default=0)
        if 'aff_backlog' in events:
            if events['aff_backlog'] != affected_queue or events['aff_blackout'] != affected_streak:
                raise ValueError('Exact reconstructed affected log differs from saved event')
            comparisons += 2
        logs.append({'t': slot, 'aff_backlog': affected_queue, 'aff_blackout': affected_streak})
        served = [0.0] * n
        device, amount = events['selected_device_index'], events['delivered_amount']
        if type(amount) not in (int, float) or not math.isfinite(amount) or amount < 0:
            raise ValueError('Saved realized amount is invalid')
        if device is not None:
            if type(device) is not int or not 0 <= device < n:
                raise ValueError('Saved realized device is invalid')
            if events.get('selected_device', device) != scene['devices'][device]['id']:
                raise ValueError('Recorded device ID/index no longer identifies the source device')
            if amount > queues[device] + 1e-9:
                raise ValueError('Recorded service exceeds reconstructed queue')
            served[device] = amount
            queues[device] -= amount
            delivered[device] += amount
            outstanding = amount
            while outstanding > 1e-9 and fifo[device]:
                born, available = fifo[device].popleft()
                taken = min(outstanding, available)
                delays[device].append((float(slot - int(born) + 1), taken))
                outstanding -= taken
                remaining = available - taken
                if remaining > 1e-9:
                    fifo[device].appendleft([born, remaining])
        elif amount != 0:
            raise ValueError('Nonzero service without a recorded selected device')
        for device in range(n):
            streak[device] = streak[device] + 1 if queues[device] > .05 and served[device] <= 1e-12 else 0
            maximum[device] = max(maximum[device], streak[device])
    devices = [{'device_index': i, 'device_id': scene['devices'][i]['id'], 'cluster': scene['devices'][i]['cluster'],
                'generated_amount': generated[i], 'delivered_amount': delivered[i],
                'pdr': delivered[i] / generated[i] if generated[i] > 1e-9 else 1.0,
                'p95_latency_slots': weighted_p95(delays[i], horizon),
                'max_blackout_slots': maximum[i]} for i in range(n)]
    recovery = horizon - ns['PERTURB_START'] + 1
    for start in range(ns['PERTURB_START'], horizon - ns['RECOVERY_HOLD']):
        if all(row['aff_backlog'] <= ns['RECOVERY_BACKLOG_STABLE_MAX']
               and row['aff_blackout'] <= ns['RECOVERY_BLACKOUT_STABLE_MAX']
               for row in logs[start:start + ns['RECOVERY_HOLD']]):
            recovery = start - ns['PERTURB_START'] + 1
            break
    triggers = policy.get('local_triggers') or []
    if isinstance(triggers, dict): triggers = [triggers]
    covered = {item['cluster'] for item in triggers if isinstance(item, dict) and item.get('cluster') in ns['CLUSTER_IDS']}
    coverage = set(scene['affected']).issubset(covered)
    qsr, passed = evaluate(devices, recovery, coverage, CANONICAL)
    metrics = dict(qsr=qsr, recovery_time=recovery, max_blackout=max(maximum),
                   p95_latency=weighted_p95([item for device_delays in delays for item in device_delays], horizon),
                   coverage_pass=coverage, passed_contract=passed)
    return {'devices': devices, 'metrics': metrics, 'logs': logs,
            'exact_event_comparisons': comparisons, 'covered_clusters': sorted(covered),
            'affected_clusters': sorted(scene['affected'])}


def evaluate(devices, recovery, coverage, thresholds):
    satisfied = sum(device['pdr'] >= thresholds['device_pdr_min']
                    and device['p95_latency_slots'] <= thresholds['device_latency_max']
                    and device['max_blackout_slots'] <= thresholds['blackout_max'] for device in devices)
    qsr = satisfied / len(devices)
    accepted = (qsr >= thresholds['qsr_min']
                and max(device['max_blackout_slots'] for device in devices) <= thresholds['blackout_max']
                and recovery <= thresholds['recovery_max'] and coverage)
    return qsr, accepted


def fixtures(ns):
    scene = {'devices': [{'id': i, 'cluster': ns['CLUSTERS'][i//10]['id']} for i in range(30)],
             'arrivals': [[1.0] * 30] + [[0.0] * 30 for _ in range(229)], 'affected': set()}
    trace = [{'slot': t, 'selected_device_index': t if t < 30 else None,
              'delivered_amount': 1.0 if t < 30 else 0.0} for t in range(230)]
    result = reconstruct(scene, {}, trace, ns)
    expected = dict(qsr=1.0, recovery_time=1, max_blackout=29, p95_latency=29.0,
                    coverage_pass=True, passed_contract=True)
    if result['metrics'] != expected:
        raise AssertionError('Hand-constructed FIFO/blackout fixture differs')
    if [d['p95_latency_slots'] for d in result['devices']] != list(range(1,31)):
        raise AssertionError('Per-device FIFO delay differs from known service order')
    latency = dict(CANONICAL, device_latency_max=20)
    qsr, passed = evaluate(result['devices'], 1, True, latency)
    if qsr != 20/30 or passed:
        raise AssertionError('True device latency sensitivity does not recompute QSR')
    if evaluate(result['devices'], 1, True, dict(latency, qsr_min=20/30))[1] is not True:
        raise AssertionError('Exact QSR equality does not pass')
    if evaluate(result['devices'], 1, False, CANONICAL)[1]:
        raise AssertionError('Coverage failure must remain binding')
    return {'status': 'PASS_KNOWN_FIFO_DEVICE_PREDICATE_FIXTURES', 'simulator_calls': 0,
            'known_global_p95': 29, 'known_device_latencies': list(range(1,31))}


def conditions():
    result = []
    for axis, grid in AXES.items():
        for value in grid['values']:
            result.append({'condition_id': f'{axis}={value:g}', 'kind': 'single_axis',
                           'axis': axis, 'value': value, 'diagnostic': axis == 'recovery_max' and value == 159,
                           'main_display': value in grid['main'],
                           'thresholds': dict(CANONICAL, **{axis: value})})
    for qsr, latency, recovery in itertools.product(AXES['qsr_min']['main'], AXES['device_latency_max']['main'], AXES['recovery_max']['main']):
        result.append({'condition_id': f'joint_q{qsr:g}_l{latency}_r{recovery}', 'kind': 'joint_appendix',
                       'axis': 'qsr_latency_recovery', 'value': None, 'diagnostic': False, 'main_display': False,
                       'thresholds': dict(CANONICAL, qsr_min=qsr, device_latency_max=latency, recovery_max=recovery)})
    return result


def latex_table(rows):
    axis_names = {'qsr_min': r'QSR lower bound', 'device_pdr_min': r'Device PDR lower bound',
                  'device_latency_max': r'Device latency (slots)', 'blackout_max': r'Blackout (slots)',
                  'recovery_max': r'Recovery (slots)'}
    lines = [r'\begin{table*}[t]', r'\centering', r'\scriptsize',
             r'\caption{Single-predicate neighborhood readings of the original fixed selected policies. Every entry gives passing counts out of 100 seeds at the three listed values. Device latency, PDR, and common blackout changes first recompute the device-satisfaction fraction; the remaining predicates and structural coverage remain fixed. No recalibration or portfolio reselection is performed.}',
             r'\label{tab:original-fixed-policy-predicates}', r'\setlength{\tabcolsep}{4pt}',
             r'\begin{tabular}{llcccc}', r'\hline',
             r'Scenario & Predicate varied & Values & Compact & Compact+expert & Compact+cached model \\', r'\hline']
    for scenario in SCENARIOS:
        for axis, grid in AXES.items():
            values = '/'.join(f'{value:g}' for value in grid['main'])
            counts = []
            for method in METHODS:
                found = [next(row['passed'] for row in rows if row['scenario']==scenario and row['method']==method
                              and row['kind']=='single_axis' and row['axis']==axis and row['value']==value)
                         for value in grid['main']]
                counts.append('/'.join(map(str, found)))
            lines.append(' & '.join([scenario[:2], axis_names[axis], values, *counts]) + r' \\')
        lines.append(r'\hline')
    lines.extend([r'\end{tabular}', r'\par\smallskip',
                  r'\parbox{0.98\textwidth}{\scriptsize The baseline is PDR $\geq0.70$, device p95 latency $\leq62$ slots, common device/global blackout $\leq52$ slots, QSR $\geq0.70$, and recovery $\leq82$ slots; one slot is 1 s. All wider single-axis values and the predeclared 27-point QSR/latency/recovery grid are retained in the companion CSV. The 159-slot recovery value is a full-horizon diagnostic relaxation, not a deployment deadline. These are boundary readings of 400 matched historical instances across three methods, not new independent effectiveness observations.}',
                  r'\end{table*}', ''])
    return '\n'.join(lines)


def report(summary):
    lines = ['# 原固定策略的多谓词邻域敏感性', '',
             '全部 1200 条已审计的固定策略，按保存的逐槽实际服务 device/amount 和 SHA-256 匹配的原确定性 arrivals 做 FIFO 记账；没有调用 simulator、重新选择动作、请求模型、重新校准或 promotion。原每设备指标、affected-region 日志、全局 metrics 和结构 coverage 精确复现。', '',
             '全网格：33 条单轴条件 + 27 条联合条件，共72000条判据读取。按S1–S4 × 三方法分层，每格100种子。单轴改变 device latency/PDR/blackout 时，先重算三项 device predicate 的 QSR；没有把全局 p95 冒充每设备 tail latency。', '',
             '| 场景 | 谓词 | 预定主三点 | Compact /100 | +expert /100 | +cached model /100 |',
             '|---|---|---|---:|---:|---:|']
    for scenario in SCENARIOS:
        for axis, grid in AXES.items():
            counts = []
            for method in METHODS:
                counts.append('/'.join(str(next(row['passed'] for row in summary['condition_summary']
                    if row['scenario']==scenario and row['method']==method and row['kind']=='single_axis'
                    and row['axis']==axis and row['value']==value)) for value in grid['main']))
            lines.append(f"| {scenario[:2]} | {axis} | " + '/'.join(f'{v:g}' for v in grid['main']) + ' | ' + ' | '.join(counts) + ' |')
    lines.extend(['',
                  '该邻域是在计算通过数前冻结，固定±.05、±10槽及原blackout三点。所有较宽值与联合27格保留；不按模型是否更好选阈值。QSR粒度为1/30，细微比例变化可能对应整数设备数的不同要求。', '',
                  '原S4 sensitivity脚本会在各新门槛下重新promotion存量候选。本分析固定原选中赢家，故应与旧 frozen-candidate re-promotion 表分别说明，不把两者当同一实验逐值对照。', '',
                  '部署口径：现有.70、62、52、82是受控示例合同，不是统一行业阈值。实际服务合同须由数据完整性需求、采样周期、可容忍尾等待/连续无服务时长、受影响区域恢复deadline以及所需覆盖设备比例制定；随后固定所有方法相同门槛。邻域结果只展示给定轨迹的条件性验收，不替代实际业务SLA或阈值标定。', '',
                  '159槽是原未恢复哨兵的诊断放宽，可让没有观察到稳定恢复的轨迹满足数值上界；它不属于主展示的合理deadline，不能据此声称恢复可靠。', '',
                  '完整产物：predicate_readings.csv(72000行)、condition_summary.csv(720行)、per_device_metrics.csv(36000行)、fixed_policy_metrics.csv(1200行)、summary.json、validation.json及20行LaTeX表。基础数据的独立审计与本分析的精确重构检查分开保存；新分析并未增加独立效果观测。', ''])
    return '\n'.join(lines)


def run(root, audit, out):
    root, audit, out = root.resolve(), audit.resolve(), out.resolve()
    if out.exists() or out.is_relative_to(root):
        raise ValueError('Use a fresh analysis output outside measured evidence')
    manifest, completion, underlying_audit = require_audited(root, audit)
    ns, source_proof = pure_original_namespace(manifest)
    manual = fixtures(ns)
    grid = conditions()
    if len(grid) != 60 or sum(c['kind']=='single_axis' for c in grid) != 33:
        raise AssertionError('Predeclared 33+27 condition scope differs')
    initial = {str(PROTOCOL): digest(PROTOCOL), str(Path(__file__).resolve()): digest(Path(__file__)),
               str(root/'manifest.json'): digest(root/'manifest.json'), str(root/'completion.json'): digest(root/'completion.json'),
               str(audit): digest(audit), **source_proof['source_hashes']}
    cell_map = {key.replace('\\','/'): value for key,value in completion['cell_hashes'].items()}
    scene_cache, tallies, metrics_rows = {}, {}, []
    processed = comparisons = readings = device_rows = 0
    out.mkdir(parents=True)
    record_fields = ['scenario','seed','method','cell_sha256','policy_hash','condition_id','kind','axis','value','diagnostic',
                     *CANONICAL,'original_service_pass','new_qsr','coverage_pass','new_service_pass','gain_from_canonical','loss_from_canonical']
    device_fields = ['scenario','seed','method','cell_sha256','policy_hash','device_index','device_id','cluster',
                     'generated_amount','delivered_amount','pdr','p95_latency_slots','max_blackout_slots']
    try:
        with (out/'predicate_readings.csv').open('x',encoding='utf-8',newline='') as rstream, \
                (out/'per_device_metrics.csv').open('x',encoding='utf-8',newline='') as dstream:
            rw,dw=csv.DictWriter(rstream,fieldnames=record_fields),csv.DictWriter(dstream,fieldnames=device_fields)
            rw.writeheader();dw.writeheader()
            for scenario,seed,method in itertools.product(SCENARIOS,range(1,101),METHODS):
                filename=f'{scenario}__{seed:03d}__{method}.json'
                path=root/'cells'/filename
                wanted=cell_map[f'cells/{filename}']
                if digest(path)!=wanted: raise ValueError('Audited cell bytes changed during analysis')
                cell=json.loads(path.read_text(encoding='utf-8'))
                if (cell['scenario'],cell['seed'],cell['method'])!=(scenario,seed,method): raise ValueError('Cell identity changed')
                if (scenario,seed) not in scene_cache:
                    scene_cache[scenario,seed]=ns['make_scenario_mixed'](seed,scenario)
                scene=scene_cache[scenario,seed]
                if canonical_hash(scene)!=cell['scenario_sha256']: raise ValueError('Generated original arrivals/scene identity differs')
                reconstructed=reconstruct(scene,cell['policy'],cell['simulation']['energy_trace'],ns)
                if reconstructed['metrics']!=cell['original_metrics'] or cell['simulation']['metrics']!=cell['original_metrics']:
                    raise ValueError('Exact original metrics reconstruction failed')
                if reconstructed['logs']!=cell['simulation']['trace']: raise ValueError('Exact complete affected-region log reconstruction failed')
                comparisons+=reconstructed['exact_event_comparisons']+len(cell['original_metrics'])+2
                original=cell['original_metrics']['passed_contract']
                ident=dict(scenario=scenario,seed=seed,method=method,cell_sha256=wanted,policy_hash=cell['policy_hash'])
                for device in reconstructed['devices']:
                    dw.writerow({**ident,**device});device_rows+=1
                metrics_rows.append({**ident,**reconstructed['metrics'],'covered_clusters':';'.join(reconstructed['covered_clusters']),
                                     'affected_clusters':';'.join(reconstructed['affected_clusters'])})
                values={}
                for condition in grid:
                    qsr,passed=evaluate(reconstructed['devices'],reconstructed['metrics']['recovery_time'],
                                        reconstructed['metrics']['coverage_pass'],condition['thresholds'])
                    base={key:condition[key] for key in ('condition_id','kind','axis','value','diagnostic')}
                    rw.writerow({**ident,**base,**condition['thresholds'],'original_service_pass':original,'new_qsr':qsr,
                                 'coverage_pass':reconstructed['metrics']['coverage_pass'],'new_service_pass':passed,
                                 'gain_from_canonical':not original and passed,'loss_from_canonical':original and not passed})
                    readings+=1
                    key=scenario,method,condition['condition_id']
                    tally=tallies.setdefault(key,dict(n=0,canonical_passed=0,passed=0,gain_from_canonical=0,loss_from_canonical=0,coverage_passed=0))
                    tally['n']+=1;tally['canonical_passed']+=original;tally['passed']+=passed
                    tally['gain_from_canonical']+=not original and passed;tally['loss_from_canonical']+=original and not passed
                    tally['coverage_passed']+=reconstructed['metrics']['coverage_pass']
                    if condition['kind']=='single_axis': values[condition['axis'],condition['value']]=passed
                for axis,spec in AXES.items():
                    statuses=[values[axis,v] for v in spec['values']]
                    if statuses!=sorted(statuses,reverse=axis in ('qsr_min','device_pdr_min')):
                        raise ValueError('Fixed-policy contract monotonicity failed')
                    comparisons+=1
                processed+=1
                if processed%300==0: print(f'CONTRACT_ANALYSIS_CELLS: {processed}/1200',flush=True)
        if processed!=1200 or device_rows!=36000 or readings!=72000: raise AssertionError('Complete data grains differ')
        rows=[]
        for scenario,method,condition in itertools.product(SCENARIOS,METHODS,grid):
            tally=tallies[scenario,method,condition['condition_id']]
            if tally['n']!=100 or tally['canonical_passed']+tally['gain_from_canonical']-tally['loss_from_canonical']!=tally['passed']:
                raise AssertionError('Matched changes/count partition failed')
            rows.append(dict(scenario=scenario,method=method,**{k:condition[k] for k in ('condition_id','kind','axis','value','diagnostic','main_display')},
                             **condition['thresholds'],**tally,pass_fraction=tally['passed']/100))
        for name,data in [('condition_summary.csv',rows),('fixed_policy_metrics.csv',metrics_rows)]:
            with (out/name).open('x',encoding='utf-8',newline='') as stream:
                writer=csv.DictWriter(stream,fieldnames=list(data[0]));writer.writeheader();writer.writerows(data)
        validation=dict(status='PASS_EXACT_FIXED_POLICY_ACCOUNTING',errors=[],completed_cells=processed,
                        exact_original_metric_cells=processed,exact_scenario_hashes=processed,exact_complete_log_cells=processed,
                        accounting_and_monotonic_checks=comparisons,manual_fixtures=manual,
                        underlying_independent_audit_status=underlying_audit['status'],underlying_independent_audit_sha256=digest(audit),
                        simulator_calls=0,model_requests=0)
        summary=dict(version='original-fixed-policy-contract-neighborhood-1',status='complete',created_utc=datetime.now(timezone.utc).isoformat(),
                     scope=dict(cells=1200,historical_tasks=400,arms=list(METHODS),per_condition_per_arm_per_scenario_n=100,
                                single_axis_conditions=33,joint_conditions=27,predicate_readings=readings,per_device_rows=device_rows,
                                new_simulator_calls=0,new_model_requests=0,new_independent_observations=0),
                     canonical_thresholds=CANONICAL,predeclared_axes=AXES,conditions=grid,condition_summary=rows,
                     input_hashes=initial,cell_hashes=completion['cell_hashes'],source_extraction_proof=source_proof,validation=validation,
                     scope_limits='Fixed original selected policies; exact realized-service accounting, no action/controller replay or reselection. '
                                  'Thresholds are controlled-contract examples, not device/industry SLAs; recovery159 is diagnostic sentinel relaxation. '
                                  'Old S4 table re-promotes cached candidate portfolios and is a different reading.')
        (out/'findings.md').write_text(report(summary),encoding='utf-8')
        (out/'original_fixed_policy_contract_neighborhood_table.tex').write_text(latex_table(rows),encoding='utf-8')
        with (out/'validation.json').open('x',encoding='utf-8') as stream: json.dump(validation,stream,indent=2,ensure_ascii=False,allow_nan=False)
        if {p:digest(p) for p in initial}!=initial: raise ValueError('Frozen analysis/input sources changed')
        summary['output_hashes']={p.name:digest(p) for p in sorted(out.iterdir()) if p.is_file()}
        with (out/'summary.json').open('x',encoding='utf-8') as stream: json.dump(summary,stream,indent=2,ensure_ascii=False,allow_nan=False)
        print(f'CONTRACT_ANALYSIS_FILE: {out/"summary.json"}',flush=True)
        return summary
    except Exception as error:
        with (out/'failure.json').open('x',encoding='utf-8') as stream:
            json.dump(dict(status='failed_preserved',error_type=type(error).__name__,message=str(error),completed_cells=processed,
                           predicate_readings=readings,device_rows=device_rows),stream,ensure_ascii=False,indent=2)
        raise


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT);parser.add_argument('--audit',type=Path,default=AUDIT)
    parser.add_argument('--out',type=Path,default=OUT)
    args=parser.parse_args()
    run(args.root,args.audit,args.out)
