#!/usr/bin/env python3
"""Build a manuscript summary figure for the CASP acceptance boundary."""
from __future__ import annotations

import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch, Rectangle
import numpy as np


HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"
FIGURES = HERE.parents[3] / "figures"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def as_float(row: dict[str, str], key: str) -> float:
    return float(row[key])


def pass_rate_from_rows(rows: list[dict[str, str]], field: str = "passed_contract") -> float:
    vals = [1.0 if str(row[field]).lower() == "true" else 0.0 for row in rows]
    return float(np.mean(vals)) if vals else 0.0


def load_canonical_rates() -> list[tuple[str, float, str]]:
    aggregate = {row["method"]: row for row in read_csv(RESULTS / "aggregate_metrics.csv")}
    strong = {row["method"]: row for row in read_csv(RESULTS / "strong_baselines_summary.csv")}
    diag = {row["method"]: row for row in read_csv(RESULTS / "diagnosis_free_search_summary.csv")}
    robust_casp = {row["method"]: row for row in read_csv(RESULTS / "robust_nominal_casp_summary.csv")}
    hybrid_rows = [row for row in read_csv(RESULTS / "hybrid_ablation_per_seed.csv") if row["backend"] == "hybrid"]

    return [
        ("Static\noptimizer", as_float(aggregate["static_nominal_optimizer"], "contract_pass_rate"), "baseline"),
        ("Diagnosis-free\nsearch", as_float(diag["diagnosis_free_same_budget"], "contract_pass_rate"), "control"),
        ("MPC", as_float(strong["receding_horizon_mpc"], "contract_pass_rate"), "baseline"),
        ("CASP\nLLM+bounded", pass_rate_from_rows(hybrid_rows), "casp"),
        ("Scripted\nCASP", as_float(aggregate["full_closed_loop_workflow"], "contract_pass_rate"), "casp"),
        ("Robust\nscenario set", as_float(strong["robust_scenario_set_optimizer"], "contract_pass_rate"), "robust"),
        ("Robust\n+ CASP", as_float(robust_casp["robust_nominal_plus_casp"], "contract_pass_rate"), "robust"),
    ]


def load_threshold_rows() -> list[dict[str, str]]:
    rows = read_csv(RESULTS / "blackout_threshold_wide.csv")
    keep = {
        "Static optimizer",
        "Diagnosis-free search",
        "Receding-horizon MPC",
        "CASP (LLM+bounded)",
        "Scripted CASP",
        "Robust scenario-set",
        "Robust+CASP replay",
    }
    return [row for row in rows if row["method"] in keep]


def load_structural_summary() -> list[dict[str, str]]:
    return read_csv(RESULTS / "robust_nominal_casp_structural_summary.csv")


def load_lever_summary() -> list[dict[str, str]]:
    return read_csv(RESULTS / "lever_composition_summary.csv")


def style() -> dict[str, str]:
    return {
        "baseline": "#8a8f98",
        "control": "#c98736",
        "casp": "#2868a8",
        "robust": "#4d8b63",
        "fixed": "#9aa0a8",
        "compact": "#6e9dc9",
        "model": "#2c5f9e",
        "route": "#b8c4d0",
        "protocol": "#d59a52",
        "full": "#4777aa",
        "marker": "#25364a",
    }


def panel_label(ax, label: str) -> None:
    ax.text(-0.12, 1.06, label, transform=ax.transAxes, fontsize=9, fontweight="bold", va="top")


def save_all(fig, stem: Path) -> None:
    fig.savefig(f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(f"{stem}.svg", bbox_inches="tight")
    fig.savefig(f"{stem}.png", dpi=600, bbox_inches="tight")
    plt.close(fig)
    print(f"Wrote {stem}.pdf/.svg/.png")


def set_pub_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "pdf.fonttype": 42,
            "svg.fonttype": "none",
            "font.size": 7,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.linewidth": 0.7,
            "xtick.major.width": 0.7,
            "ytick.major.width": 0.7,
            "legend.frameon": False,
        }
    )


def plot_acceptance_boundary_summary() -> None:
    colors = style()
    fig = plt.figure(figsize=(7.15, 5.9))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.0, 1.08], hspace=0.62, wspace=0.30)
    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    ax_c = fig.add_subplot(gs[1, 0])
    ax_d = fig.add_subplot(gs[1, 1])

    # Panel a: canonical admission under one gate.
    canonical = load_canonical_rates()
    labels = [item[0] for item in canonical]
    rates = np.array([item[1] for item in canonical])
    fams = [item[2] for item in canonical]
    y = np.arange(len(labels))
    ax_a.barh(y, rates, color=[colors[f] for f in fams], height=0.62)
    ax_a.axvline(0.52, color="#2b2b2b", lw=0.8, ls=":", alpha=0.8)
    ax_a.set_xlim(0, 1.04)
    ax_a.set_yticks(y)
    ax_a.set_yticklabels(labels)
    ax_a.invert_yaxis()
    ax_a.set_xlabel("Contract pass rate")
    ax_a.set_title("Canonical gate", loc="left", fontsize=8, pad=3)
    ax_a.grid(axis="x", color="#e6e8ec", lw=0.5)
    for yi, value in zip(y, rates):
        ax_a.text(min(value + 0.025, 1.0), yi, f"{value:.2f}", va="center", fontsize=6.6)
    panel_label(ax_a, "a")

    # Panel b: boundary sweep.
    threshold_rows = load_threshold_rows()
    xvals = np.array([46, 48, 50, 52, 54, 56, 58, 60], dtype=float)
    method_style = {
        "Static optimizer": ("Static", "#8a8f98", "-"),
        "Diagnosis-free search": ("Diag-free", "#c98736", "-"),
        "Receding-horizon MPC": ("MPC", "#7d6aa8", "-"),
        "CASP (LLM+bounded)": ("CASP LLM+bounded", "#2868a8", "-"),
        "Scripted CASP": ("Scripted CASP", "#174f87", "--"),
        "Robust scenario-set": ("Robust", "#4d8b63", "-"),
        "Robust+CASP replay": ("Robust+CASP", "#2f6f4a", "--"),
    }
    for row in threshold_rows:
        method = row["method"]
        label, color, ls = method_style[method]
        yvals = np.array([float(row[f"B{int(x)}"]) for x in xvals])
        ax_b.plot(xvals, yvals, color=color, lw=1.35, ls=ls, marker="o", ms=2.6, label=label)
        label_y = {
            "Robust+CASP replay": 1.075,
            "Scripted CASP": 1.010,
            "Receding-horizon MPC": 0.945,
            "Robust scenario-set": 0.880,
            "CASP (LLM+bounded)": 0.655,
            "Diagnosis-free search": 0.525,
            "Static optimizer": 0.245,
        }
        ax_b.annotate(
            label,
            xy=(60.0, yvals[-1]),
            xytext=(60.95, label_y[method]),
            fontsize=5.25,
            color=color,
            va="center",
            ha="left",
            clip_on=False,
            bbox=dict(facecolor="white", edgecolor="none", alpha=0.78, pad=0.3),
            arrowprops=dict(arrowstyle="-", color=color, lw=0.55, alpha=0.65, shrinkA=1.5, shrinkB=2.0),
        )
    ax_b.axvline(52, color="#2b2b2b", lw=0.8, ls=":", alpha=0.8)
    ax_b.text(
        52,
        1.088,
        "canonical",
        va="top",
        ha="center",
        fontsize=5.9,
        color="#333333",
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.80, pad=0.25),
    )
    ax_b.set_xlim(45.5, 64.15)
    ax_b.set_ylim(-0.03, 1.105)
    ax_b.set_xticks(xvals)
    ax_b.set_xlabel(r"$B^{\mathrm{thr}}$ (slots)")
    ax_b.set_ylabel("Pass rate")
    ax_b.set_title("Boundary sensitivity", loc="left", fontsize=8, pad=3)
    ax_b.grid(axis="y", color="#e6e8ec", lw=0.5)
    panel_label(ax_b, "b")

    # Panel c: robust nominal under structural replay.
    summary = load_structural_summary()
    scenarios = [
        ("S1_seen_burst_east", "S1\neast"),
        ("S2_seen_degrade_west", "S2\nwest degr."),
        ("S3_seen_moved_burst", "S3\nmoved"),
        ("S4_heldout_misleading", "S4\nmislead."),
    ]
    methods = [
        ("fixed_robust_nominal", "Fixed robust", colors["fixed"]),
        ("robust_plus_compact_casp", "Robust+compact", colors["compact"]),
        ("robust_plus_rule_model_casp", "Robust+rule/model", colors["model"]),
    ]
    lookup = {(row["setting"], row["method"]): float(row["strict_pass_rate"]) for row in summary}
    x = np.arange(len(scenarios))
    width = 0.25
    for idx, (method, label, color) in enumerate(methods):
        vals = [lookup[(scenario, method)] for scenario, _ in scenarios]
        ax_c.bar(x + (idx - 1) * width, vals, width=width, color=color, label=label)
    ax_c.set_xticks(x)
    ax_c.set_xticklabels([label for _, label in scenarios])
    ax_c.set_ylim(0, 1.08)
    ax_c.set_ylabel("Strict structural pass")
    ax_c.set_title("Robust nominal under structural replay", loc="left", fontsize=8, pad=13)
    ax_c.grid(axis="y", color="#e6e8ec", lw=0.5)
    ax_c.legend(
        fontsize=5.8,
        loc="lower left",
        bbox_to_anchor=(0.0, 1.015),
        ncol=3,
        handlelength=1.45,
        columnspacing=0.82,
        borderaxespad=0.0,
    )
    panel_label(ax_c, "c")

    # Panel d: admitted lever composition.
    lever = load_lever_summary()
    scenario_labels = {
        "S1_seen_burst_east": "S1\neast",
        "S2_seen_degrade_west": "S2\nwest degr.",
        "S3_seen_moved_burst": "S3\nmoved",
        "S4_heldout_misleading": "S4\nmislead.",
    }
    x = np.arange(len(lever))
    route = np.array([float(row["route_dwell"]) for row in lever])
    protocol = np.array([float(row["protocol_trigger"]) for row in lever])
    full = np.array([float(row["full_casp"]) for row in lever])
    model = np.array([float(row["llm_winner"]) for row in lever])
    ax_d.bar(x, route, color=colors["route"], width=0.58, label="Route/dwell")
    ax_d.bar(x, protocol, bottom=route, color=colors["protocol"], width=0.58, label="Protocol-trigger")
    ax_d.bar(x, full, bottom=route + protocol, color=colors["full"], width=0.58, label="Full CASP")
    ax_d.scatter(x, model, color=colors["marker"], marker="D", s=18, label="Model winner", zorder=4)
    for xi, total in zip(x, route + protocol + full):
        ax_d.text(xi, total + 2.0, f"{int(total)}", ha="center", va="bottom", fontsize=6.5)
    ax_d.set_xticks(x)
    ax_d.set_xticklabels([scenario_labels[row["scenario"]] for row in lever])
    ax_d.set_ylim(0, 130)
    ax_d.set_ylabel("Admitted package count")
    ax_d.set_title("Repair levers in admitted packages", loc="left", fontsize=8, pad=3)
    ax_d.grid(axis="y", color="#e6e8ec", lw=0.5)
    ax_d.legend(fontsize=5.6, ncol=2, loc="upper right", handlelength=1.4, columnspacing=0.75)
    panel_label(ax_d, "d")

    fig.suptitle("Acceptance evidence is read at a contract boundary, not as a single optimizer ranking", fontsize=9.2, y=0.995)
    fig.subplots_adjust(top=0.91, bottom=0.08, left=0.095, right=0.985)

    save_all(fig, FIGURES / "acceptance_boundary_summary")


def draw_box(
    ax,
    xy,
    width,
    height,
    title,
    body=None,
    face="#f7f9fb",
    edge="#9aa7b5",
    title_color="#25364a",
    title_size=7.2,
    body_size=5.9,
    body_y_frac=0.48,
    body_style="normal",
):
    box = FancyBboxPatch(
        xy,
        width,
        height,
        boxstyle="round,pad=0.012,rounding_size=0.015",
        linewidth=0.9,
        edgecolor=edge,
        facecolor=face,
    )
    ax.add_patch(box)
    ax.text(
        xy[0] + width * 0.05,
        xy[1] + height * 0.75,
        title,
        fontsize=title_size,
        fontweight="bold",
        color=title_color,
        va="top",
    )
    if body:
        ax.text(
            xy[0] + width * 0.05,
            xy[1] + height * body_y_frac,
            body,
            fontsize=body_size,
            color="#3b4552",
            fontstyle=body_style,
            va="top",
            linespacing=1.16,
        )
    return box


def draw_arrow(ax, start, end, color="#657181", lw=1.0, rad=0.0):
    arrow = FancyArrowPatch(
        start,
        end,
        arrowstyle="-|>",
        mutation_scale=8,
        linewidth=lw,
        color=color,
        connectionstyle=f"arc3,rad={rad}",
    )
    ax.add_patch(arrow)


def plot_nominal_to_validated_bridge() -> None:
    colors = style()
    fig, ax = plt.subplots(figsize=(3.45, 0.96))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    nodes = [
        (0.025, "Nominal QoS", "appears\nsufficient", "#f5f8fb", "#9aa7b5", "#25364a"),
        (0.395, "Contingency", "exposes\ngap", "#fff8ed", "#d59a52", "#8a5a25"),
        (0.765, "CASP gate", "admits replay\nevidence", "#f4faf6", colors["robust"], "#2f6f4a"),
    ]
    y0, width, height = 0.23, 0.210, 0.54
    for x, title, body, face, edge, title_color in nodes:
        box = FancyBboxPatch(
            (x, y0),
            width,
            height,
            boxstyle="round,pad=0.012,rounding_size=0.010",
            linewidth=0.85,
            edgecolor=edge,
            facecolor=face,
        )
        ax.add_patch(box)
        cx = x + width / 2
        ax.text(
            cx,
            y0 + height * 0.62,
            title,
            ha="center",
            va="center",
            fontsize=5.35,
            fontweight="bold",
            color=title_color,
        )
        ax.text(
            cx,
            y0 + height * 0.35,
            body,
            ha="center",
            va="center",
            fontsize=4.55,
            fontstyle="italic",
            color="#3b4552",
            linespacing=1.08,
        )

    draw_arrow(ax, (0.260, 0.50), (0.365, 0.50), color="#25364a", lw=0.95)
    draw_arrow(ax, (0.630, 0.50), (0.735, 0.50), color="#25364a", lw=0.95)
    save_all(fig, FIGURES / "nominal_to_validated_recoverability")


def plot_casp_package_object() -> None:
    colors = style()
    fig, ax = plt.subplots(figsize=(7.15, 3.95))
    ax.set_xlim(0, 1)
    ax.set_ylim(-0.055, 1)
    ax.axis("off")

    ax.text(0.02, 0.965, "CASP turns repair search into an accepted policy package", fontsize=9.0, fontweight="bold", color="#25364a", va="top")
    ax.text(
        0.02,
        0.915,
        "The proposal source is outside the gate; only replayed contract evidence enters the deployed object.",
        fontsize=6.8,
        color="#596575",
        va="top",
    )

    left_x, mid_x, right_x = 0.04, 0.355, 0.69
    draw_box(ax, (left_x, 0.61), 0.235, 0.14, "Executable contract", "QSR, blackout,\nrecovery, per-device QoS", face="#f5f8fb", edge="#9aa7b5")
    draw_box(ax, (left_x, 0.42), 0.235, 0.14, "Nominal policy", "route, dwell,\nprotocol rule", face="#f5f8fb", edge="#9aa7b5")
    draw_box(ax, (left_x, 0.23), 0.235, 0.14, "Contingency envelope", "burst/degradation,\nmoved or conflicting cues", face="#f5f8fb", edge="#9aa7b5")

    gate_y, gate_h = 0.155, 0.645
    gate = FancyBboxPatch((mid_x, gate_y), 0.265, gate_h, boxstyle="round,pad=0.018,rounding_size=0.02", linewidth=1.1, edgecolor=colors["casp"], facecolor="#f3f7fc")
    ax.add_patch(gate)
    ax.text(mid_x + 0.02, 0.765, "Contract replay gate", fontsize=8.0, fontweight="bold", color=colors["casp"])
    inner_h = 0.085
    draw_box(ax, (mid_x + 0.028, 0.610), 0.205, inner_h, "Diagnosis record", "what failed, where,\nwhich cue moved", face="white", edge="#b8c4d0", title_size=6.45, body_size=5.25)
    draw_box(ax, (mid_x + 0.028, 0.475), 0.205, inner_h, "Candidate ledger", "route, dwell, protocol,\ntrigger edits", face="white", edge="#b8c4d0", title_size=6.45, body_size=5.25)
    draw_box(ax, (mid_x + 0.028, 0.340), 0.205, inner_h, "Validation replay", "same seeds, same\ncontract predicates", face="white", edge="#b8c4d0", title_size=6.45, body_size=5.25)
    draw_box(ax, (mid_x + 0.028, 0.205), 0.205, inner_h, "Promotion boundary", "admit, reject, or request\nmission-level change", face="white", edge="#b8c4d0", title_size=6.45, body_size=5.25)

    draw_box(ax, (right_x, 0.61), 0.255, 0.14, "Accepted online rules", "nominal route plus\nvalidated fallback triggers", face="#f4faf6", edge=colors["robust"])
    draw_box(ax, (right_x, 0.42), 0.255, 0.14, "Protocol repair rules", "mode switching and\nhold constraints", face="#f4faf6", edge=colors["robust"])
    draw_box(ax, (right_x, 0.23), 0.255, 0.14, "Replay evidence", "candidate ids, metrics,\nrejection records", face="#f4faf6", edge=colors["robust"])

    for y in [0.68, 0.49, 0.30]:
        draw_arrow(ax, (left_x + 0.235 + 0.010, y), (mid_x - 0.018, y), color="#667386")
    for y in [0.68, 0.49, 0.30]:
        draw_arrow(ax, (mid_x + 0.265 + 0.020, y), (right_x - 0.016, y), color="#667386")
    yellow_y, yellow_h = -0.025, 0.075
    draw_arrow(ax, (0.49, gate_y - 0.022), (0.49, yellow_y + yellow_h + 0.006), color="#8b5e2b", lw=1.15)
    draw_box(ax, (0.345, yellow_y), 0.29, yellow_h, "Not deployed until admitted", "failed candidates remain audit evidence", face="#fff8ed", edge="#d59a52", title_color="#8a5a25", title_size=6.35, body_size=4.8, body_y_frac=0.35)

    ax.text(0.055, 0.115, "before acceptance", fontsize=6.4, color="#6c7583")
    ax.text(0.76, 0.115, "onboard executor", fontsize=6.4, color="#6c7583")
    save_all(fig, FIGURES / "casp_package_object")


def structural_rates() -> dict[tuple[str, str], float]:
    rows = read_csv(RESULTS / "mixed_structural_llm_per_seed.csv")
    lookup = {}
    for scenario in ["S1_seen_burst_east", "S2_seen_degrade_west", "S3_seen_moved_burst", "S4_heldout_misleading"]:
        for method in ["rule_only_portfolio", "hybrid_portfolio", "SR_scripted_mixed_reference"]:
            sub = [row for row in rows if row["scenario"] == scenario and row["method"] == method]
            lookup[(scenario, method)] = pass_rate_from_rows(sub)
    return lookup


def draw_cluster_row(ax, x0, y, cue):
    positions = {"W": x0, "E": x0 + 0.075, "N": x0 + 0.15}
    labels = {"W": "west", "E": "east", "N": "north"}
    for key, x in positions.items():
        circ = Circle((x, y), 0.025, facecolor="#f8fafc", edgecolor="#8d98a6", linewidth=0.8)
        ax.add_patch(circ)
        ax.text(x, y, key, ha="center", va="center", fontsize=6.4, color="#2c3642", fontweight="bold")
        ax.text(x, y - 0.045, labels[key], ha="center", va="top", fontsize=4.9, color="#6f7885")
    for mark, color, label, dy in cue:
        x = positions[mark]
        ax.add_patch(Circle((x + 0.019, y + dy), 0.010, facecolor=color, edgecolor="white", linewidth=0.45))
        ax.text(x + 0.019, y + dy - 0.001, label[0].upper(), ha="center", va="center", fontsize=4.0, color="white", fontweight="bold")


def plot_structural_scenario_map() -> None:
    colors = style()
    rates = structural_rates()
    fig, ax = plt.subplots(figsize=(7.15, 4.9))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.text(0.02, 0.965, "Structural replay asks which evidence cue should move the repair", fontsize=9.2, fontweight="bold", color="#25364a", va="top")
    ax.text(0.02, 0.92, "Each row keeps the same gate, then changes the cue that a deployable repair must explain.", fontsize=6.8, color="#596575")

    cols = [0.035, 0.285, 0.525, 0.765]
    headers = ["Scenario cue", "Evidence reading", "Portfolio pass", "Repair reading"]
    for x, h in zip(cols, headers):
        ax.text(x, 0.86, h, fontsize=7.1, fontweight="bold", color="#25364a")
    ax.plot([0.02, 0.97], [0.835, 0.835], color="#d7dde5", lw=0.8)

    scenario_rows = [
        (
            "S1_seen_burst_east",
            "S1 east burst",
            [("E", "#d9903d", "burst", -0.013), ("E", "#4777aa", "stress", 0.014)],
            "Backlog and link-stress\npoint to the same region.",
            "Compact rules already\ncover this signature.",
        ),
        (
            "S2_seen_degrade_west",
            "S2 west degradation",
            [("W", "#4777aa", "stress", 0.014)],
            "The affected region moves\nfrom east to west.",
            "Protocol-aware candidates\nenter the replay pool.",
        ),
        (
            "S3_seen_moved_burst",
            "S3 moved burst",
            [("N", "#d9903d", "burst", -0.013), ("N", "#4777aa", "stress", 0.014)],
            "The whole failure structure\nmoves with the hotspot.",
            "Model candidate changes\nmany portfolio decisions.",
        ),
        (
            "S4_heldout_misleading",
            "S4 misleading cues",
            [("E", "#d9903d", "backlog", 0.014), ("N", "#4777aa", "stress", 0.014)],
            "Backlog and link-stress\npoint to different regions.",
            "Full CASP and protocol-trigger\nrepairs dominate.",
        ),
    ]

    y_positions = [0.75, 0.57, 0.39, 0.21]
    for (scenario, title, cue, cue_text, lever_text), y in zip(scenario_rows, y_positions):
        ax.text(0.025, y + 0.06, title, fontsize=7.0, fontweight="bold", color="#25364a")
        draw_cluster_row(ax, 0.055, y, cue)
        ax.text(0.285, y + 0.04, cue_text, fontsize=6.1, color="#3b4552", va="top", linespacing=1.15)

        compact = rates[(scenario, "rule_only_portfolio")]
        model = rates[(scenario, "hybrid_portfolio")]
        ref = rates[(scenario, "SR_scripted_mixed_reference")]
        base_x = 0.565
        for idx, (name, val, color) in enumerate(
            [
                ("compact", compact, "#91aecb"),
                ("rule+model", model, colors["model"]),
                ("scripted", ref, "#6ca37d"),
            ]
        ):
            yy = y + 0.04 - idx * 0.038
            ax.add_patch(Rectangle((base_x, yy - 0.013), 0.13 * val, 0.018, facecolor=color, edgecolor="none"))
            ax.text(base_x + 0.138, yy - 0.004, f"{val:.2f}", fontsize=5.6, color="#3b4552", va="center")
            ax.text(base_x - 0.006, yy - 0.004, name, fontsize=5.2, color="#6c7583", ha="right", va="center")
        ax.text(0.765, y + 0.035, lever_text, fontsize=6.1, color="#3b4552", va="top", linespacing=1.15)
        ax.plot([0.02, 0.97], [y - 0.085, y - 0.085], color="#edf0f4", lw=0.7)

    ax.text(0.565, 0.085, "bar length = contract pass rate", fontsize=5.7, color="#6c7583")
    save_all(fig, FIGURES / "structural_scenario_map")


def main() -> None:
    FIGURES.mkdir(parents=True, exist_ok=True)
    set_pub_style()
    plot_acceptance_boundary_summary()
    plot_structural_scenario_map()
    plot_nominal_to_validated_bridge()
    plot_casp_package_object()


if __name__ == "__main__":
    main()
