# Mixed structural-repair experiment runbook

Status: frozen 100-seed evidence bundle. The deterministic preflight, live/replay
LLM records, and analysis checks are retained here with the summary files used
by the manuscript.

## Claim Being Tested

This experiment tests a narrower LLM role than the abandoned two-hotspot C4
idea:

> Given only per-cluster backlog, blackout, and link-stress evidence, can a
> structural backend select the repair target and repair mode, while bounded
> calibration and the service contract still decide admission?

The claim is not that an LLM beats every scripted expert. The clean claim, if
the run supports it, is that model-selected structure can handle a held-out
misleading-evidence case where a max-backlog rule targets the wrong cluster.

## Scenarios

| Type | Split | Hidden condition | Why it exists |
|---|---|---|---|
| S1_seen_burst_east | seen | canonical east burst + link degradation | checks the known CASP pattern |
| S2_seen_degrade_west | seen | west link degradation without burst | checks link-stress evidence |
| S3_seen_moved_burst | seen | burst + degradation moves to west/north | checks moved target localization |
| S4_heldout_misleading | held-out | mild backlog distractor in one cluster, real link-stress repair target in another | checks multi-signal structural selection |

The prompt never receives the hidden scenario type, true target, injected burst
cluster, or injected degradation cluster. It receives only per-cluster evidence.

## Methods

| CSV method | Meaning |
|---|---|
| `B1_max_backlog_route` | choose max-backlog cluster and apply single-target CASP route/dwell repair |
| `B2_max_blackout_protocol` | choose max-blackout cluster and apply protocol-trigger repair |
| `B3_scripted_east_full` | fixed east full-CASP reference |
| `rule_only_portfolio` | validator selects the best candidate from B1/B2/B3 |
| `SR_scripted_mixed_reference` | hand-written multi-signal reference; upper reference, not a target to beat |
| `llm_only_structure` | LLM selects target + repair mode; bounded calibration selects numeric thresholds |
| `hybrid_portfolio` | validator selects the best candidate from B1/B2/B3 plus the LLM candidate |

## Step 1: Deterministic Smoke

```powershell
cd "..\experiments\uav_iot_workflow"
python mixed_structural_suite.py --seeds 5 --out results\mixed_structural_smoke5.csv
```

Current 5-seed smoke shape after adding the portfolio row:

```text
S4_heldout_misleading:
B1=0.00, B2=0.40, B3=0.40, rule_only_portfolio=0.60, SR_reference=0.80
```

If `SR_scripted_mixed_reference` is not clearly above the simple baselines on
S4, stop. That means the scenario is not a clean positive test.

After the portfolio update, `rule_only_portfolio` should be no worse than B1,
B2, or B3 on every matched seed, because it chooses from those candidates using
the same contract-first promotion rule.

## Step 2: Larger Deterministic Preflight

```powershell
$env:UAV_MIXED_N = "30"
python mixed_structural_suite.py --seeds 30 --out results\mixed_structural_clean_det_30seed.csv
```

Optional slower full search:

```powershell
$env:UAV_MIXED_FULL_SEARCH = "1"
python mixed_structural_suite.py --seeds 30 --out results\mixed_structural_clean_det_30seed_fullsearch.csv
Remove-Item Env:\UAV_MIXED_FULL_SEARCH
```

Use full search only for a final clean rerun, not for quick debugging.

## Step 3: Live LLM Run

Set your OpenAI-compatible backend variables first:

```powershell
$env:UAV_LLM_PROVIDER = "openai"
$env:OPENAI_API_KEY = "sk-...."
$env:OPENAI_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
$env:UAV_MIXED_LLM_N = "30"
$env:UAV_LLM_REFRESH = "1"
python run_mixed_structural_llm.py
```

This writes:

```text
results\mixed_structural_llm_per_seed.csv
```

The runner refuses to write synthetic offline LLM rows. It also stops before any
LLM calls if the held-out scripted reference fails the deterministic capacity
check.

## Step 4: Statistics

```powershell
python mixed_structural_stats.py
```

This prints Wilson 95% CIs and held-out exact McNemar comparisons, then writes:

```text
results\mixed_structural_stats_summary.csv
```

## Decision Rule

Only consider this experiment for the manuscript if:

1. `SR_scripted_mixed_reference` is high on S4 under the deterministic clean run.
2. `hybrid_portfolio` is at least as good as both `rule_only_portfolio` and
   `llm_only_structure` on S4. This should hold by construction; if it does not,
   the implementation is wrong.
3. A positive LLM-added result requires `hybrid_portfolio` to exceed
   `rule_only_portfolio` on S4. If they tie, the finding is only that the hybrid
   portfolio preserves reliability, not that the LLM added a held-out win.
4. The prompt and scenario code are frozen before increasing seed count.
5. The result is written as structural-backend evidence, not as a universal LLM
   superiority claim.

If the LLM row does not win cleanly, do not tune the prompt after seeing the
outcome. Leave the experiment out of the paper or report it only as boundary
evidence.
