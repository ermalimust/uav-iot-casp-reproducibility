# 原 S4 同基底候选组合的补充分析

2026-10-07。**关键结果：原紧凑规则＋丰富专家候选通过 77/100，原紧凑规则＋LLM 候选通过 73/100。**本分析没有证实模型优于专家扩充，也没有证明两者统计等效。它澄清了原 0.48→0.73 增量的比较对象，直接对应 Reviewer 2.2。

这是对原冻结结果的事后补充分析，不是新的确认实验。本轮未调用模型、读取 API 配置、联网、运行仿真或生成正式场景。

## 1. 来源核对与分析方式

- [原冻结逐种子记录](F:/my-project/iotj/ZQL_UAV_submission_260708/02_復現_GitHub公開包/02_EVIDENCE_AND_EXPERIMENTS/02_EVIDENCE_AND_EXPERIMENTS/results_frozen_mixed_structural_100seed_20260617/mixed_structural_llm_per_seed.csv)：2,800 行，4 场景×100 种子×7 方法；S4 为 700 行，种子 1–100 均齐全，联结键无重复。
- CSV SHA256：`e2a422c52dad22900e1818540d59ddb607a2a4da97a669d158b3263c10084fba`，与原冻结 `SHA256SUMS.txt` 一致。
- [机器可读分析](F:/my-project/iotj/revision/experiments/results/original_s4_portfolio_analysis/analysis.json)、[逐种子配对结果](F:/my-project/iotj/revision/experiments/results/original_s4_portfolio_analysis/paired_seed_outcomes.csv)、[原模型缓存身份联结](F:/my-project/iotj/revision/experiments/results/original_s4_portfolio_analysis/s4_cache_identity_links.json)已保存，分析绑定 13 项输入来源哈希。
- 原 4 场景、7 方法的通过率全部与冻结统计摘要一致；原 compact 48/100、LLM-only 61/100、hybrid 73/100、专家单候选 66/100 完全匹配。

每个种子共同基底为 B1 max-backlog route、B2 max-blackout protocol、B3 fixed-east full CASP。分别加入既有已校准的专家候选或模型候选，重组合同优先的候选组合。存在一个已记录通过合同的候选，组合就有可选的通过候选，因此通过结果使用原 `passed_contract` 的 OR 精确计算。

必须保留原合同的所有判断，包括 affected 区域的 trigger coverage。不能只根据 CSV 的 QSR、recovery、blackout 三列重新算 pass；例如部分种子的三个数值合格，原结构覆盖仍不合格。

CSV 数值经过圆整，故本分析不将圆整后排名推导的新组合 winner 认定为原全精度排名下的精确 winner。通过 OR 不受这种圆整影响；原模型相对 compact 新增种子的 stored winner 归属则可以直接验证。

## 2. S4 主要结果

| 已有候选的组合 | 结构来源数 | 通过数 /100 | 相对原 compact 新增 |
|---|---:|---:|---:|
| 原 compact：B1＋B2＋B3 | 3 | 48 | — |
| 同基底＋mixed-signal expert | 4 | 77 | 29 |
| 同基底＋LLM | 4 | 73 | 25 |

原单独的 mixed-signal expert 仍是 66/100，原 LLM-only 仍是 61/100。新 77/100 属于“compact＋expert”组合，不能把原图的 0.66 直接改成 0.77 而不改变方法标签。

同基底两个组合的配对结果：

| 配对结果 | 种子数 |
|---|---:|
| 两组均通过 | 72 |
| 仅模型组合通过 | 1 |
| 仅专家组合通过 | 5 |
| 两组均失败 | 22 |

模型减专家的观察差异为 **−4 个百分点**。双侧 exact McNemar 未校正 `p=0.21875`；这是探索性补充对比，不能将不显著解释为统计等效。专家组合的边际 Wilson 95% 区间为 [0.6785, 0.8416]，模型组合为 [0.6357, 0.8073]；这两个边际区间不是配对差异的置信区间。

原 25 个“模型组合通过而 compact 失败”的种子，stored portfolio winner 全部为 `llm_only_structure`。这份对指定 compact 库的增量证据仍然成立。补充分析同时表明，增加一个丰富专家候选可以获得 29 个新增通过；原增量不能据此归因为模型优于丰富专家来源。

## 3. 全部六个不一致种子与局部机制

| 种子 | 支持的组合 | 专家结构 | 模型结构 |
|---|---|---|---|
| 5 | 专家 | west / full_casp | north / full_casp |
| 11 | 专家 | west / full_casp | north / full_casp |
| 12 | 专家 | west / full_casp | north / full_casp |
| 56 | 模型 | north / protocol_trigger | north / full_casp |
| 72 | 专家 | west / full_casp | east / protocol_trigger |
| 83 | 专家 | west / full_casp | north / full_casp |

完整度量见机器分析中的 `s4_discordant_seeds`。上述结构来自原 CSV；完整原合同的通过标志是最终判断依据。

种子 56 是一个实际的局部补充：两者均选择 north，专家因原规则的 backlog 阈值选择 protocol-trigger，恢复时间 102，未通过；模型选择 full-CASP，恢复时间 81、blackout 43、QSR 1，通过。这说明模型曾提出一个专家映射未选中的既有修复模式。

但是，另外五个不一致种子均支持专家组合。种子 56 不能被单独挑出来作为“模型更强”的确认案例；它只解释已报告的一个模式选择差异。模型也没有发明未知动作，这两种模式都属于原接口。

如再把专家与模型都加入 compact，共五个来源，重组通过为 78/100；相对于已包含专家的 77/100，模型仅再增加种子 56 的一个通过。这是另一项更大候选库的描述性诊断，不是相同预算优势。

## 4. 与其他原场景是否一致

| 原场景 | Compact | Compact＋expert | Compact＋LLM |
|---|---:|---:|---:|
| S1 | 98/100 | 98/100 | 98/100 |
| S2 | 94/100 | 100/100 | 100/100 |
| S3 | 69/100 | 88/100 | 88/100 |
| S4 | 48/100 | 77/100 | 73/100 |

前三个场景两个扩充组合逐种子的 pass/fail 完全一致；S4 存在上述六个不一致种子。不同场景共享实验结构，未将 400 行跨场景结果当作新的独立样本来扩大显著性。

## 5. 原成本记录能证明什么

### 5.1 可以绑定的模型用量

S4 的 100 条模型结果均 `parsed_ok=True`、`openai/qwen-plus/live`，没有回退成功混入这组模型结果。按原完整 prompt 身份，可以与原缓存最后的匹配记录 100/100 联结，所选 target/mode 全部一致。

对应最终 100 条匹配响应的 reported usage 为：

- prompt tokens：32,255。
- completion tokens：8,868。
- total tokens：41,123，平均每条 411.23。

原缓存共有 520 行，包含早期与其他场景记录；不能把整个缓存的用量记成 S4 最终 100 种子的成本。上述值仅是匹配响应的 token 报告，不是全部历史尝试的账单；未验证计费金额。

### 5.2 无法从存量结果恢复的实际成本

原逐种子 CSV、缓存没有保存 HTTP elapsed、逐种子校准调用次数、具体参数索引或候选执行台账。原 runner 只将整体耗时打印到控制台，已冻结材料没有对应控制台记录。原完整搜索环境开关也没有作为逐运行身份保存。

因此，实际数值回放次数、模型调用时延、端到端修复时延、专家开发投入均保持 **未知**。不能用本轮读取缓存所花的时间、V11 时间或代码网格上限替代它们。

### 5.3 仅能提供的静态上限

| S4 100 种子中额外来源 | 模式选择次数 | 完整原网格条目上限之和 |
|---|---|---:|
| 专家 | full 70、protocol 30 | 3,510 |
| 模型 | full 95、protocol 3、route 2 | 4,347 |

共同 compact 的原始网格上限之和为 7,500。两组各有四个结构来源，仍不意味着实际数值搜索成本相同；模型更常选择原网格较大的 full 模式。上限不是实测成本，也不能据此判断实际谁更快。

原结构空间总计九种 target/mode、225 个原始网格条目、165 个唯一可执行策略。完整枚举确实是需要认真比较的有限参考；其实际时延没有在本轮测量，不能预设枚举非常昂贵或模型必然更省搜索。

## 6. 对“为什么用 LLM”的判断

本次最直接支持的判断是：**模型能为给定 compact 库提供额外结构候选；已有数据没有证实它优于同基底专家扩充，也没有证实成本优势或降低人工投入。**

这回答了候选来源的作用，但尚未给出必须采用模型的理由。审稿人没有要求证明模型普遍必要；他要求区分可观察的增量与对较简单替代方案的优势。回复应同时呈现原 compact 增量和本次更充分的专家组合对照。

修改稿应继续保留原 CASP 与 S1–S4，补充本分析及其范围。模型定位为可替换的结构提议源，使用理由限于待验证候选来源，而非已证明的性能、效率或工程成本优势。CASP 本身的技术贡献与最近验证框架的区别仍须单独论证，不能由模型候选增益自动推导。

如果继续补成本证据，应预先固定原接口、校准器与记录字段，进行所有对照方法一致的计时/回放预算评价。若要测工程投入，还需实际人员投入记录。不能通过挑选模型独有成功种子、扩大结构空间或不断更换模型，把事后有利案例包装成原方法的确认结果。

## 7. 本轮交付与保全

新增 [可重算的补充分析](F:/my-project/iotj/revision/experiments/analyze_original_s4_portfolios.py)与上述结果文件。分析前后 13 项输入的 SHA256 一致，原冻结结果、源代码与缓存保留。独立代理逐种子复算的主要计数与 exact McNemar 值一致。

已将这项结果同步至 R2.2 回复、工作正文 VI-D 的补充分析段、摘要/Discussion/Conclusion 的局部表述，以及新增补充表。方法与原表保留。具体差异、备份和当前编译限制见[最小修改记录](F:/my-project/iotj/revision/Original_S4_Response_Changes_20261007.md)。

本报告中的新组合结果均标为事后补充分析，不替换原方法标签、原 0.66 专家单候选或原 0.73 模型组合记录。
