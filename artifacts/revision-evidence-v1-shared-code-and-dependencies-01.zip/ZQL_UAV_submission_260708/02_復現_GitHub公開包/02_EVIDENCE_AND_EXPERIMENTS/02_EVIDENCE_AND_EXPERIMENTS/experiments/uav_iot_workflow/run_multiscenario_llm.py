#!/usr/bin/env python3
"""
LLM localization for moved-hotspot generalization.

This script evaluates the structural step used in Section VI: given only
per-cluster evidence from a failed nominal run, can a live LLM identify the
affected cluster before bounded calibration repairs that cluster?

It intentionally localizes first and calibrates second. The prompt never
contains the ground-truth hotspot label; it contains only evidence computed
from simulator logs. Results are cached through the existing OpenAI-compatible
client stack, but this script refuses to run without a real API key so
synthetic fallback rows cannot be mistaken for LLM evidence.
"""
from __future__ import annotations

import csv
import json
import os
from pathlib import Path
from typing import Any

from llm_repair_agent import extract_json, make_client
from multiscenario import calibrate_ms, make_scenario_ms, simulate_ms
from run_uav_iot_workflow_experiment import CLUSTERS, route_policy


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
ALLOWED = [c["id"] for c in CLUSTERS]

SYSTEM = """\
You are a UAV-IoT failure-localization agent. A single UAV served three IoT
device clusters. A traffic burst plus regional link degradation affected one
cluster, but the cluster name is hidden. You receive only per-cluster evidence
from the failed nominal run. Identify the affected cluster.

Allowed cluster ids: west_cluster, east_hotspot, north_cluster.

Return one JSON object only:
{"affected_cluster": "<one allowed cluster id>", "rationale": "<brief reason>"}
"""


def _preflight() -> None:
    provider = os.environ.get("UAV_LLM_PROVIDER", "auto").lower()
    has_openai = bool(os.environ.get("OPENAI_API_KEY"))
    has_anthropic = bool(os.environ.get("ANTHROPIC_API_KEY"))
    if provider == "openai" and not has_openai:
        raise SystemExit("OPENAI_API_KEY is not set.")
    if provider == "anthropic" and not has_anthropic:
        raise SystemExit("ANTHROPIC_API_KEY is not set.")
    if provider in {"auto", ""} and not (has_openai or has_anthropic):
        raise SystemExit(
            "No API key detected. Set OPENAI_API_KEY or ANTHROPIC_API_KEY; "
            "this script does not use the synthetic offline fallback."
        )
    os.environ.setdefault("UAV_LLM_CACHE", str(RESULTS / "multiscenario_llm_cache.jsonl"))


def _cluster_evidence(scenario: dict[str, Any], nominal_result: dict[str, Any]) -> dict[str, Any]:
    devices = scenario["devices"]
    peak = nominal_result["peak_backlog"]
    max_blackout = {}
    for cluster in ALLOWED:
        idx = [i for i, d in enumerate(devices) if d["cluster"] == cluster]
        max_blackout[cluster] = max(nominal_result["device_max_blackout"][i] for i in idx)
    return {
        cluster: {
            "peak_post_perturb_backlog": round(float(peak[cluster]), 4),
            "max_device_blackout_slots": int(max_blackout[cluster]),
        }
        for cluster in ALLOWED
    }


def _localize(client: Any, evidence: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    user = (
        "Per-cluster evidence from the nominal failed run:\n"
        + json.dumps(evidence, indent=2)
        + "\n\nReturn the affected cluster JSON."
    )
    res = client.complete(SYSTEM, user)
    action = extract_json(res.text) or {}
    pred = action.get("affected_cluster")
    if pred not in ALLOWED:
        # Keep the row auditable; choose a deterministic invalid fallback only
        # so the downstream validation can finish.
        pred = max(evidence, key=lambda c: evidence[c]["peak_post_perturb_backlog"])
        parsed_ok = False
    else:
        parsed_ok = True
    return pred, {
        "provider": res.provider,
        "model": res.model,
        "mode": res.mode,
        "parsed_ok": parsed_ok,
        "predicted_cluster": pred,
        "rationale": str(action.get("rationale", ""))[:300],
        "usage": res.usage,
    }


def main() -> None:
    _preflight()
    RESULTS.mkdir(parents=True, exist_ok=True)

    seeds = list(range(1, int(os.environ.get("UAV_MULTI_LLM_N", "30")) + 1))
    hotspots = ["east_hotspot", "west_cluster", "north_cluster"]
    nominal = route_policy(
        "nom",
        ["west_cluster", "east_hotspot", "north_cluster"],
        [12, 12, 12],
        "best_rate",
    )
    client = make_client()

    rows: list[dict[str, Any]] = []
    for hot in hotspots:
        for seed in seeds:
            scenario = make_scenario_ms(seed, True, hot)
            nominal_result = simulate_ms(scenario, nominal)
            evidence = _cluster_evidence(scenario, nominal_result)
            pred, info = _localize(client, evidence)
            repaired = calibrate_ms(scenario, pred)
            m = repaired["metrics"]
            rows.append({
                "hotspot": hot,
                "seed": seed,
                "predicted_cluster": pred,
                "localization_hit": pred == hot,
                "qsr": m["qsr"],
                "recovery_time": m["recovery_time"],
                "max_blackout": m["max_blackout"],
                "p95_latency": m["p95_latency"],
                "passed_contract": m["passed_contract"],
                "mode": info["mode"],
                "provider": info["provider"],
                "model": info["model"],
                "parsed_ok": info["parsed_ok"],
                "rationale": info["rationale"],
                "evidence_json": json.dumps(evidence, sort_keys=True),
            })
            print(
                f"{hot:<13} seed={seed:02d} pred={pred:<13} "
                f"hit={pred == hot!s:<5} pass={m['passed_contract']} mode={info['mode']}"
            )

    per_seed = RESULTS / "multiscenario_llm_30seed_per_seed.csv"
    with per_seed.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    summary_rows = []
    for hot in hotspots:
        sub = [r for r in rows if r["hotspot"] == hot]
        n = len(sub)
        summary_rows.append({
            "hotspot": hot,
            "n": n,
            "localization_hits": sum(1 for r in sub if r["localization_hit"]),
            "localization_rate": sum(1 for r in sub if r["localization_hit"]) / n,
            "contract_pass_rate": sum(1 for r in sub if r["passed_contract"]) / n,
            "modes": json.dumps(sorted(set(r["mode"] for r in sub))),
        })
    summary = RESULTS / "multiscenario_llm_30seed_summary.csv"
    with summary.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
        writer.writeheader()
        writer.writerows(summary_rows)

    print("\nSummary")
    for r in summary_rows:
        print(r)
    print(f"\nWrote {per_seed}")
    print(f"Wrote {summary}")


if __name__ == "__main__":
    main()
