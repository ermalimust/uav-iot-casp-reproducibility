#!/usr/bin/env python3
"""Replay a second LLM backend from a frozen JSONL cache.

This script does not call a live model. It fails if any prompt is absent from
the cache, so the resulting rows cannot silently fall back to synthetic output.
"""
from __future__ import annotations

import csv
import json
import os
import statistics
import time
from pathlib import Path
from typing import Any

from llm_repair_agent import CachingClient, LLMResult, run_llm_closed_loop
from run_hybrid_ablation import calibrate, structure_from_policy
from run_uav_iot_workflow_experiment import (
    RESULTS,
    make_scenario,
    optimize_nominal_policy,
)


class _InnerIdentity:
    provider = "openai"

    def __init__(self, model: str) -> None:
        self.model = model


class StrictReplayClient:
    def __init__(self, cache_path: Path, model: str) -> None:
        self.inner = _InnerIdentity(model)
        self.provider = self.inner.provider
        self.model = model
        self.cache_path = cache_path
        self.cache: dict[str, dict[str, Any]] = {}
        for line in cache_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            self.cache[rec["key"]] = rec

    def complete(self, system: str, user: str) -> LLMResult:
        key = CachingClient._key(self.provider, self.model, system, user)
        if key not in self.cache:
            raise RuntimeError(
                f"Missing frozen-cache entry for provider={self.provider}, "
                f"model={self.model}, key={key}. No live model call was made."
            )
        rec = self.cache[key]
        return LLMResult(
            rec["text"],
            provider=rec.get("provider", self.provider),
            model=rec.get("model", self.model),
            mode="replay",
            raw=rec.get("raw"),
            usage=rec.get("usage"),
        )


def _row(model: str, backend: str, seed: int, result: dict[str, Any]) -> dict[str, Any]:
    m = result["metrics"]
    return {
        "model": model,
        "backend": backend,
        "seed": seed,
        "qsr": m["qsr"],
        "recovery_time": m["recovery_time"],
        "max_blackout": m["max_blackout"],
        "p95_latency": m["p95_latency"],
        "passed_contract": m["passed_contract"],
    }


def _aggregate(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for backend in sorted({r["backend"] for r in rows}):
        sub = [r for r in rows if r["backend"] == backend]
        item: dict[str, Any] = {"model": sub[0]["model"], "backend": backend, "n": len(sub)}
        for key in ("qsr", "recovery_time", "max_blackout", "p95_latency"):
            vals = [float(r[key]) for r in sub]
            item[f"{key}_mean"] = round(statistics.mean(vals), 5)
            item[f"{key}_median"] = round(statistics.median(vals), 5)
            item[f"{key}_std"] = round(statistics.stdev(vals), 5) if len(vals) > 1 else 0.0
        item["contract_pass_rate"] = round(
            statistics.mean(1.0 if str(r["passed_contract"]) == "True" else 0.0 for r in sub),
            5,
        )
        out.append(item)
    return out


def main() -> None:
    t0 = time.time()
    model = os.environ.get("UAV_SECOND_LLM_MODEL", "qwen-max")
    seeds = list(range(1, int(os.environ.get("UAV_SECOND_LLM_SEEDS", "100")) + 1))
    cache_path = Path(
        os.environ.get("UAV_SECOND_LLM_CACHE", str(RESULTS / "llm_cache_qwenmax_v2.jsonl"))
    )
    if not cache_path.is_absolute():
        cache_path = Path.cwd() / cache_path
    client = StrictReplayClient(cache_path, model)

    print("=" * 72)
    print(f"Second LLM replay: {model}")
    print("=" * 72)
    print(f"  cache = {cache_path}")
    print(f"  seeds = {seeds[0]}..{seeds[-1]}")

    rows: list[dict[str, Any]] = []
    replay_calls = 0
    for seed in seeds:
        perturbed = make_scenario(seed, perturbation=True)
        base = optimize_nominal_policy(seed, make_scenario(seed, perturbation=False))
        loop = run_llm_closed_loop(seed, perturbed, base, client=client, max_iters=3)
        modes = [r.get("agent_io", {}).get("mode") for r in loop["records"][1:]]
        if any(mode != "replay" for mode in modes):
            raise RuntimeError(f"Non-replay mode observed for seed {seed}: {modes}")
        replay_calls += len(modes)
        rows.append(_row(model, "pure_llm", seed, loop["final_result"]))
        _, hybrid_result = calibrate(perturbed, structure_from_policy(loop["final_policy"]))
        rows.append(_row(model, "hybrid_llm_bounded", seed, hybrid_result))
        if seed % 10 == 0:
            print(f"  replayed seed {seed}/{seeds[-1]}", end="\r")
    print()

    out_per_seed = RESULTS / f"second_llm_{model.replace('-', '')}_per_seed.csv"
    with out_per_seed.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    summary = _aggregate(rows)
    out_summary = RESULTS / f"second_llm_{model.replace('-', '')}_summary.csv"
    with out_summary.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
        w.writeheader()
        w.writerows(summary)

    print(f"replay calls = {replay_calls}")
    print(f"per-seed CSV -> {out_per_seed}")
    print(f"summary CSV  -> {out_summary}")
    for item in summary:
        print(
            f"  {item['backend']:<20} QSR={item['qsr_mean']:.3f} "
            f"rec={item['recovery_time_mean']:.2f} "
            f"Bmax={item['max_blackout_mean']:.2f} "
            f"pass={item['contract_pass_rate']:.2f}"
        )
    print(f"[{time.time() - t0:.1f}s]")


if __name__ == "__main__":
    main()
