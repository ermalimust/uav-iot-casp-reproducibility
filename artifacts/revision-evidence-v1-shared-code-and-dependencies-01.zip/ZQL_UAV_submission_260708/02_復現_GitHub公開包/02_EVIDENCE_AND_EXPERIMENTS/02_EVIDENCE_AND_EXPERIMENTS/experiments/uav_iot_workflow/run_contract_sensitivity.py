#!/usr/bin/env python3
"""Contract-boundary and promotion-weight sensitivity for the UAV-IoT study.

The script is intentionally replay-only: it reads per-seed metrics and the
candidate ledger already produced by the workflow experiments, then recomputes
acceptance decisions under nearby contract thresholds and promotion weights.
"""

from __future__ import annotations

import csv
import json
import argparse
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, median
from typing import Any


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"

DEFAULT_QSR_THR = 0.70
DEFAULT_BLACKOUT_THR = 52.0
DEFAULT_RECOVERY_BOUND = 82.0


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    target = path
    try:
        handle = target.open("w", newline="", encoding="utf-8")
    except PermissionError:
        target = path.with_name(f"{path.stem}_generated{path.suffix}")
        handle = target.open("w", newline="", encoding="utf-8")
        print(f"Target locked, wrote fallback CSV: {target}")
    with handle as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return target


def f(row: dict[str, Any], field: str) -> float:
    return float(row[field])


def passed(row: dict[str, Any], qsr_thr: float, blackout_thr: float, recovery_bound: float) -> bool:
    return (
        f(row, "qsr") >= qsr_thr
        and f(row, "max_blackout") <= blackout_thr
        and f(row, "recovery_time") <= recovery_bound
    )


def load_method_rows() -> dict[str, list[dict[str, Any]]]:
    methods: dict[str, list[dict[str, Any]]] = defaultdict(list)

    summary_method_labels = {
        "static_nominal_optimizer": "Static optimizer",
        "workflow_no_casp_triggers": "No CASP trigger",
        "full_closed_loop_workflow": "Scripted CASP",
    }
    for row in read_csv(RESULTS / "summary_metrics.csv"):
        label = summary_method_labels.get(row["method"])
        if label:
            methods[label].append(row)

    hybrid_labels = {
        "hybrid": "CASP (LLM+bounded)",
        "pure_llm": "Pure LLM",
    }
    for row in read_csv(RESULTS / "hybrid_ablation_per_seed.csv"):
        label = hybrid_labels.get(row["backend"])
        if label:
            methods[label].append(row)

    strong_labels = {
        "receding_horizon_mpc": "Receding-horizon MPC",
        "robust_scenario_set_optimizer": "Robust scenario-set optimizer",
    }
    for row in read_csv(RESULTS / "strong_baselines_per_seed.csv"):
        label = strong_labels.get(row["method"])
        if label:
            methods[label].append(row)

    diagnosis_free_path = RESULTS / "diagnosis_free_search_per_seed.csv"
    if diagnosis_free_path.exists():
        for row in read_csv(diagnosis_free_path):
            methods["Diagnosis-free same-budget search"].append(row)

    robust_casp_path = RESULTS / "robust_nominal_casp_per_seed.csv"
    if robust_casp_path.exists():
        for row in read_csv(robust_casp_path):
            if row.get("method") == "robust_nominal_plus_casp":
                methods["Robust nominal + CASP replay"].append(row)

    return dict(methods)


def summarize_threshold(
    methods: dict[str, list[dict[str, Any]]],
    sweep: str,
    qsr_thr: float,
    blackout_thr: float,
    recovery_bound: float,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for method, records in methods.items():
        pass_count = sum(passed(r, qsr_thr, blackout_thr, recovery_bound) for r in records)
        rows.append(
            {
                "sweep": sweep,
                "method": method,
                "n": len(records),
                "qsr_threshold": qsr_thr,
                "blackout_threshold": blackout_thr,
                "recovery_bound": recovery_bound,
                "pass_rate": round(pass_count / len(records), 4),
                "qsr_median": round(median(f(r, "qsr") for r in records), 4),
                "recovery_median": round(median(f(r, "recovery_time") for r in records), 2),
                "max_blackout_median": round(median(f(r, "max_blackout") for r in records), 2),
            }
        )
    return rows


def contract_sensitivity() -> list[dict[str, Any]]:
    methods = load_method_rows()
    rows: list[dict[str, Any]] = []

    for qsr_thr in [0.60, 0.70, 0.80, 0.90, 0.95, 1.00]:
        rows.extend(
            summarize_threshold(
                methods,
                sweep="qsr_threshold",
                qsr_thr=qsr_thr,
                blackout_thr=DEFAULT_BLACKOUT_THR,
                recovery_bound=DEFAULT_RECOVERY_BOUND,
            )
        )

    for blackout_thr in [46.0, 48.0, 50.0, 52.0, 54.0, 56.0, 58.0, 60.0]:
        rows.extend(
            summarize_threshold(
                methods,
                sweep="blackout_threshold",
                qsr_thr=DEFAULT_QSR_THR,
                blackout_thr=blackout_thr,
                recovery_bound=DEFAULT_RECOVERY_BOUND,
            )
        )

    for recovery_bound in [40.0, 60.0, 82.0, 100.0, 120.0, 159.0]:
        rows.extend(
            summarize_threshold(
                methods,
                sweep="recovery_bound",
                qsr_thr=DEFAULT_QSR_THR,
                blackout_thr=DEFAULT_BLACKOUT_THR,
                recovery_bound=recovery_bound,
            )
        )

    return rows


def load_s4_rows() -> dict[str, list[dict[str, Any]]]:
    from mixed_structural_suite import make_scenario_mixed

    method_labels = {
        "B1_max_backlog_route": "B1_max_backlog_route",
        "B2_max_blackout_protocol": "B2_max_blackout_protocol",
        "B3_scripted_east_full": "B3_scripted_east_full",
        "llm_only_structure": "LLM-only structure",
        "SR_scripted_mixed_reference": "Hand-written mixed-signal reference",
    }
    methods: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in read_csv(RESULTS / "mixed_structural_llm_per_seed.csv"):
        if row["scenario"] != "S4_heldout_misleading":
            continue
        label = method_labels.get(row["method"])
        if label:
            enriched = dict(row)
            enriched["true_target"] = make_scenario_mixed(
                int(row["seed"]),
                row["scenario"],
            )["target"]
            methods[label].append(enriched)
    return dict(methods)


def s4_covered(row: dict[str, Any]) -> bool:
    return str(row.get("selected_target", "")) == str(row.get("true_target", ""))


def s4_passed(row: dict[str, Any], qsr_thr: float, blackout_thr: float, recovery_bound: float) -> bool:
    return passed(row, qsr_thr, blackout_thr, recovery_bound) and s4_covered(row)


def s4_promotion_key(
    row: dict[str, Any],
    qsr_thr: float,
    blackout_thr: float,
    recovery_bound: float,
) -> tuple:
    return (
        1 if s4_passed(row, qsr_thr, blackout_thr, recovery_bound) else 0,
        f(row, "qsr"),
        -f(row, "recovery_time"),
        -f(row, "max_blackout"),
    )


def s4_eval_methods(
    methods: dict[str, list[dict[str, Any]]],
    qsr_thr: float,
    blackout_thr: float,
    recovery_bound: float,
) -> dict[str, list[dict[str, Any]]]:
    by_seed: dict[int, dict[str, dict[str, Any]]] = defaultdict(dict)
    for method, records in methods.items():
        for row in records:
            by_seed[int(row["seed"])][method] = row

    evaluated: dict[str, list[dict[str, Any]]] = defaultdict(list)
    compact_methods = ["B1_max_backlog_route", "B2_max_blackout_protocol", "B3_scripted_east_full"]
    hybrid_methods = compact_methods + ["LLM-only structure"]

    for seed in sorted(by_seed):
        rows = by_seed[seed]
        compact = max(
            [rows[m] for m in compact_methods if m in rows],
            key=lambda r: s4_promotion_key(r, qsr_thr, blackout_thr, recovery_bound),
        )
        hybrid = max(
            [rows[m] for m in hybrid_methods if m in rows],
            key=lambda r: s4_promotion_key(r, qsr_thr, blackout_thr, recovery_bound),
        )
        evaluated["Compact rule portfolio"].append(compact)
        evaluated["Rule+model portfolio"].append(hybrid)
        evaluated["LLM-only structure"].append(rows["LLM-only structure"])
        evaluated["Hand-written mixed-signal reference"].append(rows["Hand-written mixed-signal reference"])
    return dict(evaluated)


def summarize_s4_threshold(
    methods: dict[str, list[dict[str, Any]]],
    sweep: str,
    qsr_thr: float,
    blackout_thr: float,
    recovery_bound: float,
) -> list[dict[str, Any]]:
    evaluated = s4_eval_methods(methods, qsr_thr, blackout_thr, recovery_bound)
    rows: list[dict[str, Any]] = []
    for method, records in evaluated.items():
        pass_count = sum(s4_passed(r, qsr_thr, blackout_thr, recovery_bound) for r in records)
        covered_count = sum(s4_covered(r) for r in records)
        rows.append(
            {
                "sweep": sweep,
                "method": method,
                "n": len(records),
                "qsr_threshold": qsr_thr,
                "blackout_threshold": blackout_thr,
                "recovery_bound": recovery_bound,
                "pass_rate": round(pass_count / len(records), 4),
                "pass_count": pass_count,
                "coverage_rate": round(covered_count / len(records), 4),
                "qsr_median": round(median(f(r, "qsr") for r in records), 4),
                "recovery_median": round(median(f(r, "recovery_time") for r in records), 2),
                "max_blackout_median": round(median(f(r, "max_blackout") for r in records), 2),
            }
        )
    return rows


def s4_contract_sensitivity() -> list[dict[str, Any]]:
    """Full S4 threshold sensitivity over replayed candidates.

    The S4 contract contains both metric gates and structural coverage of the
    affected cluster.  The per-seed CSV stores selected targets, while the S4
    target is deterministic from the seed; together they let us recompute the
    same structural gate over nearby thresholds without another LLM call.
    """
    methods = load_s4_rows()
    rows: list[dict[str, Any]] = []

    for qsr_thr in [0.70, 0.95, 1.00]:
        rows.extend(
            summarize_s4_threshold(
                methods,
                sweep="qsr_threshold",
                qsr_thr=qsr_thr,
                blackout_thr=DEFAULT_BLACKOUT_THR,
                recovery_bound=DEFAULT_RECOVERY_BOUND,
            )
        )

    for blackout_thr in [50.0, 52.0, 54.0]:
        rows.extend(
            summarize_s4_threshold(
                methods,
                sweep="blackout_threshold",
                qsr_thr=DEFAULT_QSR_THR,
                blackout_thr=blackout_thr,
                recovery_bound=DEFAULT_RECOVERY_BOUND,
            )
        )

    for recovery_bound in [60.0, 82.0, 159.0]:
        rows.extend(
            summarize_s4_threshold(
                methods,
                sweep="recovery_bound",
                qsr_thr=DEFAULT_QSR_THR,
                blackout_thr=DEFAULT_BLACKOUT_THR,
                recovery_bound=recovery_bound,
            )
        )

    return rows


def candidate_family(candidate_id: str) -> str:
    if candidate_id.endswith("_nominal"):
        return "nominal"
    if candidate_id.endswith("_dwell_repair"):
        return "route_only"
    if candidate_id.endswith("_casp"):
        return "route_protocol_trigger"
    return candidate_id


PROMOTION_VARIANTS: dict[str, dict[str, float]] = {
    "default": {
        "pass": 12.0,
        "qsr": 105.0,
        "pdr": 22.0,
        "recovery": 0.22,
        "blackout": 0.36,
        "latency": 0.08,
        "energy": 0.003,
        "switch": 0.03,
        "trigger_bonus": 2.0,
    },
    "recovery_heavy": {
        "pass": 12.0,
        "qsr": 105.0,
        "pdr": 22.0,
        "recovery": 0.44,
        "blackout": 0.36,
        "latency": 0.08,
        "energy": 0.003,
        "switch": 0.03,
        "trigger_bonus": 2.0,
    },
    "blackout_heavy": {
        "pass": 12.0,
        "qsr": 105.0,
        "pdr": 22.0,
        "recovery": 0.22,
        "blackout": 0.72,
        "latency": 0.08,
        "energy": 0.003,
        "switch": 0.03,
        "trigger_bonus": 2.0,
    },
    "qsr_heavy": {
        "pass": 12.0,
        "qsr": 140.0,
        "pdr": 22.0,
        "recovery": 0.22,
        "blackout": 0.36,
        "latency": 0.08,
        "energy": 0.003,
        "switch": 0.03,
        "trigger_bonus": 2.0,
    },
    "energy_switch_heavy": {
        "pass": 12.0,
        "qsr": 105.0,
        "pdr": 22.0,
        "recovery": 0.22,
        "blackout": 0.36,
        "latency": 0.08,
        "energy": 0.009,
        "switch": 0.09,
        "trigger_bonus": 2.0,
    },
    "no_trigger_bonus": {
        "pass": 12.0,
        "qsr": 105.0,
        "pdr": 22.0,
        "recovery": 0.22,
        "blackout": 0.36,
        "latency": 0.08,
        "energy": 0.003,
        "switch": 0.03,
        "trigger_bonus": 0.0,
    },
}


def promotion_score(record: dict[str, Any], weights: dict[str, float]) -> float:
    metrics = record["metrics"]
    policy = record["policy"]
    has_trigger = bool(policy.get("local_triggers"))
    return (
        weights["pass"] * float(metrics["passed_contract"])
        + weights["qsr"] * float(metrics["qsr"])
        + weights["pdr"] * float(metrics["pdr"])
        - weights["recovery"] * float(metrics["recovery_time"])
        - weights["blackout"] * float(metrics["max_blackout"])
        - weights["latency"] * float(metrics["p95_latency"])
        - weights["energy"] * float(metrics["energy_used"])
        - weights["switch"] * float(metrics["switch_count"])
        + weights["trigger_bonus"] * float(has_trigger)
    )


def promotion_weight_sensitivity() -> list[dict[str, Any]]:
    by_seed: dict[int, list[dict[str, Any]]] = defaultdict(list)
    with (RESULTS / "candidate_records.jsonl").open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                record = json.loads(line)
                by_seed[int(record["seed"])].append(record)

    rows: list[dict[str, Any]] = []
    for variant, weights in PROMOTION_VARIANTS.items():
        selected: list[dict[str, Any]] = []
        for seed in sorted(by_seed):
            candidates = by_seed[seed]
            selected.append(max(candidates, key=lambda r: promotion_score(r, weights)))

        counts = Counter(candidate_family(r["candidate_id"]) for r in selected)
        pass_count = sum(bool(r["metrics"]["passed_contract"]) for r in selected)
        rows.append(
            {
                "variant": variant,
                "n": len(selected),
                "pass_rate": round(pass_count / len(selected), 4),
                "selected_nominal": counts["nominal"],
                "selected_route_only": counts["route_only"],
                "selected_route_protocol_trigger": counts["route_protocol_trigger"],
                "qsr_mean": round(mean(float(r["metrics"]["qsr"]) for r in selected), 4),
                "recovery_median": round(median(float(r["metrics"]["recovery_time"]) for r in selected), 2),
                "blackout_median": round(median(float(r["metrics"]["max_blackout"]) for r in selected), 2),
            }
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--s4-only",
        action="store_true",
        help="Only regenerate S4 contract sensitivity outputs.",
    )
    args = parser.parse_args()

    if not args.s4_only:
        contract_rows = contract_sensitivity()
        contract_path = write_csv(
            RESULTS / "contract_sensitivity.csv",
            contract_rows,
            [
                "sweep",
                "method",
                "n",
                "qsr_threshold",
                "blackout_threshold",
                "recovery_bound",
                "pass_rate",
                "qsr_median",
                "recovery_median",
                "max_blackout_median",
            ],
        )
    else:
        contract_path = RESULTS / "contract_sensitivity.csv"

    s4_rows = s4_contract_sensitivity()
    s4_path = write_csv(
        RESULTS / "s4_contract_sensitivity.csv",
        s4_rows,
        [
            "sweep",
            "method",
            "n",
            "qsr_threshold",
            "blackout_threshold",
            "recovery_bound",
            "pass_rate",
            "pass_count",
            "coverage_rate",
            "qsr_median",
            "recovery_median",
            "max_blackout_median",
        ],
    )
    s4_core_path = write_csv(
        RESULTS / "s4_core_predicate_sensitivity.csv",
        [
            {
                "status": "superseded",
                "note": "full S4 threshold sensitivity is now written to s4_contract_sensitivity.csv with structural target coverage included",
            }
        ],
        ["status", "note"],
    )

    promotion_rows: list[dict[str, Any]] = []
    if not args.s4_only:
        promotion_rows = promotion_weight_sensitivity()
        promotion_path = write_csv(
            RESULTS / "promotion_weight_sensitivity.csv",
            promotion_rows,
            [
                "variant",
                "n",
                "pass_rate",
                "selected_nominal",
                "selected_route_only",
                "selected_route_protocol_trigger",
                "qsr_mean",
                "recovery_median",
                "blackout_median",
            ],
        )
    else:
        promotion_path = RESULTS / "promotion_weight_sensitivity.csv"

    if not args.s4_only:
        print(f"Wrote {contract_path}")
    print(f"Wrote {s4_path}")
    print(f"Wrote {s4_core_path}")
    if not args.s4_only:
        print(f"Wrote {promotion_path}")
    for row in promotion_rows:
        print(
            row["variant"],
            "pass_rate=",
            row["pass_rate"],
            "route+protocol+trigger=",
            row["selected_route_protocol_trigger"],
        )


if __name__ == "__main__":
    main()
