"""Analytical energy, boundary and trajectory tests; no simulator/model requests."""
import copy
import math
import unittest
from original_energy_screen import load_config, propulsion_power, reference_energy, evaluate_profile, screen_profile, evaluate_all

def trace(displacement=0):
    rows=[]
    xy=[120.,120.]
    for slot in range(230):
        end=[xy[0]+displacement,xy[1]]
        rows.append({'slot':slot,'dt_s':1.,'slot_start_s':slot,'slot_end_s':slot+1,
                     'start_xy_m':xy,'end_xy_m':end,'move_m':float(displacement)})
        xy=end
    return rows

class EnergyTests(unittest.TestCase):
    def setUp(self): self.cfg=load_config()
    def test_hover_and_units(self):
        p=evaluate_profile(trace(),'mean_speed',1,50,self.cfg)
        self.assertAlmostEqual(p['mission_used_j'],reference_energy(self.cfg),places=6)
        self.assertGreater(p['mission_flight_j'],0)
        self.assertEqual(p['terminal_return_j'],0)
        g=screen_profile(p,1,0,True,self.cfg)
        self.assertTrue(g['energy_pass'])
        self.assertAlmostEqual(g['capacity_wh'],g['capacity_j']/3600)
    def test_reserve_and_capacity_monotonicity(self):
        p=evaluate_profile(trace(),'mean_speed',1,50,self.cfg)
        self.assertFalse(screen_profile(p,1,.1,True,self.cfg)['energy_pass'])
        self.assertTrue(screen_profile(p,1.25,.1,True,self.cfg)['energy_pass'])
        self.assertFalse(screen_profile(p,2,0,False,self.cfg)['joint_pass'])
    def test_return_conservation(self):
        p=evaluate_profile(trace(2),'mean_speed',1.25,100,self.cfg)
        self.assertAlmostEqual(p['terminal_return_seconds'],460/42)
        self.assertAlmostEqual(p['mission_used_j']+p['terminal_return_j'],p['energy_with_return_j'],places=7)
        self.assertAlmostEqual(p['endpoints'][-1]['required_j'],p['endpoints'][-2]['required_j'],places=7)
        self.assertEqual(p['endpoints'][-1]['xy_m'],[120.,120.])
    def test_motion_and_junctions(self):
        slow=evaluate_profile(trace(2),'mean_speed',1,50,self.cfg)
        split=evaluate_profile(trace(2),'travel_then_hover',1,50,self.cfg)
        self.assertEqual(len(slow['endpoints']),232)
        self.assertEqual(len(split['endpoints']),462)
        self.assertNotAlmostEqual(slow['mission_used_j'],split['mission_used_j'])
        self.assertAlmostEqual(split['endpoints'][1]['time_s'],2/42)
    def test_model_domain_and_trajectory_fail_closed(self):
        for bad in (-1,61,float('nan')):
            with self.assertRaises(ValueError): propulsion_power(bad,self.cfg)
        for mode in ('mean_speed','travel_then_hover'):
            with self.assertRaises(ValueError): evaluate_profile(trace(43),mode,1,50,self.cfg)
        bad=trace();bad[1]['start_xy_m']=[121.,120.]
        with self.assertRaises(ValueError): evaluate_profile(bad,'mean_speed',1,50,self.cfg)
        bad=trace();bad[0]['end_xy_m'].append(0)
        with self.assertRaises(ValueError): evaluate_profile(bad,'mean_speed',1,50,self.cfg)
    def test_complete_prespecified_grid(self):
        result=evaluate_all(trace(),True,self.cfg)
        self.assertEqual(len(result['profiles']),8)
        self.assertEqual(len(result['gates']),120)
        for profile in result['profiles']:
            self.assertAlmostEqual(profile['flight_with_return_j']+profile['nonpropulsive_with_return_j'],profile['energy_with_return_j'])

if __name__=='__main__': unittest.main()
