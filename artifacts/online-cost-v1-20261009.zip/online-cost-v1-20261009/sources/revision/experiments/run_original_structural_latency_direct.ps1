param(
    [switch]$Run,
    [string]$Preparation = 'F:\my-project\iotj\revision\experiments\results\original_structural_latency_preparation_20261008.json',
    [string]$Authorization = 'F:\my-project\iotj\revision\experiments\results\original_structural_latency_authorization_20261008.json',
    [string]$OutputRoot = 'F:\my-project\iotj\revision\experiments\results\original_structural_latency_live_20261008'
)
$ErrorActionPreference = 'Stop'
$taskPython = 'C:\Users\Feng Li\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$taskRoot = $PSScriptRoot
$taskRunner = Join-Path $taskRoot 'measure_original_structural_latency.py'
if (-not $Run) {
    & $taskPython -X utf8 -B $taskRunner --check-only
    exit $LASTEXITCODE
}
if (-not (Test-Path -LiteralPath $Preparation) -or -not (Test-Path -LiteralPath $Authorization)) {
    throw 'Preparation and a new explicit authorization are required. No network or API call started.'
}
if (Test-Path -LiteralPath $OutputRoot) {
    throw 'A previous output directory exists. Preserve it; no retry or resume is allowed.'
}
# Validate the new authorization before even the key-free direct-path diagnostic.
& $taskPython -X utf8 -B $taskRunner --check-launch --preparation $Preparation --authorization $Authorization --out $OutputRoot
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Output 'Checking direct DNS/route/TLS. No model probe or key access. Keep FlyShadow/TUN off.'
$taskDiagnostic = & $taskPython -X utf8 -B (Join-Path $taskRoot 'manual_dashscope_check.py') --flush-dns
$taskDiagnosticCode = $LASTEXITCODE
$taskDiagnostic | ForEach-Object { Write-Output $_ }
if ($taskDiagnosticCode -ne 0) { exit $taskDiagnosticCode }
$taskResultLines = @($taskDiagnostic | Where-Object { $_ -match '^RESULT_FILE: ' })
if ($taskResultLines.Count -ne 1) { throw 'No unique direct-path result. No model request started.' }
$taskNetworkResult = $taskResultLines[0].Substring('RESULT_FILE: '.Length).Trim()
& $taskPython -X utf8 -B $taskRunner --run --preparation $Preparation --authorization $Authorization --network-result $taskNetworkResult --out $OutputRoot
exit $LASTEXITCODE
