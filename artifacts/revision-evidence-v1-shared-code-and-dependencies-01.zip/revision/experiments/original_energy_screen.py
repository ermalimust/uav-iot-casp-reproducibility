"""Explicit literature-parameterized, fixed-trajectory energy admission screen.

No controller, simulator, inference or API. Quasi-steady horizontal model only;
always-on ancillary load and power scaling are declared sensitivity assumptions.
"""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path

CONFIG = Path(__file__).with_name('original_energy_screen_config.json')


def finite(value, name, low=0.0):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < low:
        raise ValueError(f'Invalid {name}: {value!r}')
    return float(value)


def load_config(path=CONFIG):
    cfg = json.loads(Path(path).read_text(encoding='utf-8'))
    for key, value in cfg['parameters'].items():
        finite(value, key, 1e-12)
    for key in ('dt_s', 'mission_slots', 'mission_speed_m_s', 'return_speed_m_s', 'power_speed_domain_max_m_s'):
        finite(cfg[key], key, 1e-12)
    if type(cfg['mission_slots']) is not int or cfg['mission_slots'] != 230:
        raise ValueError('Original horizon must be 230 slots')
    if cfg['dt_s'] != 1 or cfg['mission_speed_m_s'] != 42 or cfg['return_speed_m_s'] != 42:
        raise ValueError('Original slot/speed and fixed return speed changed')
    if cfg['mission_speed_m_s'] > cfg['power_speed_domain_max_m_s']:
        raise ValueError('Mission speed outside declared numerical model domain')
    if cfg['home_xy_m'] != [120, 120] or cfg['model_requests'] != 0:
        raise ValueError('Declared base/API boundary changed')
    for key in ('propulsion_scales', 'constant_nonpropulsive_w', 'capacity_multipliers'):
        if not cfg[key]:
            raise ValueError('Empty sensitivity range')
        for value in cfg[key]:
            finite(value, key, 1e-12)
    for value in cfg['reserve_fractions']:
        finite(value, 'reserve_fraction')
        if value >= 1:
            raise ValueError('Reserve fraction must be below one')
    if set(cfg['motion_interpretations']) != {'mean_speed', 'travel_then_hover'}:
        raise ValueError('Both declared motion interpretations are required')
    finite(cfg['gate_epsilon_j'], 'gate_epsilon_j')
    return cfg


def power_constants(cfg):
    p = cfg['parameters']
    tip = p['omega_rad_s'] * p['radius_m']
    induced = math.sqrt(p['weight_n'] / (2 * p['rho_kg_m3'] * p['area_m2']))
    p0 = p['delta'] / 8 * p['rho_kg_m3'] * p['solidity'] * p['area_m2'] * tip**3
    pi = (1 + p['induced_correction']) * p['weight_n']**1.5 / math.sqrt(2*p['rho_kg_m3']*p['area_m2'])
    return {'tip_speed_m_s': tip, 'hover_induced_speed_m_s': induced,
            'profile_hover_w': p0, 'induced_hover_w': pi, 'hover_propulsion_w': p0+pi}


def propulsion_power(speed, cfg):
    speed = finite(speed, 'speed')
    if speed > cfg['power_speed_domain_max_m_s'] + 1e-10:
        raise ValueError('Speed outside declared literature numerical domain')
    c, p = power_constants(cfg), cfg['parameters']
    x = speed**2 / (2*c['hover_induced_speed_m_s']**2)
    # Exact algebraic form of Eq. (6), avoiding subtractive cancellation.
    induced_factor = 1 / math.sqrt(math.sqrt(1+x*x)+x)
    return (c['profile_hover_w']*(1+3*speed**2/c['tip_speed_m_s']**2)
            + c['induced_hover_w']*induced_factor
            + .5*p['drag_ratio']*p['rho_kg_m3']*p['solidity']*p['area_m2']*speed**3)


def reference_energy(cfg):
    return cfg['mission_slots'] * cfg['dt_s'] * (propulsion_power(0, cfg)+50)


def trajectory_segments(trace, motion, cfg):
    if len(trace) != cfg['mission_slots']:
        raise ValueError('Missing original trajectory slots')
    previous = tuple(cfg['home_xy_m'])
    for slot, row in enumerate(trace):
        dt = finite(row['dt_s'], 'dt', 1e-12)
        start, end = tuple(row['start_xy_m']), tuple(row['end_xy_m'])
        if len(start) != 2 or len(end) != 2:
            raise ValueError('Horizontal trajectory must be two-dimensional')
        if row['slot'] != slot or dt != cfg['dt_s'] or start != previous:
            raise ValueError('Trajectory slot identity/continuity differs')
        if row['slot_start_s'] != slot*dt or row['slot_end_s'] != (slot+1)*dt:
            raise ValueError('Original time boundaries differ')
        for coordinate in (*start, *end):
            finite(coordinate, 'coordinate')
        move = math.dist(start, end)
        if not math.isclose(move, row['move_m'], rel_tol=1e-10, abs_tol=1e-8):
            raise ValueError('Saved move does not match positions')
        if move > cfg['mission_speed_m_s']*dt+1e-8:
            raise ValueError('Original displacement exceeds speed')
        t0 = slot*dt
        if motion == 'mean_speed':
            yield {'slot': slot, 'kind': 'mean_speed', 'start_s': t0,
                   'duration_s': dt, 'speed_m_s': move/dt, 'start_xy_m': start, 'end_xy_m': end}
        elif motion == 'travel_then_hover':
            travel = min(dt, move/cfg['mission_speed_m_s'])
            if travel > 0:
                yield {'slot': slot, 'kind': 'travel', 'start_s': t0,
                       'duration_s': travel, 'speed_m_s': cfg['mission_speed_m_s'],
                       'start_xy_m': start, 'end_xy_m': end}
            hover = dt-travel
            if hover > 0:
                yield {'slot': slot, 'kind': 'hover', 'start_s': t0+travel,
                       'duration_s': hover, 'speed_m_s': 0.0, 'start_xy_m': end, 'end_xy_m': end}
        else:
            raise ValueError('Unknown motion interpretation')
        previous = end


def evaluate_profile(trace, motion, beta, auxiliary_w, cfg):
    beta, auxiliary_w = finite(beta, 'beta', 1e-12), finite(auxiliary_w, 'auxiliary_w')
    return_power = beta*propulsion_power(cfg['return_speed_m_s'], cfg)+auxiliary_w
    home = cfg['home_xy_m']
    points = []
    used_flight = used_aux = 0.0

    def point(t, xy, slot, kind):
        return_seconds = math.dist(xy, home)/cfg['return_speed_m_s']
        return_j = return_power*return_seconds
        used = used_flight+used_aux
        return {'time_s': t, 'xy_m': list(xy), 'slot': slot, 'boundary': kind,
                'flight_used_j': used_flight, 'nonpropulsive_used_j': used_aux,
                'used_j': used, 'return_seconds': return_seconds,
                'return_j': return_j, 'required_j': used+return_j}

    points.append(point(0.0, home, -1, 'mission_start'))
    last_xy = list(home)
    for segment in trajectory_segments(trace, motion, cfg):
        used_flight += beta*propulsion_power(segment['speed_m_s'], cfg)*segment['duration_s']
        used_aux += auxiliary_w*segment['duration_s']
        last_xy = segment['end_xy_m']
        points.append(point(segment['start_s']+segment['duration_s'], last_xy,
                            segment['slot'], segment['kind']+'_end'))
    terminal = points[-1]
    maximum = max(points, key=lambda x: x['required_j'])
    return_seconds = terminal['return_seconds']
    # The straight same-speed return is appended only to the energy horizon.
    used_flight += beta*propulsion_power(cfg['return_speed_m_s'], cfg)*return_seconds
    used_aux += auxiliary_w*return_seconds
    points.append(point(cfg['mission_slots']*cfg['dt_s']+return_seconds,
                        home, cfg['mission_slots'], 'return_complete'))
    if points[-1]['required_j'] > maximum['required_j']:
        maximum = points[-1]
    return {'motion': motion, 'propulsion_scale': beta, 'constant_nonpropulsive_w': auxiliary_w,
            'mission_flight_j': terminal['flight_used_j'], 'mission_nonpropulsive_j': terminal['nonpropulsive_used_j'],
            'mission_used_j': terminal['used_j'], 'terminal_return_j': terminal['return_j'],
            'terminal_return_seconds': return_seconds,
            'flight_with_return_j': used_flight, 'nonpropulsive_with_return_j': used_aux,
            'energy_with_return_j': used_flight+used_aux,
            'required_peak_j': maximum['required_j'], 'required_peak_time_s': maximum['time_s'],
            'endpoints': points}


def screen_profile(profile, alpha, reserve_fraction, service_pass, cfg):
    if type(service_pass) is not bool:
        raise ValueError('Original service pass must be a boolean')
    alpha = finite(alpha, 'alpha', 1e-12)
    r = finite(reserve_fraction, 'reserve_fraction')
    if r >= 1:
        raise ValueError('Reserve fraction must be below one')
    capacity = alpha*reference_energy(cfg)
    reserve = r*capacity
    usable = capacity-reserve
    eps = cfg['gate_epsilon_j']
    failures = [p for p in profile['endpoints'] if p['required_j'] > usable+eps]
    passed = not failures
    end_remaining = capacity-profile['energy_with_return_j']
    return {'capacity_multiplier': alpha, 'reserve_fraction': r, 'capacity_j': capacity,
            'capacity_wh': capacity/3600, 'reserve_j': reserve,
            'usable_above_reserve_j': usable, 'required_peak_j': profile['required_peak_j'],
            'minimum_return_margin_j': usable-profile['required_peak_j'],
            'first_violation_time_s': failures[0]['time_s'] if failures else None,
            'first_violation_boundary': failures[0]['boundary'] if failures else None,
            'remaining_after_return_j': end_remaining,
            'end_reserve_margin_j': end_remaining-reserve,
            'break_even_capacity_j': profile['required_peak_j']/(1-r),
            'break_even_capacity_wh': profile['required_peak_j']/(1-r)/3600,
            'energy_pass': passed, 'service_pass': service_pass, 'joint_pass': passed and service_pass}


def evaluate_all(trace, service_pass, cfg):
    profiles, gates = [], []
    for motion in cfg['motion_interpretations']:
        for beta in cfg['propulsion_scales']:
            for auxiliary in cfg['constant_nonpropulsive_w']:
                profile = evaluate_profile(trace, motion, beta, auxiliary, cfg)
                index = len(profiles)
                profile['profile_index'] = index
                profiles.append(profile)
                for alpha in cfg['capacity_multipliers']:
                    for r in cfg['reserve_fractions']:
                        gate = screen_profile(profile, alpha, r, service_pass, cfg)
                        gate['profile_index'] = index
                        gates.append(gate)
    return {'config_sha256': hashlib.sha256(CONFIG.read_bytes()).hexdigest(),
            'reference_energy_j': reference_energy(cfg), 'power_constants': power_constants(cfg),
            'profiles': profiles, 'gates': gates}
