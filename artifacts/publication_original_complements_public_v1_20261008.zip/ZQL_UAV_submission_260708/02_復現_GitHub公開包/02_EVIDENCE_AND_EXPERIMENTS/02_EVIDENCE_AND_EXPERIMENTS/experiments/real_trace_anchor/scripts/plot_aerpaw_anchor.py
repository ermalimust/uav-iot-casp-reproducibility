from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


SCRIPT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = SCRIPT_ROOT / "data" / "raw" / "aerpaw_aadm" / "extracted"
DEFAULT_RESULTS = SCRIPT_ROOT / "results"
DEFAULT_OUT = SCRIPT_ROOT / "figures"


def parse_float(value: str | None) -> float | None:
    if value is None:
        return None
    try:
        return float(str(value).strip())
    except ValueError:
        return None


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def load_lora_rows(root: Path) -> list[dict[str, str]]:
    files = sorted(root.rglob("LORAlog.csv"))
    if not files:
        files = sorted(root.rglob("All_Logs.csv"))
    rows: list[dict[str, str]] = []
    for file in files:
        for row in load_csv(file):
            row["_source_file"] = str(file)
            rows.append(row)
    return rows


def box_data(rows: list[dict[str, str]], column: str) -> list[float]:
    return [value for value in (parse_float(row.get(column)) for row in rows) if value is not None]


def main() -> int:
    parser = argparse.ArgumentParser(description="Plot AERPAW AADM public trace anchors.")
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--results-dir", type=Path, default=DEFAULT_RESULTS)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    lora_rows = load_lora_rows(args.input)
    snr_csv = args.input / "USRP" / "Post-processing" / "other plots" / "vehicleOut_snr.csv"
    download_csv = args.input / "USRP" / "Post-processing" / "other plots" / "vehicleOut_download.csv"
    usrp_snr_rows = load_csv(snr_csv)
    usrp_download_rows = load_csv(download_csv)
    lora_summary = json.loads((args.results_dir / "lora_anchor_summary.json").read_text(encoding="utf-8"))
    usrp_summary = json.loads((args.results_dir / "usrp_anchor_summary.json").read_text(encoding="utf-8"))

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 8,
            "axes.titlesize": 9,
            "axes.labelsize": 8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
        }
    )
    fig, axes = plt.subplots(2, 2, figsize=(7.35, 4.85), dpi=300)

    ax = axes[0][0]
    lora_rssi = box_data(lora_rows, "rx_info_rssi")
    lora_snr = box_data(lora_rows, "rx_info_snr")
    bp = ax.boxplot([lora_rssi, lora_snr], tick_labels=["RSSI\n(dBm)", "SNR\n(dB)"], patch_artist=True, showfliers=False)
    for patch, color in zip(bp["boxes"], ["#3A6EA5", "#D99A32"]):
        patch.set_facecolor(color)
        patch.set_alpha(0.75)
    ax.set_title("(a) LoRa link quality across 33 flights", loc="left", fontweight="bold")
    ax.set_ylabel("dB / dBm")
    ax.text(
        0.03,
        0.94,
        f"SNR p05={lora_summary['snr_db']['p05']:.1f} dB, p50={lora_summary['snr_db']['p50']:.1f} dB",
        transform=ax.transAxes,
        fontsize=7,
        color="#4D5666",
        va="top",
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.82, "pad": 1.2},
    )

    ax = axes[0][1]
    sf_counts: dict[str, int] = {}
    for row in lora_rows:
        sf = str(row.get("tx_info_modulation_spreadingFactor", "")).strip()
        if sf:
            sf_counts[sf] = sf_counts.get(sf, 0) + 1
    sf_keys = sorted(sf_counts, key=lambda value: int(value))
    ax.bar(sf_keys, [sf_counts[key] for key in sf_keys], color="#4C956C", width=0.72)
    max_sf_count = max(sf_counts.values()) if sf_counts else 0
    ax.set_ylim(0, max_sf_count * 1.22)
    ax.set_title("(b) LoRa rate/range mix", loc="left", fontweight="bold")
    ax.set_xlabel("Spreading factor")
    ax.set_ylabel("Packets")
    gap = lora_summary["frame_counter_gap"]["loss_ratio_proxy"]
    ax.text(
        0.03,
        0.94,
        f"frame-counter gap proxy: {gap:.1%}",
        transform=ax.transAxes,
        fontsize=7,
        color="#4D5666",
        va="top",
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.82, "pad": 1.2},
    )

    ax = axes[1][0]
    snr_cols = ["snr_lw1", "snr_lw2", "snr_lw3", "snr_lw4"]
    snr_values = [box_data(usrp_snr_rows, col) for col in snr_cols]
    bp = ax.boxplot(snr_values, tick_labels=["BS1", "BS2", "BS3", "BS4"], patch_artist=True, showfliers=False)
    for patch, color in zip(bp["boxes"], ["#3A6EA5", "#D99A32", "#C15B49", "#6B5B95"]):
        patch.set_facecolor(color)
        patch.set_alpha(0.76)
    ax.axhline(0, color="#3D4655", linewidth=0.8, linestyle="--")
    ax.set_title("(c) USRP SNR by candidate serving base station", loc="left", fontweight="bold")
    ax.set_ylabel("SNR (dB)")
    outages = usrp_summary["snr"]["outage_by_file_link"]
    max_outage = max(float(item["max_outage_seconds"]) for item in outages)
    ax.text(0.03, 0.08, f"max low-SNR run: {max_outage:.0f} s", transform=ax.transAxes, fontsize=7, color="#4D5666")

    ax = axes[1][1]
    time_values = [parse_float(row.get("num")) for row in usrp_download_rows]
    colors = ["#3A6EA5", "#D99A32", "#C15B49", "#6B5B95"]
    for col, label, color in zip(["dl_lw1", "dl_lw2", "dl_lw3", "dl_lw4"], ["BS1", "BS2", "BS3", "BS4"], colors):
        values = [parse_float(row.get(col)) for row in usrp_download_rows]
        pairs = [(t, v) for t, v in zip(time_values, values) if t is not None and v is not None]
        if pairs:
            ax.plot([p[0] for p in pairs], [p[1] for p in pairs], label=label, color=color, linewidth=1.3)
    ax.set_title("(d) Uneven download accumulation", loc="left", fontweight="bold")
    ax.set_xlabel("Mission index / elapsed seconds")
    ax.set_ylabel("Cumulative download (Mbits)")
    ax.legend(
        frameon=True,
        facecolor="white",
        edgecolor="none",
        framealpha=0.86,
        ncol=1,
        loc="center right",
        bbox_to_anchor=(0.98, 0.43),
        handlelength=1.2,
        borderpad=0.25,
        labelspacing=0.28,
    )

    for ax in axes.ravel():
        ax.grid(True, axis="y", color="#DDE2EA", linewidth=0.55)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_color("#AEB7C5")
        ax.spines["bottom"].set_color("#AEB7C5")

    fig.text(
        0.01,
        0.01,
        "AERPAW AADM public dataset (Dryad DOI: 10.5061/dryad.7d7wm3898). Public traces anchor the disturbance model used in simulation-backed evaluation.",
        fontsize=6.4,
        color="#5F6978",
    )
    fig.subplots_adjust(left=0.075, right=0.99, top=0.94, bottom=0.13, hspace=0.42, wspace=0.28)
    out = args.out_dir / "aerpaw_aadm_trace_anchor.png"
    fig.savefig(out, bbox_inches="tight", pad_inches=0.04)
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
