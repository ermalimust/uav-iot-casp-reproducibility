#!/usr/bin/env python3
"""Regenerate the A4 figures (threshold sweep + per-seed blackout distribution)
from whatever per-seed data currently sits in results/. Re-run after a 100-seed
re-run to refresh figures/threshold_sweep_passrate.* and figures/blackout_distribution.*

Dependencies: numpy, pandas, matplotlib.
Usage: python plot_a4_figures.py
"""
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path

HERE = Path(__file__).resolve().parent
RES = HERE / "results"
FIG = HERE.parent.parent / "figures"     # repo-root/figures
FIG.mkdir(exist_ok=True)

sw = pd.read_csv(RES / "bthr_sweep_results_exact.csv")
relabel = {
    "static_nominal_optimizer": "Static optimizer",
    "workflow_no_casp_triggers": "No CASP trigger",
    "workflow_generic_repair": "Generic repair",
    "one_shot_agent_policy": "One-shot",
    "nearest_backlog_greedy": "Greedy backlog",
    "lawn_mower": "Lawn-mower",
}

# ---- Figure 1: pass rate vs B_thr ----
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
fig, ax = plt.subplots(figsize=(6.6, 3.4))
order = ["lawn_mower", "nearest_backlog_greedy", "one_shot_agent_policy",
         "workflow_generic_repair", "static_nominal_optimizer",
         "workflow_no_casp_triggers"]
styles = {"static_nominal_optimizer": dict(lw=2.0, color="#b71c1c", ls="--", zorder=4),
          "workflow_no_casp_triggers": dict(lw=1.4, color="#ef6c00", ls="-.")}
ax.axvspan(50, 54, color="#cfe8d6", alpha=0.5, zorder=0, label="$\\pm2$ neighborhood")
ax.axvline(52, color="gray", lw=1, ls=":", zorder=1)
ax.text(52, 1.02, "canonical $B^{\\mathrm{thr}}{=}52$", ha="center", fontsize=8, color="gray")
for m in order:
    d = sw[sw.method == m].sort_values("b_thr")
    if d.empty:
        continue
    ax.plot(d.b_thr, d.pass_rate, label=relabel.get(m, m),
            **styles.get(m, dict(lw=1.0, color="#90a4ae")))
ax.set_xlim(44, 64); ax.set_ylim(-0.02, 1.03)
ax.set_xlabel("Maximum-blackout threshold $B^{\\mathrm{thr}}$ (slots)")
ax.set_ylabel("Contract pass rate")
ax.legend(fontsize=7.3, loc="lower right", ncol=2, frameon=False)
fig.tight_layout()
for ext in ("pdf", "png"):
    fig.savefig(FIG / f"threshold_sweep_passrate.{ext}", dpi=200, bbox_inches="tight")
plt.close(fig)

# ---- Figure 2: per-seed blackout distribution ----
sm = pd.read_csv(RES / "summary_metrics.csv")
hy = pd.read_csv(RES / "hybrid_ablation_per_seed.csv")
static_bl = sm[sm.method == "static_nominal_optimizer"]["max_blackout"].to_numpy(float)
hyb_bl = hy[hy.backend == "hybrid"]["max_blackout"].to_numpy(float)

fig, ax = plt.subplots(figsize=(6.6, 3.0))
data = [static_bl, hyb_bl]
labels = ["Static\noptimizer", "Hybrid CASP\n(main)"]
cols = ["#b71c1c", "#1565c0"]
rng = np.random.default_rng(0)
ax.axvline(52, color="gray", lw=1.2, ls=":")
ax.text(52, 3.55, "$B^{\\mathrm{thr}}{=}52$", ha="center", fontsize=8, color="gray")
for i, (d, c) in enumerate(zip(data, cols)):
    y = np.full_like(d, i + 1) + rng.uniform(-0.13, 0.13, len(d))
    ax.scatter(d, y, s=18, color=c, alpha=0.65, edgecolor="white", linewidth=0.4, zorder=3)
    bp = ax.boxplot(d, positions=[i + 1], vert=False, widths=0.5, patch_artist=True,
                    showfliers=False, zorder=2, medianprops=dict(color="black"))
    for box in bp["boxes"]:
        box.set(facecolor=c, alpha=0.18)
    ax.text(63.5, i + 1, f"$\\leq$52: {np.mean(d <= 52) * 100:.0f}%", va="center", fontsize=8, color=c)
ax.set_yticks([1, 2]); ax.set_yticklabels(labels)
ax.set_xlabel("Per-seed maximum blackout (slots)"); ax.set_xlim(44, 68); ax.set_ylim(0.5, 2.7)
fig.tight_layout()
for ext in ("pdf", "png"):
    fig.savefig(FIG / f"blackout_distribution.{ext}", dpi=200, bbox_inches="tight")
plt.close(fig)
print("wrote figures/threshold_sweep_passrate.{pdf,png} and figures/blackout_distribution.{pdf,png}")
