# 原能量模型的一手资料核验

2026-10-08。仅查阅原稿、现有能量协议、代码及作者原始论文；未运行仿真，未修改原实现/协议/正文，未选择电池容量或通过阈值。公式编号和页码均对应下面明确链接的作者预印本，不能冒称出版版本页码。

原稿 III-D `Energy Model` 是距离、服务量和切换的抽象成本。代码固定 `T=230`、`DT=1 s`、`UAV_SPEED=42 m/s`，移动量为 `min(42×DT, distance)`，包含停留。现有 [能量补充协议](F:/my-project/iotj/revision/Original_Energy_Extension_Protocol_20261008.md) 已区分抽象成本与物理电量，本次核验不改变这一边界。

## 一手来源与适用对象

| 来源 | 直接核对的位置 | 对本任务的选择理由 |
|---|---|---|
| Zeng & Zhang, *Energy-Efficient UAV Communication with Trajectory Optimization*, IEEE TWC 16(6), 3747–3760, 2017，[DOI](https://doi.org/10.1109/TWC.2017.2688328)；[作者稿 arXiv:1608.01828v1](https://arxiv.org/pdf/1608.01828v1) | II-B，PDF p.7–8，式(5)–(7)；参数例在 VI，p.19；推导 Appendix A | 原稿已有引用。研究固定翼恒高度飞行，不能以该引用为当前悬停推进耗能的依据。 |
| Zeng, Xu & Zhang, *Energy Minimization for Wireless Communication with Rotary-Wing UAV*, IEEE TWC 18(4), 2329–2345, 2019，[IEEE](https://ieeexplore.ieee.org/document/8663615)、[DOI](https://doi.org/10.1109/TWC.2019.2902559)；[作者稿 arXiv:1804.02238v1](https://arxiv.org/pdf/1804.02238v1) | II-B，PDF p.6–7，式(6)；Appendix A p.27–29，式(61)–(66)、Table I；数值设置 V，p.22 | 允许有限功耗悬停，更符合含停留的运动形式。可作为文献参数化的补充模型来源，不是本任务机型的实测标定。 |

## 已核对的公式

固定翼：令 $V=\|\mathbf v\|>0$，$a_\perp^2=\|\mathbf a\|^2-(\mathbf a^\top\mathbf v)^2/V^2$，原式(5)为

$$
E_{\rm fw}=\int_0^T\left[c_1V^3+\frac{c_2}{V}\left(1+\frac{a_\perp^2}{g^2}\right)\right]dt+\frac{m}{2}(V_T^2-V_0^2).
$$

匀速直线时原式(7)给出 $P_{\rm fw}(V)=c_1V^3+c_2/V$。原数值例 $c_1=9.26\times10^{-4}$、$c_2=2250$，对应单位分别为 $\mathrm W/(\mathrm{m/s})^3$、$\mathrm W\cdot\mathrm{m/s}$；$g=9.8\,\mathrm{m/s^2}$。原模型限制正常飞行、无异常反向推力的急减速；$V\to0$ 时奇异。[II-B 与 VI](https://arxiv.org/pdf/1608.01828v1)

旋翼：原式(6)给出

$$
P_{\rm rw}(V)=P_0\left(1+\frac{3V^2}{U_{\rm tip}^2}\right)+P_i\left(\sqrt{1+\frac{V^4}{4v_0^4}}-\frac{V^2}{2v_0^2}\right)^{1/2}+\frac12 d_0\rho s A V^3.
$$

原式(61)定义 $P_0=(\delta/8)\rho sA\Omega^3R^3$、$P_i=(1+k)W^{3/2}/\sqrt{2\rho A}$；$P_{\rm rw}(0)=P_0+P_i>0$。这里 $W$ 表示重量，单位 N，不能当作质量 kg；功率 $P$ 的单位为 W。[II-B 与 Appendix A](https://arxiv.org/pdf/1804.02238v1)

## 旋翼参数表：已查版本的完整一致取值

下表取自 **arXiv:1804.02238v1 Table I，PDF p.27**；未把其他论文的常用参数混入，也未声称这些就是当前 UAV 的参数。

| 符号 | 含义 | 作者数值例 | 单位 |
|---|---|---:|---|
| $W$ | 重量 | 100 | N |
| $\rho$ | 空气密度 | 1.225 | kg/m³ |
| $R$ | 旋翼半径 | 0.5 | m |
| $A$ | 旋翼盘面积，$\pi R^2$ | 0.79（表中舍入） | m² |
| $\Omega$ | 叶片角速度 | 400 | rad/s |
| $U_{\rm tip}$ | 桨尖速度，$\Omega R$ | 200 | m/s |
| $s$ | 旋翼实度 | 0.05 | 无量纲 |
| $d_0$ | 机身阻力比 | 0.3 | 无量纲 |
| $k$ | 诱导功率修正 | 0.1 | 无量纲 |
| $\delta$ | 翼型阻力系数 | 0.012 | 无量纲 |
| $v_0$ | 悬停诱导速度，$\sqrt{W/(2\rho A)}$ | 7.2（表中舍入） | m/s |

原 V 节设置 $V_{\max}=60\,\mathrm{m/s}$、通信相关功率 $P_c=50\,\mathrm W$；它们是论文数值设置，不是验证过的本任务速度上限或各协议电池功率。[Table I、V 节](https://arxiv.org/pdf/1804.02238v1) 若后续使用该组参数，须锁定原表舍入值或公式重算值的统一规则，不能同时混用。常见 $P_0=79.86$ W、$P_i=88.63$ W、$U_{\rm tip}=120$ m/s **不是这份已查版本的参数组**；本次不采纳。

## 当前 230 时隙、42 m/s 能否直接套用

| 当前条件 | 核验结论 |
|---|---|
| 230 个 1 s 时隙 | 可在声明时内运动后以 W×s 得 J；时隙数本身不提供容量或续航证据。 |
| 静止停留 | 固定翼式不适用；旋翼式有非零悬停功率。原移动抽象成本不能换算为推进 J。 |
| 42 m/s | 低于上述旋翼作者数值例的 60 m/s，但不等于实际机型/载荷/风条件已验证。不能仅凭代入有数值就声称物理有效。 |
| 每 slot 移动不足 42 m | 代码只给位置更新，未规定全秒低速还是先以 42 m/s 移动再悬停；因功率非线性，两种解释通常不同。须事前统一，不能依结果选解释。 |
| 启停、触发转向与短驻留 | 旋翼原 II-B 明确省略加速度额外耗能，依据是机动时间占总任务比例小；Appendix A 用水平飞行、小旋翼盘倾角及推重比近似。当前原轨迹未保存加速度或实际机动时间，尚不能确认满足。 |
| 电池与返航硬筛查 | 两篇论文的功率表达式均不能自行提供本任务容量、reserve、起降耗能、风/载荷下返航上界或无线状态电流；这些仍缺来源。 |

最后三行是把论文条件与本地实现相对照后的**适用性判断**，不是论文对本代码的验证结论。论文原始假设可在 [旋翼 II-B、Appendix A](https://arxiv.org/pdf/1804.02238v1) 核对；本地运动依据在 [基础常量](F:/my-project/iotj/revision/experiments/legacy/run_uav_iot_workflow_experiment.py:23) 与 [混合场景移动更新](F:/my-project/iotj/revision/experiments/legacy/contingency_suite.py:191)。

本次资料足以排除“直接用 2017 固定翼式补悬停”并确定旋翼候选来源；不足以冻结硬电池实验。后续如采用，只能先称明确假设下的文献参数化能量敏感性。IEEE 页面用于出版身份；因在线全文访问限制，具体公式/参数以这里实际读到的作者 v1 为准，未假定与出版全文逐项相同。
