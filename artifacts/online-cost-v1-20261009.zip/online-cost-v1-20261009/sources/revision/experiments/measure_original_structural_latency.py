"""Prepare or explicitly launch a 12-request online structural-cost illustration.

Default/check-only never reads API configuration or credentials, simulates, or
opens a network connection. Live requires a newly explicit, hash-bound approval.
No existing result cache is used for new generations; no retry or resume exists.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import ipaddress
import json
import math
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
WORKSPACE = BASE.parents[1]
LEGACY = BASE / 'legacy'
RESULTS = BASE / 'results'
FROZEN = (WORKSPACE / 'ZQL_UAV_submission_260708/02_復現_GitHub公開包/'
          '02_EVIDENCE_AND_EXPERIMENTS/02_EVIDENCE_AND_EXPERIMENTS/'
          'results_frozen_mixed_structural_100seed_20260617')
PROTOCOL = BASE / 'original_structural_latency_protocol.json'
SOURCES = ('B1_max_backlog_route', 'B2_max_blackout_protocol', 'B3_scripted_east_full')
VERSION = 'original-live-structural-latency-1'


class StopExperiment(Exception):
    pass


class HttpFailure(Exception):
    def __init__(self, status, body):
        self.http_status, self.body_bytes = status, body
        super().__init__('One HTTP attempt failed; no retry')


def require(condition, message):
    if not condition:
        raise StopExperiment(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def clean(value):
    if isinstance(value, dict):
        return {key: clean(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [clean(item) for item in value]
    if isinstance(value, set):
        return sorted(clean(item) for item in value)
    return value


def save_new(path, value):
    """Append-only artifact identity: never overwrite or repair an old attempt."""
    path = Path(path)
    writing = path.with_name(path.name + '.writing')
    if path.exists() or writing.exists():
        raise FileExistsError(str(path))
    with writing.open('x', encoding='utf-8') as handle:
        json.dump(clean(value), handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())
    if os.name == 'nt':
        os.rename(writing, path)  # Windows rename refuses an existing destination.
    else:
        os.link(writing, path)  # Exclusive atomic publication on POSIX too.
        writing.unlink()


TOKEN_FIELDS = ('prompt_tokens', 'completion_tokens', 'total_tokens')


def token_usage(raw):
    """Keep absent or malformed fields unknown, including partial error usage."""
    if not isinstance(raw, dict):
        return None
    return {name: raw.get(name) if type(raw.get(name)) is int and raw[name] >= 0 else None
            for name in TOKEN_FIELDS}


def usage_status(usage):
    if usage is None or all(value is None for value in usage.values()):
        return 'unknown'
    return 'recorded' if all(value is not None for value in usage.values()) else 'partial'


def readable_record(path):
    """A partial artifact is evidence of interruption, never evidence of success."""
    try:
        return read_json(path)
    except (OSError, ValueError):
        return None


def utc():
    return datetime.now(timezone.utc).isoformat()


def tasks(profile):
    return [{'scenario': scenario, 'seed': seed} for scenario in profile['scenarios']
            for seed in profile['seeds']]


def profile_checked():
    profile = read_json(PROTOCOL)
    require(profile['protocol_id'] == 'iotj-original-structural-live-latency-1'
            and profile['model'] == 'qwen-plus'
            and profile['base_url'] == 'https://dashscope.aliyuncs.com/compatible-mode/v1'
            and profile['max_model_request_attempts'] == 12
            and profile['max_probe_attempts'] == 0 and profile['automatic_retries'] == 0
            and profile['automatic_resume'] is False and profile['full_search'] is False
            and profile['simulation_cache'] is False and profile['max_tokens'] == 1024
            and profile['temperature'] == 0.2 and profile['enable_thinking'] is False
            and profile['stream'] is False and profile['responses_per_request'] == 1
            and profile['http_socket_timeout_seconds'] == 60
            and profile['worker_total_timeout_seconds'] == 180,
            'Unexpected frozen latency profile')
    require(profile['scenarios'] == ['S1_seen_burst_east', 'S2_seen_degrade_west',
                                   'S3_seen_moved_burst', 'S4_heldout_misleading']
            and profile['seeds'] == [1, 2, 3] and len(tasks(profile)) == 12,
            'The fixed 12-task allocation changed')
    return profile


def bindings(energy=False):
    paths = [Path(__file__).resolve(), PROTOCOL,
             WORKSPACE / 'revision/Original_Live_Structural_Latency_Protocol_20261008.md',
             BASE / 'test_original_structural_latency.py',
             BASE / 'run_original_structural_latency_direct.ps1',
             BASE / 'candidate_search.py', BASE / 'structural_alignment_v12.py',
             BASE / 'measure_original_structural_costs.py', BASE / 'manual_dashscope_check.py',
             BASE / 'summarize_original_structural_costs.py']
    paths += [LEGACY / name for name in ('mixed_structural_suite.py', 'contingency_suite.py',
                                       'run_uav_iot_workflow_experiment.py',
                                       'run_mixed_structural_llm.py', 'llm_repair_agent.py')]
    paths += [FROZEN / name for name in ('mixed_structural_llm_per_seed.csv',
                                       'mixed_structural_llm_cache.jsonl')]
    if energy:
        paths += [BASE / name for name in ('original_energy_trace.py',
                                          'original_energy_screen.py',
                                          'original_energy_screen_config.json')]
    return {str(path.resolve()): sha(path) for path in paths}


def historical_rows():
    result = {}
    with (FROZEN / 'mixed_structural_llm_per_seed.csv').open(encoding='utf-8-sig', newline='') as handle:
        for row in csv.DictReader(handle):
            if row['method'] == 'llm_only_structure':
                key = row['scenario'], int(row['seed'])
                require(key not in result, 'Duplicate historical model row')
                result[key] = row
    return result


def original_prompt(evidence):
    import candidate_search as search
    helpers = search._legacy_helpers(str(LEGACY.resolve()))
    ordered = search.public_evidence(evidence)
    rounded = helpers['_rounded_evidence'](ordered)
    return helpers['SYSTEM'], ('Per-cluster evidence from the nominal failed run:\n'
           + json.dumps(rounded, indent=2) + '\n\nReturn the target cluster and repair mode JSON.')


def request_payload(profile, system, user):
    return {'model': profile['model'], 'temperature': profile['temperature'],
            'max_tokens': profile['max_tokens'], 'enable_thinking': False, 'stream': False,
            'n': 1, 'messages': [{'role': 'system', 'content': system},
                                {'role': 'user', 'content': user}]}


def prepare(energy=False):
    """Bind only saved diagnostic evidence; no scenario creation or calibration."""
    import candidate_search as search
    profile, rows, links = profile_checked(), historical_rows(), []
    for task in tasks(profile):
        row = rows[task['scenario'], task['seed']]
        evidence = json.loads(row['evidence_json'])
        linked = search.cached_llm_selection(evidence,
                     cache_path=FROZEN / 'mixed_structural_llm_cache.jsonl',
                     provider=row['provider'], model=row['model'])
        require(linked['status'] == 'hit' and (linked['target'], linked['mode']) ==
                (row['selected_target'], row['selected_mode']), 'Original response identity mismatch')
        system, user = original_prompt(evidence)
        body = request_payload(profile, system, user)
        links.append({**task, 'historical_provider': row['provider'],
                      'historical_model_alias': row['model'], 'historical_cache_key': linked['cache_key'],
                      'historical_usage': linked['usage'], 'messages': body['messages'],
                      'payload_sha256': hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()})
    require({item['historical_model_alias'] for item in links} == {'qwen-plus'}
            and {item['historical_provider'] for item in links} == {'openai'},
            'Requested backend alias differs from the historical interface')
    usage = {name: sum(item['historical_usage'][name] for item in links)
             for name in ('prompt_tokens', 'completion_tokens', 'total_tokens')}
    return {'version': VERSION, 'status': 'prepared_not_authorized',
            'protocol_id': profile['protocol_id'], 'protocol_sha256': sha(PROTOCOL),
            'source_hashes': bindings(energy), 'tasks': tasks(profile), 'energy_gate': bool(energy),
            'proposed_max_model_request_attempts': 12, 'proposed_max_probe_attempts': 0,
            'requested_output_cap_total': 12288, 'automatic_retries': 0,
            'estimated_usage_reference_of_matched_historical_12': usage,
            'estimate_status': 'historical reference only; current tokens, cost and backend version unknown',
            'historical_latency_seconds': None, 'model_config_reads': 0, 'api_key_reads': 0,
            'model_requests': 0, 'network_calls': 0, 'real_simulator_calls': 0, 'links': links}


def validate_authorization(auth, preparation, preparation_path, out):
    profile = profile_checked()
    require(auth.get('status') == 'explicitly_authorized'
            and isinstance(auth.get('human_authorization_text'), str)
            and bool(auth['human_authorization_text'].strip()), 'No explicit new human authorization')
    require(auth.get('protocol_id') == profile['protocol_id']
            and auth.get('protocol_sha256') == sha(PROTOCOL)
            and auth.get('preparation_sha256') == sha(preparation_path)
            and preparation['source_hashes'] == bindings(preparation['energy_gate']),
            'Authorization/preparation source identities differ')
    require(auth.get('model') == profile['model'] and auth.get('destination') == profile['base_url']
            and auth.get('max_model_request_attempts') == 12 and auth.get('max_probe_attempts') == 0
            and auth.get('automatic_retries') == 0 and auth.get('automatic_resume') is False
            and auth.get('energy_gate') is preparation['energy_gate'], 'New request budget/profile differs')
    require(set(auth.get('allowed_external_data', [])) == set(profile['allowed_external_data'])
            and set(auth.get('excluded_external_data', [])) == set(profile['excluded_external_data']),
            'Authorized data disclosure differs')
    require(Path(auth.get('output_root', '')).resolve() == Path(out).resolve()
            and Path(out).resolve().is_relative_to(RESULTS.resolve()), 'Unexpected live output root')
    require(preparation['tasks'] == tasks(profile), 'Prepared tasks differ')
    return profile


def validate_network(record, now=None):
    require(record.get('target') == 'dashscope.aliyuncs.com' and record.get('model_requests') == 0
            and record.get('http_requests') == 0 and record.get('wininet_proxy_enabled') is False
            and record.get('dns_cache_flush', {}).get('ok') is True, 'Direct-path check incomplete')
    checked = datetime.fromisoformat(record['checked_at_utc'])
    require(checked.tzinfo is not None, 'Direct-path timestamp needs a timezone')
    age = ((now or datetime.now(timezone.utc)) - checked).total_seconds()
    require(0 <= age <= 600, 'Direct-path check is stale')
    names = ('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'http_proxy', 'https_proxy', 'all_proxy')
    require(all(record.get('proxy_environment_variables_present', {}).get(name) is False for name in names),
            'Proxy environment remains active')
    addresses = record.get('dns', {}).get('addresses', [])
    require(record.get('dns', {}).get('ok') is True and addresses and all(
            item.get('is_global') is True and item.get('is_fake_ip_range') is False
            and ipaddress.ip_address(item['ip']).is_global for item in addresses), 'DNS is not public')
    ips = {item['ip'] for item in addresses}
    routes = record.get('selected_routes', [])
    require({item.get('target_ip') for item in routes} == ips, 'Route checks are incomplete')
    for item in routes:
        selected = item.get('lookup', {}).get('data', {}).get('routes', [])
        require(item.get('lookup', {}).get('ok') is True and selected and all(
                route.get('InterfaceAlias') == 'Ethernet' for route in selected), 'Route is not the reviewed Ethernet path')
    require(record.get('tcp', {}).get('ok') is True and record['tcp'].get('peer_ip') in ips
            and record['tcp'].get('peer_ip') == record.get('tls_connect_ip')
            and record.get('tls', {}).get('ok') is True
            and record['tls'].get('certificate_and_hostname_verification') is True,
            'Verified direct TLS did not complete')


def load_approved_key(profile):
    """Only reached inside an approved live worker, never in preparation/tests."""
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, 'Environment') as registry:
        values = {name: winreg.QueryValueEx(registry, name)[0] for name in
                  ('IOTJ_LLM_PROVIDER', 'IOTJ_LLM_MODEL', 'IOTJ_LLM_BASE_URL', 'IOTJ_LLM_API_KEY')}
    require(values['IOTJ_LLM_PROVIDER'] == 'openai' and values['IOTJ_LLM_MODEL'] == profile['model']
            and values['IOTJ_LLM_BASE_URL'].rstrip('/') == profile['base_url'], 'Saved backend differs from approval')
    key = values['IOTJ_LLM_API_KEY']
    require(isinstance(key, str) and bool(key.strip()), 'Saved API key is missing')
    return key.strip()


def direct_transport(profile, key):
    """Exactly one urllib open; no SDK retry, proxy, redirect or synthetic path."""
    import ssl
    import urllib.error
    import urllib.request
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            return None
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect(),
                                         urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    endpoint = profile['base_url'] + '/chat/completions'
    def call(payload):
        body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        request = urllib.request.Request(endpoint, data=body, method='POST',
                    headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
        try:
            with opener.open(request, timeout=profile['http_socket_timeout_seconds']) as response:
                raw, status = response.read(), response.status
        except urllib.error.HTTPError as error:
            raw = error.read().replace(key.encode(), b'[REDACTED]')
            raise HttpFailure(error.code, raw) from None
        return {'http_status': status, 'body_bytes': raw.replace(key.encode(), b'[REDACTED]')}
    return call


def generate_once(payload, transport, persist, record, clock=time.perf_counter):
    """Charge before sending and retain unknown usage on every failure; no retry."""
    require(record.get('model_request_attempts', 0) == 0, 'A cell cannot request a second generation')
    request = {'status': 'reserved', 'attempt': 1, 'automatic_retries': 0,
               'usage': None, 'usage_status': 'unknown', 'http_status': None,
               'send_entered': False, 'payload': copy.deepcopy(payload), 'started_utc': utc()}
    record['model_request_attempts'] = 1
    record['request'] = request
    persist('request_before', request)
    request['send_entered'] = True
    start = clock()
    try:
        try:
            response = transport(payload)
        finally:
            record['timing']['http_seconds'] = clock() - start
        request['http_status'] = response['http_status']
        raw = response['body_bytes'].decode('utf-8')
        persist('response_raw', {'http_status': response['http_status'], 'body': raw})
        start_decode = clock()
        try:
            result = json.loads(raw)
        finally:
            record['timing']['response_decode_seconds'] = clock() - start_decode
        usage = token_usage(result.get('usage'))
        request.update(status='responded', usage=usage, usage_status=usage_status(usage),
                       response_model=result.get('model'), response_id=result.get('id'), response_created=result.get('created'))
        choices = result.get('choices')
        require(isinstance(choices, list) and len(choices) == 1, 'Response must contain exactly one choice')
        request['finish_reason'] = choices[0].get('finish_reason')
        require(request['finish_reason'] == 'stop', 'Generation was truncated or not normally completed')
        text = choices[0].get('message', {}).get('content')
        require(isinstance(text, str) and bool(text.strip()), 'Response content is absent')
        return text
    except Exception as error:
        request.update(status='failed', error_type=type(error).__name__)
        if isinstance(error, HttpFailure):
            request['http_status'] = error.http_status
            persist('response_raw', {'http_status': error.http_status,
                                    'body': error.body_bytes.decode('utf-8', 'replace')})
            try:
                usage = token_usage(json.loads(error.body_bytes).get('usage'))
                request.update(usage=usage, usage_status=usage_status(usage))
            except (ValueError, AttributeError):
                pass
        raise
    finally:
        request['finished_utc'] = utc()
        request['timing'] = {name: record['timing'].get(name) for name in
                             ('http_seconds', 'response_decode_seconds')}
        persist('request_after', request)


def execute_cell(record, profile, diagnosis, prompt, decoder, calibrate, promote,
                 transport, persist, energy=None, clock=time.perf_counter):
    """Complete this new hybrid execution; all callbacks are injectable for pure tests."""
    timing = record.setdefault('timing', {})
    start = clock()
    def measured(name, function):
        before = clock()
        try:
            return function()
        finally:
            timing[name] = clock() - before
    try:
        evidence = measured('diagnosis_seconds', diagnosis)
        record['evidence'] = copy.deepcopy(evidence)
        system, user = measured('prompt_seconds', lambda: prompt(evidence))
        text = generate_once(request_payload(profile, system, user), transport, persist, record, clock)
        decoded = measured('parser_seconds', lambda: decoder(text, evidence))
        record['decoded'] = decoded
        require(decoded['metadata']['parsed_ok'] is True
                and decoded['metadata']['llm_attribution_eligible'] is True
                and decoded['metadata'].get('target_fallback', False) is False
                and decoded['metadata'].get('mode_fallback', False) is False,
                'Invalid model structure; original fallback is recorded but not admitted')
        selected = decoded['selection']
        candidates = measured('calibration_seconds', lambda: calibrate(evidence, selected))
        winner = measured('promotion_seconds', lambda: promote(candidates))
        timing['hybrid_wall_seconds'] = clock() - start
        timing['local_stage_seconds'] = sum(timing[name] for name in
            ('diagnosis_seconds', 'prompt_seconds', 'parser_seconds', 'calibration_seconds', 'promotion_seconds'))
        record['promotion'] = copy.deepcopy(winner)
        record['hybrid_status'] = 'complete'
        if energy is not None:
            record['energy'] = measured('energy_postprocess_seconds', lambda: energy(winner))
        record['status'] = 'complete'
        return record
    except BaseException as error:
        record.update(status='failed', error_type=type(error).__name__)
        timing['failed_cell_wall_seconds'] = clock() - start
        timing['local_stage_seconds'] = sum(timing.get(name, 0) for name in
            ('diagnosis_seconds', 'prompt_seconds', 'parser_seconds', 'calibration_seconds', 'promotion_seconds'))
        raise


def validate_worker_reservation(task, cell_root, preparation, preparation_path, out_root,
                                authorization_path, reservation_path):
    out_root = Path(out_root).resolve()
    require(not (out_root / 'completion.json').exists()
            and not (out_root / 'completion.json.writing').exists(), 'A stopped run cannot launch another worker')
    index = preparation['tasks'].index(task)
    expected = out_root / f'launch_{index+1:02d}.json'
    require(Path(reservation_path).resolve() == expected, 'Worker reservation is not its fixed task identity')
    reservation = read_json(expected)
    require(reservation.get('task') == task and reservation.get('parent_pid') == os.getppid()
            and reservation.get('preparation_sha256') == sha(preparation_path)
            and reservation.get('authorization_sha256') == sha(authorization_path)
            and reservation.get('cell_root') == str(cell_root.resolve()), 'Worker reservation differs from its live parent')
    for earlier in preparation['tasks'][:index]:
        prior = out_root / 'cells' / f"{earlier['scenario']}__{earlier['seed']:03d}" / 'cell.json'
        require((readable_record(prior) or {}).get('status') == 'complete', 'A prior task did not complete')
    save_new(expected.with_suffix('.claimed'), {'task': task, 'claimed_utc': utc(), 'reservation_sha256': sha(expected)})


def live_worker(task, cell_root, preparation, authorization, preparation_path, out_root, authorization_path,
                reservation_path):
    profile = validate_authorization(authorization, preparation, preparation_path, out_root)
    require(task in preparation['tasks'], 'Worker task is not in the fixed allocation')
    expected_root = Path(out_root).resolve() / 'cells' / f"{task['scenario']}__{task['seed']:03d}"
    require(cell_root.resolve() == expected_root and (Path(out_root) / 'manifest.json').is_file(),
            'Worker must occupy its unique parent-created cell identity')
    manifest = read_json(Path(out_root) / 'manifest.json')
    require(manifest['preparation_sha256'] == sha(preparation_path)
            and manifest['source_hashes'] == preparation['source_hashes']
            and manifest['authorization_sha256'] == sha(authorization_path), 'Parent run identity differs')
    lock = Path(authorization_path).with_suffix('.launch.lock')
    require(lock.is_file(), 'No parent launch reservation exists')
    reservation = read_json(lock)
    require(reservation.get('authorization_sha256') == sha(authorization_path)
            and reservation.get('preparation_sha256') == sha(preparation_path)
            and reservation.get('output_root') == str(Path(out_root).resolve()), 'Parent launch reservation differs')
    validate_worker_reservation(task, cell_root, preparation, preparation_path, out_root,
                                authorization_path, reservation_path)
    cell_root.mkdir()
    record = {'version': VERSION, **task, 'status': 'started', 'started_utc': utc(),
              'model_request_attempts': 0, 'groups': [], 'timing': {}, 'counts': {},
              'energy_enabled': preparation['energy_gate']}
    overall_start = time.perf_counter()
    def persist(name, value):
        save_new(cell_root / (name + '.json'), value)
    try:
        sys.path.insert(0, str(LEGACY))
        import mixed_structural_suite as suite
        import candidate_search as search
        import structural_alignment_v12 as alignment
        suite.os = SimpleNamespace(environ={'UAV_MIXED_FULL_SEARCH': ''})
        scene = suite.make_scenario_mixed(task['seed'], task['scenario'])
        history = historical_rows()[task['scenario'], task['seed']]
        original_simulator = suite.simulate_cset
        phase, active = 'nominal', None
        actual_calls, nominal_calls = 0, 0
        def simulate(scene, policy):
            nonlocal actual_calls, nominal_calls
            actual_calls += 1
            if phase == 'nominal':
                nominal_calls += 1
            attempt = {'policy': copy.deepcopy(policy), 'policy_hash': search.policy_semantic_hash(policy),
                       'status': 'started', 'raw_index': len(active['evaluations']) if active else 0}
            if active is not None:
                active['evaluations'].append(attempt)
            before = time.perf_counter()
            try:
                result = original_simulator(scene, policy)
                attempt.update(status='complete', metrics=copy.deepcopy(result['metrics']))
                return result
            except BaseException as error:
                attempt.update(status='failed', error_type=type(error).__name__)
                raise
            finally:
                attempt['elapsed_seconds'] = time.perf_counter() - before
                record['counts'].update(actual_simulator_calls=actual_calls, nominal_evaluations=nominal_calls,
                                       candidate_evaluations=actual_calls-nominal_calls, simulation_cache_hits=0)
        suite.simulate_cset = simulate
        def diagnosis():
            evidence = suite.evidence_from_nominal(scene)
            helpers = search._legacy_helpers(str(LEGACY.resolve()))
            require(helpers['_rounded_evidence'](search.public_evidence(evidence)) == json.loads(history['evidence_json']),
                    'Fresh nominal evidence differs from the fixed original task')
            return evidence
        def calibrate(evidence, selection):
            nonlocal phase, active
            phase = 'candidate'
            structures = [(SOURCES[0], suite._target_from_backlog(evidence), 'route_dwell'),
                          (SOURCES[1], suite._target_from_blackout(evidence), 'protocol_trigger'),
                          (SOURCES[2], 'east_hotspot', 'full_casp'),
                          ('fresh_model_structure', selection['target_cluster'], selection['repair_mode'])]
            candidates = []
            for index, (source, target, mode) in enumerate(structures):
                active = {'structure_index': index, 'source': source, 'target': target, 'mode': mode,
                          'raw_grid_entries': {'route_dwell': 18, 'protocol_trigger': 12, 'full_casp': 45}[mode],
                          'evaluations': []}
                record['groups'].append(active)
                before = time.perf_counter()
                try:
                    result = suite.calibrate_structure(scene, target, mode)
                    active['status'] = 'complete'
                except BaseException as error:
                    active.update(status='failed', error_type=type(error).__name__)
                    raise
                finally:
                    active.update(elapsed_seconds=time.perf_counter()-before,
                                  candidate_evaluations=len(active['evaluations']))
                active.update(
                              best_policy_hash=search.policy_semantic_hash(result['policy']),
                              best_metrics=copy.deepcopy(result['metrics']))
                candidates.append((source, result))
            total = sum(len(group['evaluations']) for group in record['groups'])
            require(actual_calls == total + 1 and total <= 120, 'Numerical replay accounting differs')
            record['counts'].update(candidate_evaluations=total, simulation_cache_hits=0)
            return candidates
        def promote(candidates):
            return suite.promote_candidate_results(candidates, 'compact_plus_fresh_model')
        def energy(winner):
            from original_energy_trace import simulate_with_energy_trace
            from original_energy_screen import load_config, evaluate_all
            record['counts']['energy_postprocess_simulator_calls'] = 1
            traced = simulate_with_energy_trace(scene, winner['policy'])
            require(traced['metrics'] == winner['metrics'], 'Energy instrumentation changed original service metrics')
            return {'timing_scope': 'after the complete original hybrid timer',
                    'result': evaluate_all(traced['energy_trace'], winner['metrics']['passed_contract'], load_config())}
        # No credential/config accessor is used until the authorization is validated.
        key = load_approved_key(profile)
        transport = direct_transport(profile, key)
        record['timing']['preparation_seconds'] = time.perf_counter() - overall_start
        execute_cell(record, profile, diagnosis, original_prompt, alignment.decode_legacy_response,
                     calibrate, promote, transport, persist,
                     energy=energy if preparation['energy_gate'] else None)
    except BaseException as error:
        record.update(status='failed', error_type=type(error).__name__)
        raise
    finally:
        record['finished_utc'] = utc()
        record['timing']['worker_body_seconds'] = time.perf_counter() - overall_start
        save_new(cell_root / 'cell.json', record)


def run(preparation_path, authorization_path, network_path, out):
    preparation, authorization = read_json(preparation_path), read_json(authorization_path)
    profile = validate_authorization(authorization, preparation, preparation_path, out)
    validate_network(read_json(network_path))
    out = Path(out).resolve()
    require(not out.exists(), 'A previous run exists; no overwrite/retry/resume is permitted')
    lock = Path(authorization_path).with_suffix('.launch.lock')
    save_new(lock, {'started_utc': utc(), 'authorization_sha256': sha(authorization_path),
                    'preparation_sha256': sha(preparation_path), 'output_root': str(out)})
    out.mkdir()
    save_new(out / 'manifest.json', {'version': VERSION, 'status': 'started', 'profile': profile,
             'source_hashes': preparation['source_hashes'], 'energy_gate': preparation['energy_gate'],
             'tasks': preparation['tasks'], 'authorization_sha256': sha(authorization_path),
             'preparation_sha256': sha(preparation_path), 'network_result_sha256': sha(network_path)})
    save_new(out / 'authorization.json', authorization)
    save_new(out / 'preparation.json', preparation)
    (out / 'cells').mkdir()
    completed, start, failure = 0, time.perf_counter(), None
    try:
        for task in preparation['tasks']:
            require(bindings(preparation['energy_gate']) == preparation['source_hashes'], 'Frozen source changed')
            cell_root = out / 'cells' / f"{task['scenario']}__{task['seed']:03d}"
            worker_reservation = out / f'launch_{completed+1:02d}.json'
            save_new(worker_reservation, {'task': task, 'parent_pid': os.getpid(),
                     'preparation_sha256': sha(preparation_path), 'authorization_sha256': sha(authorization_path),
                     'cell_root': str(cell_root), 'reserved_utc': utc()})
            command = [sys.executable, '-X', 'utf8', '-B', str(Path(__file__).resolve()), '--worker',
                       '--scenario', task['scenario'], '--seed', str(task['seed']), '--cell-root', str(cell_root),
                       '--preparation', str(preparation_path), '--authorization', str(authorization_path), '--out', str(out),
                       '--worker-reservation', str(worker_reservation)]
            before = time.perf_counter()
            try:
                child = subprocess.run(command, capture_output=True, text=True, encoding='utf-8',
                                       timeout=profile['worker_total_timeout_seconds'])
            except subprocess.TimeoutExpired:
                save_new(out / f'worker_{completed+1:02d}.json', {'task': task, 'status': 'timed_out',
                         'returncode': None, 'worker_seconds': time.perf_counter()-before,
                         'usage_status': 'read saved request artifacts; missing fields remain unknown'})
                raise
            save_new(out / f'worker_{completed+1:02d}.json', {'task': task, 'returncode': child.returncode,
                     'worker_seconds': time.perf_counter()-before, 'stderr': child.stderr[-1500:]})
            require(child.returncode == 0, 'Worker failed; preserve records and stop without retry')
            require(read_json(cell_root / 'cell.json')['status'] == 'complete', 'Worker did not complete')
            completed += 1
            print(f'LATENCY_TASK_DONE {completed}/12 {task["scenario"]} seed={task["seed"]}', flush=True)
        require(bindings(preparation['energy_gate']) == preparation['source_hashes'], 'Sources changed after final worker')
    except BaseException as error:
        failure = type(error).__name__
    cell_records = [record for path in sorted((out / 'cells').glob('*/cell.json'))
                    if (record := readable_record(path)) is not None]
    before_records = list((out / 'cells').glob('*/request_before.json'))
    completion = {'version': VERSION, 'status': 'complete' if completed == 12 and failure is None else 'failed',
                  'completed_cells': completed, 'expected_cells': 12, 'request_attempts_reserved': len(before_records),
                  'request_attempts_cap': 12, 'probe_attempts': 0, 'automatic_retries': 0,
                  'error_type': failure, 'run_wall_seconds': time.perf_counter()-start,
                  'source_hashes_after': bindings(preparation['energy_gate']),
                  'cell_hashes': {str(path.relative_to(out)): sha(path) for path in (out / 'cells').rglob('*.json')},
                  'unknown_worker_attempts': sum(readable_record(path.parent/'request_after.json') is None for path in before_records),
                  'interrupted_writing_artifacts': [str(path.relative_to(out)) for path in out.rglob('*.writing')],
                  'finished_utc': utc()}
    save_new(out / 'completion.json', completion)
    summarize_live(out, cell_records, completion)
    print('RESULT_FILE:', out / 'completion.json', flush=True)
    return 0 if completion['status'] == 'complete' else 2


def summarize_live(out, cells, completion):
    from summarize_original_structural_costs import numeric_summary
    names = ('http_seconds', 'response_decode_seconds', 'diagnosis_seconds', 'prompt_seconds',
             'parser_seconds', 'calibration_seconds', 'promotion_seconds', 'local_stage_seconds',
             'hybrid_wall_seconds', 'failed_cell_wall_seconds', 'energy_postprocess_seconds')
    # A killed worker may leave a responded request but no final cell. Its known
    # tokens and HTTP time remain part of the attempted-request population.
    before_paths = sorted(Path(out).glob('cells/*/request_before.json'))
    requests = [(readable_record(path.parent / 'request_after.json')
                 or {'status': 'unknown_after_interruption', 'usage': None, 'timing': {}})
                for path in before_paths]
    usages = [token_usage(request.get('usage')) for request in requests]
    usage_fields = {}
    for name in TOKEN_FIELDS:
        observed = [usage[name] for usage in usages if usage is not None and usage[name] is not None]
        usage_fields[name] = {'observed_total': sum(observed) if observed else None,
                             'observed_count': len(observed), 'unknown_count': len(requests)-len(observed)}
    summary = {'scope': '12-task current online illustration; not historical timing, effect evidence, or a population p95 guarantee',
               'completion_status': completion['status'], 'completed_cells': completion['completed_cells'],
               'saved_cells': len(cells), 'reserved_attempts': completion['request_attempts_reserved'],
               'unknown_worker_attempts': completion['unknown_worker_attempts'],
               'failed_cells': sum(cell.get('status') != 'complete' for cell in cells),
               'service_passes': sum(cell.get('promotion', {}).get('metrics', {}).get('passed_contract') is True for cell in cells),
               'service_failures': sum(cell.get('promotion', {}).get('metrics', {}).get('passed_contract') is False for cell in cells),
               'usage_unknown_requests': sum(usage_status(usage) != 'recorded' for usage in usages),
               'invalid_model_structures': sum(cell.get('decoded', {}).get('metadata', {}).get('parsed_ok') is False
                                               or cell.get('decoded', {}).get('metadata', {}).get('llm_attribution_eligible') is False
                                               or cell.get('decoded', {}).get('metadata', {}).get('target_fallback') is True
                                               or cell.get('decoded', {}).get('metadata', {}).get('mode_fallback') is True
                                               for cell in cells),
               'request_failures_or_unknown': sum(request.get('status') != 'responded' for request in requests),
               'unexecuted_tasks': 12 - len(before_paths),
               'usage_fields': usage_fields,
               'time_seconds': {name: numeric_summary(cell.get('timing', {}).get(name) for cell in cells) for name in names},
               'request_http_seconds': numeric_summary(request.get('timing', {}).get('http_seconds') for request in requests),
               'historical_latency_seconds': None, 'automatic_retries': 0, 'new_probe_requests': 0}
    save_new(Path(out) / 'summary.json', summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--check-launch', action='store_true', help='Validate a new approval without key/network/simulation access')
    parser.add_argument('--prepare', type=Path, help='Write a fresh reviewable preparation/budget package')
    parser.add_argument('--energy', action='store_true', help='Bind optional separately timed postprocessing at preparation')
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--preparation', type=Path)
    parser.add_argument('--authorization', type=Path)
    parser.add_argument('--network-result', type=Path)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--worker', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--scenario', help=argparse.SUPPRESS)
    parser.add_argument('--seed', type=int, help=argparse.SUPPRESS)
    parser.add_argument('--cell-root', type=Path, help=argparse.SUPPRESS)
    parser.add_argument('--worker-reservation', type=Path, help=argparse.SUPPRESS)
    arguments = parser.parse_args()
    try:
        if arguments.worker:
            require(not any((arguments.check_only, arguments.check_launch, arguments.run, arguments.prepare,
                             arguments.energy, arguments.network_result)), 'Worker cannot override a check or run mode')
            require(all((arguments.preparation, arguments.authorization, arguments.out, arguments.cell_root,
                         arguments.worker_reservation)), 'Worker inputs incomplete')
            live_worker({'scenario': arguments.scenario, 'seed': arguments.seed}, arguments.cell_root,
                        read_json(arguments.preparation), read_json(arguments.authorization), arguments.preparation,
                        arguments.out, arguments.authorization, arguments.worker_reservation)
            return 0
        if arguments.check_launch:
            require(not any((arguments.run, arguments.prepare, arguments.energy, arguments.check_only))
                    and all((arguments.preparation, arguments.authorization, arguments.out)), 'Launch-check inputs differ')
            validate_authorization(read_json(arguments.authorization), read_json(arguments.preparation),
                                   arguments.preparation, arguments.out)
            require(not arguments.out.exists() and not arguments.authorization.with_suffix('.launch.lock').exists(),
                    'A prior run/reservation exists; review it before any new attempt')
            print('CHECK_LAUNCH: PASS; model/config/key/network/simulator access=0')
            return 0
        if arguments.run:
            require(not arguments.check_only and not arguments.prepare and not arguments.energy,
                    'A live run must use its frozen preparation, without override flags')
            require(all((arguments.preparation, arguments.authorization, arguments.network_result, arguments.out)), 'Live inputs incomplete')
            return run(arguments.preparation, arguments.authorization, arguments.network_result, arguments.out)
        package = prepare(arguments.energy)
        if arguments.prepare:
            save_new(arguments.prepare, package)
            print('PREPARATION_FILE:', arguments.prepare.resolve())
        print(json.dumps({key: package[key] for key in ('status', 'model_requests', 'network_calls',
                           'model_config_reads', 'api_key_reads', 'real_simulator_calls',
                           'estimated_usage_reference_of_matched_historical_12')}, ensure_ascii=False))
        return 0
    except BaseException as error:
        print('STOPPED:', type(error).__name__, '; no automatic retry; preserve all records.', flush=True)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
