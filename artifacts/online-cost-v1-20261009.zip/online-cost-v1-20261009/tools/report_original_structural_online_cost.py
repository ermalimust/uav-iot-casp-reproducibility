"""Recompute a descriptive cost report from saved measurements, without imports of experiment code."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stats(values):
    values = sorted(values)
    assert values and all(type(v) in (int, float) and math.isfinite(v) and v >= 0 for v in values)
    def q(f):
        x = (len(values)-1)*f
        lo, hi = math.floor(x), math.ceil(x)
        return values[lo]+(values[hi]-values[lo])*(x-lo)
    return dict(n=len(values), minimum=min(values), median=q(.5), sample_p95=q(.95), maximum=max(values))


def generate(root, out):
    assert not out.exists(), 'Preserve previous report; choose a new output directory'
    completion = read(root/'completion.json')
    preparation = read(root/'preparation.json')
    assert completion['status'] == 'complete' and completion['completed_cells'] == 12
    assert completion['request_attempts_reserved'] == 12 and completion['automatic_retries'] == completion['probe_attempts'] == 0
    for relative, digest in completion['cell_hashes'].items():
        assert sha(root/relative.replace('\\','/')) == digest, relative
    rows = []
    for index, task in enumerate(preparation['tasks'], 1):
        directory = root/'cells'/f"{task['scenario']}__{task['seed']:03d}"
        cell, request = read(directory/'cell.json'), read(directory/'request_after.json')
        raw = json.loads(read(directory/'response_raw.json')['body'])
        worker = read(root/f'worker_{index:02d}.json')
        assert cell['status'] == 'complete' and request['status'] == 'responded' and worker['returncode'] == 0
        assert worker['task'] == task == {k:cell[k] for k in ('scenario','seed')}
        assert cell['model_request_attempts'] == request['attempt'] == 1
        assert request['automatic_retries'] == 0 and cell['counts']['simulation_cache_hits'] == 0
        assert all(raw['usage'][k] == request['usage'][k] for k in ('prompt_tokens','completion_tokens','total_tokens'))
        t=cell['timing']
        rows.append(dict(**task, request_seconds=t['http_seconds'], local_stage_seconds=t['local_stage_seconds'],
                         calibration_seconds=t['calibration_seconds'], diagnosis_to_promotion_seconds=t['hybrid_wall_seconds'],
                         worker_startup_to_exit_seconds=worker['worker_seconds'],
                         candidate_evaluations=cell['counts']['candidate_evaluations'],
                         nominal_evaluations=cell['counts']['nominal_evaluations'],
                         actual_simulator_calls=cell['counts']['actual_simulator_calls'],
                         portfolio_service_pass=cell['promotion']['metrics']['passed_contract'],
                         portfolio_winner=cell['promotion']['portfolio_winner'],
                         response_model=request['response_model'], prompt_tokens=request['usage']['prompt_tokens'],
                         completion_tokens=request['usage']['completion_tokens'],total_tokens=request['usage']['total_tokens']))
    assert len(rows) == 12
    intervals=[('request_seconds','Request/response'),('local_stage_seconds','Local stages'),
               ('calibration_seconds','Numerical calibration'),('diagnosis_to_promotion_seconds','Diagnosis to promotion'),
               ('worker_startup_to_exit_seconds','Worker startup to exit')]
    measures={key:stats([row[key] for row in rows]) for key,label in intervals}
    totals={key:sum(row[key] for row in rows) for key in ('candidate_evaluations','nominal_evaluations','actual_simulator_calls',
                                                       'prompt_tokens','completion_tokens','total_tokens')}
    assert totals['actual_simulator_calls'] == totals['candidate_evaluations']+totals['nominal_evaluations']
    report={'scope':'Prespecified 12-task current cost illustration; no new effectiveness comparison or population tail guarantee',
            'quantile_rule':'Linear interpolation at sorted index (n-1)*q, type 7','timing_seconds':measures,'totals':totals,
            'requests':12,'retries':0,'probes':0,'energy_screen_enabled':False,
            'diagnosis_to_promotion_scope':'Includes online request and request/response persistence; excludes worker startup/preparation and final cell-artifact writing',
            'request_scope':'Transport call, including request encoding/construction, verified direct connection, service/generation and response transfer/handling; not pure model compute',
            'input_identities':{name:sha(root/name) for name in ('completion.json','preparation.json','manifest.json','summary.json')}}
    table=['% Generated from saved measurements only; nested intervals are not additive.','\\begin{table*}[t]','\\centering',
           '\\caption{Current online cost illustration: three predeclared seeds per S1--S4 case, one fresh model request per task ($n=12$). All tasks are retained. Quantiles describe this sample; intervals are nested and must not be added.}',
           '\\label{tab:original_structural_online_cost}','\\small','\\begin{tabular}{lrrrr}','\\hline',
           'Measured interval & $n$ & Median (s) & Sample p95 (s) & Range (s) \\\\','\\hline']
    for key,label in intervals:
        m=measures[key]
        table.append(f"{label} & {m['n']} & {m['median']:.3f} & {m['sample_p95']:.3f} & {m['minimum']:.3f}--{m['maximum']:.3f} \\\\")
    table += ['\\hline','\\end{tabular}','\\end{table*}','']
    out.mkdir(parents=True,exist_ok=False)
    (out/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    with (out/'per_task.csv').open('w',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (out/'original_structural_online_cost_table.tex').write_text('\n'.join(table),encoding='utf-8',newline='\n')
    markdown=['# Current online repair-loop cost','',report['scope'],'',
              '| Measured interval | n | Median (s) | Sample p95 (s) | Range (s) |','|---|---:|---:|---:|---:|']
    for key,label in intervals:
        m=measures[key];markdown.append(f"| {label} | {m['n']} | {m['median']:.3f} | {m['sample_p95']:.3f} | {m['minimum']:.3f}–{m['maximum']:.3f} |")
    markdown += ['',report['diagnosis_to_promotion_scope']+'.', '',report['request_scope']+'.',
                 '',f"Actual numerical/nominal simulator calls: {totals['candidate_evaluations']} + {totals['nominal_evaluations']} = {totals['actual_simulator_calls']}. Twelve requests, zero retries/probes. Reported tokens: {totals['prompt_tokens']} prompt + {totals['completion_tokens']} completion = {totals['total_tokens']} total. No monetary bill is inferred.",'']
    (out/'report.md').write_text('\n'.join(markdown),encoding='utf-8',newline='\n')
    print('REPORT_DIRECTORY:',out)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--result-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    generate(args.result_root,args.output)
