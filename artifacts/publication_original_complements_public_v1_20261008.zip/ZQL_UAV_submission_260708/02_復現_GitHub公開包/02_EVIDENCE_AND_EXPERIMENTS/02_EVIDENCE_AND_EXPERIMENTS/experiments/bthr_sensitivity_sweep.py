#!/usr/bin/env python3
"""
Contract-threshold (B_thr) sensitivity sweep -- EXACT contract logic, no re-simulation.

v2: replicates the simulator's `passed_contract` definition exactly
(validated to match per-method pass rates at the canonical threshold):

    QSR(B_thr) >= qsr_min  AND  max_i b_obs <= B_thr  AND  recovery_time <= rec_max
    where S_i = [pdr_i >= rho_min  AND  l95_i <= l_max  AND  b_obs_i <= B_thr]

INPUT
  --device-csv   per-device metrics: method, seed, device, pdr, l95, b_obs
  --summary-csv  per-seed metrics:   method, seed, recovery_time (e.g. summary_metrics.csv)

USAGE
  python bthr_sensitivity_sweep.py \
      --device-csv results/per_device_metrics.csv \
      --summary-csv results/summary_metrics.csv

OUTPUT
  bthr_sweep_results_exact.csv, bthr_sweep_plot_exact.png, knife-edge report.
"""
import argparse

import numpy as np
import pandas as pd

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAVE_MPL = True
except ImportError:
    HAVE_MPL = False


def parse_args():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--device-csv", required=True)
    p.add_argument("--summary-csv", required=True)
    p.add_argument("--pdr-min", type=float, default=0.70)
    p.add_argument("--l95-max", type=float, default=62.0)
    p.add_argument("--qsr-min", type=float, default=0.70)
    p.add_argument("--rec-max", type=float, default=82.0)
    p.add_argument("--bthr-grid", nargs=3, type=float, default=[40, 70, 1],
                   metavar=("START", "STOP", "STEP"))
    p.add_argument("--canonical-bthr", type=float, default=52.0)
    p.add_argument("--out-prefix", default="bthr_sweep")
    return p.parse_args()


def main():
    a = parse_args()
    dev = pd.read_csv(a.device_csv)
    summ = pd.read_csv(a.summary_csv)
    rec = summ.set_index(["method", "seed"])["recovery_time"]
    rho = dev["rho_min"] if "rho_min" in dev.columns else a.pdr_min
    lmax = dev["l_max"] if "l_max" in dev.columns else a.l95_max
    pre_ok = (dev["pdr"] >= rho) & (dev["l95"] <= lmax)

    def pass_rates(bthr):
        ok = pre_ok & (dev["b_obs"] <= bthr)
        g = dev.assign(ok=ok).groupby(["method", "seed"])
        qsr, maxb = g["ok"].mean(), g["b_obs"].max()
        passed = (qsr >= a.qsr_min) & (maxb <= bthr) & (rec.reindex(qsr.index) <= a.rec_max)
        return passed.groupby(level=0).mean()

    # validation at the canonical threshold against the simulator's own verdicts
    if "passed_contract" in summ.columns:
        recomp = pass_rates(a.canonical_bthr)
        orig = summ.groupby("method")["passed_contract"].mean()
        bad = (recomp - orig.reindex(recomp.index)).abs() > 1e-9
        if bad.any():
            raise SystemExit(f"validation FAILED at canonical threshold:\n"
                             f"{pd.DataFrame({'recomputed': recomp[bad], 'simulator': orig[bad]})}")
        print(f"validation at B_thr={a.canonical_bthr:g}: exact match with simulator verdicts")

    start, stop, step = a.bthr_grid
    grid = np.arange(start, stop + step / 2, step)
    rows = [{"method": m, "b_thr": float(b), "pass_rate": round(float(p), 4)}
            for b in grid for m, p in pass_rates(b).items()]
    out = pd.DataFrame(rows)
    out.to_csv(f"{a.out_prefix}_results_exact.csv", index=False)
    print(f"wrote {a.out_prefix}_results_exact.csv")

    print(f"\nKnife-edge around canonical ({a.canonical_bthr:g} +/- 2 slots):")
    piv = out.pivot(index="b_thr", columns="method", values="pass_rate")
    sel = [a.canonical_bthr + d for d in (-2, 0, 2) if a.canonical_bthr + d in piv.index]
    print(piv.loc[sel].round(2).T.to_string())

    if HAVE_MPL:
        fig, ax = plt.subplots(figsize=(7, 4.2))
        for m, g in out.groupby("method"):
            ax.plot(g["b_thr"], g["pass_rate"], marker="o", ms=2, lw=1.1, label=m)
        ax.axvline(a.canonical_bthr, color="k", ls="--", lw=0.8,
                   label=f"canonical ({a.canonical_bthr:g})")
        ax.set_xlabel(r"$B^{\mathrm{thr}}$ (slots)")
        ax.set_ylabel("contract pass rate")
        ax.legend(fontsize=6.5, ncol=2)
        fig.tight_layout()
        fig.savefig(f"{a.out_prefix}_plot_exact.png", dpi=200)
        print(f"wrote {a.out_prefix}_plot_exact.png")


if __name__ == "__main__":
    main()
