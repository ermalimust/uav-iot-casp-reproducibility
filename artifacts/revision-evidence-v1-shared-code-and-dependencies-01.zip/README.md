# UAV-IoT CASP reproducibility — original core

Version: **original-core-v1**, 2026-10-08.
Repository: https://github.com/ermalimust/uav-iot-casp-reproducibility

This snapshot contains the submitted study's simulator, contract/configuration
records, seed-level CSVs, candidate/backend caches, and original reduced ns-3
sources. The scientific files are byte-identical to the independently checked
original-core review candidate. No API credential, reviewer report, response
document, or manuscript is included. This version supports offline numerical
reproduction; it does not require a new model request.

The archive is `publication_original_core_v1_20261008.zip`. After extracting it,
run the commands below from the extracted root. `MANIFEST.json` records file
identities, while the repository's publication receipt records the archive hash
and the verified public commit. No additional reuse license is granted by this
snapshot; any existing source attribution and third-party terms remain applicable.

## Offline verification

Python 3.12 is used in the accompanying measurements. Run `python -B
verify_artifact.py` from this directory to verify every packaged hash and recover
the original four-case structural pass counts from the frozen seed ledger. This
command uses only the Python standard library and sends no network request.

The original source hierarchy is retained to preserve imports and path bindings.
The original clients are included for inspectability; offline verification does
not import them. Replaying saved responses does not require a model API key.

## Re-run the original numerical loop without new model calls

Install the simulator's numerical/plot dependencies (`numpy`, `matplotlib`) in a
separate Python environment if absent. A small full-loop reproduction from this
clean snapshot is:

`python -B revision/experiments/measure_original_structural_costs.py --seeds 1:1 --out reproduction_smoke`

This evaluates all S1–S4 cases and the compact, compact+expert, and compact+cached
model arms using the original raw grids and first-pass rules. It refuses to
overwrite an existing output. Change the seed range to `1:100` for the complete
400-instance / 1200-cell service-calibration reproduction. The current hardware
will determine timing/memory; new resource measurements are not historical model
request latencies. API requests remain zero.

## Evidence boundaries and supplemental release

The canonical study uses normalized service profiles and 30 stationary devices;
the included old ns-3 program is only a reduced two-node anchor. It must not be
called the new full multi-node validation. The hard-energy, multi-predicate,
fresh online-latency, and full native CASP extensions are being separately
assembled; this original-core snapshot does not claim to include those pending
extensions. Historical filenames and exploratory data are retained as provenance;
the source-backed index in the manuscript determines which rows support a claim.

An API cache's model alias identifies saved responses, not a guaranteed current
provider version. Costs, physical safety, and deployment SLA requirements must
be interpreted under the specified simulator/measurement contract.
