# 原结构校准的新增实测成本

统计对象为新增的本地离线回放，包含全部服务通过及未通过样本。原模型响应读取自缓存；真实 LLM/HTTP 延迟没有保存，保持 null，不能由本地读取时间代替。

共 1200 个 worker cell、400 个 task；候选仿真合计 75614 次，另有 nominal diagnosis 1200 次，实际仿真合计 76814 次。新增模型请求 0，计时过程仿真 cache hit 0。

local method 秒数覆盖 diagnosis、selector、calibration 和 promotion，排除 worker 准备及事后验证；这是带记录运行，嵌套 replay 计时包含 policy hash/复制等记录开销，不能称纯 simulator CPU 时间，且不再重复相加。内存为独立 worker 的绝对 peakWorkingSet，包含解释器/导入/准备及事后验证，采样截至 artifact 编码之前，单位 MiB；不是方法独占内存或增量内存。

分位数：linear interpolation at sorted index (n - 1) * q (R type 7)。

| 场景 | 方法 | n | 服务通过/失败 | 实际候选 median / p95 | local method s median / p95 | 绝对 peak MiB median / p95 / max |
|---|---|---:|---:|---:|---:|---:|
| S1_seen_burst_east | Compact | 100 | 98/2 | 22.0 / 38.0 | 1.043 / 1.781 | 32.26 / 32.82 / 32.84 |
| S1_seen_burst_east | Compact + expert | 100 | 98/2 | 23.0 / 55.0 | 1.084 / 2.564 | 32.44 / 32.65 / 32.75 |
| S1_seen_burst_east | Compact + cached LLM | 100 | 98/2 | 23.0 / 55.0 | 1.090 / 2.561 | 32.58 / 32.73 / 32.98 |
| S2_seen_degrade_west | Compact | 100 | 94/6 | 62.0 / 75.0 | 2.995 / 3.462 | 32.39 / 32.70 / 32.84 |
| S2_seen_degrade_west | Compact + expert | 100 | 100/0 | 64.0 / 76.0 | 3.101 / 3.727 | 32.23 / 32.68 / 32.88 |
| S2_seen_degrade_west | Compact + cached LLM | 100 | 100/0 | 69.0 / 83.2 | 3.328 / 4.104 | 32.28 / 32.70 / 32.81 |
| S3_seen_moved_burst | Compact | 100 | 69/31 | 66.0 / 75.0 | 3.052 / 3.469 | 32.36 / 32.82 / 32.84 |
| S3_seen_moved_burst | Compact + expert | 100 | 88/12 | 80.0 / 120.0 | 3.702 / 5.469 | 32.45 / 32.69 / 32.74 |
| S3_seen_moved_burst | Compact + cached LLM | 100 | 88/12 | 78.0 / 120.0 | 3.595 / 5.471 | 32.25 / 32.62 / 32.70 |
| S4_heldout_misleading | Compact | 100 | 48/52 | 75.0 / 75.0 | 3.446 / 3.508 | 32.29 / 32.70 / 32.95 |
| S4_heldout_misleading | Compact + expert | 100 | 77/23 | 87.0 / 120.0 | 4.008 / 5.543 | 32.23 / 32.80 / 32.94 |
| S4_heldout_misleading | Compact + cached LLM | 100 | 73/27 | 91.5 / 120.0 | 4.226 / 5.561 | 32.33 / 32.72 / 32.96 |

## 同 task 配对增量

以下为同场景、同 seed 的增强方法减 compact；各方法在独立 worker 中实测。负时间差保留，反映计时波动；这不是对单个进程额外代码段的计时。

| 场景 | 增强方法 | 配对 n | Δ候选 median / p95 | Δlocal s median / p95 | 负时间差 n |
|---|---|---:|---:|---:|---:|
| S1_seen_burst_east | Compact + expert | 100 | 1.0 / 17.0 | 0.046 / 0.784 | 3 |
| S1_seen_burst_east | Compact + cached LLM | 100 | 1.0 / 17.0 | 0.051 / 0.794 | 2 |
| S2_seen_degrade_west | Compact + expert | 100 | 1.0 / 8.2 | 0.066 / 0.503 | 9 |
| S2_seen_degrade_west | Compact + cached LLM | 100 | 6.0 / 18.0 | 0.314 / 0.853 | 1 |
| S3_seen_moved_burst | Compact + expert | 100 | 14.0 / 45.0 | 0.649 / 2.032 | 0 |
| S3_seen_moved_burst | Compact + cached LLM | 100 | 13.0 / 45.0 | 0.573 / 2.035 | 1 |
| S4_heldout_misleading | Compact + expert | 100 | 13.0 / 45.0 | 0.578 / 2.065 | 1 |
| S4_heldout_misleading | Compact + cached LLM | 100 | 22.0 / 45.0 | 0.967 / 2.090 | 1 |

这些测量不包含原在线 API 推理时间，也不代表真实飞行任务耗时、功耗或电池可行性。成功/失败总体和候选数量按原 first-pass 流程统计，理论 grid 上限没有代替实际执行次数。

完整数值、缺失计数、machine 信息和每个 measured cell 的 SHA-256 见 `summary.json`。


## 2026-10-08 核验与文稿同步

完整独立审计 PASS：524,956 项内部一致性检查、0 错误；检查数不是统计样本量。原输入及执行源哈希前后不变，原15页提交PDF保留。三组通过总数分别309/400、363/400、359/400；这是旧任务的成本重放，不增加独立效果观测。

R1.10已填入本地计量与边界；R2.3补入成本、原能量实现事实及安全范围，硬能量实验和在线模型时延明确未完成。正文仅补IV-B计算上界、能量字段事实和安全范围；补充材料增加实测表，R2.2既有收益表述保留。

[完整记录](F:/my-project/iotj/revision/experiments/results/original_structural_cost_20261008/completion.json)、[独立审计](F:/my-project/iotj/revision/experiments/results/original_structural_cost_20261008_independent_audit.json)、[统计JSON](F:/my-project/iotj/revision/experiments/results/original_structural_cost_analysis_20261008/summary.json)。本轮API请求0。真实推理时延、硬电池/返航以及完整多节点ns-3仍需后续补证。

内置回复编译在最终源上仍报 `Unable to find standard directories for platform`；源括号、27条审稿意见与R2.2保留、12行表格及输入引用已检查，PDF排版未验证。
