﻿Frozen mixed structural experiment
Date: 2026-06-17
N: 100 seeds/type
Backend: openai/qwen-plus
Key result on held-out S4:
rule_only_portfolio = 0.48
llm_only_structure = 0.61
hybrid_portfolio = 0.73
SR_scripted_mixed_reference = 0.66
Holm-adjusted p, hybrid vs rule_only_portfolio = 1.788e-07

Do not rerun with UAV_LLM_REFRESH=1 for manuscript evidence.
Use this frozen folder for paper tables/statistics.
