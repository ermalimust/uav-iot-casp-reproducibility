"""Recompute saved revision evidence without simulation or model requests.

Scientific files are read at their original bytes. This separate adapter changes
only runtime path interpretation and writes into a fresh directory outside the
extracted package. Python 3.10 or later; standard library only.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path as RealPath, PureWindowsPath
import sys

sys.dont_write_bytecode = True

HISTORICAL_ROOT = "F:/my-project/iotj"
MODULE_FILES = {
    "audit_original_structural_costs": "revision/experiments/audit_original_structural_costs.py",
    "summarize_original_structural_costs": "revision/experiments/summarize_original_structural_costs.py",
    "audit_original_energy_screen": "revision/experiments/audit_original_energy_screen.py",
    "summarize_original_energy_screen": "revision/experiments/summarize_original_energy_screen.py",
    "analyze_original_contract_neighborhood": "revision/experiments/analyze_original_contract_neighborhood.py",
    "audit_original_contract_neighborhood": "revision/experiments/audit_original_contract_neighborhood.py",
}
ACTIONS = ("verify", "cost-audit", "cost-summary", "energy-audit",
           "energy-summary", "predicates", "predicate-audit")


def raw_sha(path):
    return hashlib.sha256(RealPath(path).read_bytes()).hexdigest()


def write_new_json(path, value):
    with RealPath(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


class Adapter:
    def __init__(self, root, out=None):
        self.root = RealPath(root).resolve()
        self.out = RealPath(out).resolve() if out is not None else None
        if not self.root.is_dir():
            raise ValueError("Extracted package root is missing")
        if self.out is not None:
            if self.out.exists():
                raise ValueError("Output must be a new directory")
            if self.out == self.root or self.root in self.out.parents or self.out in self.root.parents:
                raise ValueError("Output and extracted package directories must be disjoint")
        self.manifest_path = self.root / "revision-evidence-v1/MANIFEST.json"
        self.manifest = json.loads(self.manifest_path.read_text(encoding="utf-8-sig"))
        records = self.manifest.get("files")
        if not isinstance(records, list) or not records:
            raise ValueError("MANIFEST must contain a nonempty files list")
        self.files, self.expected = set(), {}
        for record in records:
            if not isinstance(record, dict):
                raise ValueError("Malformed inventory record")
            relative = record.get("path")
            if not isinstance(relative, str) or not relative:
                raise ValueError("Inventory path must be a nonempty relative string")
            relative = relative.replace("\\", "/")
            if PureWindowsPath(relative).drive or RealPath(relative).is_absolute() or ".." in relative.split("/"):
                raise ValueError("Unsafe inventory path")
            path = (self.root / relative).resolve()
            if self.root not in path.parents or path == self.manifest_path:
                raise ValueError("Inventory escapes root or self-hashes its manifest")
            if path in self.files:
                raise ValueError("Duplicate or colliding inventory path")
            size, wanted = record.get("bytes"), record.get("sha256")
            if type(size) is not int or size < 0 or not isinstance(wanted, str) or len(wanted) != 64:
                raise ValueError("Malformed byte count or SHA256")
            if not path.is_file() or path.stat().st_size != size or raw_sha(path) != wanted:
                raise ValueError("Inventory byte identity failed: " + relative)
            self.files.add(path)
            self.expected[path] = (size, wanted)
        self.ancestors = {self.root}
        for path in self.files:
            self.ancestors.update(parent for parent in path.parents if parent == self.root or self.root in parent.parents)
        self.modules = {}

    def portable_path(self, *parts):
        if not parts:
            return RealPath()
        first = os.fspath(parts[0])
        if isinstance(first, bytes):
            raise TypeError("Bytes paths are unsupported")
        normalized = first.replace("\\", "/")
        old = HISTORICAL_ROOT.lower()
        mapped = normalized.lower() == old or normalized.lower().startswith(old + "/")
        # A fresh checkout/output may itself sit below the historical workspace.
        # Recognize those actual domains before considering the old prefix.
        incoming = RealPath(normalized)
        if incoming.is_absolute():
            actual = incoming.resolve()
            already_fresh = actual == self.root or self.root in actual.parents
            already_output = self.out is not None and (actual == self.out or self.out in actual.parents)
            if already_fresh or already_output:
                mapped = False
        if mapped:
            suffix = normalized[len(HISTORICAL_ROOT):].lstrip("/")
            path = self.root / suffix
        else:
            if PureWindowsPath(normalized).drive and os.name != "nt":
                raise ValueError("Unmapped foreign absolute path")
            path = RealPath(normalized)
        for part in parts[1:]:
            path = path / os.fspath(part).replace("\\", "/")
        if mapped:
            path = path.resolve()
            if path not in self.files and path not in self.ancestors:
                raise ValueError("Historical path is absent from inventory")
        return path

    def read_allowed(self, path):
        path = self.portable_path(path).resolve()
        generated = self.out is not None and self.out in path.parents
        if path not in self.files and not generated:
            raise ValueError("Read or hash outside verified inventory/output: " + str(path))
        return path

    def digest(self, path):
        return raw_sha(self.read_allowed(path))

    def read_json(self, path):
        return json.loads(self.read_allowed(path).read_text(encoding="utf-8-sig"))

    def mapped_binding_keys(self, values):
        if not isinstance(values, dict):
            raise ValueError("Path binding ledger must be a dictionary")
        mapped = {}
        for key, value in values.items():
            local = str(self.portable_path(key).resolve())
            if local in mapped:
                raise ValueError("Path binding mapping collision")
            self.read_allowed(local)
            mapped[local] = value
        return mapped

    def load(self, name):
        if name in self.modules:
            return self.modules[name]
        if name not in MODULE_FILES:
            raise ValueError("Scientific module is not an allowed accounting entry")
        if name == "analyze_original_contract_neighborhood":
            self.load("summarize_original_energy_screen")
        path = self.read_allowed(self.root / MODULE_FILES[name])
        if name in sys.modules:
            raise ValueError("Module name is already occupied: " + name)
        spec = importlib.util.spec_from_file_location(name, path)
        if spec is None or spec.loader is None:
            raise ValueError("Cannot load accounting module")
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        # Only this module's path and I/O helpers are adapted. The global
        # pathlib module, scientific source, metrics and policies are untouched.
        module.Path = self.portable_path
        for helper in ("sha", "sha256", "digest"):
            if hasattr(module, helper):
                setattr(module, helper, self.digest)
        for helper in ("read", "read_json"):
            if hasattr(module, helper):
                setattr(module, helper, self.read_json)
        if name == "summarize_original_structural_costs":
            completion_path = (self.root / "revision/experiments/results/original_structural_cost_20261008/completion.json").resolve()
            def cost_read(path):
                value = self.read_json(path)
                if self.portable_path(path).resolve() == completion_path:
                    value = dict(value)
                    bindings = {}
                    for key, wanted in value["cell_hashes"].items():
                        local = str(RealPath(key.replace("\\", "/")))
                        if local in bindings:
                            raise ValueError("Relative cell path normalization collision")
                        bindings[local] = wanted
                    value["cell_hashes"] = bindings
                return value
            module.read_json = cost_read
        if name == "analyze_original_contract_neighborhood":
            original_namespace = module.pure_original_namespace
            def portable_namespace(manifest):
                local = dict(manifest)
                local["source_hashes_before"] = self.mapped_binding_keys(manifest["source_hashes_before"])
                return original_namespace(local)
            module.pure_original_namespace = portable_namespace
        self.modules[name] = module
        return module

    def final_verify(self):
        for path, (size, wanted) in self.expected.items():
            if not path.is_file() or path.stat().st_size != size or raw_sha(path) != wanted:
                raise ValueError("Verified input changed during accounting: " + str(path))

    def execute(self, action):
        results = self.root / "revision/experiments/results"
        cost = results / "original_structural_cost_20261008"
        energy = results / "original_energy_screen_20261008"
        energy_audit = results / "original_energy_screen_20261008_independent_audit.json"
        if action == "cost-audit":
            result = self.load("audit_original_structural_costs").audit_run(cost, "full")
            self.out.mkdir(parents=True)
            write_new_json(self.out / "result.json", result)
        elif action == "energy-audit":
            result = self.load("audit_original_energy_screen").audit_run(energy, "full")
            self.out.mkdir(parents=True)
            write_new_json(self.out / "result.json", result)
        elif action == "cost-summary":
            module = self.load("summarize_original_structural_costs")
            cells, metadata = module.load_measurements(cost)
            result = module.build_summary(cells, metadata)
            module.write_reports(result, self.out, cost)
        elif action == "energy-summary":
            result = self.load("summarize_original_energy_screen").run(energy, energy_audit, self.out)
        elif action == "predicates":
            result = self.load("analyze_original_contract_neighborhood").run(energy, energy_audit, self.out)
        elif action == "predicate-audit":
            module = self.load("audit_original_contract_neighborhood")
            module.ROOT = self.out
            module.ANALYSIS = results / "original_contract_neighborhood_analysis_20261008"
            module.ENERGY = energy
            self.out.mkdir(parents=True)
            module.main()
            result = self.read_json(self.out / "original_contract_neighborhood_independent_audit_20261008.json")
        else:
            raise ValueError("Unknown action")
        self.final_verify()
        if result.get("errors") or str(result.get("status", "")).startswith("FAIL"):
            raise RuntimeError("Accounting did not pass; preserve the complete output")
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=RealPath, required=True, help="Fresh extracted package root")
    parser.add_argument("--action", choices=ACTIONS, default="verify")
    parser.add_argument("--out", type=RealPath, help="New output directory outside the package")
    args = parser.parse_args()
    if args.action != "verify" and args.out is None:
        parser.error("--out is required for an accounting action")
    if args.action == "verify" and args.out is not None:
        parser.error("verify does not create an output directory")
    adapter = Adapter(args.root, args.out)
    receipt = {
        "adapter_version": "portable-saved-revision-evidence-1",
        "action": args.action, "created_utc": datetime.now(timezone.utc).isoformat(),
        "root": str(adapter.root), "verified_files": len(adapter.files),
        "inventory_sha256": raw_sha(adapter.manifest_path),
        "simulator_calls": 0, "model_requests": 0,
        "runtime_path_mapping": {"historical_root": HISTORICAL_ROOT, "fresh_root": str(adapter.root)},
        "limitations": [
            "Only saved observations, original pure selection logic and independent mathematical accounting are recomputed.",
            "No controller, physical simulator, model client or network request is run; historical measured timing is read, not remeasured.",
            "Path metadata changes at runtime; frozen source/data bytes, policy values and metrics are unchanged.",
            "A reproduced audit checks saved records and cannot create new effectiveness or hardware reliability evidence.",
        ],
    }
    if args.action == "verify":
        receipt["status"] = "PASS_INVENTORY_BYTES_ONLY"
        print(json.dumps(receipt, indent=2, ensure_ascii=False))
        return 0
    try:
        result = adapter.execute(args.action)
        receipt["status"] = "COMPLETE_SAVED_ACCOUNTING_REPRODUCTION"
        receipt["result_status"] = result.get("status", "complete_descriptive_summary")
        receipt["actual_counts"] = {
            key: result[key] for key in ("assertions", "checks", "expected_cells", "audited_cells",
                "audited_completed_cells", "original_cache_bindings", "profiles", "gate_records",
                "selected_policies", "device_records", "predicate_readings", "conditions") if key in result
        }
        if "totals" in result:
            receipt["actual_counts"]["summary_cells"] = result["totals"]["cells"]
        if "scope" in result and isinstance(result["scope"], dict):
            receipt["actual_scope"] = copy.deepcopy(result["scope"])
        receipt["outputs"] = [str(p.relative_to(adapter.out)).replace("\\", "/")
                              for p in sorted(adapter.out.rglob("*")) if p.is_file()]
        write_new_json(adapter.out / "portable_execution_receipt.json", receipt)
        print(json.dumps(receipt, indent=2, ensure_ascii=False))
        return 0
    except Exception as error:
        receipt.update(status="FAILED_PRESERVED", error_type=type(error).__name__, message=str(error))
        if adapter.out.exists():
            write_new_json(adapter.out / "portable_execution_failure.json", receipt)
        print(json.dumps(receipt, indent=2, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
