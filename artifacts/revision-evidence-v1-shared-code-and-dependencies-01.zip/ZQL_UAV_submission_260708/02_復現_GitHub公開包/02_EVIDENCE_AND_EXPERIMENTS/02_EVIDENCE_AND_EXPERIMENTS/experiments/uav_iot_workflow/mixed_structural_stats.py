#!/usr/bin/env python3
"""Statistics for results/mixed_structural_llm_per_seed.csv."""
from __future__ import annotations

import csv
import math
import sys
from pathlib import Path

from mixed_structural_suite import HELD_OUT, STYPES


RES = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "results"
CSV = RES / "mixed_structural_llm_per_seed.csv"


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return float("nan"), float("nan")
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


def mcnemar_exact(b: int, c: int) -> float:
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    return min(1.0, 2 * sum(math.comb(n, i) for i in range(k + 1)) * (0.5**n))


def holm(pairs: list[tuple[str, float]]) -> dict[str, float]:
    ranked = sorted(pairs, key=lambda kv: kv[1])
    out = {}
    running = 0.0
    m = len(ranked)
    for i, (name, p) in enumerate(ranked):
        running = max(running, min(1.0, (m - i) * p))
        out[name] = running
    return out


def load() -> list[dict]:
    if not CSV.exists():
        raise SystemExit(f"missing {CSV}; run run_mixed_structural_llm.py first")
    rows = list(csv.DictReader(open(CSV, encoding="utf-8")))
    for row in rows:
        row["seed"] = int(row["seed"])
        row["pass"] = str(row["passed_contract"]).strip().lower() == "true"
    return rows


def pass_rate(rows: list[dict], scenario: str, method: str) -> tuple[int, int]:
    sub = [r for r in rows if r["scenario"] == scenario and r["method"] == method]
    return sum(1 for r in sub if r["pass"]), len(sub)


def matched(rows: list[dict], scenario: str, a: str, b: str) -> tuple[int, int, float, int]:
    left = {r["seed"]: r["pass"] for r in rows if r["scenario"] == scenario and r["method"] == a}
    right = {r["seed"]: r["pass"] for r in rows if r["scenario"] == scenario and r["method"] == b}
    keys = set(left) & set(right)
    b_only = sum(1 for key in keys if (not left[key]) and right[key])
    a_only = sum(1 for key in keys if left[key] and (not right[key]))
    return b_only, a_only, mcnemar_exact(b_only, a_only), len(keys)


def main() -> None:
    rows = load()
    methods = sorted({r["method"] for r in rows})
    print("Mixed structural pass rates (Wilson 95% CI)\n" + "=" * 62)
    out_rows = []
    for scenario in STYPES:
        print(f"\n[{scenario}]")
        for method in methods:
            k, n = pass_rate(rows, scenario, method)
            if n == 0:
                continue
            lo, hi = wilson(k, n)
            print(f"  {method:28s} {k/n:.3f} [{lo:.2f},{hi:.2f}] (n={n})")
            out_rows.append(
                {
                    "scenario": scenario,
                    "method": method,
                    "n": n,
                    "pass_rate": round(k / n, 3),
                    "ci_lo": round(lo, 3),
                    "ci_hi": round(hi, 3),
                }
            )

    print(f"\nHeld-out {HELD_OUT}: hybrid_portfolio vs alternatives\n" + "=" * 62)
    pairs = []
    for alt in [
        "rule_only_portfolio",
        "llm_only_structure",
        "B1_max_backlog_route",
        "B2_max_blackout_protocol",
        "B3_scripted_east_full",
        "SR_scripted_mixed_reference",
    ]:
        if alt not in methods or "hybrid_portfolio" not in methods:
            continue
        b, c, p, n = matched(rows, HELD_OUT, alt, "hybrid_portfolio")
        pairs.append((f"hybrid_vs_{alt}", p))
        print(f"  hybrid vs {alt:28s} discordant(b={b},c={c}) n={n} p={p:.4g}")
    adj = holm(pairs)
    for name, _ in pairs:
        print(f"  {name:38s} Holm_adj={adj[name]:.4g}")

    def pr(method: str) -> float:
        k, n = pass_rate(rows, HELD_OUT, method)
        return k / n if n else float("nan")

    sr = pr("SR_scripted_mixed_reference")
    rule = pr("rule_only_portfolio")
    llm = pr("llm_only_structure")
    hybrid = pr("hybrid_portfolio")
    if sr >= 0.6 and hybrid > rule:
        verdict = "candidate positive LLM-added portfolio evidence"
    elif sr >= 0.6 and hybrid >= rule and hybrid >= llm:
        verdict = "reliability-preserving hybrid portfolio; no held-out LLM gain"
    else:
        verdict = "do not use as a positive manuscript result"
    print(f"\n=> {verdict}")

    if out_rows:
        outp = RES / "mixed_structural_stats_summary.csv"
        with outp.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(out_rows[0].keys()))
            writer.writeheader()
            writer.writerows(out_rows)
        print(f"wrote {outp}")


if __name__ == "__main__":
    main()
