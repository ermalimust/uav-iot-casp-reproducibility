"""Instrument the original frozen structural calibrator; no network/client calls.

One fresh sequential worker per scenario/seed/method. All raw duplicate policies
are physically replayed; no simulation memoization. Cached model lookup is local
and never reported as online model inference latency. See the frozen protocol.
"""
from __future__ import annotations
import argparse
import copy
import csv
import ctypes
import hashlib
import json
import os
import platform
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
WORKSPACE = BASE.parents[1]
LEGACY = BASE / 'legacy'
FROZEN = (WORKSPACE / 'ZQL_UAV_submission_260708/02_復現_GitHub公開包/'
          '02_EVIDENCE_AND_EXPERIMENTS/02_EVIDENCE_AND_EXPERIMENTS/'
          'results_frozen_mixed_structural_100seed_20260617')
PROTOCOL = WORKSPACE / 'revision/Original_Structural_Cost_Protocol_20261008.md'
EXPECTED_PROTOCOL = '7b19b4dd36f645eac8b104a07b64ea3d61aa86f47369d6066d31699c6b8f0676'
STYPES = ['S1_seen_burst_east', 'S2_seen_degrade_west',
          'S3_seen_moved_burst', 'S4_heldout_misleading']
METHODS = ['compact', 'compact_plus_expert', 'compact_plus_cached_model']
SOURCES = ['B1_max_backlog_route', 'B2_max_blackout_protocol', 'B3_scripted_east_full']
VERSION = 'original-structural-cost-profile-1'


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def clean(value):
    if isinstance(value, dict):
        return {key: clean(item) for key, item in value.items()}
    if isinstance(value, set):
        return sorted(clean(item) for item in value)
    if isinstance(value, (list, tuple)):
        return [clean(item) for item in value]
    return value


def save(path, value):
    # Artifact encoding/writing is outside the method timing interval.
    Path(path).write_text(json.dumps(clean(value), ensure_ascii=False, indent=2,
                                    allow_nan=False), encoding='utf-8')


def bindings():
    paths = [Path(__file__).resolve(), PROTOCOL, BASE / 'candidate_search.py']
    paths += [LEGACY / name for name in (
        'mixed_structural_suite.py', 'contingency_suite.py',
        'run_uav_iot_workflow_experiment.py', 'run_mixed_structural_llm.py',
        'llm_repair_agent.py')]
    paths += [FROZEN / name for name in (
        'mixed_structural_llm_per_seed.csv', 'mixed_structural_llm_cache.jsonl')]
    return {str(path.resolve()): sha(path) for path in paths}


def frozen_rows():
    rows = {}
    with (FROZEN / 'mixed_structural_llm_per_seed.csv').open(
            encoding='utf-8-sig', newline='') as handle:
        for row in csv.DictReader(handle):
            key = row['scenario'], int(row['seed']), row['method']
            if key in rows:
                raise ValueError('Duplicate historical row')
            rows[key] = row
    return rows


def memory():
    if os.name == 'nt':
        class Counters(ctypes.Structure):
            _fields_ = [('cb', ctypes.c_ulong), ('PageFaultCount', ctypes.c_ulong)] + [
                (name, ctypes.c_size_t) for name in (
                    'PeakWorkingSetSize', 'WorkingSetSize', 'QuotaPeakPagedPoolUsage',
                    'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage',
                    'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage',
                    'PrivateUsage')]
        data = Counters()
        data.cb = ctypes.sizeof(data)
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.GetCurrentProcess.restype = ctypes.c_void_p
        psapi = ctypes.WinDLL('psapi', use_last_error=True)
        psapi.GetProcessMemoryInfo.argtypes = [ctypes.c_void_p, ctypes.c_void_p,
                                             ctypes.c_ulong]
        if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(),
                                          ctypes.byref(data), data.cb):
            raise ctypes.WinError(ctypes.get_last_error())
        return {'peak_working_set_bytes': int(data.PeakWorkingSetSize),
                'current_working_set_bytes': int(data.WorkingSetSize),
                'measurement': 'Windows GetProcessMemoryInfo lifetime PeakWorkingSetSize'}
    import resource
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    peak = int(value * (1 if sys.platform == 'darwin' else 1024))
    return {'peak_working_set_bytes': peak, 'current_working_set_bytes': None,
            'measurement': 'resource.ru_maxrss lifetime peak resident set'}


def machine():
    result = {'os': platform.platform(), 'python': sys.version,
              'processor': platform.processor(), 'logical_processors': os.cpu_count(),
              'executable': sys.executable, 'measurement_workers': 1,
              'physical_memory_bytes': None}
    if os.name == 'nt':
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            r'HARDWARE\DESCRIPTION\System\CentralProcessor\0') as key:
            result['processor'] = winreg.QueryValueEx(key, 'ProcessorNameString')[0].strip()
        class Mem(ctypes.Structure):
            _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong)] + [
                (name, ctypes.c_ulonglong) for name in (
                    'totalPhysical', 'availablePhysical', 'totalPage', 'availablePage',
                    'totalVirtual', 'availableVirtual', 'extendedVirtual')]
        data = Mem()
        data.length = ctypes.sizeof(data)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(data)):
            result['physical_memory_bytes'] = int(data.totalPhysical)
    return result


def check_only():
    import candidate_search as search
    rows = frozen_rows()
    count = 0
    keys = []
    for (_, _, method), row in rows.items():
        if method != 'llm_only_structure':
            continue
        linked = search.cached_llm_selection(json.loads(row['evidence_json']),
                     cache_path=FROZEN / 'mixed_structural_llm_cache.jsonl',
                     provider=row['provider'], model=row['model'])
        assert linked['status'] == 'hit'
        assert (linked['target'], linked['mode']) == (row['selected_target'], row['selected_mode'])
        keys.append(linked['cache_key'])
        count += 1
    assert count == len(set(keys)) == 400
    assert sha(PROTOCOL) == EXPECTED_PROTOCOL
    print(json.dumps({'status': 'ready', 'cache_identity_matches': count,
                      'model_requests': 0, 'simulator_calls': 0,
                      'source_hashes': bindings()}, ensure_ascii=False))


def worker(scenario_name, seed, method, output):
    start = time.perf_counter()
    record = {'version': VERSION, 'status': 'started', 'scenario': scenario_name,
              'seed': seed, 'method': method, 'model_requests': 0,
              'worker': {'pid': os.getpid(), 'parent_pid': os.getppid(),
                         'spawn_id': f'{scenario_name}__{seed}__{method}',
                         'start_method': 'spawn'},
              'online_model_request_seconds': None, 'groups': [],
              'full_search': False, 'simulation_cache': False, 'started_utc': utc()}
    actual_calls = 0
    nominal_seconds = 0.0
    phase = 'nominal'
    active_group = None
    try:
        sys.path.insert(0, str(LEGACY))
        import mixed_structural_suite as suite
        import candidate_search as search
        # Preserve the original function while fixing its only search-mode input.
        # No API/client module is imported and no environment config is read.
        suite.os = SimpleNamespace(environ={'UAV_MIXED_FULL_SEARCH': ''})
        helpers = search._legacy_helpers(str(LEGACY.resolve()))
        rows = frozen_rows()
        historical = rows[scenario_name, seed, 'llm_only_structure']
        scenario = suite.make_scenario_mixed(seed, scenario_name)
        record['scenario_sha256'] = hashlib.sha256(json.dumps(clean(scenario),
                sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
        baseline = memory()
        preparation_end = time.perf_counter()
        original_simulator = suite.simulate_cset

        def measured_simulator(scene, policy):
            nonlocal actual_calls, nominal_seconds
            actual_calls += 1
            before = time.perf_counter()
            attempt = {'raw_index': len(active_group['evaluations']) if active_group else 0,
                       'policy': copy.deepcopy(policy),
                       'policy_hash': search.policy_semantic_hash(policy), 'status': 'started'}
            if active_group is not None:
                active_group['evaluations'].append(attempt)
            try:
                result = original_simulator(scene, policy)
            except BaseException as exc:
                attempt.update(status='failed', error_type=type(exc).__name__, error=str(exc),
                               elapsed_seconds=time.perf_counter() - before)
                raise
            elapsed = time.perf_counter() - before
            if phase == 'nominal':
                nominal_seconds += elapsed
                record['nominal'] = {'policy_hash': attempt['policy_hash'],
                                      'elapsed_seconds': elapsed,
                                      'metrics': copy.deepcopy(result['metrics'])}
            else:
                attempt.update(status='complete', elapsed_seconds=elapsed,
                               metrics=copy.deepcopy(result['metrics']))
            return result

        suite.simulate_cset = measured_simulator
        method_start = time.perf_counter()
        before = time.perf_counter()
        evidence = suite.evidence_from_nominal(scenario)
        diagnosis_seconds = time.perf_counter() - before
        record['evidence'] = evidence
        before = time.perf_counter()
        structures = [(SOURCES[0], suite._target_from_backlog(evidence), 'route_dwell'),
                      (SOURCES[1], suite._target_from_blackout(evidence), 'protocol_trigger'),
                      (SOURCES[2], 'east_hotspot', 'full_casp')]
        linked = None
        if method == 'compact_plus_expert':
            target, mode = suite.scripted_structure(evidence)
            structures.append(('SR_scripted_mixed_reference', target, mode))
        if method == 'compact_plus_cached_model':
            linked = search.cached_llm_selection(evidence,
                      cache_path=FROZEN / 'mixed_structural_llm_cache.jsonl',
                      provider=historical['provider'], model=historical['model'])
            if linked['status'] != 'hit':
                raise ValueError('Fresh nominal evidence has no exact valid cached proposal')
            structures.append(('llm_only_structure', linked['target'], linked['mode']))
        selector_seconds = time.perf_counter() - before
        before = time.perf_counter()
        phase = 'candidate'
        candidates = []
        for index, (source, target, mode) in enumerate(structures):
            active_group = {'structure_index': index, 'source': source, 'target': target,
                            'mode': mode, 'evaluations': [],
                            'raw_grid_entries': {'route_dwell': 18, 'protocol_trigger': 12,
                                                 'full_casp': 45}[mode]}
            record['groups'].append(active_group)
            group_start = time.perf_counter()
            selected = suite.calibrate_structure(scenario, target, mode)
            group_elapsed = time.perf_counter() - group_start
            active_group.update(elapsed_seconds=group_elapsed,
                 simulator_seconds=sum(item['elapsed_seconds'] for item in active_group['evaluations']),
                 candidate_evaluations=len(active_group['evaluations']),
                 best_policy_hash=search.policy_semantic_hash(selected['policy']),
                 best_metrics=copy.deepcopy(selected['metrics']))
            candidates.append((source, selected))
        calibration_seconds = time.perf_counter() - before
        before = time.perf_counter()
        selected = suite.promote_candidate_results(candidates, method)
        promotion_seconds = time.perf_counter() - before
        method_end = time.perf_counter()
        record['promotion'] = {'winner': selected['portfolio_winner'],
                               'metrics': copy.deepcopy(selected['metrics']),
                               'policy_hash': search.policy_semantic_hash(selected['policy']),
                               'target': selected['selected_target'], 'mode': selected['selected_mode']}
        record['timing'] = {'preparation_seconds': preparation_end - start,
                            'diagnosis_seconds': diagnosis_seconds,
                            'selector_seconds': selector_seconds,
                            'calibration_seconds': calibration_seconds,
                            'promotion_seconds': promotion_seconds,
                            'method_seconds': method_end - method_start,
                            'nominal_simulator_seconds': nominal_seconds,
                            'candidate_simulator_seconds': sum(g['simulator_seconds'] for g in record['groups'])}
        # Validation is outside method timing, and never supplies a rule substitute.
        if linked is None:
            linked = search.cached_llm_selection(evidence,
                       cache_path=FROZEN / 'mixed_structural_llm_cache.jsonl',
                       provider=historical['provider'], model=historical['model'])
        assert linked['status'] == 'hit'
        assert (linked['target'], linked['mode']) == (historical['selected_target'], historical['selected_mode'])
        rounded = helpers['_rounded_evidence'](evidence)
        assert rounded == json.loads(historical['evidence_json'])
        assert historical['parsed_ok'] == 'True'
        record['evidence_rounded'] = rounded
        record['model_link'] = linked
        record['historical_pass_matches'] = {}
        for source, result in candidates:
            record['historical_pass_matches'][source] = (
                result['metrics']['passed_contract'] ==
                (rows[scenario_name, seed, source]['passed_contract'] == 'True'))
        record['historical_compact_pass'] = rows[scenario_name, seed, 'rule_only_portfolio']['passed_contract'] == 'True'
        record['historical_model_portfolio_pass'] = rows[scenario_name, seed, 'hybrid_portfolio']['passed_contract'] == 'True'
        candidate_count = sum(g['candidate_evaluations'] for g in record['groups'])
        assert actual_calls == candidate_count + 1
        record['counts'] = {'nominal_evaluations': 1, 'candidate_evaluations': candidate_count,
                            'actual_simulator_calls': actual_calls, 'simulation_cache_hits': 0}
        record['memory'] = memory()
        record['memory']['baseline_working_set_bytes'] = baseline['current_working_set_bytes']
        record['memory']['scope'] = 'absolute worker lifetime peak through validation, before artifact encoding'
        record['status'] = 'complete'
        record['finished_utc'] = utc()
    except BaseException as exc:
        record.update(status='failed', actual_simulator_calls=actual_calls,
                      error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
        save(output, record)
        raise
    save(output, record)


def run(seeds, out):
    if out.exists():
        raise FileExistsError('Measurement output must be fresh; old attempts are never overwritten')
    if sha(PROTOCOL) != EXPECTED_PROTOCOL:
        raise ValueError('Frozen measurement protocol hash changed')
    before_hashes = bindings()
    tasks = [{'scenario': scenario, 'seed': seed} for scenario in STYPES for seed in seeds]
    manifest = {'version': VERSION, 'started_utc': utc(), 'expected_cells': len(tasks) * 3,
                'tasks': tasks, 'methods': METHODS, 'method_order': 'rotate by zero-based task index',
                'source_hashes': before_hashes, 'protocol_sha256': EXPECTED_PROTOCOL,
                'full_search': False, 'simulation_cache': False, 'model_requests': 0,
                'online_model_request_seconds': None, 'machine': machine(),
                'scope': 'supplemental cache-disabled measurement, not historical execution timing'}
    out.mkdir(parents=True)
    (out / 'cells').mkdir()
    save(out / 'manifest.json', manifest)
    completed = 0
    hashes = {}
    started = time.perf_counter()
    try:
        for index, task in enumerate(tasks):
            methods = METHODS[index % 3:] + METHODS[:index % 3]
            for method in methods:
                if bindings() != before_hashes:
                    raise ValueError('Bound source or input changed during measurement')
                path = out / 'cells' / f"{task['scenario']}__{task['seed']:03d}__{method}.json"
                command = [sys.executable, '-X', 'utf8', '-B', str(Path(__file__).resolve()),
                           '--worker', '--scenario', task['scenario'], '--seed', str(task['seed']),
                           '--method', method, '--cell-output', str(path)]
                worker_start = time.perf_counter()
                child = subprocess.run(command, capture_output=True, text=True, encoding='utf-8')
                worker_seconds = time.perf_counter() - worker_start
                if child.returncode:
                    save(out / 'worker_failure.json', {'task': task, 'method': method,
                         'returncode': child.returncode, 'stdout': child.stdout, 'stderr': child.stderr,
                         'worker_seconds': worker_seconds, 'cell': str(path)})
                    raise RuntimeError(f"Worker failed: {task['scenario']} seed {task['seed']} {method}")
                cell = json.loads(path.read_text(encoding='utf-8'))
                if cell['status'] != 'complete':
                    raise ValueError('Worker did not complete')
                cell['timing']['worker_seconds'] = worker_seconds
                save(path, cell)
                hashes[str(path.relative_to(out))] = sha(path)
                completed += 1
            print(f"TASK_DONE {index+1}/{len(tasks)} {task['scenario']} seed={task['seed']} cells={completed}", flush=True)
        after_hashes = bindings()
        if after_hashes != before_hashes:
            raise ValueError('Source hashes changed after final worker')
        save(out / 'completion.json', {'version': VERSION, 'status': 'complete',
             'completed_cells': completed, 'expected_cells': len(tasks) * 3,
             'source_hashes_after': after_hashes, 'cell_hashes': hashes,
             'model_requests': 0, 'wall_seconds': time.perf_counter() - started,
             'finished_utc': utc()})
        print('RESULT_FILE:', out / 'completion.json', flush=True)
    except BaseException as exc:
        save(out / 'completion.json', {'status': 'failed', 'completed_cells': completed,
             'expected_cells': len(tasks)*3, 'source_hashes_after': bindings(), 'cell_hashes': hashes,
             'model_requests': 0, 'wall_seconds': time.perf_counter()-started,
             'error_type': type(exc).__name__, 'error': str(exc), 'finished_utc': utc()})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--seeds', help='Inclusive low:high original seed range')
    parser.add_argument('--out', type=Path)
    parser.add_argument('--worker', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--scenario', choices=STYPES, help=argparse.SUPPRESS)
    parser.add_argument('--seed', type=int, help=argparse.SUPPRESS)
    parser.add_argument('--method', choices=METHODS, help=argparse.SUPPRESS)
    parser.add_argument('--cell-output', type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        worker(args.scenario, args.seed, args.method, args.cell_output)
    elif args.seeds:
        low, high = map(int, args.seeds.split(':'))
        if not (1 <= low <= high <= 100) or args.out is None:
            parser.error('--seeds must be within 1:100 and requires --out')
        run(list(range(low, high+1)), args.out.resolve())
    else:
        check_only()


if __name__ == '__main__':
    main()
