from __future__ import annotations

import csv
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
SCRATCH_SRC = ROOT / "scratch" / "uav_iot_link_sanity.cc"
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"

DEFAULT_NS3_ROOT = Path(r"D:\tools\ns3\ns-allinone-3.47\ns-3.47")
DEFAULT_MSYS_BIN = Path(r"D:\tools\ns3\msys64\mingw64\bin")
DEFAULT_MSYS_USR_BIN = Path(r"D:\tools\ns3\msys64\usr\bin")
DEFAULT_CLEAN_TOOL_ROOT = Path(r"D:\tools\ns3")
DEFAULT_BUILD_ROOT = Path(r"C:\tmp\ns3_uav_iot_build")


def detect_gcc_version(mingw_root: Path, env: dict[str, str]) -> str:
    if "NS3_GCC_VERSION" in env:
        return env["NS3_GCC_VERSION"]
    gcc_dir = mingw_root / "lib" / "gcc" / "x86_64-w64-mingw32"
    versions = [path.name for path in gcc_dir.iterdir() if path.is_dir()] if gcc_dir.exists() else []
    if not versions:
        return "15.2.0"

    def version_key(value: str) -> tuple[int, ...]:
        parts = []
        for token in value.split("."):
            try:
                parts.append(int(token))
            except ValueError:
                parts.append(0)
        return tuple(parts)

    return sorted(versions, key=version_key)[-1]


def font(size: int, bold: bool = False):
    candidates = [
        r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\segoeuib.ttf" if bold else r"C:\Windows\Fonts\segoeui.ttf",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size)
        except OSError:
            continue
    return ImageFont.load_default()


def draw_text(draw: ImageDraw.ImageDraw, xy, text, size=16, fill=(38, 42, 50), bold=False):
    draw.text(xy, text, font=font(size, bold), fill=fill)


def make_env() -> dict[str, str]:
    env = os.environ.copy()
    tool_root = Path(env.get("NS3_TOOL_ROOT", str(DEFAULT_CLEAN_TOOL_ROOT)))
    if tool_root.exists():
        mingw_bin = Path(env.get("NS3_MINGW_BIN", str(tool_root / "msys64" / "mingw64" / "bin")))
        usr_bin = Path(env.get("NS3_USR_BIN", str(tool_root / "msys64" / "usr" / "bin")))
    else:
        mingw_bin = Path(env.get("NS3_MINGW_BIN", str(DEFAULT_MSYS_BIN)))
        usr_bin = Path(env.get("NS3_USR_BIN", str(DEFAULT_MSYS_USR_BIN)))
    extra = [str(mingw_bin), str(usr_bin)]
    env["PATH"] = ";".join(extra + [env.get("PATH", "")])
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    mingw_root = mingw_bin.parent
    gcc_version = detect_gcc_version(mingw_root, env)
    env["NS3_GCC_VERSION"] = gcc_version
    env["C_INCLUDE_PATH"] = str(mingw_root / "include")
    env["CPLUS_INCLUDE_PATH"] = ";".join(
        [
            str(mingw_root / "include" / "c++" / gcc_version),
            str(mingw_root / "include" / "c++" / gcc_version / "x86_64-w64-mingw32"),
            str(mingw_root / "include"),
        ]
    )
    env["LIBRARY_PATH"] = ";".join(
        [
            str(mingw_root / "lib"),
            str(mingw_root / "x86_64-w64-mingw32" / "lib"),
            str(mingw_root / "lib" / "gcc" / "x86_64-w64-mingw32" / gcc_version),
        ]
    )
    env["COMPILER_PATH"] = str(mingw_root / "libexec" / "gcc" / "x86_64-w64-mingw32" / gcc_version)
    env["CMAKE_PREFIX_PATH"] = str(mingw_root)
    return env


def run_cmd(cmd: list[str], cwd: Path, env: dict[str, str], timeout: int = 300) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        cwd=str(cwd),
        env=env,
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )


def configure_direct(source_root: Path, build_root: Path, env: dict[str, str]) -> None:
    cmake = Path(env["NS3_CMAKE"]) if "NS3_CMAKE" in env else Path(env["PATH"].split(";")[0]) / "cmake.exe"
    cxx = Path(env["NS3_CXX"]) if "NS3_CXX" in env else Path(env["PATH"].split(";")[0]) / "c++.exe"
    cc = Path(env["NS3_CC"]) if "NS3_CC" in env else Path(env["PATH"].split(";")[0]) / "gcc.exe"
    ninja = Path(env["NS3_NINJA"]) if "NS3_NINJA" in env else Path(env["PATH"].split(";")[0]) / "ninja.exe"
    mingw_root = Path(env["CMAKE_PREFIX_PATH"])
    gcc_version = env.get("NS3_GCC_VERSION", "15.2.0")
    gcc_start = mingw_root / "lib" / "gcc" / "x86_64-w64-mingw32" / gcc_version
    bflags = f"-B{gcc_start.as_posix()}/ -B{(mingw_root / 'lib').as_posix()}/"
    lflags = " ".join(
        [
            bflags,
            f"-L{gcc_start.as_posix()}",
            f"-L{(mingw_root / 'lib').as_posix()}",
            f"-L{(mingw_root / 'x86_64-w64-mingw32' / 'lib').as_posix()}",
        ]
    )
    build_root.mkdir(parents=True, exist_ok=True)
    if (build_root / "CMakeCache.txt").exists():
        return
    configure = run_cmd(
        [
            str(cmake),
            "-S",
            str(source_root),
            "-B",
            str(build_root),
            "-G",
            "Ninja",
            f"-DCMAKE_MAKE_PROGRAM={ninja}",
            f"-DCMAKE_C_COMPILER={cc}",
            f"-DCMAKE_CXX_COMPILER={cxx}",
            "-DCMAKE_BUILD_TYPE=Release",
            f"-DCMAKE_C_FLAGS={bflags}",
            f"-DCMAKE_CXX_FLAGS={bflags}",
            f"-DCMAKE_EXE_LINKER_FLAGS={lflags}",
            f"-DCMAKE_SHARED_LINKER_FLAGS={lflags}",
            "-DNS3_ASSERT=OFF",
            "-DNS3_LOG=OFF",
            "-DNS3_WARNINGS_AS_ERRORS=OFF",
            "-DNS3_NATIVE_OPTIMIZATIONS=OFF",
            "-DNS3_EXAMPLES=OFF",
            "-DNS3_TESTS=OFF",
            "-DNS3_ENABLED_MODULES=core,network,mobility,propagation,wifi,internet,applications",
        ],
        source_root,
        env,
        timeout=600,
    )
    if configure.returncode != 0:
        (RESULTS / "ns3_configure_failed.log").write_text(configure.stdout, encoding="utf-8")
        raise RuntimeError("ns-3 configure failed; see results/ns3_configure_failed.log")


def build_scratch(source_root: Path, build_root: Path, env: dict[str, str]) -> Path:
    cmake = Path(env["NS3_CMAKE"]) if "NS3_CMAKE" in env else Path(env["PATH"].split(";")[0]) / "cmake.exe"
    build = run_cmd(
        [str(cmake), "--build", str(build_root), "--target", "scratch_uav_iot_link_sanity", "-j", "4"],
        build_root,
        env,
        timeout=900,
    )
    if build.returncode != 0:
        (RESULTS / "ns3_build_failed.log").write_text(build.stdout, encoding="utf-8")
        raise RuntimeError("ns-3 scratch build failed; see results/ns3_build_failed.log")
    matches = list(build_root.rglob("*uav_iot_link_sanity*.exe"))
    matches.extend((source_root / "build").rglob("*uav_iot_link_sanity*.exe"))
    if not matches:
        raise RuntimeError(f"Could not find built scratch executable under {build_root}")
    return matches[0]


def parse_row(line: str) -> dict[str, str] | None:
    if not line.startswith("NS3_SANITY,"):
        return None
    parts = line.strip().split(",")
    keys = [
        "tag",
        "profile",
        "distance_m",
        "degraded",
        "offered_mbps",
        "rx_mbps",
        "pdr",
        "rx_bytes",
        "tx_power_dbm",
        "path_loss_exponent",
        "reference_loss_db",
        "data_mode",
    ]
    return dict(zip(keys, parts))


def run_sweep(source_root: Path, build_root: Path, env: dict[str, str]) -> list[dict[str, str]]:
    scratch_dst = source_root / "scratch" / SCRATCH_SRC.name
    shutil.copy2(SCRATCH_SRC, scratch_dst)
    configure_direct(source_root, build_root, env)
    exe = build_scratch(source_root, build_root, env)
    env = env.copy()
    env["PATH"] = ";".join(
        [
            str(source_root / "build" / "lib"),
            str(source_root / "build" / "bin"),
            str(build_root / "lib"),
            str(build_root / "bin"),
            env.get("PATH", ""),
        ]
    )

    rows: list[dict[str, str]] = []
    logs: list[str] = []
    distances = [25, 50, 75, 100, 125, 150, 175, 200, 225, 250, 300, 350]
    for profile in ["short_high_rate", "robust_low_rate"]:
        for degraded in [0, 1]:
            for distance in distances:
                target = (
                    f"{exe.name} --profile={profile} --distance={distance} "
                    f"--degraded={degraded} --duration=12"
                )
                proc = run_cmd(
                    [str(exe), f"--profile={profile}", f"--distance={distance}", f"--degraded={degraded}", "--duration=12"],
                    build_root,
                    env,
                    timeout=120,
                )
                logs.append(f"$ {target}\n{proc.stdout}\n")
                if proc.returncode != 0:
                    (RESULTS / "ns3_run_failed.log").write_text("\n".join(logs), encoding="utf-8")
                    raise RuntimeError("ns-3 run failed; see results/ns3_run_failed.log")
                for line in proc.stdout.splitlines():
                    row = parse_row(line)
                    if row:
                        rows.append(row)
    (RESULTS / "ns3_run.log").write_text("\n".join(logs), encoding="utf-8")
    return rows


def write_csv(rows: list[dict[str, str]]) -> None:
    path = RESULTS / "ns3_link_sanity_raw.csv"
    with path.open("w", newline="", encoding="utf-8") as f:
        fieldnames = [
            "profile",
            "distance_m",
            "degraded",
            "offered_mbps",
            "rx_mbps",
            "pdr",
            "rx_bytes",
            "tx_power_dbm",
            "path_loss_exponent",
            "reference_loss_db",
            "data_mode",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row[k] for k in fieldnames})


def line_plot(rows: list[dict[str, str]], metric: str, title: str, subtitle: str, filename: str) -> None:
    img = Image.new("RGB", (1280, 760), (250, 251, 253))
    draw = ImageDraw.Draw(img)
    draw_text(draw, (42, 30), title, 30, bold=True)
    draw_text(draw, (44, 68), subtitle, 16, fill=(82, 88, 101))

    x0, y0, x1, y1 = 110, 130, 1160, 640
    draw.rectangle((x0, y0, x1, y1), fill=(255, 255, 255), outline=(218, 223, 232))
    distances = sorted({float(r["distance_m"]) for r in rows})
    max_y = max(float(r[metric]) for r in rows) * 1.08
    if metric == "pdr":
        max_y = 1.05
    max_y = max(max_y, 0.01)

    for frac in [0.25, 0.50, 0.75, 1.0]:
        y = y1 - int(frac * (y1 - y0))
        draw.line((x0, y, x1, y), fill=(232, 235, 241))
        draw_text(draw, (45, y - 8), f"{frac * max_y:.2f}", 12, fill=(96, 102, 116))

    colors = {
        ("short_high_rate", "0"): (48, 111, 176),
        ("short_high_rate", "1"): (197, 94, 76),
        ("robust_low_rate", "0"): (82, 145, 105),
        ("robust_low_rate", "1"): (197, 151, 61),
    }
    labels = {
        ("short_high_rate", "0"): "short high-rate / normal",
        ("short_high_rate", "1"): "short high-rate / degraded",
        ("robust_low_rate", "0"): "robust low-rate / normal",
        ("robust_low_rate", "1"): "robust low-rate / degraded",
    }

    for key, color in colors.items():
        series = [r for r in rows if (r["profile"], r["degraded"]) == key]
        series = sorted(series, key=lambda r: float(r["distance_m"]))
        pts = []
        for row in series:
            x = x0 + int((float(row["distance_m"]) - min(distances)) / (max(distances) - min(distances)) * (x1 - x0))
            y = y1 - int(float(row[metric]) / max_y * (y1 - y0))
            pts.append((x, y))
        if len(pts) > 1:
            draw.line(pts, fill=color, width=3)
        for x, y in pts:
            draw.ellipse((x - 4, y - 4, x + 4, y + 4), fill=color, outline=(255, 255, 255))

    draw_text(draw, (x0, y1 + 35), "distance between sender and receiver (m)", 14)
    draw_text(draw, (42, y0 - 25), "PDR" if metric == "pdr" else "rx throughput (Mbps)", 14)

    lx, ly = 760, 145
    for idx, key in enumerate(colors):
        y = ly + idx * 27
        draw.line((lx, y, lx + 42, y), fill=colors[key], width=4)
        draw_text(draw, (lx + 52, y - 9), labels[key], 13)
    img.save(FIGURES / filename)


def write_summary(rows: list[dict[str, str]], source_root: Path, build_root: Path) -> None:
    summary: dict[str, object] = {
        "ns3_source_root": str(source_root),
        "ns3_build_root": str(build_root),
        "ns3_version": (source_root / "VERSION").read_text(encoding="utf-8").strip(),
        "num_rows": len(rows),
        "profiles": sorted({r["profile"] for r in rows}),
        "degraded_settings": sorted({r["degraded"] for r in rows}),
        "interpretation": [
            "short_high_rate throughput and PDR decrease with distance under log-distance loss",
            "degraded setting shifts the same link toward lower serviceability",
            "robust_low_rate keeps lower throughput but degrades more gradually",
        ],
        "boundary": (
            "These are representative link sanity checks for the Python simulator abstraction. "
            "They are not hardware validation and do not model LoRaWAN or cellular standards directly."
        ),
    }
    (RESULTS / "ns3_sanity_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")


def main() -> int:
    RESULTS.mkdir(parents=True, exist_ok=True)
    FIGURES.mkdir(parents=True, exist_ok=True)
    env = make_env()
    tool_root = Path(os.environ.get("NS3_TOOL_ROOT", str(DEFAULT_CLEAN_TOOL_ROOT)))
    if tool_root.exists():
        source_root = Path(os.environ.get("NS3_ROOT", str(tool_root / "ns-allinone-3.47" / "ns-3.47")))
    else:
        source_root = Path(os.environ.get("NS3_ROOT", str(DEFAULT_NS3_ROOT)))
    build_root = Path(os.environ.get("NS3_BUILD_ROOT", str(DEFAULT_BUILD_ROOT)))
    rows = run_sweep(source_root, build_root, env)
    write_csv(rows)
    write_summary(rows, source_root, build_root)
    line_plot(
        rows,
        "rx_mbps",
        "ns-3 link sanity check: received throughput",
        "Two-node Wi-Fi profiles under normal and degraded log-distance loss settings.",
        "ns3_throughput_vs_distance.png",
    )
    line_plot(
        rows,
        "pdr",
        "ns-3 link sanity check: packet delivery ratio",
        "The sanity check validates directionality of distance and degradation effects, not hardware fidelity.",
        "ns3_pdr_vs_distance.png",
    )
    print(f"Wrote {len(rows)} ns-3 rows to {RESULTS / 'ns3_link_sanity_raw.csv'}")
    print(f"Wrote figures to {FIGURES}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
