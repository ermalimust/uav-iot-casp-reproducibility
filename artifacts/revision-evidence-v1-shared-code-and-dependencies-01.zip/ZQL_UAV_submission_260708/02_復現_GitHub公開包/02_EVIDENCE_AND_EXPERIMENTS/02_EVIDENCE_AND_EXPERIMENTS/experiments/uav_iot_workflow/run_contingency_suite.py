#!/usr/bin/env python3
"""Heterogeneous Contingency Suite - full runner (deterministic baselines + LLM backends).

Reuses the LLM agent's generation/validation/caching machinery
(make_client, SYSTEM_PROMPT, extract_json, validate_and_apply) but substitutes the
GENERALIZED simulator (contingency_suite.simulate_cset) and a leak-free per-cluster
diagnosis, so the model must infer the repair structure from evidence without
being told the perturbation location or contingency type.

Deterministic backends (no key): B1_max_backlog, B2_scripted_east,
B3_single_target_diag, MT_scripted_reference. LLM backends (need a key, like
run_hybrid_ablation.py):
  pure_llm    : the LLM's promoted policy under the validator (structure + thresholds).
  hybrid_casp : LLM proposes target structure; contingency_suite.calibrate_targets
                calibrates thresholds by bounded search.

Run (PowerShell):
    $env:UAV_LLM_PROVIDER="openai"
    $env:OPENAI_API_KEY="sk-..."; $env:OPENAI_BASE_URL="https://dashscope.aliyuncs.com/compatible-mode/v1"
    $env:UAV_CSUITE_N="50"
    python run_contingency_suite.py
Use `contingency_suite.py` for no-key smoke tests. This full runner stops if no
live LLM backend is configured, so no placeholder rows are written as evidence.
"""
from __future__ import annotations
import os, json, csv, statistics, time
from pathlib import Path

from contingency_suite import (
    CTYPES, HELD_OUT, CLUSTER_IDS, contingency_clusters, make_scenario_cset,
    simulate_cset, calibrate_targets, run_method, DET_METHODS, _nominal, _trigger,
)
from llm_repair_agent import (
    make_client, SYSTEM_PROMPT, extract_json, validate_and_apply, CachingClient,
    BOUNDS,
)
from run_uav_iot_workflow_experiment import CONTRACT

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
TH = CONTRACT["qos_thresholds"]


# --------------------------------------------------------------------------
# Leak-free, per-cluster diagnosis (does NOT reveal the injected hotspot)
# --------------------------------------------------------------------------
def diagnose_cset(result: dict) -> dict:
    pbk, pbl = result["peak_backlog"], result["peak_blackout"]
    pls = result.get("peak_link_stress", {c: 0.0 for c in CLUSTER_IDS})
    worst_bl = max(pbl, key=pbl.get)
    failures = []
    if result["metrics"]["max_blackout"] > TH["device_max_blackout_max_slots"]:
        failures.append("regional_blackout")
    if any(pbl[c] >= 16 for c in CLUSTER_IDS):
        failures.append("protocol_mismatch_under_degradation")
    if any(pbk[c] >= 18.0 for c in CLUSTER_IDS):
        failures.append("queue_congestion")
    if not failures:
        failures = ["no_major_violation"]
    return {
        "failure_types": failures,
        "primary_blackout_cluster": worst_bl,
        "time_window": [CONTRACT["perturbation"]["start_slot"], CONTRACT["perturbation"]["end_slot"]],
        "evidence": {c: {"peak_backlog": round(pbk[c], 2),
                         "peak_blackout": int(pbl[c]),
                         "peak_link_stress": round(pls[c], 3)}
                     for c in CLUSTER_IDS},
        "likely_cause": "service evidence shows link stress, blackout, or backlog after the disturbance; "
                        "choose any repair action from the per-cluster evidence and history.",
    }


def _context(iteration, policy, diag, metrics, history):
    return {
        "iteration": iteration,
        "contract": {"qos_thresholds": CONTRACT["qos_thresholds"],
                     "promotion_criteria": CONTRACT["promotion_criteria"]},
        "current_policy": {"route_clusters": [wp["cluster"] for wp in policy.get("route", [])],
                           "dwell_times": [wp["dwell"] for wp in policy.get("route", [])],
                           "protocol_mode": policy.get("protocol_mode"),
                           "min_protocol_hold_slots": policy.get("min_protocol_hold_slots", 0),
                           "local_triggers": policy.get("local_triggers")},
        "current_metrics": metrics,
        "latest_diagnosis": diag,
        "history": history,
    }


def _llm_loop(scenario: dict, base_policy: dict, client, max_iters: int = 3) -> dict:
    prev = json.loads(json.dumps(base_policy)); prev["policy_id"] = "cs_cand0"
    res = simulate_cset(scenario, prev)
    diag = diagnose_cset(res)
    cands = [(prev, res)]
    history = [{"candidate": "cand0", "qsr": res["metrics"]["qsr"],
                "max_blackout": res["metrics"]["max_blackout"],
                "passed_contract": res["metrics"]["passed_contract"]}]
    for k in range(1, max_iters + 1):
        ctx = _context(k, prev, diag, res["metrics"], history)
        user = (
            ("Repair iteration %d. State as JSON.\n\n" % k)
            + json.dumps(ctx, ensure_ascii=False, indent=2)
            + "\n\nReturn the next repair action as a single JSON object following the policy-action schema. "
            + "Use only the latest diagnosis evidence and history; do not assume injected contingency labels. "
            + "The hybrid validator will calibrate numeric thresholds."
        )
        out = client.complete(SYSTEM_PROMPT, user)
        action = extract_json(out.text)
        policy, applied = validate_and_apply_cset(prev, action, f"cs_cand{k}")
        res = simulate_cset(scenario, policy)
        diag = diagnose_cset(res)
        cands.append((policy, res))
        history.append({"candidate": f"cand{k}", "qsr": res["metrics"]["qsr"],
                        "max_blackout": res["metrics"]["max_blackout"],
                        "passed_contract": res["metrics"]["passed_contract"]})
        prev = policy
        if res["metrics"]["passed_contract"] or (action or {}).get("request_replanning"):
            break
    promoted_policy, promoted_res = max(cands, key=lambda pr: promotion_score_cset(pr[1], pr[0]))
    return {"final_policy": promoted_policy, "final_result": promoted_res, "final_diagnosis": diag}


def promotion_score_cset(result: dict, policy: dict) -> float:
    """Promotion score for the contingency suite metrics."""
    m = result["metrics"]
    local_triggers = policy.get("local_triggers")
    if isinstance(local_triggers, list):
        trigger_count = len(local_triggers)
    elif local_triggers:
        trigger_count = 1
    else:
        trigger_count = 0
    return (
        (12.0 if m["passed_contract"] else 0.0)
        + 110.0 * float(m["qsr"])
        - 0.24 * float(m["recovery_time"])
        - 0.40 * float(m["max_blackout"])
        - 0.08 * float(m["p95_latency"])
        + 1.5 * trigger_count
        + (3.0 if m.get("coverage_pass", True) else 0.0)
    )


def _bounded_num(value, field, default):
    try:
        v = float(value)
    except (TypeError, ValueError):
        v = default
    lo, hi = BOUNDS[field]
    return max(lo, min(hi, v))


def validate_and_apply_cset(prev_policy: dict, action: dict | None, new_policy_id: str):
    """Use the shared validator, then allow list-valued trigger proposals."""
    policy, applied = validate_and_apply(prev_policy, action, new_policy_id)
    raw = (action or {}).get("local_triggers")
    if not isinstance(raw, list):
        return policy, applied
    triggers = []
    seen = set()
    for item in raw:
        if not isinstance(item, dict):
            continue
        cluster = item.get("cluster")
        if cluster not in CLUSTER_IDS or cluster in seen:
            continue
        seen.add(cluster)
        trig = _trigger(
            cluster,
            b=int(_bounded_num(item.get("max_blackout_threshold_slots"), "max_blackout_threshold_slots", 16)),
            dwell=int(_bounded_num(item.get("fallback_dwell_min_slots"), "fallback_dwell_min_slots", 4)),
            cooldown=int(_bounded_num(item.get("cooldown_slots"), "cooldown_slots", 12)),
        )
        trig["queue_threshold"] = _bounded_num(item.get("queue_threshold"), "queue_threshold", 18.0)
        trig["release_threshold"] = min(
            _bounded_num(item.get("release_threshold"), "release_threshold", 10.0),
            trig["queue_threshold"],
        )
        triggers.append(trig)
        if len(triggers) >= 2:
            break
    if triggers:
        policy["local_triggers"] = triggers
        applied["local_triggers"] = triggers
        applied.setdefault("clamp_notes", []).append("contingency suite accepted multi-trigger list")
    return policy, applied


def _targets_from_policy(policy: dict) -> list[str]:
    """Which clusters the LLM chose to emphasize (revisited >=2x, or its trigger)."""
    seq = [wp["cluster"] for wp in policy.get("route", [])]
    counts = {c: seq.count(c) for c in set(seq) if c in CLUSTER_IDS}
    targets = [c for c, n in counts.items() if n >= 2]
    trig = policy.get("local_triggers")
    if isinstance(trig, dict) and trig.get("cluster") in CLUSTER_IDS and trig["cluster"] not in targets:
        targets.append(trig["cluster"])
    elif isinstance(trig, list):
        for item in trig:
            if isinstance(item, dict) and item.get("cluster") in CLUSTER_IDS and item["cluster"] not in targets:
                targets.append(item["cluster"])
    if not targets:
        targets = [max(counts, key=counts.get)] if counts else ["east_hotspot"]
    return targets[:2]


ALL_METHODS = DET_METHODS + ["pure_llm", "hybrid_casp"]
DISPLAY = {
    "B1_max_backlog": "B1",
    "B2_scripted_east": "B2",
    "B3_single_target_diag": "B3",
    "MT_scripted_reference": "MT_ref",
    "pure_llm": "pure_llm",
    "hybrid_casp": "hybrid_casp",
}


def _preflight_capacity_check(seeds: list[int]) -> None:
    """Abort the LLM run if even the scripted multi-target reference cannot pass C4."""
    probe_seeds = seeds[: min(5, len(seeds))]
    if not probe_seeds:
        return
    mt_pass = []
    for s in probe_seeds:
        bc, dc = contingency_clusters(HELD_OUT, s)
        sc = make_scenario_cset(s, bc, dc)
        r = run_method("MT_scripted_reference", sc)
        mt_pass.append(bool(r["metrics"]["passed_contract"]))
    rate = statistics.mean(1.0 if x else 0.0 for x in mt_pass)
    if rate <= 0.0:
        raise SystemExit(
            "Clean preflight stopped the LLM run: MT_scripted_reference passes 0/"
            f"{len(probe_seeds)} C4 smoke seeds under the unrelaxed contract. "
            "Treat C4 as a capacity-boundary stress test, not as a positive "
            "hybrid-result experiment. Do not spend API calls on this suite unless "
            "the clean deterministic backbone is redesigned and documented first."
        )


def main():
    seeds = list(range(1, int(os.environ.get("UAV_CSUITE_N", "50")) + 1))
    _preflight_capacity_check(seeds)
    client = make_client()
    inner = getattr(client, "inner", None)
    inner_provider = str(getattr(inner, "provider", ""))
    if inner_provider.startswith("offline"):
        raise SystemExit(
            "No live LLM backend detected. Set UAV_LLM_PROVIDER and API-key variables, "
            "or run contingency_suite.py for the no-key deterministic smoke test."
        )
    print(f"Contingency suite: {len(seeds)} seeds/type; LLM backend="
          f"{getattr(inner,'provider','?')}/{getattr(inner,'model','?')}")
    rows = []; t0 = time.time()
    hdr = f"{'contingency':<16}" + "".join(f"{DISPLAY.get(m, m):>12}" for m in ALL_METHODS)
    print(hdr); print("-" * len(hdr))
    for ctype in CTYPES:
        agg = {m: [] for m in ALL_METHODS}
        for s in seeds:
            bc, dc = contingency_clusters(ctype, s)
            sc = make_scenario_cset(s, bc, dc)
            for m in DET_METHODS:
                r = run_method(m, sc)
                agg[m].append(r["metrics"]["passed_contract"])
                rows.append(_row(ctype, s, m, r))
            try:
                loop = _llm_loop(sc, _nominal(), client, max_iters=3)
            except RuntimeError as exc:
                raise SystemExit(
                    "LLM call failed before contingency_suite_clean_per_seed.csv was written. "
                    "Check the API key, base URL, quota, and network access, then rerun. "
                    f"Original error: {exc}"
                ) from exc
            r_pure = loop["final_result"]
            agg["pure_llm"].append(r_pure["metrics"]["passed_contract"])
            llm_targets = _targets_from_policy(loop["final_policy"])
            rows.append(_row(ctype, s, "pure_llm", r_pure, llm_targets))
            r_hyb = calibrate_targets(sc, llm_targets)
            agg["hybrid_casp"].append(r_hyb["metrics"]["passed_contract"])
            rows.append(_row(ctype, s, "hybrid_casp", r_hyb, llm_targets))
        print(f"{ctype:<16}" + "".join(f"{statistics.mean(1.0 if x else 0.0 for x in agg[m]):>12.2f}"
                                       for m in ALL_METHODS))
    RESULTS.mkdir(parents=True, exist_ok=True)
    outp = RESULTS / "contingency_suite_clean_per_seed.csv"
    fieldnames = ["contingency", "seed", "method", "passed_contract", "coverage_pass",
                  "qsr", "recovery_time", "max_blackout", "target_clusters", "held_out"]
    with open(outp, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)
    print(f"\nwrote {outp}  [{time.time()-t0:.0f}s]")
    print("Next: python contingency_stats.py   (Wilson CIs + held-out McNemar/Holm)")


def _row(ctype, seed, method, r, targets=None):
    m = r["metrics"]
    return {"contingency": ctype, "seed": seed, "method": method,
            "passed_contract": bool(m["passed_contract"]),
            "coverage_pass": bool(m.get("coverage_pass", True)),
            "qsr": round(m["qsr"], 4),
            "recovery_time": m["recovery_time"], "max_blackout": m["max_blackout"],
            "target_clusters": ";".join(targets or []),
            "held_out": (ctype == HELD_OUT)}


if __name__ == "__main__":
    main()
