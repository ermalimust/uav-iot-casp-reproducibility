"""Independent audit of fixed-policy predicate accounting; no simulation/API."""
import csv
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'results'
ANALYSIS = ROOT / 'original_contract_neighborhood_analysis_20261008'
ENERGY = ROOT / 'original_energy_screen_20261008'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(name):
    with (ANALYSIS / name).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def boolean(value):
    if value not in ('True', 'False'):
        raise ValueError('Invalid boolean record')
    return value == 'True'


def main():
    checks = 0
    def check(value, message):
        nonlocal checks
        checks += 1
        if not value:
            raise AssertionError(message)
    summary = json.loads((ANALYSIS / 'summary.json').read_text(encoding='utf-8'))
    for name, expected in summary['output_hashes'].items():
        check(sha(ANALYSIS / name) == expected, 'Analysis output hash mismatch: ' + name)
    fixed = rows('fixed_policy_metrics.csv')
    device_rows = rows('per_device_metrics.csv')
    readings = rows('predicate_readings.csv')
    aggregates = rows('condition_summary.csv')
    check(tuple(map(len, (fixed, device_rows, readings, aggregates))) == (1200, 36000, 72000, 720), 'Wrong grains')
    key = lambda row: (row['scenario'], int(row['seed']), row['method'])
    policies = {key(row): row for row in fixed}
    check(len(policies) == 1200, 'Duplicate selected policy')
    devices = defaultdict(list)
    for row in device_rows:
        devices[key(row)].append(row)
    for identity, policy in policies.items():
        scenario, seed, method = identity
        source = ENERGY / 'cells' / f'{scenario}__{seed:03d}__{method}.json'
        check(sha(source) == policy['cell_sha256'], 'Source cell binding')
        cell = json.loads(source.read_text(encoding='utf-8'))
        metrics = cell['original_metrics']
        for field in ('qsr', 'recovery_time', 'max_blackout', 'p95_latency'):
            check(float(policy[field]) == metrics[field], 'Canonical source metric mismatch')
        for field in ('coverage_pass', 'passed_contract'):
            check(boolean(policy[field]) == metrics[field], 'Canonical source predicate mismatch')
        check(len(devices[identity]) == 30 and {int(d['device_index']) for d in devices[identity]} == set(range(30)), 'Device grain')
        for device in devices[identity]:
            check(device['cell_sha256'] == policy['cell_sha256'] and device['policy_hash'] == policy['policy_hash'], 'Device source binding')
            generated, delivered = float(device['generated_amount']), float(device['delivered_amount'])
            check(math.isfinite(generated) and math.isfinite(delivered) and generated > 0 and 0 <= delivered <= generated + 1e-9, 'Volume range')
            check(float(device['pdr']) == delivered / generated, 'Device PDR arithmetic')
    grouped = defaultdict(lambda: [0, 0, 0, 0, 0, 0])
    seen = set()
    axes = {'qsr_min': (.60,.65,.70,.75,.80,.90,.95,1.), 'device_pdr_min': (.60,.65,.70,.75,.80),
            'device_latency_max': (42,52,62,72,82), 'blackout_max': (46,48,50,52,54,56,58,60),
            'recovery_max': (60,72,82,92,100,120,159)}
    canonical = dict(qsr_min=.70, device_pdr_min=.70, device_latency_max=62, blackout_max=52, recovery_max=82)
    all_conditions = set()
    for row in readings:
        identity = key(row)
        policy = policies[identity]
        record_key = (identity, row['condition_id'])
        check(record_key not in seen, 'Duplicate predicate reading')
        seen.add(record_key)
        bounds = {field: float(row[field]) for field in canonical}
        all_conditions.add((row['condition_id'], row['kind']))
        if row['kind'] == 'single_axis':
            axis, value = row['axis'], float(row['value'])
            check(axis in axes and value in axes[axis], 'Undeclared threshold')
            check(bounds == {**canonical, axis: value}, 'Single-axis isolation')
        else:
            check(row['kind'] == 'joint_appendix' and bounds['qsr_min'] in (.65,.70,.75)
                  and bounds['device_latency_max'] in (52,62,72) and bounds['recovery_max'] in (72,82,92)
                  and bounds['device_pdr_min'] == .70 and bounds['blackout_max'] == 52, 'Undeclared joint grid')
        satisfied = sum(float(d['pdr']) >= bounds['device_pdr_min'] and float(d['p95_latency_slots']) <= bounds['device_latency_max']
                        and int(d['max_blackout_slots']) <= bounds['blackout_max'] for d in devices[identity])
        qsr = satisfied / 30
        coverage = boolean(policy['coverage_pass'])
        passed = qsr >= bounds['qsr_min'] and float(policy['max_blackout']) <= bounds['blackout_max'] and float(policy['recovery_time']) <= bounds['recovery_max'] and coverage
        original = boolean(policy['passed_contract'])
        check(float(row['new_qsr']) == qsr and boolean(row['new_service_pass']) == passed, 'Independent gate arithmetic')
        check(boolean(row['original_service_pass']) == original and boolean(row['coverage_pass']) == coverage, 'Preserved canonical/coverage')
        check(boolean(row['gain_from_canonical']) == (passed and not original) and boolean(row['loss_from_canonical']) == (original and not passed), 'Matched transitions')
        group = grouped[(identity[0], identity[2], row['condition_id'])]
        for index, value in enumerate((1, original, passed, passed and not original, original and not passed, coverage)):
            group[index] += value
    check(len(all_conditions) == 60 and sum(kind == 'single_axis' for _, kind in all_conditions) == 33, 'Full declared condition set')
    for row in aggregates:
        group = grouped[(row['scenario'], row['method'], row['condition_id'])]
        check(group == [int(row[name]) for name in ('n','canonical_passed','passed','gain_from_canonical','loss_from_canonical','coverage_passed')], 'Independent aggregate')
        check(float(row['pass_fraction']) == group[2] / group[0], 'Aggregate fraction')
    output = ROOT / 'original_contract_neighborhood_independent_audit_20261008.json'
    result = dict(status='PASS_INDEPENDENT_PREDICATE_ACCOUNTING_AUDIT', checks=checks, errors=[],
                  selected_policies=1200, device_records=36000, predicate_readings=72000, conditions=60,
                  simulator_calls=0, model_requests=0, auditor_sha256=sha(Path(__file__)),
                  analysis_summary_sha256=sha(ANALYSIS / 'summary.json'),
                  scope='Independent CSV/source bindings, per-device PDR, full gate arithmetic and matched aggregate counts. FIFO trace reconstruction is covered by the separately saved analysis validation; this audit does not independently replay the controller or reconstruct that FIFO.')
    output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
