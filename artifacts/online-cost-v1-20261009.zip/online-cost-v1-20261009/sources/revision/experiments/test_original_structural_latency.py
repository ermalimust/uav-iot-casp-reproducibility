"""Pure tests: all callbacks and responses are handmade, never scientific runs."""
from __future__ import annotations

import copy
import importlib
import json
import pathlib
import sys
import tempfile
import unittest
from unittest.mock import patch

import measure_original_structural_latency as experiment


class Clock:
    def __init__(self):
        self.now = 0.0
    def __call__(self):
        self.now += 0.01
        return self.now
    def advance(self, seconds):
        self.now += seconds


class PureLatencyChecks(unittest.TestCase):
    def response(self, content=None, finish='stop', usage=True):
        return {'http_status': 200, 'body_bytes': json.dumps({
            'choices': [{'finish_reason': finish, 'message': {'content': content or '{"target_cluster":"east_hotspot","repair_mode":"full_casp"}'}}],
            'usage': {'prompt_tokens': 20, 'completion_tokens': 10, 'total_tokens': 30} if usage else None,
            'model': 'qwen-plus-current-response-alias', 'id': 'artificial', 'created': 1}).encode()}

    def callbacks(self, clock, response=None, error=None, invalid=False, calibration_error=False, energy=False):
        calls, events = [], []
        def transport(payload):
            calls.append('http')
            clock.advance(5)
            if error:
                raise error
            return response or self.response()
        def diagnosis():
            calls.append('diagnosis')
            return {'artificial': True}
        def decode(text, evidence):
            calls.append('decode')
            return {'selection': {'target_cluster': 'east_hotspot', 'repair_mode': 'full_casp'},
                    'metadata': {'parsed_ok': not invalid, 'llm_attribution_eligible': not invalid}}
        def calibrate(evidence, selected):
            calls.append('calibrate_four_sources')
            clock.advance(2)
            if calibration_error:
                raise ValueError('handmade calibration failure')
            return [('rule1', {}), ('rule2', {}), ('rule3', {}), ('model', {})]
        def promote(candidates):
            self.assertEqual(len(candidates), 4)
            calls.append('promotion')
            return {'metrics': {'passed_contract': False}, 'policy': {'fixture': True}}
        def gate(winner):
            calls.append('energy')
            clock.advance(100)
            return {'fixture_gate': True}
        return calls, events, {'diagnosis': diagnosis, 'prompt': lambda evidence: ('system fixture', 'user fixture'),
                'decoder': decode, 'calibrate': calibrate, 'promote': promote, 'transport': transport,
                'persist': lambda name, value: events.append((name, copy.deepcopy(value))),
                'energy': gate if energy else None, 'clock': clock}

    def test_complete_current_hybrid_not_old_time_plus_http(self):
        clock = Clock()
        calls, events, callbacks = self.callbacks(clock)
        record = {}
        experiment.execute_cell(record, experiment.profile_checked(), **callbacks)
        self.assertEqual(calls, ['diagnosis', 'http', 'decode', 'calibrate_four_sources', 'promotion'])
        self.assertEqual(record['model_request_attempts'], 1)
        self.assertEqual(record['status'], 'complete')
        self.assertGreater(record['timing']['hybrid_wall_seconds'], 7)
        self.assertAlmostEqual(record['timing']['http_seconds'], 5.01)
        self.assertLess(record['timing']['local_stage_seconds'], 3)
        self.assertEqual([name for name, _ in events], ['request_before', 'response_raw', 'request_after'])
        self.assertFalse(events[0][1]['send_entered'])

    def test_service_failure_is_retained(self):
        clock = Clock()
        _, _, callbacks = self.callbacks(clock)
        result = experiment.execute_cell({}, experiment.profile_checked(), **callbacks)
        self.assertIs(result['promotion']['metrics']['passed_contract'], False)
        self.assertEqual(result['status'], 'complete')

    def test_energy_is_outside_original_hybrid_and_local_timers(self):
        clock = Clock()
        calls, _, callbacks = self.callbacks(clock, energy=True)
        result = experiment.execute_cell({}, experiment.profile_checked(), **callbacks)
        self.assertEqual(calls[-1], 'energy')
        self.assertLess(result['timing']['hybrid_wall_seconds'], 8)
        self.assertGreater(result['timing']['energy_postprocess_seconds'], 100)
        self.assertLess(result['timing']['local_stage_seconds'], 3)

    def test_timeout_one_attempt_no_retry_and_unknown_usage(self):
        clock = Clock()
        calls, events, callbacks = self.callbacks(clock, error=TimeoutError())
        record = {}
        with self.assertRaises(TimeoutError):
            experiment.execute_cell(record, experiment.profile_checked(), **callbacks)
        self.assertEqual(calls.count('http'), 1)
        self.assertNotIn('calibrate_four_sources', calls)
        self.assertIsNone(record['request']['usage'])
        self.assertEqual(record['request']['usage_status'], 'unknown')
        self.assertGreater(record['timing']['http_seconds'], 5)
        self.assertEqual(events[-1][0], 'request_after')

    def test_invalid_model_structure_stops_without_rule_substitution(self):
        clock = Clock()
        calls, _, callbacks = self.callbacks(clock, invalid=True)
        record = {}
        with self.assertRaises(experiment.StopExperiment):
            experiment.execute_cell(record, experiment.profile_checked(), **callbacks)
        self.assertNotIn('calibrate_four_sources', calls)
        self.assertEqual(record['request']['usage']['total_tokens'], 30)
        self.assertEqual(record['status'], 'failed')

    def test_truncation_retains_usage_and_stops(self):
        clock = Clock()
        calls, _, callbacks = self.callbacks(clock, response=self.response(finish='length'))
        record = {}
        with self.assertRaises(experiment.StopExperiment):
            experiment.execute_cell(record, experiment.profile_checked(), **callbacks)
        self.assertEqual(record['request']['usage']['completion_tokens'], 10)
        self.assertNotIn('decode', calls)

    def test_calibration_error_is_timed_and_promotion_not_attempted(self):
        clock = Clock()
        calls, _, callbacks = self.callbacks(clock, calibration_error=True)
        record = {}
        with self.assertRaises(ValueError):
            experiment.execute_cell(record, experiment.profile_checked(), **callbacks)
        self.assertNotIn('promotion', calls)
        self.assertGreater(record['timing']['calibration_seconds'], 2)
        self.assertEqual(record['model_request_attempts'], 1)

    def test_second_generation_refused_even_with_handmade_transport(self):
        with self.assertRaises(experiment.StopExperiment):
            experiment.generate_once({}, lambda _: self.fail('No second call'), lambda *_: None,
                                     {'model_request_attempts': 1, 'timing': {}})

    def test_default_check_does_not_reach_configuration_credentials_transport_or_simulator(self):
        with (patch.object(experiment, 'load_approved_key', side_effect=AssertionError('key access')),
              patch.object(experiment, 'direct_transport', side_effect=AssertionError('network access')),
              patch.dict(sys.modules, {'mixed_structural_suite': None, 'llm_repair_agent': None})):
            package = experiment.prepare(False)
        self.assertEqual(len(package['tasks']), 12)
        self.assertEqual(package['model_requests'], 0)
        self.assertEqual(package['model_config_reads'], 0)
        self.assertEqual(package['api_key_reads'], 0)
        self.assertEqual(package['network_calls'], 0)
        self.assertEqual(package['real_simulator_calls'], 0)
        self.assertEqual({item['historical_model_alias'] for item in package['links']}, {'qwen-plus'})

    def test_request_payload_has_only_original_diagnosis_messages_and_declared_new_limits(self):
        profile = experiment.profile_checked()
        body = experiment.request_payload(profile, 's', 'u')
        self.assertEqual(body['messages'], [{'role': 'system', 'content': 's'}, {'role': 'user', 'content': 'u'}])
        self.assertEqual(body['max_tokens'], 1024)
        self.assertEqual(body['n'], 1)
        self.assertIs(body['enable_thinking'], False)
        self.assertNotIn('api_key', body)
        self.assertNotIn('seed', body)

    def test_old_or_proposed_authorization_refused_before_any_configuration(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / 'fixture.json'
            path.write_text('{}', encoding='utf-8')
            with self.assertRaises(experiment.StopExperiment):
                experiment.validate_authorization({'status': 'authorized_within_prior_budget'}, {}, path, pathlib.Path(temporary))

    def test_append_only_artifacts_cannot_be_overwritten(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / 'attempt.json'
            experiment.save_new(path, {'attempt': 1})
            with self.assertRaises(FileExistsError):
                experiment.save_new(path, {'attempt': 2})
            self.assertEqual(experiment.read_json(path), {'attempt': 1})

    def test_token_fields_unknown_not_zero_and_booleans_rejected(self):
        self.assertEqual(experiment.token_usage({'total_tokens': 30, 'prompt_tokens': True}),
                         {'prompt_tokens': None, 'completion_tokens': None, 'total_tokens': 30})
        self.assertEqual(experiment.usage_status(experiment.token_usage({})), 'unknown')
        self.assertEqual(experiment.usage_status(experiment.token_usage({'total_tokens': 30})), 'partial')

    def test_partial_usage_and_interrupted_response_in_summary(self):
        with tempfile.TemporaryDirectory() as temporary:
            out = pathlib.Path(temporary)
            for index in range(2):
                cell = out / 'cells' / str(index)
                cell.mkdir(parents=True)
                experiment.save_new(cell / 'request_before.json', {'fixture': True})
            experiment.save_new(out / 'cells/0/request_after.json',
                {'status': 'responded', 'usage': {'total_tokens': 30}, 'timing': {'http_seconds': 5}})
            (out / 'cells/1/request_after.json.writing').write_text('{', encoding='utf-8')
            summary = experiment.summarize_live(out, [], {'status': 'failed', 'completed_cells': 0,
                               'request_attempts_reserved': 2, 'unknown_worker_attempts': 1})
            self.assertEqual(summary['usage_fields']['total_tokens'],
                             {'observed_total': 30, 'observed_count': 1, 'unknown_count': 1})
            self.assertEqual(summary['usage_fields']['prompt_tokens']['observed_total'], None)
            self.assertEqual(summary['usage_fields']['prompt_tokens']['unknown_count'], 2)
            self.assertEqual(summary['request_failures_or_unknown'], 1)

    def test_worker_cannot_override_check_mode(self):
        with (patch.object(sys, 'argv', ['fixture', '--worker', '--check-only']),
              patch.object(experiment, 'live_worker', side_effect=AssertionError('must not enter live'))):
            self.assertEqual(experiment.main(), 2)

    def test_stopped_run_rejects_manual_worker_before_any_other_access(self):
        with tempfile.TemporaryDirectory() as temporary:
            out = pathlib.Path(temporary)
            experiment.save_new(out / 'completion.json', {'status': 'failed'})
            with self.assertRaises(experiment.StopExperiment):
                experiment.validate_worker_reservation({}, out / 'cell', {}, out / 'prep', out,
                                                       out / 'auth', out / 'launch')

    def test_original_target_fallback_not_admitted_as_model_structure(self):
        clock = Clock()
        calls, _, callbacks = self.callbacks(clock)
        callbacks['decoder'] = lambda *_: {'selection': {'target_cluster': 'east_hotspot', 'repair_mode': 'full_casp'},
                                         'metadata': {'parsed_ok': True, 'llm_attribution_eligible': True,
                                                      'target_fallback': True, 'mode_fallback': False}}
        record = {}
        with self.assertRaises(experiment.StopExperiment):
            experiment.execute_cell(record, experiment.profile_checked(), **callbacks)
        self.assertNotIn('calibrate_four_sources', calls)
        self.assertEqual(record['request']['usage']['total_tokens'], 30)

    def test_unpublished_writing_artifact_is_not_overwritten_or_completed(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = pathlib.Path(temporary) / 'attempt.json'
            path.with_name('attempt.json.writing').write_text('{', encoding='utf-8')
            with self.assertRaises(FileExistsError):
                experiment.save_new(path, {'attempt': 2})
            self.assertIsNone(experiment.readable_record(path))

    def test_parent_reservation_is_single_use_and_task_bound(self):
        with tempfile.TemporaryDirectory() as temporary:
            out = pathlib.Path(temporary)
            prep, auth = out / 'prep.json', out / 'auth.json'
            prep.write_text('{}', encoding='utf-8')
            auth.write_text('{}', encoding='utf-8')
            task = {'scenario': 'fixture', 'seed': 1}
            cell, reservation = out / 'cell', out / 'launch_01.json'
            experiment.save_new(reservation, {'task': task, 'parent_pid': 123,
                'preparation_sha256': experiment.sha(prep), 'authorization_sha256': experiment.sha(auth),
                'cell_root': str(cell.resolve())})
            with patch.object(experiment.os, 'getppid', return_value=123):
                experiment.validate_worker_reservation(task, cell, {'tasks': [task]}, prep, out, auth, reservation)
                with self.assertRaises(FileExistsError):
                    experiment.validate_worker_reservation(task, cell, {'tasks': [task]}, prep, out, auth, reservation)

    def test_manual_shell_parent_cannot_borrow_worker_reservation(self):
        with tempfile.TemporaryDirectory() as temporary:
            out = pathlib.Path(temporary)
            task = {'scenario': 'fixture', 'seed': 1}
            reservation = out / 'launch_01.json'
            experiment.save_new(reservation, {'task': task, 'parent_pid': 123})
            with patch.object(experiment.os, 'getppid', return_value=999):
                with self.assertRaises(experiment.StopExperiment):
                    experiment.validate_worker_reservation(task, out / 'cell', {'tasks': [task]},
                                                           out / 'prep', out, out / 'auth', reservation)

    def test_http_error_preserves_partial_usage_once_without_retry(self):
        clock = Clock()
        body = json.dumps({'usage': {'total_tokens': 7}, 'error': {'code': 'fixture'}}).encode()
        calls, events, callbacks = self.callbacks(clock, error=experiment.HttpFailure(429, body))
        record = {}
        with self.assertRaises(experiment.HttpFailure):
            experiment.execute_cell(record, experiment.profile_checked(), **callbacks)
        self.assertEqual(calls.count('http'), 1)
        self.assertEqual(record['request']['http_status'], 429)
        self.assertEqual(record['request']['usage_status'], 'partial')
        self.assertIsNone(record['request']['usage']['prompt_tokens'])
        self.assertEqual(record['request']['usage']['total_tokens'], 7)
        self.assertEqual([name for name, _ in events], ['request_before', 'response_raw', 'request_after'])


if __name__ == '__main__':
    unittest.main()
