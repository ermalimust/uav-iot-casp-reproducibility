#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/network-module.h"
#include "ns3/wifi-module.h"

#include <algorithm>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("UavIotMiniReplay");

static std::string
MbpsString(double value)
{
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3) << value << "Mbps";
    return oss.str();
}

struct Sample
{
    double time;
    uint64_t rxBytes;
};

static bool
TrafficActive(double t, double simStop, double burstStart, double burstStop)
{
    return (t >= 1.0 && t < simStop) || (t >= burstStart && t < burstStop);
}

static void
SetUavPosition(Ptr<MobilityModel> mobility, double x, double y)
{
    mobility->SetPosition(Vector(x, y, 0.0));
}

static void
SampleSink(Ptr<PacketSink> sink,
           std::vector<Sample>* samples,
           double now,
           double simStop,
           double slot)
{
    samples->push_back({now, sink->GetTotalRx()});
    if (now + slot <= simStop + 1e-9)
    {
        Simulator::Schedule(Seconds(slot), &SampleSink, sink, samples, now + slot, simStop, slot);
    }
}

static void
ScheduleReplayRoute(const std::string& method, Ptr<MobilityModel> uavMobility)
{
    const double nearX = 100.0;
    const double targetX = 120.0;
    const double farX = 245.0;
    const double y = 0.0;

    bool targetReturn = (method == "route_only" || method == "route_protocol" || method == "casp");
    if (targetReturn)
    {
        // Route-repair skeleton: a pre-admitted fallback returns to the
        // disturbed target region during the burst/degradation window.
        Simulator::Schedule(Seconds(0.0), &SetUavPosition, uavMobility, nearX, y);
        Simulator::Schedule(Seconds(6.0), &SetUavPosition, uavMobility, farX, y);
        Simulator::Schedule(Seconds(10.0), &SetUavPosition, uavMobility, nearX, y);
        Simulator::Schedule(Seconds(21.0), &SetUavPosition, uavMobility, farX, y);
        Simulator::Schedule(Seconds(23.0), &SetUavPosition, uavMobility, nearX, y);
        Simulator::Schedule(Seconds(26.0), &SetUavPosition, uavMobility, farX, y);
        return;
    }

    // Static replay: the nominal route visits the target before and after the
    // burst, but not while the target is stressed.
    Simulator::Schedule(Seconds(0.0), &SetUavPosition, uavMobility, nearX, y);
    Simulator::Schedule(Seconds(6.0), &SetUavPosition, uavMobility, farX, y);
    Simulator::Schedule(Seconds(21.0), &SetUavPosition, uavMobility, nearX, y);
    Simulator::Schedule(Seconds(25.0), &SetUavPosition, uavMobility, farX, y);
}

int
main(int argc, char* argv[])
{
    std::string method = "static";
    uint32_t run = 1;
    double simStop = 30.0;
    double burstStart = 10.0;
    double burstStop = 20.0;
    double slot = 1.0;
    double baseMbps = 0.05;
    double burstMbps = 0.75;
    uint32_t packetSize = 256;

    CommandLine cmd(__FILE__);
    cmd.AddValue("method", "static, route_only, protocol_only, route_protocol, or casp", method);
    cmd.AddValue("run", "ns-3 RNG run number", run);
    cmd.AddValue("simStop", "simulation stop time in seconds", simStop);
    cmd.AddValue("burstStart", "burst/degradation start time", burstStart);
    cmd.AddValue("burstStop", "burst/degradation stop time", burstStop);
    cmd.AddValue("baseMbps", "base target-device offered load", baseMbps);
    cmd.AddValue("burstMbps", "additional burst offered load", burstMbps);
    cmd.AddValue("packetSize", "UDP payload size in bytes", packetSize);
    cmd.Parse(argc, argv);

    RngSeedManager::SetSeed(20260621);
    RngSeedManager::SetRun(run);

    NodeContainer nodes;
    nodes.Create(2); // node 0: UAV receiver; node 1: target IoT device

    bool robustProfile = (method == "protocol_only" || method == "route_protocol");
    std::string dataMode = robustProfile ? "DsssRate1Mbps" : "ErpOfdmRate54Mbps";
    std::string controlMode = robustProfile ? "DsssRate1Mbps" : "ErpOfdmRate6Mbps";
    double txPowerDbm = robustProfile ? 22.0 : 17.0;
    double pathLossExponent = robustProfile ? 2.45 : 2.65;
    double referenceLossDb = robustProfile ? 44.0 : 44.5;
    std::string profile = robustProfile ? "long_range_robust" : "short_high_rate";

    WifiHelper wifi;
    wifi.SetStandard(robustProfile ? WIFI_STANDARD_80211b : WIFI_STANDARD_80211g);
    wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                 "DataMode",
                                 StringValue(dataMode),
                                 "ControlMode",
                                 StringValue(controlMode));
    Config::SetDefault("ns3::WifiRemoteStationManager::NonUnicastMode",
                       StringValue(controlMode));

    YansWifiChannelHelper channel;
    channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    channel.AddPropagationLoss("ns3::LogDistancePropagationLossModel",
                               "Exponent",
                               DoubleValue(pathLossExponent),
                               "ReferenceDistance",
                               DoubleValue(1.0),
                               "ReferenceLoss",
                               DoubleValue(referenceLossDb));

    YansWifiPhyHelper phy;
    phy.SetChannel(channel.Create());
    phy.Set("TxPowerStart", DoubleValue(txPowerDbm));
    phy.Set("TxPowerEnd", DoubleValue(txPowerDbm));

    WifiMacHelper mac;
    mac.SetType("ns3::AdhocWifiMac");
    NetDeviceContainer devices = wifi.Install(phy, mac, nodes);

    MobilityHelper mobility;
    Ptr<ListPositionAllocator> positions = CreateObject<ListPositionAllocator>();
    positions->Add(Vector(100.0, 0.0, 0.0));   // UAV starts within service range
    positions->Add(Vector(120.0, 0.0, 0.0));   // target device
    mobility.SetPositionAllocator(positions);
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(nodes);

    Ptr<MobilityModel> uavMobility = nodes.Get(0)->GetObject<MobilityModel>();
    ScheduleReplayRoute(method, uavMobility);

    InternetStackHelper internet;
    internet.Install(nodes);
    Ipv4AddressHelper ipv4;
    ipv4.SetBase("10.20.0.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = ipv4.Assign(devices);

    uint16_t port = 9100;
    PacketSinkHelper sinkHelper("ns3::UdpSocketFactory",
                                InetSocketAddress(Ipv4Address::GetAny(), port));
    ApplicationContainer sinkApps = sinkHelper.Install(nodes.Get(0));
    sinkApps.Start(Seconds(0.0));
    sinkApps.Stop(Seconds(simStop + 1.0));

    OnOffHelper baseSource("ns3::UdpSocketFactory",
                           InetSocketAddress(interfaces.GetAddress(0), port));
    baseSource.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1]"));
    baseSource.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
    baseSource.SetAttribute("PacketSize", UintegerValue(packetSize));
    baseSource.SetAttribute("DataRate", DataRateValue(DataRate(MbpsString(baseMbps))));
    ApplicationContainer baseApps = baseSource.Install(nodes.Get(1));
    baseApps.Start(Seconds(1.0));
    baseApps.Stop(Seconds(simStop));

    OnOffHelper burstSource("ns3::UdpSocketFactory",
                            InetSocketAddress(interfaces.GetAddress(0), port));
    burstSource.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1]"));
    burstSource.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
    burstSource.SetAttribute("PacketSize", UintegerValue(packetSize));
    burstSource.SetAttribute("DataRate", DataRateValue(DataRate(MbpsString(burstMbps))));
    ApplicationContainer burstApps = burstSource.Install(nodes.Get(1));
    burstApps.Start(Seconds(burstStart));
    burstApps.Stop(Seconds(burstStop));

    std::vector<Sample> samples;
    Ptr<PacketSink> sink = DynamicCast<PacketSink>(sinkApps.Get(0));
    Simulator::Schedule(Seconds(0.0), &SampleSink, sink, &samples, 0.0, simStop, slot);

    Simulator::Stop(Seconds(simStop + 1.0));
    Simulator::Run();

    uint64_t rxBytes = sink->GetTotalRx();
    double expectedBits = baseMbps * 1000000.0 * (simStop - 1.0)
                          + burstMbps * 1000000.0 * (burstStop - burstStart);
    double expectedBytes = expectedBits / 8.0;
    double pdr = expectedBytes > 0.0 ? std::min(1.0, static_cast<double>(rxBytes) / expectedBytes) : 0.0;

    uint32_t currentBlackout = 0;
    uint32_t maxBlackout = 0;
    uint64_t prev = samples.empty() ? 0 : samples.front().rxBytes;
    for (size_t i = 1; i < samples.size(); ++i)
    {
        double t0 = samples[i - 1].time;
        double t1 = samples[i].time;
        bool active = TrafficActive(t0, simStop, burstStart, burstStop);
        bool delivered = samples[i].rxBytes > prev;
        if (active && !delivered)
        {
            currentBlackout += static_cast<uint32_t>(std::round(t1 - t0));
            maxBlackout = std::max(maxBlackout, currentBlackout);
        }
        else if (delivered)
        {
            currentBlackout = 0;
        }
        prev = samples[i].rxBytes;
    }

    bool pass = (pdr >= 0.55 && maxBlackout <= 5);
    double rxMbps = (static_cast<double>(rxBytes) * 8.0) / ((simStop - 1.0) * 1000000.0);

    std::cout << "NS3_REPLAY," << method << "," << profile << "," << run << "," << std::fixed
              << std::setprecision(3) << simStop << "," << burstStart << ","
              << burstStop << "," << baseMbps << "," << burstMbps << ","
              << std::setprecision(6) << rxMbps << "," << pdr << "," << rxBytes
              << "," << static_cast<uint64_t>(expectedBytes) << "," << maxBlackout
              << "," << dataMode << "," << txPowerDbm << "," << pathLossExponent
              << "," << referenceLossDb << "," << (pass ? 1 : 0) << std::endl;

    Simulator::Destroy();
    return 0;
}
